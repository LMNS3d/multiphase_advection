### created by Zhang
### HKUST FU's Lab
### 2024.11.06
import math
import random
from shapely.geometry import Point
from shapely.geometry.polygon import Polygon


# point = Point(0.5, 0.5)
# polygon = Polygon([(0, 0), (0, 1), (1, 1), (1, 0)])
# print(polygon.contains(point))

from src.functions.functions import *
import numpy as np

####################################################### DDA #######################################################
### judge if a point lies inside or on the convex polygon, by laser method
### odd intersections and even intersections to judge if ...
def point_in_polygon(point, polygon):
    ### FIRST JUDGE THE MAXIMUM BOX
    polygon = np.array(polygon)
    if np.max(polygon[:,0]) < point[0] or np.max(polygon[:,1]) < point[1] or point[0] < np.min(polygon[:,0]) or point[1] < np.min(polygon[:,1]):
        return False
    elif point_on_polygon_edge(point, polygon):
        # print('point on edge')
        return True
    else:
        point = np.array(point)
        # print(point)
        # Calculate the boundary vector of the polygon
        vote_for_True = 0
        vote_for_False = 0
        edges = []
        for i in range(len(polygon)):
            p1 = polygon[i]
            p2 = polygon[(i + 1) % len(polygon)]
            edges.append(np.array([p1, p2]))
        edges = np.array(edges)
        # print(edges)
        # Count the number of intersections between a horizontal right-ray and a polygon
        count = 0
        for edge in edges:
            if ray_insec_edg_r(point, edge):
                count += 1
            else:
                pass
        # Determine whether a point is inside or on the border of a polygon
        if count % 2 == 1:
            vote_for_True += 1
        else:
            vote_for_False += 1
        # print(vote_for_True, vote_for_False)
        # Count the number of intersections between a horizontal left-ray and a polygon
        count = 0
        for edge in edges:
            if ray_insec_edg_l(point, edge):
                count += 1
            else:
                pass
        if count % 2 == 1:
            vote_for_True += 1
        else:
            vote_for_False += 1
        # print(vote_for_True, vote_for_False)
        # Count the number of intersections between a vertical up-ray and a polygon
        count = 0
        for edge in edges:
            if ray_insec_edg_u(point, edge):
                count += 1
            else:
                pass
        if count % 2 == 1:
            vote_for_True += 1
        else:
            vote_for_False += 1
        # print(vote_for_True, vote_for_False)
        # Count the number of intersections between a vertical down-ray and a polygon
        count = 0
        for edge in edges:
            if ray_insec_edg_d(point, edge):
                count += 1
            else:
                pass
        if count % 2 == 1:
            vote_for_True += 1
        else:
            vote_for_False += 1
        # print(vote_for_True, vote_for_False)
        ### final voting decision
        if vote_for_True >= vote_for_False:
            return True
        else:
            return False

### THIS FUNCTION IS USED TO TEST IF A POINT LIES ON THE BOUNDARY OF A GIVEN POLYGON
def point_on_polygon_edge(point, polygon):
    edges = []
    for i in range(len(polygon)):
        p1 = polygon[i]
        p2 = polygon[(i + 1) % len(polygon)]
        edges.append(np.array([p1, p2]))
    edges = np.array(edges)
    for i in range(len(edges)):
        if judge_on_line(point, edges[i, 0], edges[i, 1]):
            return True
    return False

### THIS FUNCTION RETURNS INTERSECTION CONDITION OF A HORIZONTAL RIGHT-RAY AND AN EDGE
def ray_insec_edg_r(point, edge):
    ### AVOID HORIZONTAL EDGE
    if edge[0, 1] != edge[1, 1]:
        ### MAKE SURE THE FIRST POINT IS BELOW SECOND POINT
        if edge[0, 1] < edge[1, 1]:
            pass
        else:
            edge_copy = edge.copy()
            edge_copy[0] = edge[1]
            edge_copy[1] = edge[0]
            edge = edge_copy
    else:
        if min(edge[0, 0], edge[1, 0]) <= point[0] <= max(edge[0, 0], edge[1, 0]) and point[1] == edge[0, 1]:
            return True
        else:
            return False
    # ### AVOID RAY ON THE VERTEX
    # if point[1] == edge[0, 1] or point[1] == edge[1, 1]:
    #     point[1] += 1e-8
    # else:
    #     pass
    ### JUDGE IF OUT OF RANGE
    if point[1] < edge[0, 1] or point[1] > edge[1, 1]:
        return False
    elif point[0] > max(edge[0, 0], edge[1, 0]):
        return False
    else:
        if point[0] <= min(edge[0, 0], edge[1, 0]):
            return True
        else:
            if edge[0, 0] != edge[1, 0]:
                k_edge = (edge[1, 1] - edge[0, 1]) / (edge[1, 0] - edge[0, 0])
            else:
                k_edge = float('inf')
            if point[0] != edge[0, 0]:
                k_p_edge = (point[1] - edge[0, 1]) / (point[0] - edge[0, 0])
            else:
                k_p_edge = float('inf')
            if k_p_edge >= k_edge:
                return True
            else:
                return False

### THIS FUNCTION RETURNS INTERSECTION CONDITION OF A HORIZONTAL LEFT-RAY AND AN EDGE
def ray_insec_edg_l(point, edge):
    ### AVOID HORIZONTAL EDGE
    if edge[0, 1] != edge[1, 1]:
        ### MAKE SURE THE FIRST POINT IS BELOW SECOND POINT
        if edge[0, 1] < edge[1, 1]:
            pass
        else:
            edge_copy = edge.copy()
            edge_copy[0] = edge[1]
            edge_copy[1] = edge[0]
            edge = edge_copy
    else:
        if min(edge[0, 0], edge[1, 0]) <= point[0] <= max(edge[0, 0], edge[1, 0]) and point[1] == edge[0, 1]:
            return True
        else:
            return False
    # ### AVOID RAY ON THE VERTEX
    # if point[1] == edge[0, 1] or point[1] == edge[1, 1]:
    #     point[1] += 1e-8
    # else:
    #     pass
    ### JUDGE IF OUT OF RANGE
    if point[1] < edge[0, 1] or point[1] > edge[1, 1]:
        return False
    elif point[0] < min(edge[0, 0], edge[1, 0]):
        return False
    else:
        if point[0] >= max(edge[0, 0], edge[1, 0]):
            return True
        else:
            if edge[0, 0] != edge[1, 0]:
                k_edge = (edge[1, 1] - edge[0, 1]) / (edge[1, 0] - edge[0, 0])
            else:
                k_edge = float('inf')
            if point[0] != edge[0, 0]:
                k_p_edge = (point[1] - edge[0, 1]) / (point[0] - edge[0, 0])
            else:
                k_p_edge = float('inf')
            if k_p_edge <= k_edge:
                return True
            else:
                return False

### THIS FUNCTION RETURNS INTERSECTION CONDITION OF A HORIZONTAL UP-RAY AND AN EDGE
def ray_insec_edg_u(point, edge):
    ### AVOID VERTICLE EDGE
    if edge[0, 0] != edge[1, 0]:
        # print('edge[0, 0] != edge[1, 0]')
        ### MAKE SURE THE FIRST POINT IS TO THE LEFT
        if edge[0, 0] < edge[1, 0]:
            pass
        else:
            edge_copy = edge.copy()
            edge_copy[0] = edge[1]
            edge_copy[1] = edge[0]
            edge = edge_copy
    else:
        # print('edge[0, 0] = edge[1, 0]')
        if min(edge[0, 1], edge[1, 1]) <= point[1] <= max(edge[0, 1], edge[1, 1]) and point[0] == edge[0, 0]:
            # print('min(edge[0, 1], edge[1, 1]) <= point[1] <= max(edge[0, 1], edge[1, 1]) and point[0] == edge[0, 0]')
            return True
        else:
            return False
    # print(edge)
    # ### AVOID RAY ON THE VERTEX
    # if point[0] == edge[0, 0] or point[0] == edge[1, 0]:
    #     point[0] += 1e-8
    # else:
    #     pass
    ### JUDGE IF OUT OF RANGE
    if point[0] < edge[0, 0] or point[0] > edge[1, 0]:
        return False
    elif point[1] > max(edge[0, 1], edge[1, 1]):
        return False
    else:
        if point[1] <= min(edge[0, 1], edge[1, 1]):
            # print('point[1] <= min(edge[0, 1], edge[1, 1])')
            return True
        else:
            if edge[0, 0] != edge[1, 0]:
                k_edge = (edge[1, 1] - edge[0, 1]) / (edge[1, 0] - edge[0, 0])
            else:
                if edge[0, 1] > edge[1, 1]:
                    k_edge = -float('inf')
                else:
                    k_edge = float('inf')
            if point[0] != edge[0, 0]:
                k_p_edge = (point[1] - edge[0, 1]) / (point[0] - edge[0, 0])
            else:
                if edge[0, 1] > point[1]:
                    k_p_edge = -float('inf')
                else:
                    k_p_edge = float('inf')
            if k_p_edge <= k_edge:
                # print('k_p_edge <= k_edge')
                return True
            else:
                return False

### THIS FUNCTION RETURNS INTERSECTION CONDITION OF A HORIZONTAL DOWN-RAY AND AN EDGE
def ray_insec_edg_d(point, edge):
    ### AVOID VERTICLE EDGE
    if edge[0, 0] != edge[1, 0]:
        ### MAKE SURE THE FIRST POINT IS TO THE LEFT
        if edge[0, 0] < edge[1, 0]:
            pass
        else:
            edge_copy = edge.copy()
            edge_copy[0] = edge[1]
            edge_copy[1] = edge[0]
            edge = edge_copy
    else:
        if min(edge[0, 1], edge[1, 1]) <= point[1] <= max(edge[0, 1], edge[1, 1]) and point[0] == edge[0, 0]:
            return True
        else:
            return False
    # ### AVOID RAY ON THE VERTEX
    # if point[0] == edge[0, 0] or point[0] == edge[1, 0]:
    #     point[0] += 1e-8
    # else:
    #     pass
    ### JUDGE IF OUT OF RANGE
    if point[0] < edge[0, 0] or point[0] > edge[1, 0]:
        return False
    elif point[1] < min(edge[0, 1], edge[1, 1]):
        return False
    else:
        if point[1] >= max(edge[0, 1], edge[1, 1]):
            return True
        else:
            if edge[0, 0] != edge[1, 0]:
                k_edge = (edge[1, 1] - edge[0, 1]) / (edge[1, 0] - edge[0, 0])
            else:
                if edge[0, 1] > edge[1, 1]:
                    k_edge = -float('inf')
                else:
                    k_edge = float('inf')
            if point[0] != edge[0, 0]:
                k_p_edge = (point[1] - edge[0, 1]) / (point[0] - edge[0, 0])
            else:
                if edge[0, 1] > point[1]:
                    k_p_edge = -float('inf')
                else:
                    k_p_edge = float('inf')
            if k_p_edge >= k_edge:
                return True
            else:
                return False

def graham_scan(points):
    # Calculate the cross product
    def cross_product(p1, p2, p3):
        return np.cross((p2 - p1), (p3 - p1))

    # Find the bottom point
    def find_lowest_point(points):
        lowest_point = points[0]
        for point in points:
            if point[1] < lowest_point[1]:
                lowest_point = point
            elif point[1] == lowest_point[1] and point[0] < lowest_point[0]:
                    lowest_point = point
            else:
                pass
        return lowest_point

    # Calculate polar angle
    def polar_angle(p1, p2):
        # print(p1, p2)
        # print(math.atan2(p2[1] - p1[1], p2[0] - p1[0]))
        return math.atan2(p2[1] - p1[1], p2[0] - p1[0])

    # print(points)
    # Find the bottom point
    lowest_point = find_lowest_point(points)
    # print(lowest_point)
    # Sort by polar angle and x
    sorted_points = sorted(points, key=lambda p: (polar_angle(lowest_point, p), p[0], p[1]))
    # Initialize the stack
    # print(sorted_points)
    stack = [sorted_points[0], sorted_points[1]]
    # Traverse the remaining points
    for point in sorted_points[2:]:
        while len(stack) > 1 and cross_product(stack[-2], stack[-1], point) <= 0:
            stack.pop()
        stack.append(point)

    return np.array(stack)

### This function is to calculate the overlapping area of two convex polygons
### Using a marching calculation algorithm
### input
### polygon1(reference polygon), polygon2
### output
### clipped polygon
def clip_polygon(polygon1, polygon2):
    vertices = []
    for v in range(len(polygon1)):
        if point_in_polygon_shapely(polygon1[v], polygon2):
            vertices.append(polygon1[v])
        else:
            pass
    # print('do_region point in cell: ', vertices)
    for v2 in range(len(polygon2)):
        if point_in_polygon_shapely(polygon2[v2], polygon1):
            ### judge if repeat element
            repeat = False
            for vi in range(len(vertices)):
                if (polygon2[v2][0] - vertices[vi][0]) ** 2 + (polygon2[v2][1] - vertices[vi][1]) ** 2 == 0.:
                    repeat = True
                    break
            if repeat == False:
                vertices.append(polygon2[v2])
            else:
                pass
    # print('cell point in do_region: ', vertices)
    for i in range(len(polygon1)):
        p1 = polygon1[i % len(polygon1)]
        p2 = polygon1[(i + 1) % len(polygon1)]
        n, d = reform_edge_descri(p1, p2, polygon1)
        intersects = plic_get_intersects(polygon2, n, d)
        for j in range(len(intersects)):
            if not np.isnan(intersects[j]).all() and judge_on_line(intersects[j], p1, p2):
                ### judge if repeat element
                repeat = False
                for vi in range(len(vertices)):
                    if (intersects[j][0] - vertices[vi][0]) ** 2 + (intersects[j][1] - vertices[vi][1]) ** 2 == 0.:
                        repeat = True
                        break
                if repeat == False:
                    vertices.append(intersects[j])
                else:
                    pass
    # print(vertices)
    ### after find all vertices components of the overlapping cell, we construct it with concave order
    if len(vertices) > 2:
        overlap_polygon = graham_scan(vertices)
    else:
        overlap_polygon = np.array(vertices)
    return overlap_polygon

### This function judge if the point is on the line segment, constructed by p1 and p2:
def judge_on_line(point, p1, p2):
    def distance(p1, p2):
        return ((p1[0]-p2[0])**2 + (p1[1]-p2[1])**2)**0.5
    # Determine whether the point is on the line segment
    d1 = distance(point, p1)
    d2 = distance(point, p2)
    d3 = distance(p1, p2)
    return abs(d1 + d2 - d3) < 1e-8

### This function is to calculate the normal and distance for an edge of a polygon
### The normal points outward the polygon
def reform_edge_descri(p1, p2, polygon):
    ###the vector along the line from p1 to p2
    l = p2 - p1
    ###the vector perpendicular to l
    n = np.array([l[1], -l[0]])
    ###normalize to unit vector
    n = n / np.sqrt(n[0] ** 2 + n[1] ** 2)
    ###redirect the normal vector such that the vertice is included in region n * x - d <= 0
    ###which means the normal vector points outwards
    d = n.dot(p1)
    for i in range(len(polygon)):
        vert = polygon[i]
        if n.dot(vert) - d > 0:
            n = -n
            break
    return n, d

def get_flux_donating_exc(U, PLIC_recons, dx, dy, dt, ghost, start_x, end_x, start_y, end_y, flux_stencil):
    ghost -= flux_stencil
    ### extend one cell length to store the donating flux of the broaders
    sub_flux = np.zeros([4, 3, end_x - start_x + 2 * flux_stencil, end_y - start_y + 2 * flux_stencil])
    for i in range(end_x - start_x):
        for j in range(end_y - start_y):
            # print(i + ghost + start_x, j + ghost + start_y)
            ### central scheme
            u_left  = 0.5 * (U[0, i + ghost + start_x, j + ghost + start_y] +
                             U[0, i + ghost + start_x - 1, j + ghost + start_y])
            u_right = 0.5 * (U[0, i + ghost + start_x, j + ghost + start_y] +
                             U[0, i + ghost + start_x + 1, j + ghost + start_y])
            v_bot   = 0.5 * (U[1, i + ghost + start_x, j + ghost + start_y] +
                             U[1, i + ghost + start_x, j + ghost + start_y - 1])
            v_top   = 0.5 * (U[1, i + ghost + start_x, j + ghost + start_y] +
                             U[1, i + ghost + start_x, j + ghost + start_y + 1])
            velocity_list = np.array([u_left, u_right, v_bot, v_top], dtype='float64')
            for u in range(len(velocity_list)):
                if abs(velocity_list[u]) < 1e-8:
                    velocity_list[u] = 0
            # print(velocity_list)
            ### identification of the donating region
            ### right face is donating region
            # if velocity_list[1] > 0:
            #     cal_donating_flux_right(sub_flux, flux_stencil, PLIC_recons, dx, dy, dt, ghost, start_x, start_y, velocity_list, i, j)
            # ### left face is donating region
            # if velocity_list[0] < 0:
            #     cal_donating_flux_left(sub_flux, flux_stencil, PLIC_recons, dx, dy, dt, ghost, start_x, start_y, velocity_list, i, j)
            # ### top face is donating region
            # if velocity_list[3] > 0:
            #     cal_donating_flux_top(sub_flux, flux_stencil, PLIC_recons, dx, dy, dt, ghost, start_x, start_y, velocity_list, i, j)
            # ### bottom face is donating region
            # if velocity_list[2] < 0:
            #     cal_donating_flux_bot(sub_flux, flux_stencil, PLIC_recons, dx, dy, dt, ghost, start_x, start_y, velocity_list, i, j)

            if velocity_list[1] > 0:
                cal_donating_flux_right_shapely(sub_flux, flux_stencil, PLIC_recons, dx, dy, dt, ghost, start_x, start_y, velocity_list, i, j)
            ### left face is donating region
            if velocity_list[0] < 0:
                cal_donating_flux_left_shapely(sub_flux, flux_stencil, PLIC_recons, dx, dy, dt, ghost, start_x, start_y, velocity_list, i, j)
            ### top face is donating region
            if velocity_list[3] > 0:
                cal_donating_flux_top_shapely(sub_flux, flux_stencil, PLIC_recons, dx, dy, dt, ghost, start_x, start_y, velocity_list, i, j)
            ### bottom face is donating region
            if velocity_list[2] < 0:
                cal_donating_flux_bot_shapely(sub_flux, flux_stencil, PLIC_recons, dx, dy, dt, ghost, start_x, start_y, velocity_list, i, j)

    # for i in range(end_x - start_x):
    #     for j in range(end_y - start_y):
    #         if (i + ghost + start_x == 15 or i + ghost + start_x == 14) and j + ghost + start_y == 27:
    #             print(i + ghost + start_x, j + ghost + start_y)
    #             u_left = 0.5 * (U[0, i + ghost + start_x, j + ghost + start_y] +
    #                             U[0, i + ghost + start_x - 1, j + ghost + start_y])
    #             u_right = 0.5 * (U[0, i + ghost + start_x, j + ghost + start_y] +
    #                              U[0, i + ghost + start_x + 1, j + ghost + start_y])
    #             v_bot = 0.5 * (U[1, i + ghost + start_x, j + ghost + start_y] +
    #                            U[1, i + ghost + start_x, j + ghost + start_y - 1])
    #             v_top = 0.5 * (U[1, i + ghost + start_x, j + ghost + start_y] +
    #                            U[1, i + ghost + start_x, j + ghost + start_y + 1])
    #             velocity_list = [u_left, u_right, v_bot, v_top]
    #             print(velocity_list)
    #             print(sub_flux[:, :, i + flux_stencil, j + flux_stencil])
    return sub_flux
            
### vel = [u_left, u_right, v_bot, v_top]
def cal_donating_flux_right(sub_flux, flux_stencil, PLIC_recons, dx, dy, dt, ghost, start_x, start_y, vel, i, j):
    ### first identify the gradient of the two sides
    k_tr = max(0., vel[3] / (vel[1] + 1e-8))
    k_lr = min(0., vel[2] / (vel[1] + 1e-8))
    V = dx * dy
    ### solve a quadratic polynomial to satisfy the flux constraint, u_R*dy*dt = Area
    ### a < 0 always
    a = 0.5 * (k_lr - k_tr)
    if a != 0:
        ### b > 0 always
        b = dy
        ### c < 0 always
        c = -vel[1] * dy * dt
        delta = b ** 2 - 4 * a * c
        ### 0 < dx1 < dx2 always, since -4ac < 0 always
        dx1 = (-b + np.sqrt(delta)) / (2 * a)
        # dx2 = (-b - np.sqrt(delta)) / (2 * a)
        ### choose the relative smaller result, because delta_x has an upper bound delta_x < 2 u_R * dt
        delta_x = dx1
        ### construct the donating region as a polygon
        if delta_x * (k_tr - k_lr) < dy:
            do_region = np.array([[dx, 0.],
                                  [dx, dy],
                                  [dx - delta_x, dy - k_tr * delta_x],
                                  [dx - delta_x, 0. - k_lr * delta_x]])
        else:
            do_region = np.array([[dx, 0.],
                                  [dx, dy],
                                  [dx - delta_x, 0. - k_lr * delta_x]])
    else:
        delta_x = vel[1] * dt
        do_region = np.array([[dx, 0.],
                              [dx, dy],
                              [dx - delta_x, dy],
                              [dx - delta_x, 0.]])
    cells = PLIC_recons[i + start_x + ghost][j + start_y + ghost][1]['cells']
    for ind in range(len(cells)):
        cell_info = cells[ind]
        phase_ind = cell_info[0]
        cell = cell_info[1]
        if get_cell_volume_new(do_region) > 0:
            do_polygon = clip_polygon(do_region, cell)
        else:
            do_polygon = np.array([])
        if len(do_polygon) > 2 and len(cell) > 2:
            do_volume = get_cell_volume_new(do_polygon)
            sub_flux[1, phase_ind, i + flux_stencil, j + flux_stencil] -= do_volume / V
            sub_flux[0, phase_ind, i + flux_stencil + 1, j + flux_stencil] += do_volume / V
        else:
            pass

def cal_donating_flux_left(sub_flux, flux_stencil, PLIC_recons, dx, dy, dt, ghost, start_x, start_y, vel, i, j):
    ### first identify the gradient of the two sides
    k_tl = min(0., vel[3] / (vel[0] + 1e-8))
    k_ll = max(0., vel[2] / (vel[0] + 1e-8))
    V = dx * dy
    ### solve a quadratic polynomial to satisfy the flux constraint, u_R*dy*dt = Area
    ### a < 0 always
    a = 0.5 * (k_tl - k_ll)
    if a != 0:
        ### b > 0 always
        b = dy
        ### c < 0 always
        c = vel[0] * dy * dt
        delta = b ** 2 - 4 * a * c
        ### 0 < dx1 < dx2 always, since -4ac < 0 always
        dx1 = (-b + np.sqrt(delta)) / (2 * a)
        # dx2 = (-b - np.sqrt(delta)) / (2 * a)
        ### choose the relative smaller result, because delta_x has an upper bound delta_x < 2 u_R * dt
        delta_x = dx1
        ### construct the donating region as a polygon
        if delta_x * (k_ll - k_tl) < dy:
            do_region = np.array([[0., 0.],
                                  [delta_x, 0. + k_ll * delta_x],
                                  [delta_x, dy + k_tl * delta_x],
                                  [0., dy]])
        else:
            do_region = np.array([[0., 0.],
                                  [delta_x, 0. + k_ll * delta_x],
                                  [0., dy]])
    else:
        delta_x = -vel[0] * dt
        do_region = np.array([[0., 0.],
                              [delta_x, 0.],
                              [delta_x, dy],
                              [0., dy]])
    cells = PLIC_recons[i + start_x + ghost][j + start_y + ghost][1]['cells']

    # if i + start_x + ghost == 16 and j + start_y + ghost == 25:
    #     print(cells)
    #     print(do_region)

    for ind in range(len(cells)):
        cell_info = cells[ind]
        phase_ind = cell_info[0]
        cell = cell_info[1]
        if get_cell_volume_new(do_region) > 0:
            do_polygon = clip_polygon(do_region, cell)
        else:
            do_polygon = np.array([])
        if len(do_polygon) > 2 and len(cell) > 2:
            do_volume = get_cell_volume_new(do_polygon)
            sub_flux[0, phase_ind, i + flux_stencil, j + flux_stencil] -= do_volume / V
            sub_flux[1, phase_ind, i + flux_stencil - 1, j + flux_stencil] += do_volume / V
            # if i + start_x + ghost == 16 and j + start_y + ghost == 25:
            #     print(phase_ind)
            #     print(do_polygon)
        else:
            pass

def cal_donating_flux_top(sub_flux, flux_stencil, PLIC_recons, dx, dy, dt, ghost, start_x, start_y, vel, i, j):
    V = dx * dy
    ### first identify the gradient of the two sides
    if vel[0] < 0 and vel[1] > 0:
        ### first identify the gradient of the two sides
        k_tl = vel[3] / (vel[0] + 1e-8)
        k_tr = vel[3] / (vel[1] + 1e-8)
        ### solve a quadratic polynomial to satisfy the flux constraint, u_R*dy*dt = Area
        ### a < 0 always
        a = (k_tr - k_tl) / (2 * k_tr * k_tl)
        ### b > 0 always
        b = dx
        ### c < 0 always
        c = -vel[3] * dx * dt
        delta = b ** 2 - 4 * a * c
        ### 0 < dx1 < dx2 always, since -4ac < 0 always
        dy1 = (-b + np.sqrt(delta)) / (2 * a)
        # dy2 = (-b - np.sqrt(delta)) / (2 * a)
        ### choose the relative smaller result, because delta_x has an upper bound delta_x < 2 u_R * dt
        delta_y = dy1
        ### construct the donating region as a polygon
        if -delta_y * 2 * a < dx:
            do_region = np.array([[dx, dy],
                                  [0., dy],
                                  [-delta_y / k_tl, dy - delta_y],
                                  [dx - delta_y / k_tr, dy - delta_y]])
        elif -delta_y * 2 * a == dx:
            do_region = np.array([[dx, dy],
                                  [0., dy],
                                  [-delta_y / k_tl, dy - delta_y]])
        else:
            print('reduce the CFL!, top')
            print(i + start_x + ghost, j + start_y + ghost)
            print(vel)
            return False
    elif vel[0] >= 0 and vel[1] > 0:
        ### k_tr > 0
        k_tr = vel[3] / (vel[1] + 1e-8)
        ### a < 0 always
        a = -1 / (2 * k_tr)
        ### b > 0 always
        b = dx
        ### c < 0 always
        c = -vel[3] * dx * dt
        delta = b ** 2 - 4 * a * c
        ### 0 < dx1 < dx2 always, since -4ac < 0 always
        dy1 = (-b + np.sqrt(delta)) / (2 * a)
        # dy2 = (-b - np.sqrt(delta)) / (2 * a)
        ### choose the relative smaller result, because delta_x has an upper bound delta_x < 2 u_R * dt
        delta_y = dy1
        ### construct the donating region as a polygon
        if -delta_y * 2 * a < dx:
            do_region = np.array([[dx, dy],
                                  [0., dy],
                                  [0., dy - delta_y],
                                  [dx - delta_y / k_tr, dy - delta_y]])
        elif -delta_y * 2 * a == dx:
            do_region = np.array([[dx, dy],
                                  [0., dy],
                                  [0., 0.]])
        else:
            print('reduce the CFL!, top')
            print(i + start_x + ghost, j + start_y + ghost)
            print(vel)
            return False
    elif vel[1] <= 0 and vel[0] < 0:
        ### k_tl < 0
        k_tl = vel[3] / (vel[0] + 1e-8)
        ### a < 0 always
        a = 1 / (2 * k_tl)
        ### b > 0 always
        b = dx
        ### c < 0 always
        c = -vel[3] * dx * dt
        delta = b ** 2 - 4 * a * c
        ### 0 < dx1 < dx2 always, since -4ac < 0 always
        dy1 = (-b + np.sqrt(delta)) / (2 * a)
        # dy2 = (-b - np.sqrt(delta)) / (2 * a)
        ### choose the relative smaller result, because delta_x has an upper bound delta_x < 2 u_R * dt
        delta_y = dy1
        ### construct the donating region as a polygon
        if -delta_y * 2 * a < dx:
            do_region = np.array([[dx, dy],
                                  [0., dy],
                                  [-delta_y / k_tl, dy - delta_y],
                                  [dx, dy - delta_y]])
        elif -delta_y * 2 * a == dx:
            do_region = np.array([[dx, dy],
                                  [0., dy],
                                  [dx, 0.]])
        else:
            print('reduce the CFL!, top')
            print(i + start_x + ghost, j + start_y + ghost)
            print(vel)
            return False
    else:
        # print('else')
        delta_y = vel[3] * dt
        if delta_y <= dy:
            do_region = np.array([[dx, dy],
                                  [0., dy],
                                  [0., dy - delta_y],
                                  [dx, dy - delta_y]])
        else:
            print('reduce the CFL!, top')
            print(i + start_x + ghost, j + start_y + ghost)
            print(vel)
            return False
    cells = PLIC_recons[i + start_x + ghost][j + start_y + ghost][1]['cells']

    # if i + start_x + ghost == 24 and j + start_y + ghost in [26, 27, 28]:
    #     print(i + start_x + ghost, j + start_y + ghost)
    #     print(cells)
    #     print(do_region)

    for ind in range(len(cells)):
        cell_info = cells[ind]
        phase_ind = cell_info[0]
        cell = cell_info[1]
        if get_cell_volume_new(do_region) > 0:
            do_polygon = clip_polygon(do_region, cell)
        else:
            do_polygon = np.array([])
        # if i + start_x + ghost == 24 and j + start_y + ghost in [26, 27, 28]:
        #     print(i + start_x + ghost, j + start_y + ghost)
        #     print(phase_ind)
        #     print(do_polygon)
        if len(do_polygon) > 2 and len(cell) > 2:
            do_volume = get_cell_volume_new(do_polygon)
            sub_flux[3, phase_ind, i + flux_stencil, j + flux_stencil] -= do_volume / V
            sub_flux[2, phase_ind, i + flux_stencil, j + flux_stencil + 1] += do_volume / V
        else:
            pass

def cal_donating_flux_bot(sub_flux, flux_stencil, PLIC_recons, dx, dy, dt, ghost, start_x, start_y, vel, i, j):
    V = dx * dy
    if vel[0] < 0 and vel[1] > 0:
        ### first identify the gradient of the two sides
        ### k_ll > 0, k_lr < 0
        k_ll = vel[2] / (vel[0] + 1e-8)
        k_lr = vel[2] / (vel[1] + 1e-8)
        ### solve a quadratic polynomial to satisfy the flux constraint, u_R*dy*dt = Area
        ### a < 0 always
        a = (k_ll - k_lr) / (2 * k_ll * k_lr)
        ### b > 0 always
        b = dx
        ### c < 0 always
        c = vel[2] * dx * dt
        delta = b ** 2 - 4 * a * c
        ### 0 < dx1 < dx2 always, since -4ac < 0 always
        dy1 = (-b + np.sqrt(delta)) / (2 * a)
        # dy2 = (-b - np.sqrt(delta)) / (2 * a)
        ### choose the relative smaller result, because delta_x has an upper bound delta_x < 2 u_R * dt
        delta_y = dy1
        ### construct the donating region as a polygon
        if -delta_y * 2 * a < dx:
            do_region = np.array([[0., 0.],
                                  [dx, 0.],
                                  [dx + delta_y / k_lr, delta_y],
                                  [delta_y / k_ll, delta_y]])
        elif -delta_y * 2 * a == dx:
            do_region = np.array([[0., 0.],
                                  [dx, 0.],
                                  [delta_y / k_ll, delta_y]])
        else:
            print('reduce the CFL!, bot')
            print(i + start_x + ghost, j + start_y + ghost)
            print(vel)
            return False
    elif vel[0] >= 0 and vel[1] > 0:
        ### k_lr < 0
        k_lr = vel[2] / (vel[1] + 1e-8)
        ### a < 0 always
        a = 1 / (2 * k_lr)
        ### b > 0 always
        b = dx
        ### c < 0 always
        c = vel[2] * dx * dt
        delta = b ** 2 - 4 * a * c
        ### 0 < dx1 < dx2 always, since -4ac < 0 always
        dy1 = (-b + np.sqrt(delta)) / (2 * a)
        # dy2 = (-b - np.sqrt(delta)) / (2 * a)
        ### choose the relative smaller result, because delta_x has an upper bound delta_x < 2 u_R * dt
        delta_y = dy1
        ### construct the donating region as a polygon
        if -delta_y * 2 * a < dx:
            do_region = np.array([[0., 0.],
                                  [dx, 0.],
                                  [dx + delta_y / k_lr, delta_y],
                                  [0., delta_y]])
        elif -delta_y * 2 * a == dx:
            do_region = np.array([[0., 0.],
                                  [dx, 0.],
                                  [0., dy]])
        else:
            print('reduce the CFL!, bot')
            print(i + start_x + ghost, j + start_y + ghost)
            print(vel)
            return False
    elif vel[1] <= 0 and vel[0] < 0:
        ### k_ll > 0
        k_ll = vel[2] / (vel[0] + 1e-8)
        ### a < 0 always
        a = -1 / (2 * k_ll)
        ### b > 0 always
        b = dx
        ### c < 0 always
        c = vel[2] * dx * dt
        delta = b ** 2 - 4 * a * c
        ### 0 < dx1 < dx2 always, since -4ac < 0 always
        dy1 = (-b + np.sqrt(delta)) / (2 * a)
        # dy2 = (-b - np.sqrt(delta)) / (2 * a)
        ### choose the relative smaller result, because delta_x has an upper bound delta_x < 2 u_R * dt
        delta_y = dy1
        ### construct the donating region as a polygon
        if -delta_y * 2 * a < dx:
            do_region = np.array([[0., 0.],
                                  [dx, 0.],
                                  [dx, delta_y],
                                  [delta_y / k_ll, delta_y]])
        elif -delta_y * 2 * a == dx:
            do_region = np.array([[0., 0.],
                                  [dx, 0.],
                                  [dx, dy]])
        else:
            print('reduce the CFL!, bot')
            print(i + start_x + ghost, j + start_y + ghost)
            print(vel)
            return False
    else:
        # print('else')
        delta_y = -vel[2] * dt
        if delta_y <= dy:
            do_region = np.array([[0., 0.],
                                  [dx, 0.],
                                  [dx, delta_y],
                                  [0., delta_y]])
        else:
            print('reduce the CFL!, bot')
            print(i + start_x + ghost, j + start_y + ghost)
            print(vel)
            return False
    cells = PLIC_recons[i + start_x + ghost][j + start_y + ghost][1]['cells']

    # if i + start_x + ghost == 15 and j + start_y + ghost == 26:
    #     print(cells)
    #     print(do_region)

    for ind in range(len(cells)):
        cell_info = cells[ind]
        phase_ind = cell_info[0]
        cell = cell_info[1]
        if get_cell_volume_new(do_region) > 0:
            do_polygon = clip_polygon(do_region, cell)
        else:
            do_polygon = np.array([])
        if len(do_polygon) > 2 and len(cell) > 2:
            do_volume = get_cell_volume_new(do_polygon)
            sub_flux[2, phase_ind, i + flux_stencil, j + flux_stencil] -= do_volume / V
            sub_flux[3, phase_ind, i + flux_stencil, j + flux_stencil - 1] += do_volume / V
        else:
            pass

def assign_face_velocity(U, nx, ny, face_vel_stencil, u_stencil):
    ### U_face = [left, right, bottom, top]
    U_face = np.zeros([4, nx, ny])
    for i in range(nx - 2 * (face_vel_stencil + u_stencil)):
        for j in range(ny - 2 * (face_vel_stencil + u_stencil)):
            U_face[0, i + (face_vel_stencil + u_stencil), j + (face_vel_stencil + u_stencil)] \
                            = 0.5 * (U[0, i + face_vel_stencil + u_stencil - 1, j + face_vel_stencil + u_stencil] +
                                     U[0, i + face_vel_stencil + u_stencil, j + face_vel_stencil + u_stencil])
            U_face[1, i + (face_vel_stencil + u_stencil), j + (face_vel_stencil + u_stencil)] \
                            = 0.5 * (U[0, i + face_vel_stencil + u_stencil + 1, j + face_vel_stencil + u_stencil] +
                                     U[0, i + face_vel_stencil + u_stencil, j + face_vel_stencil + u_stencil])
            U_face[2, i + (face_vel_stencil + u_stencil), j + (face_vel_stencil + u_stencil)] \
                            = 0.5 * (U[1, i + face_vel_stencil + u_stencil, j + face_vel_stencil + u_stencil - 1] +
                                     U[1, i + face_vel_stencil + u_stencil, j + face_vel_stencil + u_stencil])
            U_face[3, i + (face_vel_stencil + u_stencil), j + (face_vel_stencil + u_stencil)] \
                            = 0.5 * (U[1, i + face_vel_stencil + u_stencil, j + face_vel_stencil + u_stencil + 1] +
                                     U[1, i + face_vel_stencil + u_stencil, j + face_vel_stencil + u_stencil])
    return U_face

################################################# UTILIZING CONSERVATION FIX ###########################################
##########!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! MODIFICATION IS NEEDED, REFERENCED TO ABOVE !!!!!!!!!!!!!!!!!!!!!!!!!!!
def get_flux_donating_CONSFIX_exc(U, PLIC_recons, dx, dy, dt, ghost, start_x, end_x, start_y, end_y, flux_stencil, conservation_r, cfl):
    ### extend one cell length to store the donating flux of the broaders
    sub_flux = np.zeros([4, 3, end_x - start_x + 2 * flux_stencil, end_y - start_y + 2 * flux_stencil])
    conservation_fix_r = (1. + conservation_filter(conservation_r, 1e-4) / cfl) ** -1
    for i in range(end_x - start_x):
        for j in range(end_y - start_y):
            # print(i + ghost + start_x, j + ghost + start_y)
            ### central scheme
            u_left = 0.5 * (U[0, i + ghost + start_x, j + ghost + start_y] +
                            U[0, i + ghost + start_x - 1, j + ghost + start_y])
            u_right = 0.5 * (U[0, i + ghost + start_x, j + ghost + start_y] +
                             U[0, i + ghost + start_x + 1, j + ghost + start_y])
            v_bot = 0.5 * (U[1, i + ghost + start_x, j + ghost + start_y] +
                           U[1, i + ghost + start_x, j + ghost + start_y - 1])
            v_top = 0.5 * (U[1, i + ghost + start_x, j + ghost + start_y] +
                           U[1, i + ghost + start_x, j + ghost + start_y + 1])
            velocity_list = [u_left, u_right, v_bot, v_top]
            ### identification of the donating region
            ### right face is donating region
            if u_right > 0:
                cal_donating_flux_right_CONSFIX(sub_flux, flux_stencil, PLIC_recons, dx, dy, dt, ghost, start_x, start_y,
                                        velocity_list, i, j, conservation_fix_r)
            ### left face is donating region
            if u_left < 0:
                cal_donating_flux_left_CONSFIX(sub_flux, flux_stencil, PLIC_recons, dx, dy, dt, ghost, start_x, start_y,
                                       velocity_list, i, j, conservation_fix_r)
            ### top face is donating region
            if v_top > 0:
                cal_donating_flux_top_CONSFIX(sub_flux, flux_stencil, PLIC_recons, dx, dy, dt, ghost, start_x, start_y,
                                      velocity_list, i, j, conservation_fix_r)
            ### bottom face is donating region
            if v_bot < 0:
                cal_donating_flux_bot_CONSFIX(sub_flux, flux_stencil, PLIC_recons, dx, dy, dt, ghost, start_x, start_y,
                                      velocity_list, i, j, conservation_fix_r)
    return sub_flux


### vel = [u_left, u_right, v_bot, v_top]
def cal_donating_flux_right_CONSFIX(sub_flux, flux_stencil, PLIC_recons, dx, dy, dt, ghost, start_x, start_y, vel, i, j, conservation_fix_r):
    ### first identify the gradient of the two sides
    k_tr = max(0., vel[3] / vel[1])
    k_lr = min(0., vel[2] / vel[1])
    V = dx * dy
    ### solve a quadratic polynomial to satisfy the flux constraint, u_R*dy*dt = Area
    ### a < 0 always
    a = 0.5 * (k_lr - k_tr)
    if a != 0:
        ### b > 0 always
        b = dy
        ### c < 0 always
        c = -vel[1] * dy * dt
        delta = b ** 2 - 4 * a * c
        ### 0 < dx1 < dx2 always, since -4ac < 0 always
        dx1 = (-b + np.sqrt(delta)) / (2 * a)
        # dx2 = (-b - np.sqrt(delta)) / (2 * a)
        ### choose the relative smaller result, because delta_x has an upper bound delta_x < 2 u_R * dt
        delta_x = dx1
        ### construct the donating region as a polygon
        if delta_x * (k_tr - k_lr) < dy:
            do_region = np.array([[dx, 0.],
                                  [dx, dy],
                                  [dx - delta_x, dy - k_tr * delta_x],
                                  [dx - delta_x, 0. - k_lr * delta_x]])
        else:
            do_region = np.array([[dx, 0.],
                                  [dx, dy],
                                  [dx - delta_x, 0. - k_lr * delta_x]])
    else:
        delta_x = vel[1] * dt
        do_region = np.array([[dx, 0.],
                              [dx, dy],
                              [dx - delta_x, dy],
                              [dx - delta_x, 0.]])
    cells = PLIC_recons[i + start_x + ghost][j + start_y + ghost][1]['cells']
    for ind in range(len(cells)):
        cell_info = cells[ind]
        phase_ind = cell_info[0]
        cell = cell_info[1]
        if get_cell_volume_new(do_region) > 0:
            do_polygon = clip_polygon(do_region, cell)
        else:
            do_polygon = np.array([])
        if len(do_polygon) > 2:
            do_volume = get_cell_volume_new(do_polygon)
            sub_flux[1, phase_ind, i + flux_stencil, j + flux_stencil] -= do_volume / V
            sub_flux[0, phase_ind, i + flux_stencil + 1, j + flux_stencil] += (do_volume / V) * conservation_fix_r[phase_ind]
        else:
            pass


def cal_donating_flux_left_CONSFIX(sub_flux, flux_stencil, PLIC_recons, dx, dy, dt, ghost, start_x, start_y, vel, i, j, conservation_fix_r):
    ### first identify the gradient of the two sides
    k_tl = min(0., vel[3] / vel[0])
    k_ll = max(0., vel[2] / vel[0])
    V = dx * dy
    ### solve a quadratic polynomial to satisfy the flux constraint, u_R*dy*dt = Area
    ### a < 0 always
    a = 0.5 * (k_tl - k_ll)
    if a != 0:
        ### b > 0 always
        b = dy
        ### c < 0 always
        c = vel[0] * dy * dt
        delta = b ** 2 - 4 * a * c
        ### 0 < dx1 < dx2 always, since -4ac < 0 always
        dx1 = (-b + np.sqrt(delta)) / (2 * a)
        # dx2 = (-b - np.sqrt(delta)) / (2 * a)
        ### choose the relative smaller result, because delta_x has an upper bound delta_x < 2 u_R * dt
        delta_x = dx1
        ### construct the donating region as a polygon
        if delta_x * (k_ll - k_tl) < dy:
            do_region = np.array([[0., 0.],
                                  [delta_x, 0. + k_ll * delta_x],
                                  [delta_x, dy + k_tl * delta_x],
                                  [0., dy]])
        else:
            do_region = np.array([[0., 0.],
                                  [delta_x, 0. + k_ll * delta_x],
                                  [0., dy]])
    else:
        delta_x = -vel[0] * dt
        do_region = np.array([[0., 0.],
                              [delta_x, 0.],
                              [delta_x, dy],
                              [0., dy]])
    cells = PLIC_recons[i + start_x + ghost][j + start_y + ghost][1]['cells']
    for ind in range(len(cells)):
        cell_info = cells[ind]
        phase_ind = cell_info[0]
        cell = cell_info[1]
        if get_cell_volume_new(do_region) > 0:
            do_polygon = clip_polygon(do_region, cell)
        else:
            do_polygon = np.array([])
        if len(do_polygon) > 2:
            do_volume = get_cell_volume_new(do_polygon)
            sub_flux[0, phase_ind, i + flux_stencil, j + flux_stencil] -= do_volume / V
            sub_flux[1, phase_ind, i + flux_stencil - 1, j + flux_stencil] += (do_volume / V) * conservation_fix_r[phase_ind]
        else:
            pass


def cal_donating_flux_top_CONSFIX(sub_flux, flux_stencil, PLIC_recons, dx, dy, dt, ghost, start_x, start_y, vel, i, j, conservation_fix_r):
    V = dx * dy
    ### first identify the gradient of the two sides
    if vel[0] < 0 and vel[1] > 0:
        ### first identify the gradient of the two sides
        k_tl = vel[3] / (vel[0])
        k_tr = vel[3] / (vel[1])
        ### solve a quadratic polynomial to satisfy the flux constraint, u_R*dy*dt = Area
        ### a < 0 always
        a = (k_tr - k_tl) / (2 * k_tr * k_tl)
        ### b > 0 always
        b = dx
        ### c < 0 always
        c = -vel[3] * dx * dt
        delta = b ** 2 - 4 * a * c
        ### 0 < dx1 < dx2 always, since -4ac < 0 always
        dy1 = (-b + np.sqrt(delta)) / (2 * a)
        # dy2 = (-b - np.sqrt(delta)) / (2 * a)
        ### choose the relative smaller result, because delta_x has an upper bound delta_x < 2 u_R * dt
        delta_y = dy1
        ### construct the donating region as a polygon
        if -delta_y * 2 * a < dx:
            do_region = np.array([[dx, dy],
                                  [0., dy],
                                  [-delta_y / k_tl, dy - delta_y],
                                  [dx - delta_y / k_tr, dy - delta_y]])
        elif -delta_y * 2 * a == dx:
            do_region = np.array([[dx, dy],
                                  [0., dy],
                                  [-delta_y / k_tl, dy - delta_y]])
        else:
            print('reduce the CFL!')
            return False
    elif vel[0] >= 0 and vel[1] > 0:
        ### k_tr > 0
        k_tr = vel[3] / (vel[1])
        ### a < 0 always
        a = -1 / (2 * k_tr)
        ### b > 0 always
        b = dx
        ### c < 0 always
        c = -vel[3] * dx * dt
        delta = b ** 2 - 4 * a * c
        ### 0 < dx1 < dx2 always, since -4ac < 0 always
        dy1 = (-b + np.sqrt(delta)) / (2 * a)
        # dy2 = (-b - np.sqrt(delta)) / (2 * a)
        ### choose the relative smaller result, because delta_x has an upper bound delta_x < 2 u_R * dt
        delta_y = dy1
        ### construct the donating region as a polygon
        if -delta_y * 2 * a < dx:
            do_region = np.array([[dx, dy],
                                  [0., dy],
                                  [0., dy - delta_y],
                                  [dx - delta_y / k_tr, dy - delta_y]])
        elif -delta_y * 2 * a == dx:
            do_region = np.array([[dx, dy],
                                  [0., dy],
                                  [0., 0.]])
        else:
            print('reduce the CFL!')
            return False
    elif vel[1] <= 0 and vel[0] < 0:
        ### k_tl < 0
        k_tl = vel[3] / (vel[0])
        ### a < 0 always
        a = 1 / (2 * k_tl)
        ### b > 0 always
        b = dx
        ### c < 0 always
        c = -vel[3] * dx * dt
        delta = b ** 2 - 4 * a * c
        ### 0 < dx1 < dx2 always, since -4ac < 0 always
        dy1 = (-b + np.sqrt(delta)) / (2 * a)
        # dy2 = (-b - np.sqrt(delta)) / (2 * a)
        ### choose the relative smaller result, because delta_x has an upper bound delta_x < 2 u_R * dt
        delta_y = dy1
        ### construct the donating region as a polygon
        if -delta_y * 2 * a < dx:
            do_region = np.array([[dx, dy],
                                  [0., dy],
                                  [-delta_y / k_tl, dy - delta_y],
                                  [dx, dy - delta_y]])
        elif -delta_y * 2 * a == dx:
            do_region = np.array([[dx, dy],
                                  [0., dy],
                                  [dx, 0.]])
        else:
            print('reduce the CFL!')
            return False
    else:
        # print('else')
        delta_y = vel[3] * dt
        if delta_y <= dy:
            do_region = np.array([[dx, dy],
                                  [0., dy],
                                  [0., dy - delta_y],
                                  [dx, dy - delta_y]])
        else:
            print('reduce the CFL!')
            return False
    cells = PLIC_recons[i + start_x + ghost][j + start_y + ghost][1]['cells']
    for ind in range(len(cells)):
        cell_info = cells[ind]
        phase_ind = cell_info[0]
        cell = cell_info[1]
        if get_cell_volume_new(do_region) > 0:
            do_polygon = clip_polygon(do_region, cell)
        else:
            do_polygon = np.array([])
        if len(do_polygon) > 2:
            do_volume = get_cell_volume_new(do_polygon)
            sub_flux[3, phase_ind, i + flux_stencil, j + flux_stencil] -= do_volume / V
            sub_flux[2, phase_ind, i + flux_stencil, j + flux_stencil + 1] += (do_volume / V) * conservation_fix_r[phase_ind]
        else:
            pass


def cal_donating_flux_bot_CONSFIX(sub_flux, flux_stencil, PLIC_recons, dx, dy, dt, ghost, start_x, start_y, vel, i, j, conservation_fix_r):
    V = dx * dy
    if vel[0] < 0 and vel[1] > 0:
        ### first identify the gradient of the two sides
        ### k_ll > 0, k_lr < 0
        k_ll = vel[2] / (vel[0])
        k_lr = vel[2] / (vel[1])
        ### solve a quadratic polynomial to satisfy the flux constraint, u_R*dy*dt = Area
        ### a < 0 always
        a = (k_ll - k_lr) / (2 * k_ll * k_lr)
        ### b > 0 always
        b = dx
        ### c < 0 always
        c = vel[2] * dx * dt
        delta = b ** 2 - 4 * a * c
        ### 0 < dx1 < dx2 always, since -4ac < 0 always
        dy1 = (-b + np.sqrt(delta)) / (2 * a)
        # dy2 = (-b - np.sqrt(delta)) / (2 * a)
        ### choose the relative smaller result, because delta_x has an upper bound delta_x < 2 u_R * dt
        delta_y = dy1
        ### construct the donating region as a polygon
        if -delta_y * 2 * a < dx:
            do_region = np.array([[0., 0.],
                                  [dx, 0.],
                                  [dx + delta_y / k_lr, delta_y],
                                  [delta_y / k_ll, delta_y]])
        elif -delta_y * 2 * a == dx:
            do_region = np.array([[0., 0.],
                                  [dx, 0.],
                                  [delta_y / k_ll, delta_y]])
        else:
            print('reduce the CFL!')
            return False
    elif vel[0] >= 0 and vel[1] > 0:
        ### k_lr < 0
        k_lr = vel[2] / (vel[1])
        ### a < 0 always
        a = 1 / (2 * k_lr)
        ### b > 0 always
        b = dx
        ### c < 0 always
        c = vel[2] * dx * dt
        delta = b ** 2 - 4 * a * c
        ### 0 < dx1 < dx2 always, since -4ac < 0 always
        dy1 = (-b + np.sqrt(delta)) / (2 * a)
        # dy2 = (-b - np.sqrt(delta)) / (2 * a)
        ### choose the relative smaller result, because delta_x has an upper bound delta_x < 2 u_R * dt
        delta_y = dy1
        ### construct the donating region as a polygon
        if -delta_y * 2 * a < dx:
            do_region = np.array([[0., 0.],
                                  [dx, 0.],
                                  [dx + delta_y / k_lr, delta_y],
                                  [0., delta_y]])
        elif -delta_y * 2 * a == dx:
            do_region = np.array([[0., 0.],
                                  [dx, 0.],
                                  [0., dy]])
        else:
            print('reduce the CFL!')
            return False
    elif vel[1] <= 0 and vel[0] < 0:
        ### k_ll > 0
        k_ll = vel[2] / (vel[0])
        ### a < 0 always
        a = -1 / (2 * k_ll)
        ### b > 0 always
        b = dx
        ### c < 0 always
        c = vel[2] * dx * dt
        delta = b ** 2 - 4 * a * c
        ### 0 < dx1 < dx2 always, since -4ac < 0 always
        dy1 = (-b + np.sqrt(delta)) / (2 * a)
        # dy2 = (-b - np.sqrt(delta)) / (2 * a)
        ### choose the relative smaller result, because delta_x has an upper bound delta_x < 2 u_R * dt
        delta_y = dy1
        ### construct the donating region as a polygon
        if -delta_y * 2 * a < dx:
            do_region = np.array([[0., 0.],
                                  [dx, 0.],
                                  [dx, delta_y],
                                  [delta_y / k_ll, delta_y]])
        elif -delta_y * 2 * a == dx:
            do_region = np.array([[0., 0.],
                                  [dx, 0.],
                                  [dx, dy]])
        else:
            print('reduce the CFL!')
            return False
    else:
        # print('else')
        delta_y = -vel[2] * dt
        if delta_y <= dy:
            do_region = np.array([[0., 0.],
                                  [dx, 0.],
                                  [dx, delta_y],
                                  [0., delta_y]])
        else:
            print('reduce the CFL!')
            return False
    cells = PLIC_recons[i + start_x + ghost][j + start_y + ghost][1]['cells']
    for ind in range(len(cells)):
        cell_info = cells[ind]
        phase_ind = cell_info[0]
        cell = cell_info[1]
        if get_cell_volume_new(do_region) > 0:
            do_polygon = clip_polygon(do_region, cell)
        else:
            do_polygon = np.array([])
        if len(do_polygon) > 2:
            do_volume = get_cell_volume_new(do_polygon)
            sub_flux[2, phase_ind, i + flux_stencil, j + flux_stencil] -= do_volume / V
            sub_flux[3, phase_ind, i + flux_stencil, j + flux_stencil - 1] += (do_volume / V) * conservation_fix_r[phase_ind]
        else:
            pass

################################################### SHAPELY ###########################################################

def cal_donating_flux_right_shapely(sub_flux, flux_stencil, PLIC_recons, dx, dy, dt, ghost, start_x, start_y, vel, i, j):
    ### first identify the gradient of the two sides
    k_tr = max(0., vel[3] / (vel[1] + 1e-8))
    k_lr = min(0., vel[2] / (vel[1] + 1e-8))
    V = dx * dy
    ### solve a quadratic polynomial to satisfy the flux constraint, u_R*dy*dt = Area
    ### a < 0 always
    a = 0.5 * (k_lr - k_tr)
    if a != 0:
        ### b > 0 always
        b = dy
        ### c < 0 always
        c = -vel[1] * dy * dt
        delta = b ** 2 - 4 * a * c
        ### 0 < dx1 < dx2 always, since -4ac < 0 always
        dx1 = (-b + np.sqrt(delta)) / (2 * a)
        # dx2 = (-b - np.sqrt(delta)) / (2 * a)
        ### choose the relative smaller result, because delta_x has an upper bound delta_x < 2 u_R * dt
        delta_x = dx1
        ### construct the donating region as a polygon
        if delta_x * (k_tr - k_lr) < dy:
            do_region = np.array([[dx, 0.],
                                  [dx, dy],
                                  [dx - delta_x, dy - k_tr * delta_x],
                                  [dx - delta_x, 0. - k_lr * delta_x]])
        else:
            do_region = np.array([[dx, 0.],
                                  [dx, dy],
                                  [dx - delta_x, 0. - k_lr * delta_x]])
    else:
        delta_x = vel[1] * dt
        do_region = np.array([[dx, 0.],
                              [dx, dy],
                              [dx - delta_x, dy],
                              [dx - delta_x, 0.]])
    cells = PLIC_recons[i + start_x + ghost][j + start_y + ghost][1]['cells']
    for ind in range(len(cells)):
        cell_info = cells[ind]
        phase_ind = cell_info[0]
        cell = cell_info[1]
        if get_cell_volume_shapely(do_region) > 0 and get_cell_volume_shapely(cell) > 0:
            do_polygon = clip_polygon_shapely(do_region, cell)
            do_volume = do_polygon.area
            sub_flux[1, phase_ind, i + flux_stencil, j + flux_stencil] -= do_volume / V
            sub_flux[0, phase_ind, i + flux_stencil + 1, j + flux_stencil] += do_volume / V
        else:
            pass

def cal_donating_flux_left_shapely(sub_flux, flux_stencil, PLIC_recons, dx, dy, dt, ghost, start_x, start_y, vel, i, j):
    ### first identify the gradient of the two sides
    k_tl = min(0., vel[3] / (vel[0] + 1e-8))
    k_ll = max(0., vel[2] / (vel[0] + 1e-8))
    V = dx * dy
    ### solve a quadratic polynomial to satisfy the flux constraint, u_R*dy*dt = Area
    ### a < 0 always
    a = 0.5 * (k_tl - k_ll)
    if a != 0:
        ### b > 0 always
        b = dy
        ### c < 0 always
        c = vel[0] * dy * dt
        delta = b ** 2 - 4 * a * c
        ### 0 < dx1 < dx2 always, since -4ac < 0 always
        dx1 = (-b + np.sqrt(delta)) / (2 * a)
        # dx2 = (-b - np.sqrt(delta)) / (2 * a)
        ### choose the relative smaller result, because delta_x has an upper bound delta_x < 2 u_R * dt
        delta_x = dx1
        ### construct the donating region as a polygon
        if delta_x * (k_ll - k_tl) < dy:
            do_region = np.array([[0., 0.],
                                  [delta_x, 0. + k_ll * delta_x],
                                  [delta_x, dy + k_tl * delta_x],
                                  [0., dy]])
        else:
            do_region = np.array([[0., 0.],
                                  [delta_x, 0. + k_ll * delta_x],
                                  [0., dy]])
    else:
        delta_x = -vel[0] * dt
        do_region = np.array([[0., 0.],
                              [delta_x, 0.],
                              [delta_x, dy],
                              [0., dy]])
    cells = PLIC_recons[i + start_x + ghost][j + start_y + ghost][1]['cells']

    # if i + start_x + ghost == 16 and j + start_y + ghost == 25:
    #     print(cells)
    #     print(do_region)

    for ind in range(len(cells)):
        cell_info = cells[ind]
        phase_ind = cell_info[0]
        cell = cell_info[1]
        if get_cell_volume_shapely(do_region) > 0 and get_cell_volume_shapely(cell) > 0:
            do_polygon = clip_polygon_shapely(do_region, cell)
            do_volume = do_polygon.area
            sub_flux[0, phase_ind, i + flux_stencil, j + flux_stencil] -= do_volume / V
            sub_flux[1, phase_ind, i + flux_stencil - 1, j + flux_stencil] += do_volume / V
            # if i + start_x + ghost == 16 and j + start_y + ghost == 25:
            #     print(phase_ind)
            #     print(do_polygon)
        else:
            pass

def cal_donating_flux_top_shapely(sub_flux, flux_stencil, PLIC_recons, dx, dy, dt, ghost, start_x, start_y, vel, i, j):
    V = dx * dy
    ### first identify the gradient of the two sides
    if vel[0] < 0 and vel[1] > 0:
        ### first identify the gradient of the two sides
        k_tl = vel[3] / (vel[0] + 1e-8)
        k_tr = vel[3] / (vel[1] + 1e-8)
        ### solve a quadratic polynomial to satisfy the flux constraint, u_R*dy*dt = Area
        ### a < 0 always
        a = (k_tr - k_tl) / (2 * k_tr * k_tl)
        ### b > 0 always
        b = dx
        ### c < 0 always
        c = -vel[3] * dx * dt
        delta = b ** 2 - 4 * a * c
        ### 0 < dx1 < dx2 always, since -4ac < 0 always
        dy1 = (-b + np.sqrt(delta)) / (2 * a)
        # dy2 = (-b - np.sqrt(delta)) / (2 * a)
        ### choose the relative smaller result, because delta_x has an upper bound delta_x < 2 u_R * dt
        delta_y = dy1
        ### construct the donating region as a polygon
        if -delta_y * 2 * a < dx:
            do_region = np.array([[dx, dy],
                                  [0., dy],
                                  [-delta_y / k_tl, dy - delta_y],
                                  [dx - delta_y / k_tr, dy - delta_y]])
        elif -delta_y * 2 * a == dx:
            do_region = np.array([[dx, dy],
                                  [0., dy],
                                  [-delta_y / k_tl, dy - delta_y]])
        else:
            print('reduce the CFL!, top')
            print(i + start_x + ghost, j + start_y + ghost)
            print(vel)
            return False
    elif vel[0] >= 0 and vel[1] > 0:
        ### k_tr > 0
        k_tr = vel[3] / (vel[1] + 1e-8)
        ### a < 0 always
        a = -1 / (2 * k_tr)
        ### b > 0 always
        b = dx
        ### c < 0 always
        c = -vel[3] * dx * dt
        delta = b ** 2 - 4 * a * c
        ### 0 < dx1 < dx2 always, since -4ac < 0 always
        dy1 = (-b + np.sqrt(delta)) / (2 * a)
        # dy2 = (-b - np.sqrt(delta)) / (2 * a)
        ### choose the relative smaller result, because delta_x has an upper bound delta_x < 2 u_R * dt
        delta_y = dy1
        ### construct the donating region as a polygon
        if -delta_y * 2 * a < dx:
            do_region = np.array([[dx, dy],
                                  [0., dy],
                                  [0., dy - delta_y],
                                  [dx - delta_y / k_tr, dy - delta_y]])
        elif -delta_y * 2 * a == dx:
            do_region = np.array([[dx, dy],
                                  [0., dy],
                                  [0., 0.]])
        else:
            print('reduce the CFL!, top')
            print(i + start_x + ghost, j + start_y + ghost)
            print(vel)
            return False
    elif vel[1] <= 0 and vel[0] < 0:
        ### k_tl < 0
        k_tl = vel[3] / (vel[0] + 1e-8)
        ### a < 0 always
        a = 1 / (2 * k_tl)
        ### b > 0 always
        b = dx
        ### c < 0 always
        c = -vel[3] * dx * dt
        delta = b ** 2 - 4 * a * c
        ### 0 < dx1 < dx2 always, since -4ac < 0 always
        dy1 = (-b + np.sqrt(delta)) / (2 * a)
        # dy2 = (-b - np.sqrt(delta)) / (2 * a)
        ### choose the relative smaller result, because delta_x has an upper bound delta_x < 2 u_R * dt
        delta_y = dy1
        ### construct the donating region as a polygon
        if -delta_y * 2 * a < dx:
            do_region = np.array([[dx, dy],
                                  [0., dy],
                                  [-delta_y / k_tl, dy - delta_y],
                                  [dx, dy - delta_y]])
        elif -delta_y * 2 * a == dx:
            do_region = np.array([[dx, dy],
                                  [0., dy],
                                  [dx, 0.]])
        else:
            print('reduce the CFL!, top')
            print(i + start_x + ghost, j + start_y + ghost)
            print(vel)
            return False
    else:
        # print('else')
        delta_y = vel[3] * dt
        if delta_y <= dy:
            do_region = np.array([[dx, dy],
                                  [0., dy],
                                  [0., dy - delta_y],
                                  [dx, dy - delta_y]])
        else:
            print('reduce the CFL!, top')
            print(i + start_x + ghost, j + start_y + ghost)
            print(vel)
            return False
    cells = PLIC_recons[i + start_x + ghost][j + start_y + ghost][1]['cells']

    # if i + start_x + ghost == 24 and j + start_y + ghost in [26, 27, 28]:
    #     print(i + start_x + ghost, j + start_y + ghost)
    #     print(cells)
    #     print(do_region)

    for ind in range(len(cells)):
        cell_info = cells[ind]
        phase_ind = cell_info[0]
        cell = cell_info[1]
        if get_cell_volume_shapely(do_region) > 0 and get_cell_volume_shapely(cell) > 0:
            do_polygon = clip_polygon_shapely(do_region, cell)
            do_volume = do_polygon.area
            sub_flux[3, phase_ind, i + flux_stencil, j + flux_stencil] -= do_volume / V
            sub_flux[2, phase_ind, i + flux_stencil, j + flux_stencil + 1] += do_volume / V
        else:
            pass

def cal_donating_flux_bot_shapely(sub_flux, flux_stencil, PLIC_recons, dx, dy, dt, ghost, start_x, start_y, vel, i, j):
    V = dx * dy
    if vel[0] < 0 and vel[1] > 0:
        ### first identify the gradient of the two sides
        ### k_ll > 0, k_lr < 0
        k_ll = vel[2] / (vel[0] + 1e-8)
        k_lr = vel[2] / (vel[1] + 1e-8)
        ### solve a quadratic polynomial to satisfy the flux constraint, u_R*dy*dt = Area
        ### a < 0 always
        a = (k_ll - k_lr) / (2 * k_ll * k_lr)
        ### b > 0 always
        b = dx
        ### c < 0 always
        c = vel[2] * dx * dt
        delta = b ** 2 - 4 * a * c
        ### 0 < dx1 < dx2 always, since -4ac < 0 always
        dy1 = (-b + np.sqrt(delta)) / (2 * a)
        # dy2 = (-b - np.sqrt(delta)) / (2 * a)
        ### choose the relative smaller result, because delta_x has an upper bound delta_x < 2 u_R * dt
        delta_y = dy1
        ### construct the donating region as a polygon
        if -delta_y * 2 * a < dx:
            do_region = np.array([[0., 0.],
                                  [dx, 0.],
                                  [dx + delta_y / k_lr, delta_y],
                                  [delta_y / k_ll, delta_y]])
        elif -delta_y * 2 * a == dx:
            do_region = np.array([[0., 0.],
                                  [dx, 0.],
                                  [delta_y / k_ll, delta_y]])
        else:
            print('reduce the CFL!, bot')
            print(i + start_x + ghost, j + start_y + ghost)
            print(vel)
            return False
    elif vel[0] >= 0 and vel[1] > 0:
        ### k_lr < 0
        k_lr = vel[2] / (vel[1] + 1e-8)
        ### a < 0 always
        a = 1 / (2 * k_lr)
        ### b > 0 always
        b = dx
        ### c < 0 always
        c = vel[2] * dx * dt
        delta = b ** 2 - 4 * a * c
        ### 0 < dx1 < dx2 always, since -4ac < 0 always
        dy1 = (-b + np.sqrt(delta)) / (2 * a)
        # dy2 = (-b - np.sqrt(delta)) / (2 * a)
        ### choose the relative smaller result, because delta_x has an upper bound delta_x < 2 u_R * dt
        delta_y = dy1
        ### construct the donating region as a polygon
        if -delta_y * 2 * a < dx:
            do_region = np.array([[0., 0.],
                                  [dx, 0.],
                                  [dx + delta_y / k_lr, delta_y],
                                  [0., delta_y]])
        elif -delta_y * 2 * a == dx:
            do_region = np.array([[0., 0.],
                                  [dx, 0.],
                                  [0., dy]])
        else:
            print('reduce the CFL!, bot')
            print(i + start_x + ghost, j + start_y + ghost)
            print(vel)
            return False
    elif vel[1] <= 0 and vel[0] < 0:
        ### k_ll > 0
        k_ll = vel[2] / (vel[0] + 1e-8)
        ### a < 0 always
        a = -1 / (2 * k_ll)
        ### b > 0 always
        b = dx
        ### c < 0 always
        c = vel[2] * dx * dt
        delta = b ** 2 - 4 * a * c
        ### 0 < dx1 < dx2 always, since -4ac < 0 always
        dy1 = (-b + np.sqrt(delta)) / (2 * a)
        # dy2 = (-b - np.sqrt(delta)) / (2 * a)
        ### choose the relative smaller result, because delta_x has an upper bound delta_x < 2 u_R * dt
        delta_y = dy1
        ### construct the donating region as a polygon
        if -delta_y * 2 * a < dx:
            do_region = np.array([[0., 0.],
                                  [dx, 0.],
                                  [dx, delta_y],
                                  [delta_y / k_ll, delta_y]])
        elif -delta_y * 2 * a == dx:
            do_region = np.array([[0., 0.],
                                  [dx, 0.],
                                  [dx, dy]])
        else:
            print('reduce the CFL!, bot')
            print(i + start_x + ghost, j + start_y + ghost)
            print(vel)
            return False
    else:
        # print('else')
        delta_y = -vel[2] * dt
        if delta_y <= dy:
            do_region = np.array([[0., 0.],
                                  [dx, 0.],
                                  [dx, delta_y],
                                  [0., delta_y]])
        else:
            print('reduce the CFL!, bot')
            print(i + start_x + ghost, j + start_y + ghost)
            print(vel)
            return False
    cells = PLIC_recons[i + start_x + ghost][j + start_y + ghost][1]['cells']

    # if i + start_x + ghost == 15 and j + start_y + ghost == 26:
    #     print(cells)
    #     print(do_region)

    for ind in range(len(cells)):
        cell_info = cells[ind]
        phase_ind = cell_info[0]
        cell = cell_info[1]
        if get_cell_volume_shapely(do_region) > 0 and get_cell_volume_shapely(cell) > 0:
            do_polygon = clip_polygon_shapely(do_region, cell)
            do_volume = do_polygon.area
            sub_flux[2, phase_ind, i + flux_stencil, j + flux_stencil] -= do_volume / V
            sub_flux[3, phase_ind, i + flux_stencil, j + flux_stencil - 1] += do_volume / V
        else:
            pass

### HERE THE FUNCTION APPLIES A FILTER TO THE FIXING RATIO
def conservation_filter(conservation_r, tolerance):
    conservation_r_copy = conservation_r.copy()
    for i in range(len(conservation_r)):
        if abs(conservation_r[i]) <= tolerance:
            conservation_r_copy[i] = 0.
        else:
            pass
    return conservation_r_copy



# polygon = np.array([[1, 0],
#                     [1, 1],
#                     [0, 1],
#                     [0, 0]])
# do_region = np.array([[0.03125, 0.03125],
#                       [0., 0.03125],
#                       [0.0089912, 0.02615923],
#                       [0.03125, 0.02615923]])
# cell = np.array([[0., 0.],
#                  [0., 0.02650551],
#                  [0.00151689, 0.03125],
#                  [0.03125, 0.03125],
#                  [0.03125, 0.]])
# intersection = clip_polygon_shapely(do_region, cell)
# print(intersection)
# print(intersection.area)
# cell_2 = np.array([[0.00819148, 0],
#                    [0.00385633, 0.03125],
#                    [0.03125, 0.03125],
#                    [0.03125, 0.]])
# print(polygon)
# for i in range(len(polygon)):
#     print(point_in_polygon(polygon[i], polygon))
# print(point_in_polygon(np.array([0.5, 0.5]), polygon))
# print(point_in_polygon(np.array([0.99999, 1]), polygon))
# print(point_in_polygon(np.array([1., 0.999999]), polygon))
# print(point_in_polygon(np.array([0.999999, 0.999999]), polygon))
# print(point_in_polygon(np.array([1., 1.00001]), polygon))
# print(point_in_polygon(np.array([1.00001, 1]), polygon))
# print(point_in_polygon(cell[1], do_region))
# flux_polygon_1 = clip_polygon(do_region, cell)
# print(flux_polygon_1)
# print(get_cell_volume_new(flux_polygon_1) / (0.03125**2))
# flux_polygon_2 = clip_polygon(do_region, cell_2)
# print(flux_polygon_2)
# print(get_cell_volume_new(flux_polygon_2) / (0.03125**2))
