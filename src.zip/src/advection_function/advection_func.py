### created by Huang and Zhang
### HKUST FU's Lab
### 2024.04.25
import multiprocessing
from src.functions.functions import *
from multiprocessing import Queue
from src.functions.mp_function import *
import numba as nb

def boundary_update_1(f, ghost):
    for i in range(len(f[0])):
        for j in range(ghost):
            ### slip lower
            f[:, i, j] = f[:, i, 2 * ghost - 1 - j]
            ### slip upper
            f[:, i, len(f[0, 0]) - j - 1] = f[:, i, len(f[0, 0]) - 2 * ghost + j]
    for i in range(len(f[0, 0])):
        for j in range(ghost):
            ### inflow left
            f[:, j, i] = f[:, ghost, i]
            ### ouflow right
            f[:, len(f[0]) - j - 1, i] = f[:, len(f[0]) - ghost, i]
    return f

def boundary_update_2(f, ghost):
    for i in range(len(f[0])):
        for j in range(ghost):
            ### inflow lower
            f[:, i, j] = f[:, i, ghost]
            ### outflow upper
            f[:, i, len(f[0, 0]) - j - 1] = f[:, i, len(f[0, 0]) - ghost]
    for i in range(len(f[0, 0])):
        for j in range(ghost):
            ### slip left
            f[:, j, i] = f[:, 2 * ghost - 1 - j, i]
            ### slip right
            f[:, len(f[0]) - j - 1, i] = f[:, len(f[0]) - 2 * ghost + j, i]
    return f

@nb.jit(nopython=True)
def boundary_update_3(f, ghost):
    for i in range(len(f[0])):
        for j in range(ghost):
            ### slip lower
            f[:, i, j] = f[:, i, 2 * ghost - 1 - j]
            ### slip upper
            f[:, i, len(f[0, 0]) - 1 - j] = f[:, i, len(f[0, 0]) - 2 * ghost + j]
    for i in range(len(f[0, 0])):
        for j in range(ghost):
            ### slip left
            f[:, j, i] = f[:, 2 * ghost - 1 - j, i]
            ### slip right
            f[:, len(f[0]) - j - 1, i] = f[:, len(f[0]) - 2 * ghost + j, i]
    return f

### This function apply the volume fraction repair
### The Volume Fraction should be larger than 0, sumaller than 1, and the summation of the phases should normalized to 1
def repair(f, ghost, x, y, phase_num, tolerance):
    ### first apply the [0, 1] constraint
    for i in range(ghost, len(x) - ghost):
        for j in range(ghost, len(y) - ghost):
            for p in range(phase_num):
                f[p, i, j] = min(1., max(0., f[p, i, j]))
    ### then apply the tolerance threshold
    for i in range(ghost, len(x) - ghost):
        for j in range(ghost, len(y) - ghost):
            for p in range(phase_num):
                if f[p, i, j] - 0. < tolerance:
                    f[p, i, j] = 0.
                else:
                    pass
                if 1 - f[p, i, j] < tolerance:
                    f[p, i, j] = 1.
                else:
                    pass
    ### then apply the noramlization
    for i in range(ghost, len(x) - ghost):
        for j in range(ghost, len(y) - ghost):
            sum_ = sum(f[:, i, j])
            for p in range(phase_num):
                f[p, i, j] = f[p, i, j] / sum_
    return f

def repair2(f, ghost, tolerance):
    ### first apply the [0, 1] constraint
    for i in range(ghost, len(f[0]) - ghost):
        for j in range(ghost, len(f[0, 0]) - ghost):
            for p in range(len(f)):
                f[p, i, j] = min(1., max(0., f[p, i, j]))
    ### then apply the tolerance threshold
    for i in range(ghost, len(f[0]) - ghost):
        for j in range(ghost, len(f[0, 0]) - ghost):
            for p in range(len(f)):
                if f[p, i, j] - 0. < tolerance:
                    f[p, i, j] = 0.
                else:
                    pass
                if 1 - f[p, i, j] < tolerance:
                    f[p, i, j] = 1.
                else:
                    pass
    ### then apply the noramlization
    for i in range(ghost, len(f[0]) - ghost):
        for j in range(ghost, len(f[0, 0]) - ghost):
            sum_ = sum(f[:, i, j])
            for p in range(len(f)):
                f[p, i, j] = f[p, i, j] / sum_
    return f

def repair3(f, tolerance):
    ### first apply the [0, 1] constraint
    for i in range(len(f[0])):
        for j in range(len(f[0, 0])):
            for p in range(len(f)):
                f[p, i, j] = min(1., max(0., f[p, i, j]))
    ### then apply the tolerance threshold
    for i in range(len(f[0])):
        for j in range(len(f[0, 0])):
            for p in range(len(f)):
                if f[p, i, j] - 0. < tolerance:
                    f[p, i, j] = 0.
                else:
                    pass
                if 1 - f[p, i, j] < tolerance:
                    f[p, i, j] = 1.
                else:
                    pass
    ### then apply the noramlization
    for i in range(len(f[0])):
        for j in range(len(f[0, 0])):
            sum_ = sum(f[:, i, j])
            for p in range(len(f)):
                f[p, i, j] = f[p, i, j] / sum_
    return f

### This works better than repair3
@nb.jit(nopython=True)
def repair4(f, tolerance):
    ### first apply the >0 constraint
    for i in range(len(f[0])):
        for j in range(len(f[0, 0])):
            for p in range(len(f)):
                f[p, i, j] = max(0., f[p, i, j])
    # ### then apply the noramlization
    # for i in range(len(f[0])):
    #     for j in range(len(f[0, 0])):
    #         sum_ = sum(f[:, i, j])
    #         for p in range(len(f)):
    #             f[p, i, j] = f[p, i, j] / sum_
    # ### then apply the <1 constraint
    # for i in range(len(f[0])):
    #     for j in range(len(f[0, 0])):
    #         for p in range(len(f)):
    #             f[p, i, j] = min(1., f[p, i, j])
    ### then apply the tolerance threshold
    for i in range(len(f[0])):
        for j in range(len(f[0, 0])):
            for p in range(len(f)):
                if f[p, i, j] - 0. < tolerance:
                    f[p, i, j] = 0.
                else:
                    pass
                if 1 - f[p, i, j] < tolerance:
                    f[p, i, j] = 1.
                else:
                    pass
    ### then apply the noramlization
    for i in range(len(f[0])):
        for j in range(len(f[0, 0])):
            sum_ = sum(f[:, i, j])
            for p in range(len(f)):
                f[p, i, j] = f[p, i, j] / sum_
    return f

def repair4_particle_relax(f, tolerance):
    return_f = f.copy()
    ### first apply the [0, 1] constraint
    for i in range(len(f[0])):
        for j in range(len(f[0, 0])):
            for p in range(len(f)):
                # f[p, i, j] = min(1., max(0., f[p, i, j]))
                return_f[p, i, j] = max(0., return_f[p, i, j])
    ### apply the tolerance threshold
    for i in range(len(f[0])):
        for j in range(len(f[0, 0])):
            for p in range(len(f)):
                if abs(return_f[p, i, j] - 0.) < tolerance:
                    return_f[p, i, j] = 0.
                else:
                    pass
                if abs(1 - return_f[p, i, j]) < tolerance:
                    return_f[p, i, j] = 1.
                else:
                    pass
    return return_f

### This method combines initialization and update process
def update_u_mp(phi, nx, ny, u_stencil, dx, dy, case, num_p):
    manager = multiprocessing.Manager()
    que = Queue()
    return_dict_u = manager.dict()
    return_dict_u['u'] = np.zeros((2, nx, ny), dtype=float)
    x_parts, y_parts = divide_domain(nx - 2 * u_stencil, ny - 2 * u_stencil, num_p)
    info = {'phi': phi,
            'dx': dx,
            'dy': dy,
            'u_stencil': u_stencil,
            'case': case,
            'x_parts': x_parts,
            'y_parts': y_parts}
    processes = create_processes_u(update_u_mp_exc, combine_results_u, info, que, return_dict_u)
    U = start_and_join_processes_u(processes, return_dict_u)
    return U

def update_u_mp_exc(info, que, start_x, end_x, start_y, end_y):
    phi = info['phi']
    dx = info['dx']
    dy = info['dy']
    case = info['case']
    u_stencil = info['u_stencil']
    sub_U = np.zeros((2, end_x - start_x, end_y - start_y), dtype=float)
    ### case 0 is uniform velocity
    if case == 0:
        for i in range(0, end_x - start_x):
            for j in range(0, end_y - start_y):
                ### ux = dphi/dy  second-order central
                sub_U[0, i, j] = (phi[i + u_stencil + start_x, j + u_stencil + 1 + start_y] -
                                  phi[i + u_stencil + start_x, j + u_stencil - 1 + start_y]) / (2 * dy)
                ### uy = -dphi/dx
                sub_U[1, i, j] = -(phi[i + u_stencil + 1 + start_x, j + u_stencil + start_y] -
                                   phi[i + u_stencil - 1 + start_x, j + u_stencil + start_y]) / (2 * dx)
    ### case 1 is uniform velocity U = constant, V = 0
    elif case == 1:
        for i in range(0, end_x - start_x):
            for j in range(0, end_y - start_y):
                ### ux = dphi/dy  second-order central
                sub_U[0, i, j] = (phi[i + u_stencil + start_x, j + u_stencil + 1 + start_y] -
                                  phi[i + u_stencil + start_x, j + u_stencil - 1 + start_y]) / (2 * dy)
                ### uy = -dphi/dx
                sub_U[1, i, j] = -(phi[i + u_stencil + 1 + start_x, j + u_stencil + start_y] -
                                   phi[i + u_stencil - 1 + start_x, j + u_stencil + start_y]) / (2 * dx)
    ### case 2 is Rider and Kothe single reverse vortex
    elif case >= 2:
        ### using second order central scheme to calculate gradient dphi/dx = (phi(i+1) - 2phi(i) + phi(i-1)) / dx^2
        for i in range(0, end_x - start_x):
            for j in range(0, end_y - start_y):
                ### ux = dphi/dy  second-order central
                sub_U[0, i, j] = (phi[i + u_stencil + start_x, j + u_stencil + 1 + start_y] -
                                  phi[i + u_stencil + start_x, j + u_stencil - 1 + start_y]) / (2 * dy)
                ### uy = -dphi/dx
                sub_U[1, i, j] = -(phi[i + u_stencil + 1 + start_x, j + u_stencil + start_y] -
                                   phi[i + u_stencil - 1 + start_x, j + u_stencil + start_y]) / (2 * dx)
    else:
        pass
    que.put({'sub_result': sub_U, 'start_x': start_x, 'end_x': end_x, 'start_y': start_y, 'end_y': end_y})

def get_phi_mp(nx, ny, t, N, T, dx, dy, ghost, case, num_p):
    manager = multiprocessing.Manager()
    que = Queue()
    return_dict_u = manager.dict()
    return_dict_u['phi'] = np.zeros([nx, ny])
    x_parts, y_parts = divide_domain(nx, ny, num_p)
    info = {'t': t,
            'N': N,
            'T': T,
            'dx': dx,
            'dy': dy,
            'ghost': ghost,
            'x_parts': x_parts,
            'y_parts': y_parts,
            'case': case}
    processes = create_processes_circle(get_phi_mp_exc, combine_results_phi, info, que, return_dict_u)
    phi = start_and_join_processes_phi(processes, return_dict_u)
    return phi

def get_phi_mp_exc(info, que, start_x, end_x, start_y, end_y):
    sub_phi = np.zeros([end_x - start_x, end_y - start_y])
    dx = info['dx']
    dy = info['dy']
    ghost = info['ghost']
    t = info['t']
    N = info['N']
    T = info['T']
    case = info['case']
    for i in range(len(sub_phi)):
        for j in range(len(sub_phi[0])):
            if case == 2:
                sub_phi[i, j] = RK_reverse_vortex(dx * (i + 0.5 - ghost + start_x),
                                                  dy * (j + 0.5 - ghost + start_y),
                                                  t, N, T)
            elif case == 3:
                sub_phi[i, j] = RK_deformation_test(dx * (i + 0.5 - ghost + start_x),
                                                    dy * (j + 0.5 - ghost + start_y),
                                                    t, N, T)
            elif case == 1:
                sub_phi[i, j] = horizontal_test(dx * (i + 0.5 - ghost + start_x), dy * (j + 0.5 - ghost + start_y), t, N, T)
            elif case == 0:
                sub_phi[i, j] = diagonal_test(dx * (i + 0.5 - ghost + start_x), dy * (j + 0.5 - ghost + start_y), t,
                                                N, T)
            else:
                pass
    que.put({'sub_result': sub_phi, 'start_x': start_x, 'end_x': end_x, 'start_y': start_y, 'end_y': end_y})

#################################### NJIT ########################################
@nb.jit(nopython=True)
def get_phi_njit(nx, ny, t, N, T, dx, dy, ghost, case):
    phi = np.zeros((nx, ny), dtype=np.float64)
    for i in range(nx):
        for j in range(ny):
            if case == 2:
                phi[i, j] = RK_reverse_vortex_njit(dx * (i + 0.5 - ghost), dy * (j + 0.5 - ghost), t, N, T)
            elif case == 3:
                phi[i, j] = RK_deformation_test_njit(dx * (i + 0.5 - ghost), dy * (j + 0.5 - ghost) + 0.25, t, N, T)
            elif case == 1:
                phi[i, j] = horizontal_test_njit(dx * (i + 0.5 - ghost), dy * (j + 0.5 - ghost), t, N, T)
            elif case == 0:
                phi[i, j] = diagonal_test_njit(dx * (i + 0.5 - ghost), dy * (j + 0.5 - ghost), t, N, T)
            else:
                pass
    return phi

@nb.jit(nopython=True)
def update_u_njit(phi, nx, ny, u_stencil, dx, dy):
    U = np.zeros((2, nx, ny), dtype=np.float64)
    for i in range(0, nx - 2 * u_stencil):
        for j in range(0, ny - 2 * u_stencil):
            ### ux = dphi/dy  second-order central
            U[0, i + u_stencil, j + u_stencil] = (phi[i + u_stencil, j + u_stencil + 1] -
                              phi[i + u_stencil, j + u_stencil - 1]) / (2 * dy)
            ### uy = -dphi/dx
            U[1, i + u_stencil, j + u_stencil] = -(phi[i + u_stencil + 1, j + u_stencil] -
                               phi[i + u_stencil - 1, j + u_stencil]) / (2 * dx)
    return U

@nb.jit(nopython=True)
def RK_reverse_vortex_njit(x, y, t, N, T):
    result = (1 / np.pi) * ((np.sin((np.pi / N) * x)) ** 2) * ((np.sin((np.pi / N) * y)) ** 2) * np.cos(
        np.pi * (t / T))
    return result

@nb.jit(nopython=True)
def RK_deformation_test_njit(x, y, t, N, T):
    result = -((1 / (4 * np.pi)) * np.sin(4 * np.pi * (x + 0.5)) * np.cos(4 * np.pi * (y + 0.5)) *
              np.cos((2 * np.pi * t) / T))
    return result

@nb.jit(nopython=True)
def horizontal_test_njit(x, y, t, N, T):
    result = (N * y + 0.) * np.cos(np.pi * (t / T))
    # result = (N * y + 0.) * (-1) ** (t > (T / 2))
    return result

@nb.jit(nopython=True)
def diagonal_test_njit(x, y, t, N, T):
    result = (-N * x + N * y) * (-1) ** (t > (T / 2))
    return result

###################################################################################################
def RK_reverse_vortex(x, y, t, N, T):
    result = (1 / np.pi) * ((np.sin((np.pi / N) * x)) ** 2) * ((np.sin((np.pi / N) * y)) ** 2) * np.cos(
        np.pi * (t / T))
    return result

def RK_deformation_test(x, y, t, N, T):
    result = -((1 / (4 * np.pi)) * np.sin(4 * np.pi * (x + 0.5)) * np.cos(4 * np.pi * (y + 0.5)) *
              np.cos((2 * np.pi * t) / T))
    return result

def horizontal_test(x, y, t, N, T):
    result = (N * y + 0.)
    # result = (N * y + 0.) * (-1) ** (t > (T / 2))
    return result

def diagonal_test(x, y, t, N, T):
    result = (-N * x + N * y) * (-1) ** (t > (T / 2))
    return result

def get_phi_deformation_field_mp(nx, ny, t, N, T, dx, dy, ghost, case, num_p):
    manager = multiprocessing.Manager()
    que = Queue()
    return_dict_u = manager.dict()
    return_dict_u['phi'] = np.zeros([nx, ny])
    x_parts, y_parts = divide_domain(nx, ny, num_p)
    info = {'t': t,
            'N': N,
            'T': T,
            'dx': dx,
            'dy': dy,
            'ghost': ghost,
            'x_parts': x_parts,
            'y_parts': y_parts,
            'case': case}
    processes = create_processes_circle(get_phi_deformation_field_mp_exc, combine_results_phi, info, que, return_dict_u)
    phi = start_and_join_processes_phi(processes, return_dict_u)
    return phi

def get_phi_deformation_field_mp_exc(info, que, start_x, end_x, start_y, end_y):
    sub_phi = np.zeros([end_x - start_x, end_y - start_y])
    dx = info['dx']
    dy = info['dy']
    ghost = info['ghost']
    t = info['t']
    N = info['N']
    T = info['T']
    case = info['case']
    for i in range(len(sub_phi)):
        for j in range(len(sub_phi[0])):
            if case == 2:
                sub_phi[i, j] = RK_reverse_vortex(dx * (i + 0.5 - ghost + start_x),
                                                  dy * (j + 0.5 - ghost + start_y),
                                                  t, N, T)
            elif case == 3:
                sub_phi[i, j] = RK_deformation_test(dx * (i + 0.5 - ghost + start_x),
                                                    dy * (j + 0.5 - ghost + start_y) + 0.25,
                                                    t, N, T)
    que.put({'sub_result': sub_phi, 'start_x': start_x, 'end_x': end_x, 'start_y': start_y, 'end_y': end_y})
