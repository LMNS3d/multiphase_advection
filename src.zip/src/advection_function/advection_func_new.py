### created by Zhang
### HKUST FU's Lab
### 2024.11.11

import math
import random

from shapely import LineString
from src.functions.functions import plic_get_intersects, get_cell_volume_shapely, get_cell_volume_new
import numpy as np
from shapely.geometry import Point
from shapely.geometry.polygon import Polygon
import matplotlib.pyplot as plt


####################################################### DQA #######################################################
### judge if a point lies inside the convex polygon, by laser method
### odd intersections and even intersections to judge if ...
def point_in_polygon_shapely(point, polygon):
    point = np.array(point)
    polygon = np.array(polygon)
    ### JUDGE BY THE LARGEST CELL
    if np.max(polygon[:, 0]) < point[0]:
        return False
    elif np.min(polygon[:, 0]) > point[0]:
        return False
    elif np.max(polygon[:, 1]) < point[1]:
        return False
    elif np.min(polygon[:, 1]) > point[1]:
        return False
    elif point_on_polygon_edge(point, polygon):
        return True
    else:
        point = Point(point[0], point[1])
        polygon_inp = []
        for i in range(len(polygon)):
            polygon_inp.append((polygon[i, 0], polygon[i, 1]))
        polygon = Polygon(polygon_inp)
        result = polygon.contains(point)
        return result

def point_in_polygon(point, polygon):
    ### FIRST JUDGE THE MAXIMUM BOX
    polygon = np.array(polygon)
    if np.max(polygon[:,0]) < point[0] or np.max(polygon[:,1]) < point[1] or point[0] < np.min(polygon[:,0]) or point[1] < np.min(polygon[:,1]):
        return False
    elif point_on_polygon_edge(point, polygon):
        # print('point on edge')
        return True
    else:
        point = np.array(point)
        # Calculate the boundary vector of the polygon
        vote_for_True = 0
        vote_for_False = 0
        edges = []
        for i in range(len(polygon)):
            p1 = polygon[i]
            p2 = polygon[(i + 1) % len(polygon)]
            edges.append(np.array([p1, p2]))
        edges = np.array(edges)
        # print(edges)
        # Count the number of intersections between a horizontal right-ray and a polygon
        count = 0
        for edge in edges:
            if ray_insec_edg_r(point, edge):
                count += 1
            else:
                pass
        # Determine whether a point is inside or on the border of a polygon
        if count % 2 == 1:
            vote_for_True += 1
        else:
            vote_for_False += 1
        # print(vote_for_True, vote_for_False)
        # Count the number of intersections between a horizontal left-ray and a polygon
        count = 0
        for edge in edges:
            if ray_insec_edg_l(point, edge):
                count += 1
            else:
                pass
        if count % 2 == 1:
            vote_for_True += 1
        else:
            vote_for_False += 1
        # print(vote_for_True, vote_for_False)
        # Count the number of intersections between a vertical up-ray and a polygon
        count = 0
        for edge in edges:
            if ray_insec_edg_u(point, edge):
                count += 1
            else:
                pass
        if count % 2 == 1:
            vote_for_True += 1
        else:
            vote_for_False += 1
        # print(vote_for_True, vote_for_False)
        # Count the number of intersections between a vertical down-ray and a polygon
        count = 0
        for edge in edges:
            if ray_insec_edg_d(point, edge):
                count += 1
            else:
                pass
        if count % 2 == 1:
            vote_for_True += 1
        else:
            vote_for_False += 1
        # print(vote_for_True, vote_for_False)
        ### final voting decision
        if vote_for_True >= vote_for_False:
            return True
        else:
            return False

### THIS FUNCTION IS USED TO TEST IF A POINT LIES ON THE BOUNDARY OF A GIVEN POLYGON
def point_on_polygon_edge(point, polygon):
    edges = []
    for i in range(len(polygon)):
        p1 = polygon[i]
        p2 = polygon[(i + 1) % len(polygon)]
        edges.append(np.array([p1, p2]))
    edges = np.array(edges)
    for i in range(len(edges)):
        if judge_on_line(point, edges[i, 0], edges[i, 1]):
            return True
    return False

### THIS FUNCTION RETURNS INTERSECTION CONDITION OF A HORIZONTAL RIGHT-RAY AND AN EDGE
def ray_insec_edg_r(point, edge):
    ### AVOID HORIZONTAL EDGE
    if edge[0, 1] != edge[1, 1]:
        ### MAKE SURE THE FIRST POINT IS BELOW SECOND POINT
        if edge[0, 1] < edge[1, 1]:
            pass
        else:
            edge_copy = edge.copy()
            edge_copy[0] = edge[1]
            edge_copy[1] = edge[0]
            edge = edge_copy
    else:
        if min(edge[0, 0], edge[1, 0]) <= point[0] <= max(edge[0, 0], edge[1, 0]) and point[1] == edge[0, 1]:
            return True
        else:
            return False
    # ### AVOID RAY ON THE VERTEX
    # if point[1] == edge[0, 1] or point[1] == edge[1, 1]:
    #     point[1] += 1e-8
    # else:
    #     pass
    ### JUDGE IF OUT OF RANGE
    if point[1] < edge[0, 1] or point[1] > edge[1, 1]:
        return False
    elif point[0] > max(edge[0, 0], edge[1, 0]):
        return False
    else:
        if point[0] <= min(edge[0, 0], edge[1, 0]):
            return True
        else:
            if edge[0, 0] != edge[1, 0]:
                k_edge = (edge[1, 1] - edge[0, 1]) / (edge[1, 0] - edge[0, 0])
            else:
                k_edge = float('inf')
            if point[0] != edge[0, 0]:
                k_p_edge = (point[1] - edge[0, 1]) / (point[0] - edge[0, 0])
            else:
                k_p_edge = float('inf')
            if k_p_edge >= k_edge:
                return True
            else:
                return False

### THIS FUNCTION RETURNS INTERSECTION CONDITION OF A HORIZONTAL LEFT-RAY AND AN EDGE
def ray_insec_edg_l(point, edge):
    ### AVOID HORIZONTAL EDGE
    if edge[0, 1] != edge[1, 1]:
        ### MAKE SURE THE FIRST POINT IS BELOW SECOND POINT
        if edge[0, 1] < edge[1, 1]:
            pass
        else:
            edge_copy = edge.copy()
            edge_copy[0] = edge[1]
            edge_copy[1] = edge[0]
            edge = edge_copy
    else:
        if min(edge[0, 0], edge[1, 0]) <= point[0] <= max(edge[0, 0], edge[1, 0]) and point[1] == edge[0, 1]:
            return True
        else:
            return False
    # ### AVOID RAY ON THE VERTEX
    # if point[1] == edge[0, 1] or point[1] == edge[1, 1]:
    #     point[1] += 1e-8
    # else:
    #     pass
    ### JUDGE IF OUT OF RANGE
    if point[1] < edge[0, 1] or point[1] > edge[1, 1]:
        return False
    elif point[0] < min(edge[0, 0], edge[1, 0]):
        return False
    else:
        if point[0] >= max(edge[0, 0], edge[1, 0]):
            return True
        else:
            if edge[0, 0] != edge[1, 0]:
                k_edge = (edge[1, 1] - edge[0, 1]) / (edge[1, 0] - edge[0, 0])
            else:
                k_edge = float('inf')
            if point[0] != edge[0, 0]:
                k_p_edge = (point[1] - edge[0, 1]) / (point[0] - edge[0, 0])
            else:
                k_p_edge = float('inf')
            if k_p_edge <= k_edge:
                return True
            else:
                return False

### THIS FUNCTION RETURNS INTERSECTION CONDITION OF A HORIZONTAL UP-RAY AND AN EDGE
def ray_insec_edg_u(point, edge):
    ### AVOID VERTICLE EDGE
    if edge[0, 0] != edge[1, 0]:
        # print('edge[0, 0] != edge[1, 0]')
        ### MAKE SURE THE FIRST POINT IS TO THE LEFT
        if edge[0, 0] < edge[1, 0]:
            pass
        else:
            edge_copy = edge.copy()
            edge_copy[0] = edge[1]
            edge_copy[1] = edge[0]
            edge = edge_copy
    else:
        # print('edge[0, 0] = edge[1, 0]')
        if min(edge[0, 1], edge[1, 1]) <= point[1] <= max(edge[0, 1], edge[1, 1]) and point[0] == edge[0, 0]:
            # print('min(edge[0, 1], edge[1, 1]) <= point[1] <= max(edge[0, 1], edge[1, 1]) and point[0] == edge[0, 0]')
            return True
        else:
            return False
    # print(edge)
    # ### AVOID RAY ON THE VERTEX
    # if point[0] == edge[0, 0] or point[0] == edge[1, 0]:
    #     point[0] += 1e-8
    # else:
    #     pass
    ### JUDGE IF OUT OF RANGE
    if point[0] < edge[0, 0] or point[0] > edge[1, 0]:
        return False
    elif point[1] > max(edge[0, 1], edge[1, 1]):
        return False
    else:
        if point[1] <= min(edge[0, 1], edge[1, 1]):
            # print('point[1] <= min(edge[0, 1], edge[1, 1])')
            return True
        else:
            if edge[0, 0] != edge[1, 0]:
                k_edge = (edge[1, 1] - edge[0, 1]) / (edge[1, 0] - edge[0, 0])
            else:
                if edge[0, 1] > edge[1, 1]:
                    k_edge = -float('inf')
                else:
                    k_edge = float('inf')
            if point[0] != edge[0, 0]:
                k_p_edge = (point[1] - edge[0, 1]) / (point[0] - edge[0, 0])
            else:
                if edge[0, 1] > point[1]:
                    k_p_edge = -float('inf')
                else:
                    k_p_edge = float('inf')
            if k_p_edge <= k_edge:
                # print('k_p_edge <= k_edge')
                return True
            else:
                return False

### THIS FUNCTION RETURNS INTERSECTION CONDITION OF A HORIZONTAL DOWN-RAY AND AN EDGE
def ray_insec_edg_d(point, edge):
    ### AVOID VERTICLE EDGE
    if edge[0, 0] != edge[1, 0]:
        ### MAKE SURE THE FIRST POINT IS TO THE LEFT
        if edge[0, 0] < edge[1, 0]:
            pass
        else:
            edge_copy = edge.copy()
            edge_copy[0] = edge[1]
            edge_copy[1] = edge[0]
            edge = edge_copy
    else:
        if min(edge[0, 1], edge[1, 1]) <= point[1] <= max(edge[0, 1], edge[1, 1]) and point[0] == edge[0, 0]:
            return True
        else:
            return False
    # ### AVOID RAY ON THE VERTEX
    # if point[0] == edge[0, 0] or point[0] == edge[1, 0]:
    #     point[0] += 1e-8
    # else:
    #     pass
    ### JUDGE IF OUT OF RANGE
    if point[0] < edge[0, 0] or point[0] > edge[1, 0]:
        return False
    elif point[1] < min(edge[0, 1], edge[1, 1]):
        return False
    else:
        if point[1] >= max(edge[0, 1], edge[1, 1]):
            return True
        else:
            if edge[0, 0] != edge[1, 0]:
                k_edge = (edge[1, 1] - edge[0, 1]) / (edge[1, 0] - edge[0, 0])
            else:
                if edge[0, 1] > edge[1, 1]:
                    k_edge = -float('inf')
                else:
                    k_edge = float('inf')
            if point[0] != edge[0, 0]:
                k_p_edge = (point[1] - edge[0, 1]) / (point[0] - edge[0, 0])
            else:
                if edge[0, 1] > point[1]:
                    k_p_edge = -float('inf')
                else:
                    k_p_edge = float('inf')
            if k_p_edge >= k_edge:
                return True
            else:
                return False

### This function judge if the point is on the line segment, constructed by p1 and p2:
def judge_on_line(point, p1, p2):
    def distance(p1, p2):
        return ((p1[0]-p2[0])**2 + (p1[1]-p2[1])**2)**0.5
    # Determine whether the point is on the line segment
    d1 = distance(point, p1)
    d2 = distance(point, p2)
    d3 = distance(p1, p2)
    # print(point, p1, p2, abs(d1 + d2 - d3) < 1e-8)
    return abs(d1 + d2 - d3) < 1e-8

def get_flux_particle_consfix_exc(U, U_p, PLIC_recons, dx, dy, dt, ghost,
                          start_x, end_x, start_y, end_y, flux_stencil, Z, conservation_fix_r, cfl):
    ### extend one cell length to store the donating flux of the broaders
    sub_flux_mid = np.zeros([2, 3, end_x - start_x + 2 * flux_stencil, end_y - start_y + 2 * flux_stencil])
    n_l = [[-1, -1], [-1, 0], [-1, 1], [0, 1], [1, 1], [1, 0], [1, -1], [0, -1]]
    for i in range(end_x - start_x):
        for j in range(end_y - start_y):
            n_l_ind = [0, 1, 2, 3, 4, 5, 6, 7]
            sco = PLIC_recons[i + start_x + ghost][j + start_y + ghost][1]['sco']
            flux_in_stencil = np.zeros([2, 3, 3, 3])
            ### RECORD ALL SCO=1 NEIGHBOR (CLOCKWISE)
            for o in range(len(n_l)):
                sco_n = PLIC_recons[i + start_x + ghost + n_l[o][0]][j + start_y + ghost + n_l[o][1]][1]['sco']
                if sco_n == 0:
                    n_l_ind.remove(o)
                else:
                    pass
            cells = PLIC_recons[i + start_x + ghost][j + start_y + ghost][1]['cells']
            U_stencil = U[:                                              ,
                          i - 1 + ghost + start_x:i + 2 + ghost + start_x,
                          j - 1 + ghost + start_y:j + 2 + ghost + start_y]
            U_p_stencil = U_p[:                                              ,
                              i - 1 + ghost + start_x:i + 2 + ghost + start_x,
                              j - 1 + ghost + start_y:j + 2 + ghost + start_y]
            U_mid_stencil = 0.5 * (U_stencil + U_p_stencil)
            if sco == 1:
                ### GET ALL THE PARTICLES IN THE ADVECTION ACTIVE RIM REGION
                ### THE PARTICLE ARE ORDERED IN CELL-WISE
                particles_all, particle_fractions = gen_ALL_p_in_rim(Z, cfl, dx, dy, cells)
                # ### ADDING RANDOM ORDER
                ### GET THE PARTICULIZED INFORMATION OF THE CELL POLYGONS
                for k in range(len(cells)):
                    phase = cells[k][0]
                    ### CONSERVATION_FIX
                    if len(cells) > 1:
                        particle_fraction_fix = particle_fractions[k] * conservation_fix_r[phase]
                    else:
                        particle_fraction_fix = particle_fractions[k]
                    flow_out = 0.
                    particles = particles_all[k]
                    for q in range(len(particles)):
                        ### RK2
                        u_i, v_i = get_particle_u_4Node(U_stencil, particles[q][0], particles[q][1], dx, dy)
                        p_mid = particles[q] + 0.5 * dt * np.array([u_i, v_i])
                        u_mid, v_mid = get_particle_u_4Node(U_mid_stencil, p_mid[0], p_mid[1], dx, dy)
                        particle_moved = particles[q] + dt * np.array([u_mid, v_mid])
                        out = accum_lag_p_flux_sco_1_shapely(particle_moved, phase, flux_in_stencil,
                                                             particle_fraction_fix, dx, dy, n_l_ind)
                        flow_out += out
                    flux_in_stencil[1, phase, 1, 1] += flow_out * particle_fractions[k]
            else:
                if n_l_ind:
                    particles_all, particle_fractions = gen_ALL_p_in_rim(Z, cfl, dx, dy, cells)
                    phase = cells[0][0]
                    particles = particles_all[0]
                    for q in range(len(particles)):
                        u_i, v_i = get_particle_u_4Node(U_stencil, particles[q][0], particles[q][1], dx, dy)
                        p_mid = particles[q] + 0.5 * dt * np.array([u_i, v_i])
                        u_mid, v_mid = get_particle_u_4Node(U_mid_stencil, p_mid[0], p_mid[1], dx, dy)
                        particle_moved = particles[q] + dt * np.array([u_mid, v_mid])
                        accum_lag_p_flux_sco_0_shapely(particle_moved, phase, flux_in_stencil, particle_fractions[0], dx, dy, n_l_ind)
                else:
                    pass
            sub_flux_mid[:                                        ,
                         :                                        ,
                         i - 1 + flux_stencil:i + 2 + flux_stencil,
                         j - 1 + flux_stencil:j + 2 + flux_stencil] += flux_in_stencil
    return sub_flux_mid

def get_flux_particle_exc(U, U_p, PLIC_recons, dx, dy, dt, ghost,
                          start_x, end_x, start_y, end_y, flux_stencil, Z, cfl):
    ### extend one cell length to store the donating flux of the broaders
    sub_flux_mid = np.zeros([2, 3, end_x - start_x + 2 * flux_stencil, end_y - start_y + 2 * flux_stencil])
    n_l = [[-1, -1], [-1, 0], [-1, 1], [0, 1], [1, 1], [1, 0], [1, -1], [0, -1]]
    for i in range(end_x - start_x):
        for j in range(end_y - start_y):
            n_l_ind = [0, 1, 2, 3, 4, 5, 6, 7]
            sco = PLIC_recons[i + start_x + ghost][j + start_y + ghost][1]['sco']
            flux_in_stencil = np.zeros([2, 3, 3, 3])
            ### RECORD ALL SCO=1 NEIGHBOR (CLOCKWISE)
            for o in range(len(n_l)):
                sco_n = PLIC_recons[i + start_x + ghost + n_l[o][0]][j + start_y + ghost + n_l[o][1]][1]['sco']
                if sco_n == 0:
                    n_l_ind.remove(o)
                else:
                    pass
            cells = PLIC_recons[i + start_x + ghost][j + start_y + ghost][1]['cells']
            U_stencil = U[:                                              ,
                          i - 1 + ghost + start_x:i + 2 + ghost + start_x,
                          j - 1 + ghost + start_y:j + 2 + ghost + start_y]
            U_p_stencil = U_p[:                                              ,
                              i - 1 + ghost + start_x:i + 2 + ghost + start_x,
                              j - 1 + ghost + start_y:j + 2 + ghost + start_y]
            U_mid_stencil = 0.5 * (U_stencil + U_p_stencil)
            if sco == 1:
                ### GET ALL THE PARTICLES IN THE ADVECTION ACTIVE RIM REGION
                ### THE PARTICLE ARE ORDERED IN CELL-WISE
                particles_all, particle_fractions = gen_ALL_p_in_rim(Z, cfl, dx, dy, cells)
                # ### ADDING RANDOM ORDER
                ### GET THE PARTICULIZED INFORMATION OF THE CELL POLYGONS
                for k in range(len(cells)):
                    phase = cells[k][0]
                    flow_out = 0.
                    particles = particles_all[k]
                    for q in range(len(particles)):
                        ### RK2
                        u_i, v_i = get_particle_u_4Node(U_stencil, particles[q][0], particles[q][1], dx, dy)
                        p_mid = particles[q] + 0.5 * dt * np.array([u_i, v_i])
                        u_mid, v_mid = get_particle_u_4Node(U_mid_stencil, p_mid[0], p_mid[1], dx, dy)
                        particle_moved = particles[q] + dt * np.array([u_mid, v_mid])
                        out = accum_lag_p_flux_sco_1_shapely(particle_moved, phase, flux_in_stencil, particle_fractions[k], dx, dy, n_l_ind)
                        flow_out += out
                    flux_in_stencil[1, phase, 1, 1] += flow_out * particle_fractions[k]
            else:
                if n_l_ind:
                    particles_all, particle_fractions = gen_ALL_p_in_rim(Z, cfl, dx, dy, cells)
                    phase = cells[0][0]
                    particles = particles_all[0]
                    for q in range(len(particles)):
                        u_i, v_i = get_particle_u_4Node(U_stencil, particles[q][0], particles[q][1], dx, dy)
                        p_mid = particles[q] + 0.5 * dt * np.array([u_i, v_i])
                        u_mid, v_mid = get_particle_u_4Node(U_mid_stencil, p_mid[0], p_mid[1], dx, dy)
                        particle_moved = particles[q] + dt * np.array([u_mid, v_mid])
                        accum_lag_p_flux_sco_0_shapely(particle_moved, phase, flux_in_stencil, particle_fractions[0], dx, dy, n_l_ind)
                else:
                    pass
            sub_flux_mid[:                                        ,
                         :                                        ,
                         i - 1 + flux_stencil:i + 2 + flux_stencil,
                         j - 1 + flux_stencil:j + 2 + flux_stencil] += flux_in_stencil
    return sub_flux_mid

### THIS METHOD EMPLOYED DILITATION FACTOR
def get_flux_particle_2_consfix_exc(U, U_p, PLIC_recons, dx, dy, dt, ghost,
                          start_x, end_x, start_y, end_y, flux_stencil, Z, conservation_fix_r, cfl):
    ### extend one cell length to store the donating flux of the broaders
    sub_flux_mid = np.zeros([2, 3, end_x - start_x + 2 * flux_stencil, end_y - start_y + 2 * flux_stencil])
    n_l = [[-1, -1], [-1, 0], [-1, 1], [0, 1], [1, 1], [1, 0], [1, -1], [0, -1]]
    ### CALCULATE THE DILATATION Z TO MAKE SURE THE NUMBER OF EFFECTIVE LAG POINTS IS NOT DECREASING
    if cfl < 0.5:
        Z = int(Z * np.sqrt(1 / (4 * cfl - 4 * cfl ** 2)))
    else:
        pass
    for i in range(end_x - start_x):
        for j in range(end_y - start_y):
            n_l_ind = [0, 1, 2, 3, 4, 5, 6, 7]
            sco = PLIC_recons[i + start_x + ghost][j + start_y + ghost][1]['sco']
            flux_in_stencil = np.zeros([2, 3, 3, 3])
            ### RECORD ALL SCO=1 NEIGHBOR (CLOCKWISE)
            for o in range(len(n_l)):
                sco_n = PLIC_recons[i + start_x + ghost + n_l[o][0]][j + start_y + ghost + n_l[o][1]][1]['sco']
                if sco_n == 0:
                    n_l_ind.remove(o)
                else:
                    pass
            cells = PLIC_recons[i + start_x + ghost][j + start_y + ghost][1]['cells']
            U_stencil = U[:                                              ,
                          i - 1 + ghost + start_x:i + 2 + ghost + start_x,
                          j - 1 + ghost + start_y:j + 2 + ghost + start_y]
            U_p_stencil = U_p[:                                              ,
                              i - 1 + ghost + start_x:i + 2 + ghost + start_x,
                              j - 1 + ghost + start_y:j + 2 + ghost + start_y]
            U_mid_stencil = 0.5 * (U_stencil + U_p_stencil)
            if sco == 1:
                ### GET ALL THE PARTICLES IN THE ADVECTION ACTIVE RIM REGION
                ### THE PARTICLE ARE ORDERED IN CELL-WISE
                classification_m, particle_fractions, normal_cell, particle_append = gen_ALL_p_in_rim_2(Z, cfl, dx, dy, cells)
                x_a = np.linspace(0., dx, Z)
                y_a = np.linspace(0., dy, Z)
                ### point ~ [2, nn, nn]
                points = np.meshgrid(x_a, y_a)
                points = np.array(points)
                # ### ADDING RANDOM ORDER
                ### GET THE PARTICULIZED INFORMATION OF THE CELL POLYGONS
                for k in range(len(cells)):
                    phase = cells[k][0]
                    flow_out = 0.
                    ### CONSERVATION_FIX
                    if len(cells) > 1:
                        particle_fraction_fix = particle_fractions[k] * conservation_fix_r[phase]
                    else:
                        particle_fraction_fix = particle_fractions[k]
                    if normal_cell[k]:
                        classification_m_k = classification_m[k, :, :]
                        for ii in range(len(x_a)):
                            for jj in range(len(y_a)):
                                if classification_m_k[ii, jj]:
                                    particle = points[:, ii, jj]
                                    ### RK2
                                    u_i, v_i = get_particle_u_4Node(U_stencil, particle[0], particle[1], dx, dy)
                                    p_mid = particle + 0.5 * dt * np.array([u_i, v_i])
                                    u_mid, v_mid = get_particle_u_4Node(U_mid_stencil, p_mid[0], p_mid[1], dx, dy)
                                    particle_moved = particle + dt * np.array([u_mid, v_mid])
                                    out = accum_lag_p_flux_sco_1_shapely(particle_moved, phase, flux_in_stencil, particle_fraction_fix, dx, dy, n_l_ind)
                                    flow_out += out
                                else:
                                    pass
                    else:
                        particles = particle_append[k]
                        for q in range(len(particles)):
                            u_i, v_i = get_particle_u_4Node(U_stencil, particles[q][0], particles[q][1], dx, dy)
                            p_mid = particles[q] + 0.5 * dt * np.array([u_i, v_i])
                            u_mid, v_mid = get_particle_u_4Node(U_mid_stencil, p_mid[0], p_mid[1], dx, dy)
                            particle_moved = particles[q] + dt * np.array([u_mid, v_mid])
                            accum_lag_p_flux_sco_0_shapely(particle_moved, phase, flux_in_stencil, particle_fraction_fix, dx, dy, n_l_ind)
                    flux_in_stencil[1, phase, 1, 1] += flow_out * particle_fractions[k]
            else:
                if n_l_ind:
                    activation_m, particle_fraction = gen_ALL_p_in_rim_2_one_cell(Z, cfl)
                    x_a = np.linspace(0., dx, Z)
                    y_a = np.linspace(0., dy, Z)
                    ### point ~ [2, nn, nn]
                    points = np.meshgrid(x_a, y_a)
                    points = np.array(points)
                    phase = cells[0][0]
                    for ii in range(len(x_a)):
                        for jj in range(len(y_a)):
                            if activation_m[ii, jj]:
                                particle = points[:, ii, jj]
                                u_i, v_i = get_particle_u_4Node(U_stencil, particle[0], particle[1], dx, dy)
                                p_mid = particle + 0.5 * dt * np.array([u_i, v_i])
                                u_mid, v_mid = get_particle_u_4Node(U_mid_stencil, p_mid[0], p_mid[1], dx, dy)
                                particle_moved = particle + dt * np.array([u_mid, v_mid])
                                accum_lag_p_flux_sco_0_shapely(particle_moved, phase, flux_in_stencil, particle_fraction, dx, dy, n_l_ind)
                else:
                    pass
            sub_flux_mid[:                                        ,
                         :                                        ,
                         i - 1 + flux_stencil:i + 2 + flux_stencil,
                         j - 1 + flux_stencil:j + 2 + flux_stencil] += flux_in_stencil
    return sub_flux_mid

def get_flux_particle_2_exc(U, U_p, PLIC_recons, dx, dy, dt, ghost,
                          start_x, end_x, start_y, end_y, flux_stencil, Z, cfl):
    ### extend one cell length to store the donating flux of the broaders
    sub_flux_mid = np.zeros([2, 3, end_x - start_x + 2 * flux_stencil, end_y - start_y + 2 * flux_stencil])
    n_l = [[-1, -1], [-1, 0], [-1, 1], [0, 1], [1, 1], [1, 0], [1, -1], [0, -1]]
    ### CALCULATE THE DILATATION Z TO MAKE SURE THE NUMBER OF EFFECTIVE LAG POINTS IS NOT DECREASING
    if cfl < 0.5:
        Z = int(Z * np.sqrt(1 / (4 * cfl - 4 * cfl ** 2)))
    else:
        pass
    for i in range(end_x - start_x):
        for j in range(end_y - start_y):
            n_l_ind = [0, 1, 2, 3, 4, 5, 6, 7]
            sco = PLIC_recons[i + start_x + ghost][j + start_y + ghost][1]['sco']
            flux_in_stencil = np.zeros([2, 3, 3, 3])
            ### RECORD ALL SCO=1 NEIGHBOR (CLOCKWISE)
            for o in range(len(n_l)):
                sco_n = PLIC_recons[i + start_x + ghost + n_l[o][0]][j + start_y + ghost + n_l[o][1]][1]['sco']
                if sco_n == 0:
                    n_l_ind.remove(o)
                else:
                    pass
            cells = PLIC_recons[i + start_x + ghost][j + start_y + ghost][1]['cells']
            U_stencil = U[:                                              ,
                          i - 1 + ghost + start_x:i + 2 + ghost + start_x,
                          j - 1 + ghost + start_y:j + 2 + ghost + start_y]
            U_p_stencil = U_p[:                                              ,
                              i - 1 + ghost + start_x:i + 2 + ghost + start_x,
                              j - 1 + ghost + start_y:j + 2 + ghost + start_y]
            U_mid_stencil = 0.5 * (U_stencil + U_p_stencil)
            if sco == 1:
                ### GET ALL THE PARTICLES IN THE ADVECTION ACTIVE RIM REGION
                ### THE PARTICLE ARE ORDERED IN CELL-WISE
                classification_m, particle_fractions, normal_cell, particle_append = gen_ALL_p_in_rim_2(Z, cfl, dx, dy, cells)
                x_a = np.linspace(0., dx, Z)
                y_a = np.linspace(0., dy, Z)
                ### point ~ [2, nn, nn]
                points = np.meshgrid(x_a, y_a)
                points = np.array(points)
                # ### ADDING RANDOM ORDER
                ### GET THE PARTICULIZED INFORMATION OF THE CELL POLYGONS
                for k in range(len(cells)):
                    phase = cells[k][0]
                    flow_out = 0.
                    if normal_cell[k]:
                        classification_m_k = classification_m[k, :, :]
                        for ii in range(len(x_a)):
                            for jj in range(len(y_a)):
                                if classification_m_k[ii, jj]:
                                    particle = points[:, ii, jj]
                                    ### RK2
                                    u_i, v_i = get_particle_u_4Node(U_stencil, particle[0], particle[1], dx, dy)
                                    p_mid = particle + 0.5 * dt * np.array([u_i, v_i])
                                    u_mid, v_mid = get_particle_u_4Node(U_mid_stencil, p_mid[0], p_mid[1], dx, dy)
                                    particle_moved = particle + dt * np.array([u_mid, v_mid])
                                    out = accum_lag_p_flux_sco_1_shapely(particle_moved, phase, flux_in_stencil, particle_fractions[k], dx, dy, n_l_ind)
                                    flow_out += out
                                else:
                                    pass
                    else:
                        particles = particle_append[k]
                        for q in range(len(particles)):
                            u_i, v_i = get_particle_u_4Node(U_stencil, particles[q][0], particles[q][1], dx, dy)
                            p_mid = particles[q] + 0.5 * dt * np.array([u_i, v_i])
                            u_mid, v_mid = get_particle_u_4Node(U_mid_stencil, p_mid[0], p_mid[1], dx, dy)
                            particle_moved = particles[q] + dt * np.array([u_mid, v_mid])
                            accum_lag_p_flux_sco_0_shapely(particle_moved, phase, flux_in_stencil, particle_fractions[0], dx, dy, n_l_ind)
                    flux_in_stencil[1, phase, 1, 1] += flow_out * particle_fractions[k]
            else:
                if n_l_ind:
                    activation_m, particle_fraction = gen_ALL_p_in_rim_2_one_cell(Z, cfl)
                    x_a = np.linspace(0., dx, Z)
                    y_a = np.linspace(0., dy, Z)
                    ### point ~ [2, nn, nn]
                    points = np.meshgrid(x_a, y_a)
                    points = np.array(points)
                    phase = cells[0][0]
                    for ii in range(len(x_a)):
                        for jj in range(len(y_a)):
                            if activation_m[ii, jj]:
                                particle = points[:, ii, jj]
                                u_i, v_i = get_particle_u_4Node(U_stencil, particle[0], particle[1], dx, dy)
                                p_mid = particle + 0.5 * dt * np.array([u_i, v_i])
                                u_mid, v_mid = get_particle_u_4Node(U_mid_stencil, p_mid[0], p_mid[1], dx, dy)
                                particle_moved = particle + dt * np.array([u_mid, v_mid])
                                accum_lag_p_flux_sco_0_shapely(particle_moved, phase, flux_in_stencil, particle_fraction, dx, dy, n_l_ind)
                else:
                    pass
            sub_flux_mid[:                                        ,
                         :                                        ,
                         i - 1 + flux_stencil:i + 2 + flux_stencil,
                         j - 1 + flux_stencil:j + 2 + flux_stencil] += flux_in_stencil
    return sub_flux_mid

### https://geekplux.com/posts/how-to-picking-uniform-points-in-irregular-polygon
### generate random points in a polygon within a bonding box
def gen_p_in_polygon(polygon, nn):
    polygon = np.array(polygon)
    ### creating the bonding box
    xs = polygon[:, 0]
    ys = polygon[:, 1]
    x_min = np.min(xs)
    x_max = np.max(xs)
    y_min = np.min(ys)
    y_max = np.max(ys)
    nn_ = 0
    points = []
    while nn_ < nn:
        x = random.random() * (x_max - x_min) + x_min
        y = random.random() * (y_max - y_min) + y_min
        point = np.array([x, y])
        if point_in_polygon_shapely(point, polygon):
            points.append(point)
            nn_ += 1
        else:
            continue
    return np.array(points)

### RIM TYPE

def gen_ALL_p_in_rim(nn, cfl, dx, dy, cells):
    particle_fraction = np.zeros(len(cells))
    normal_cell = np.ones(len(cells))
    # except_volume = 0.
    x_a = np.linspace(0., dx, nn)
    y_a = np.linspace(0., dy, nn)
    particle_all = [[] for ii in range(len(cells))]
    cell_particle_num = np.zeros(len(cells), dtype=int)
    for i in range(len(x_a)):
        for j in range(len(y_a)):
            particle = np.array([x_a[i], y_a[j]])
            for k in range(len(cells)):
                if point_in_polygon_shapely(particle, cells[k][1]):
                    out_rim = abs(x_a[i] - 0.5 * dx) < (0.5 - cfl - 1 / nn) * dx and abs(y_a[j] - 0.5 * dy) < (0.5 - cfl - 1 / nn) * dy
                    cell_particle_num[k] += 1
                    if out_rim:
                        pass
                    else:
                        particle_all[k].append(particle)
                    break
                else:
                    pass
    cells_volume = np.zeros(len(cells))
    for i in range(len(cells)):
        cell = np.array(cells[i][1])
        cell_volume = get_cell_volume_new(cell)
        cells_volume[i] = cell_volume
        if len(particle_all[i]) == 0 and cell_volume > 0:
            # print('here1')
            normal_cell[i] = 0
            # except_volume += cells_volume
            p_num = int((cell_volume * nn) / (dx * dy)) + 1
            cell_particle_num[i] = p_num
            if p_num == 1:
                xs = cell[:, 0]
                ys = cell[:, 1]
                x_avg = 0.5 * (np.min(xs) + np.max(xs))
                y_avg = 0.5 * (np.min(ys) + np.max(ys))
                particle = np.array([x_avg, y_avg])
                particle_all[i].append(particle)
            else:
                particles = gen_p_in_polygon(cell, p_num)
                for particle in particles:
                    particle_all[i].append(particle)
            particle_fraction[i] = (cell_volume / (dx * dy)) / p_num
        else:
            pass
    # normal_volume = dx * dy - except_volume
    for i in range(len(cells)):
        if normal_cell[i] == 1:
            particle_fraction[i] = (cells_volume[i] / (dx * dy)) / cell_particle_num[i]
    # print(cell_particle_num)
    return particle_all, particle_fraction

### THIS FUNCTION ONLY GENERATE CANDIDATE POINTS IN THE RIM REGION, USING AN EXTRA DIMENSION TO TAG THE PARTICLE
def gen_ALL_p_in_rim_2(nn, cfl, dx, dy, cells):
    particle_fraction = np.zeros(len(cells))
    normal_cell = np.ones(len(cells))
    ###
    x_a = np.linspace(0., dx, nn)
    y_a = np.linspace(0., dy, nn)
    ### point ~ [2, nn, nn]
    points = np.meshgrid(x_a, y_a)
    points = np.array(points)
    ### ACTIVATION MATRIX
    activation_m = np.ones([len(x_a), len(y_a)], dtype=int)
    if cfl < 0.5:
        trunca_ind = int(cfl * nn) + 1
        activation_m[trunca_ind:(len(activation_m) - trunca_ind), trunca_ind:(len(activation_m[0]) - trunca_ind)] = (
            np.zeros([len(activation_m) - 2 * trunca_ind, len(activation_m) - 2 * trunca_ind], dtype=int))
    ### LAG POINTS CLASSIFICATION MATRIX
    classification_m = np.zeros([len(cells), len(x_a), len(y_a)], dtype=int)
    cell_particle_num = np.zeros(len(cells), dtype=int)
    for ii in range(len(x_a)):
        for jj in range(len(y_a)):
            for k in range(len(cells)):
                particle = points[:, ii, jj]
                if point_in_polygon_shapely(particle, cells[k][1]):
                    if activation_m[ii, jj]:
                        classification_m[k, ii, jj] = 1
                    cell_particle_num[k] += 1
                    break
                else:
                    pass
    cells_volume = np.zeros(len(cells))
    particle_append = [[] for kk in range(len(cells))]
    for ii in range(len(cells)):
        cell = np.array(cells[ii][1])
        cell_volume = get_cell_volume_shapely(cell)
        cells_volume[ii] = cell_volume
        cell_particle_num_activated = np.sum(classification_m[ii, :, :])
        if cell_particle_num_activated == 0 and cell_volume > 0:
            normal_cell[ii] = 0
            p_num = int((cell_volume * nn ** 2) / (dx * dy)) + 1
            cell_particle_num[ii] = p_num
            if p_num == 1:
                xs = cell[:, 0]
                ys = cell[:, 1]
                x_avg = 0.5 * (np.min(xs) + np.max(xs))
                y_avg = 0.5 * (np.min(ys) + np.max(ys))
                particle = np.array([x_avg, y_avg])
                particle_append[ii].append(particle)
            else:
                particles = gen_p_in_polygon(cell, p_num)
                for particle in particles:
                    particle_append[ii].append(particle)
            particle_fraction[ii] = (cell_volume / (dx * dy)) / p_num
        else:
            pass
    for ii in range(len(cells)):
        if normal_cell[ii] == 1:
            particle_fraction[ii] = (cells_volume[ii] / (dx * dy)) / cell_particle_num[ii]

    return classification_m, particle_fraction, normal_cell, particle_append

### THIS FUNCTION IS USED TO GENERATE CLASSIFICATION MATRIX FOR NO-INTERFACE CELL
def gen_ALL_p_in_rim_2_one_cell(nn, cfl):
    particle_fraction = 1 / nn ** 2
    ### ACTIVATION MATRIX
    activation_m = np.ones([nn, nn], dtype=int)
    if cfl < 0.5:
        trunca_ind = int(cfl * nn) + 1
        activation_m[trunca_ind:(len(activation_m) - trunca_ind), trunca_ind:(len(activation_m[0]) - trunca_ind)] = (
            np.zeros([len(activation_m) - 2 * trunca_ind, len(activation_m) - 2 * trunca_ind], dtype=int))
    return activation_m, particle_fraction

### DETERMINE THE NUMBER OF POINTS IN POLYGON, AND THE FRACTIONS PER POINTS
def get_p_num(volume, dx, dy, Z):
    fraction = volume / (dx * dy)
    cri_fraction = 1 / Z
    if fraction >= cri_fraction:
        num_p = int(fraction * Z)
        particle_fraction = fraction / num_p
    else:
        num_p = 1
        particle_fraction = fraction
    return num_p, particle_fraction

### CALCULATE THE VELOCITY FIELD INSIDE CELL (i, j) USING THE 9-NODE QUADRILATERAL SHAPE FUNCTION
### U_stencil = U[:,i-1:i+1,j-1:j+1]
### x_loc, y_loc is localized coordinates with respect to cell (i,j)
def get_particle_u(U_stencil, x_loc, y_loc, dx, dy):
    xi = (x_loc - 0.5 * dx) / dx
    yita = (y_loc - 0.5 * dy) / dy
    shape_N = np.array([0.25 * xi * (xi - 1) * yita * (yita - 1),
                        -0.5 * xi * (xi - 1) * (yita + 1) * (yita - 1),
                        0.25 * xi * (xi - 1) * yita * (yita + 1),
                        -0.5 * (xi + 1) * (xi - 1) * yita * (yita + 1),
                        0.25 * xi * (xi + 1) * yita * (yita + 1),
                        -0.5 * xi * (xi + 1) * (yita + 1) * (yita - 1),
                        0.25 * xi * (xi + 1) * yita * (yita - 1),
                        -0.5 * (xi + 1) * (xi - 1) * yita * (yita - 1),
                        (xi + 1) * (xi - 1) * (yita + 1) * (yita - 1)])
    shaped_u = np.array([U_stencil[0, 0, 0], U_stencil[0, 0, 1], U_stencil[0, 0, 2],
                         U_stencil[0, 1, 2], U_stencil[0, 2, 2], U_stencil[0, 2, 1],
                         U_stencil[0, 2, 0], U_stencil[0, 1, 0], U_stencil[0, 1, 1]])
    shaped_v = np.array([U_stencil[1, 0, 0], U_stencil[1, 0, 1], U_stencil[1, 0, 2],
                         U_stencil[1, 1, 2], U_stencil[1, 2, 2], U_stencil[1, 2, 1],
                         U_stencil[1, 2, 0], U_stencil[1, 1, 0], U_stencil[1, 1, 1]])
    u = shape_N.dot(shaped_u)
    v = shape_N.dot(shaped_v)
    return u, v

### USING 4-NODE SHAPE FUNCTION
def get_particle_u_4Node(U_stencil, x_loc, y_loc, dx, dy):
    if x_loc <= 0.5 * dx:
        if y_loc <= 0.5 * dy:
            xi = x_loc / dx * 2
            yita = y_loc / dy * 2
            shaped_u = np.array([U_stencil[0, 0, 0], U_stencil[0, 0, 1], U_stencil[0, 1, 1], U_stencil[0, 1, 0]])
            shaped_v = np.array([U_stencil[1, 0, 0], U_stencil[1, 0, 1], U_stencil[1, 1, 1], U_stencil[1, 1, 0]])
        else:
            xi = x_loc / dx * 2
            yita = (y_loc - dy) / dy * 2
            shaped_u = np.array([U_stencil[0, 0, 1], U_stencil[0, 0, 2], U_stencil[0, 1, 2], U_stencil[0, 1, 1]])
            shaped_v = np.array([U_stencil[1, 0, 1], U_stencil[1, 0, 2], U_stencil[1, 1, 2], U_stencil[1, 1, 1]])
    else:
        if y_loc <= 0.5 * dy:
            xi = (x_loc - dx) / dx * 2
            yita = y_loc / dy * 2
            shaped_u = np.array([U_stencil[0, 1, 0], U_stencil[0, 1, 1], U_stencil[0, 2, 1], U_stencil[0, 2, 0]])
            shaped_v = np.array([U_stencil[1, 1, 0], U_stencil[1, 1, 1], U_stencil[1, 2, 1], U_stencil[1, 2, 0]])
        else:
            xi = (x_loc - dx) / dx * 2
            yita = (y_loc - dy) / dy * 2
            shaped_u = np.array([U_stencil[0, 1, 1], U_stencil[0, 1, 2], U_stencil[0, 2, 2], U_stencil[0, 2, 1]])
            shaped_v = np.array([U_stencil[1, 1, 1], U_stencil[1, 1, 2], U_stencil[1, 2, 2], U_stencil[1, 2, 1]])
    shape_N = np.array([0.25 * (1 - xi) * (1 - yita),
                        0.25 * (1 - xi) * (1 + yita),
                        0.25 * (1 + xi) * (1 + yita),
                        0.25 * (1 + xi) * (1 - yita)])
    u = shape_N.dot(shaped_u)
    v = shape_N.dot(shaped_v)
    return u, v

### USING LEAST SQUARE REGRESSION TO OBTAIN THE VELOCITY IN 4 NODE AREA
def get_particle_u_LSR_4Node(U_stencil, x_loc, y_loc, dx, dy):
    if x_loc <= 0.5:
        if y_loc <= 0.5:
            xi = x_loc
            yita = y_loc
            A = np.array([[1 / (xi + 0.5 * dx), 1 / (yita + 0.5 * dy)],
                          [1 / (xi + 0.5 * dx), 1 / (yita - 0.5 * dy)],
                          [1 / (xi - 0.5 * dx), 1 / (yita - 0.5 * dy)],
                          [1 / (xi - 0.5 * dx), 1 / (yita + 0.5 * dy)]])
            b = np.array([[1 / (xi + 0.5 * dx) * U_stencil[0, 0, 0] + 1 / (yita + 0.5 * dy) * U_stencil[1, 0, 0]],
                          [1 / (xi + 0.5 * dx) * U_stencil[0, 0, 1] + 1 / (yita - 0.5 * dy) * U_stencil[1, 0, 1]],
                          [1 / (xi - 0.5 * dx) * U_stencil[0, 1, 1] + 1 / (yita - 0.5 * dy) * U_stencil[1, 1, 1]],
                          [1 / (xi - 0.5 * dx) * U_stencil[0, 1, 0] + 1 / (yita + 0.5 * dy) * U_stencil[1, 1, 0]]])
            x = np.linalg.inv(A.transpose().dot(A)).dot(A.transpose().dot(b))
        else:
            xi = x_loc
            yita = y_loc - dy
            A = np.array([[1 / (xi + 0.5 * dx), 1 / (yita + 0.5 * dy)],
                          [1 / (xi + 0.5 * dx), 1 / (yita - 0.5 * dy)],
                          [1 / (xi - 0.5 * dx), 1 / (yita - 0.5 * dy)],
                          [1 / (xi - 0.5 * dx), 1 / (yita + 0.5 * dy)]])
            b = np.array([[1 / (xi + 0.5 * dx) * U_stencil[0, 0, 1] + 1 / (yita + 0.5 * dy) * U_stencil[1, 0, 1]],
                          [1 / (xi + 0.5 * dx) * U_stencil[0, 0, 2] + 1 / (yita - 0.5 * dy) * U_stencil[1, 0, 2]],
                          [1 / (xi - 0.5 * dx) * U_stencil[0, 1, 2] + 1 / (yita - 0.5 * dy) * U_stencil[1, 1, 2]],
                          [1 / (xi - 0.5 * dx) * U_stencil[0, 1, 1] + 1 / (yita + 0.5 * dy) * U_stencil[1, 1, 1]]])
            x = np.linalg.inv(A.transpose().dot(A)).dot(A.transpose().dot(b))
    else:
        if y_loc <= 0.5:
            xi = x_loc - dx
            yita = y_loc
            A = np.array([[1 / (xi + 0.5 * dx), 1 / (yita + 0.5 * dy)],
                          [1 / (xi + 0.5 * dx), 1 / (yita - 0.5 * dy)],
                          [1 / (xi - 0.5 * dx), 1 / (yita - 0.5 * dy)],
                          [1 / (xi - 0.5 * dx), 1 / (yita + 0.5 * dy)]])
            b = np.array([[1 / (xi + 0.5 * dx) * U_stencil[0, 1, 0] + 1 / (yita + 0.5 * dy) * U_stencil[1, 1, 0]],
                          [1 / (xi + 0.5 * dx) * U_stencil[0, 1, 1] + 1 / (yita - 0.5 * dy) * U_stencil[1, 1, 1]],
                          [1 / (xi - 0.5 * dx) * U_stencil[0, 2, 1] + 1 / (yita - 0.5 * dy) * U_stencil[1, 2, 1]],
                          [1 / (xi - 0.5 * dx) * U_stencil[0, 2, 0] + 1 / (yita + 0.5 * dy) * U_stencil[1, 2, 0]]])
            x = np.linalg.inv(A.transpose().dot(A)).dot(A.transpose().dot(b))
        else:
            xi = x_loc - dx
            yita = y_loc - dy
            A = np.array([[1 / (xi + 0.5 * dx), 1 / (yita + 0.5 * dy)],
                          [1 / (xi + 0.5 * dx), 1 / (yita - 0.5 * dy)],
                          [1 / (xi - 0.5 * dx), 1 / (yita - 0.5 * dy)],
                          [1 / (xi - 0.5 * dx), 1 / (yita + 0.5 * dy)]])
            b = np.array([[1 / (xi + 0.5 * dx) * U_stencil[0, 1, 1] + 1 / (yita + 0.5 * dy) * U_stencil[1, 1, 1]],
                          [1 / (xi + 0.5 * dx) * U_stencil[0, 1, 2] + 1 / (yita - 0.5 * dy) * U_stencil[1, 1, 2]],
                          [1 / (xi - 0.5 * dx) * U_stencil[0, 2, 2] + 1 / (yita - 0.5 * dy) * U_stencil[1, 2, 2]],
                          [1 / (xi - 0.5 * dx) * U_stencil[0, 2, 1] + 1 / (yita + 0.5 * dy) * U_stencil[1, 2, 1]]])
            x = np.linalg.inv(A.transpose().dot(A)).dot(A.transpose().dot(b))
    return x[0], x[1]

def accum_lag_p_flux_sco_1(particle_moved, phase, stencil_flux, particle_fraction, dx, dy, sco_n_1):
    out = True
    ### TRANSPORT TO OTHERS CELLS
    if -dx <= particle_moved[0] < 0. and -dy <= particle_moved[1] < 0.:
        if [-1, -1] in sco_n_1:
            stencil_flux[0, phase, 0, 0] += particle_fraction
        else:
            pass
        return out
    elif -dx <= particle_moved[0] < 0. and 0. <= particle_moved[1] < dy:
        if [-1, 0] in sco_n_1:
            stencil_flux[0, phase, 0, 1] += particle_fraction
        else:
            pass
        return out
    elif -dx <= particle_moved[0] < 0. and dy <= particle_moved[1] <= 2 * dy:
        if [-1, 1] in sco_n_1:
            stencil_flux[0, phase, 0, 2] += particle_fraction
        else:
            pass
        return out
    elif 0. <= particle_moved[0] < dx and -dy <= particle_moved[1] < 0.:
        if [0, -1] in sco_n_1:
            stencil_flux[0, phase, 1, 0] += particle_fraction
        else:
            pass
        return out
    elif 0. <= particle_moved[0] < dx and dy <= particle_moved[1] <= 2 * dy:
        if [0, 1] in sco_n_1:
            stencil_flux[0, phase, 1, 2] += particle_fraction
        else:
            pass
        return out
    elif dx <= particle_moved[0] <= 2 * dx and -dy <= particle_moved[1] < 0.:
        if [1, -1] in sco_n_1:
            stencil_flux[0, phase, 2, 0] += particle_fraction
        else:
            pass
        return out
    elif dx <= particle_moved[0] <= 2 * dx and 0. <= particle_moved[1] < dy:
        if [1, 0] in sco_n_1:
            stencil_flux[0, phase, 2, 1] += particle_fraction
        else:
            pass
        return out
    elif dx <= particle_moved[0] <= 2 * dx and dy <= particle_moved[1] <= 2 * dy:
        if [1, 1] in sco_n_1:
            stencil_flux[0, phase, 2, 2] += particle_fraction
        else:
            pass
        return out
    ### STAY IN THE ORIGINAL CELL
    else:
        out = False
        return out

def accum_lag_p_flux_sco_0(particle_moved, phase, stencil_flux, particle_fraction, dx, dy, sco_n_1):
    ### TRANSPORT TO OTHERS CELLS
    if -dx <= particle_moved[0] < 0. and -dy <= particle_moved[1] < 0. and [-1, -1] in sco_n_1:
        stencil_flux[0, phase, 0, 0] += particle_fraction
        return
    elif -dx <= particle_moved[0] < 0. and 0. <= particle_moved[1] < dy and [-1, 0] in sco_n_1:
        stencil_flux[0, phase, 0, 1] += particle_fraction
        return
    elif -dx <= particle_moved[0] < 0. and dy <= particle_moved[1] <= 2 * dy and [-1, 1] in sco_n_1:
        stencil_flux[0, phase, 0, 2] += particle_fraction
        return
    elif 0. <= particle_moved[0] < dx and -dy <= particle_moved[1] < 0. and [0, -1] in sco_n_1:
        stencil_flux[0, phase, 1, 0] += particle_fraction
        return
    elif 0. <= particle_moved[0] < dx and dy <= particle_moved[1] <= 2 * dy and [0, 1] in sco_n_1:
        stencil_flux[0, phase, 1, 2] += particle_fraction
        return
    elif dx <= particle_moved[0] <= 2 * dx and -dy <= particle_moved[1] < 0. and [1, -1] in sco_n_1:
        stencil_flux[0, phase, 2, 0] += particle_fraction
        return
    elif dx <= particle_moved[0] <= 2 * dx and 0. <= particle_moved[1] < dy and [1, 0] in sco_n_1:
        stencil_flux[0, phase, 2, 1] += particle_fraction
        return
    elif dx <= particle_moved[0] <= 2 * dx and dy <= particle_moved[1] <= 2 * dy and [1, 1] in sco_n_1:
        stencil_flux[0, phase, 2, 2] += particle_fraction
        return
    ### STAY IN THE ORIGINAL CELL
    else:
        return

def accum_lag_p_flux_sco_1_shapely(particle_moved, phase, stencil_flux, particle_fraction, dx, dy, sco_n_1):
    out = 1.
    ### JUDGE IF INSIDE THE ORIGINAL CELLS (BOUNDARY NOT INCLUDED)
    if 0. < particle_moved[0] < dx and 0. < particle_moved[1] < dy:
        out = 0.
        return out
    ### JUDGE IF INSIDE THE NEIGHBORING CELLS (BOUNDARY NOT INCLUDED)
    elif particle_moved[0] < 0. and particle_moved[1] < 0.:
        if 0 in sco_n_1:
            stencil_flux[0, phase, 0, 0] += particle_fraction
        else:
            pass
        return out
    elif particle_moved[0] < 0. < particle_moved[1] < dy:
        if 1 in sco_n_1:
            stencil_flux[0, phase, 0, 1] += particle_fraction
        else:
            pass
        return out
    elif particle_moved[0] < 0. and dy < particle_moved[1]:
        if 2 in sco_n_1:
            stencil_flux[0, phase, 0, 2] += particle_fraction
        else:
            pass
        return out
    elif 0. < particle_moved[0] < dx and dy < particle_moved[1]:
        if 3 in sco_n_1:
            stencil_flux[0, phase, 1, 2] += particle_fraction
        else:
            pass
        return out
    elif dx < particle_moved[0] and dy < particle_moved[1]:
        if 4 in sco_n_1:
            stencil_flux[0, phase, 2, 2] += particle_fraction
        else:
            pass
        return out
    elif dx < particle_moved[0] and 0. < particle_moved[1] < dy:
        if 5 in sco_n_1:
            stencil_flux[0, phase, 2, 1] += particle_fraction
        else:
            pass
        return out
    elif dx < particle_moved[0] and particle_moved[1] < 0.:
        if 6 in sco_n_1:
            stencil_flux[0, phase, 2, 0] += particle_fraction
        else:
            pass
        return out
    elif dx > particle_moved[0] > 0. > particle_moved[1]:
        if 7 in sco_n_1:
            stencil_flux[0, phase, 1, 0] += particle_fraction
        else:
            pass
        return out
    ### JUDGE IF ON THE BOUNDARY
    elif LineString([(0., 0.),(0., dy)]).contains(Point(particle_moved[0], particle_moved[1])):
        if 1 in sco_n_1:
            stencil_flux[0, phase, 0, 1] += particle_fraction * 0.5
        else:
            pass
        out = 0.5
        return out
    elif LineString([(0., dy),(dx, dy)]).contains(Point(particle_moved[0], particle_moved[1])):
        if 3 in sco_n_1:
            stencil_flux[0, phase, 1, 2] += particle_fraction * 0.5
        else:
            pass
        out = 0.5
        return out
    elif LineString([(dx, dy),(dx, 0.)]).contains(Point(particle_moved[0], particle_moved[1])):
        if 5 in sco_n_1:
            stencil_flux[0, phase, 2, 1] += particle_fraction * 0.5
        else:
            pass
        out = 0.5
        return out
    elif LineString([(0., 0.),(dx, 0.)]).contains(Point(particle_moved[0], particle_moved[1])):
        if 7 in sco_n_1:
            stencil_flux[0, phase, 1, 0] += particle_fraction * 0.5
        else:
            pass
        out = 0.5
        return out
    elif LineString([(0., 0.),(0., -dy)]).contains(Point(particle_moved[0], particle_moved[1])):
        if 0 in sco_n_1:
            stencil_flux[0, phase, 0, 0] += particle_fraction * 0.5
        else:
            pass
        if 7 in sco_n_1:
            stencil_flux[0, phase, 1, 0] += particle_fraction * 0.5
        else:
            pass
        return out
    elif LineString([(0., 0.),(-dx, 0.)]).contains(Point(particle_moved[0], particle_moved[1])):
        if 0 in sco_n_1:
            stencil_flux[0, phase, 0, 0] += particle_fraction * 0.5
        else:
            pass
        if 1 in sco_n_1:
            stencil_flux[0, phase, 0, 1] += particle_fraction * 0.5
        else:
            pass
        return out
    elif LineString([(0., dy),(-dx, dy)]).contains(Point(particle_moved[0], particle_moved[1])):
        if 2 in sco_n_1:
            stencil_flux[0, phase, 0, 2] += particle_fraction * 0.5
        else:
            pass
        if 1 in sco_n_1:
            stencil_flux[0, phase, 0, 1] += particle_fraction * 0.5
        else:
            pass
        return out
    elif LineString([(0., dy),(0., 2 * dy)]).contains(Point(particle_moved[0], particle_moved[1])):
        if 2 in sco_n_1:
            stencil_flux[0, phase, 0, 2] += particle_fraction * 0.5
        else:
            pass
        if 3 in sco_n_1:
            stencil_flux[0, phase, 1, 2] += particle_fraction * 0.5
        else:
            pass
        return out
    elif LineString([(dx, dy),(dx, 2 * dy)]).contains(Point(particle_moved[0], particle_moved[1])):
        if 4 in sco_n_1:
            stencil_flux[0, phase, 2, 2] += particle_fraction * 0.5
        else:
            pass
        if 3 in sco_n_1:
            stencil_flux[0, phase, 1, 2] += particle_fraction * 0.5
        else:
            pass
        return out
    elif LineString([(dx, dy),(2 * dx, dy)]).contains(Point(particle_moved[0], particle_moved[1])):
        if 4 in sco_n_1:
            stencil_flux[0, phase, 2, 2] += particle_fraction * 0.5
        else:
            pass
        if 5 in sco_n_1:
            stencil_flux[0, phase, 2, 1] += particle_fraction * 0.5
        else:
            pass
        return out
    elif LineString([(dx, 0.),(2 * dx, 0.)]).contains(Point(particle_moved[0], particle_moved[1])):
        if 6 in sco_n_1:
            stencil_flux[0, phase, 2, 0] += particle_fraction * 0.5
        else:
            pass
        if 5 in sco_n_1:
            stencil_flux[0, phase, 2, 1] += particle_fraction * 0.5
        else:
            pass
        return out
    elif LineString([(dx, 0.),(dx, -dy)]).contains(Point(particle_moved[0], particle_moved[1])):
        if 6 in sco_n_1:
            stencil_flux[0, phase, 2, 0] += particle_fraction * 0.5
        else:
            pass
        if 7 in sco_n_1:
            stencil_flux[0, phase, 1, 0] += particle_fraction * 0.5
        else:
            pass
        return out
    ### JUDGE IF ON THE VERTEX
    elif particle_moved[0] == 0. and particle_moved[1] == 0.:
        if 0 in sco_n_1:
            stencil_flux[0, phase, 0, 0] += particle_fraction * 0.25
        else:
            pass
        if 1 in sco_n_1:
            stencil_flux[0, phase, 0, 1] += particle_fraction * 0.25
        else:
            pass
        if 7 in sco_n_1:
            stencil_flux[0, phase, 1, 0] += particle_fraction * 0.25
        else:
            pass
        out = 0.25
        return out
    elif particle_moved[0] == 0. and particle_moved[1] == dy:
        if 2 in sco_n_1:
            stencil_flux[0, phase, 0, 2] += particle_fraction * 0.25
        else:
            pass
        if 1 in sco_n_1:
            stencil_flux[0, phase, 0, 1] += particle_fraction * 0.25
        else:
            pass
        if 3 in sco_n_1:
            stencil_flux[0, phase, 1, 2] += particle_fraction * 0.25
        else:
            pass
        out = 0.25
        return out
    elif particle_moved[0] == dx and particle_moved[1] == dy:
        if 4 in sco_n_1:
            stencil_flux[0, phase, 2, 2] += particle_fraction * 0.25
        else:
            pass
        if 5 in sco_n_1:
            stencil_flux[0, phase, 2, 1] += particle_fraction * 0.25
        else:
            pass
        if 3 in sco_n_1:
            stencil_flux[0, phase, 1, 2] += particle_fraction * 0.25
        else:
            pass
        out = 0.25
        return out
    elif particle_moved[0] == dx and particle_moved[1] == 0.:
        if 6 in sco_n_1:
            stencil_flux[0, phase, 2, 0] += particle_fraction * 0.25
        else:
            pass
        if 5 in sco_n_1:
            stencil_flux[0, phase, 2, 1] += particle_fraction * 0.25
        else:
            pass
        if 7 in sco_n_1:
            stencil_flux[0, phase, 1, 0] += particle_fraction * 0.25
        else:
            pass
        out = 0.25
        return out
    else:
        print('reduce the CFL number!')
        out = False
        return out

def accum_lag_p_flux_sco_0_shapely(particle_moved, phase, stencil_flux, particle_fraction, dx, dy, sco_n_1):
    ### JUDGE IF INSIDE THE ORIGINAL CELLS (BOUNDARY NOT INCLUDED)
    if 0. < particle_moved[0] < dx and 0. < particle_moved[1] < dy:
        return
    ### JUDGE IF INSIDE THE NEIGHBORING CELLS (BOUNDARY NOT INCLUDED)
    elif particle_moved[0] < 0. and particle_moved[1] < 0.:
        if 0 in sco_n_1:
            stencil_flux[0, phase, 0, 0] += particle_fraction
        else:
            pass
        return
    elif particle_moved[0] < 0. < particle_moved[1] < dy:
        if 1 in sco_n_1:
            stencil_flux[0, phase, 0, 1] += particle_fraction
        else:
            pass
        return
    elif particle_moved[0] < 0. and dy < particle_moved[1]:
        if 2 in sco_n_1:
            stencil_flux[0, phase, 0, 2] += particle_fraction
        else:
            pass
        return
    elif 0. < particle_moved[0] < dx and dy < particle_moved[1]:
        if 3 in sco_n_1:
            stencil_flux[0, phase, 1, 2] += particle_fraction
        else:
            pass
        return
    elif dx < particle_moved[0] and dy < particle_moved[1]:
        if 4 in sco_n_1:
            stencil_flux[0, phase, 2, 2] += particle_fraction
        else:
            pass
        return
    elif dx < particle_moved[0] and 0. < particle_moved[1] < dy:
        if 5 in sco_n_1:
            stencil_flux[0, phase, 2, 1] += particle_fraction
        else:
            pass
        return
    elif dx < particle_moved[0] and particle_moved[1] < 0.:
        if 6 in sco_n_1:
            stencil_flux[0, phase, 2, 0] += particle_fraction
        else:
            pass
        return
    elif dx > particle_moved[0] > 0. > particle_moved[1]:
        if 7 in sco_n_1:
            stencil_flux[0, phase, 1, 0] += particle_fraction
        else:
            pass
        return
    ### JUDGE IF ON THE BOUNDARY
    elif LineString([(0., 0.),(0., dy)]).contains(Point(particle_moved[0], particle_moved[1])):
        if 1 in sco_n_1:
            stencil_flux[0, phase, 0, 1] += particle_fraction * 0.5
        else:
            pass
        return
    elif LineString([(0., dy),(dx, dy)]).contains(Point(particle_moved[0], particle_moved[1])):
        if 3 in sco_n_1:
            stencil_flux[0, phase, 1, 2] += particle_fraction * 0.5
        else:
            pass
        return
    elif LineString([(dx, dy),(dx, 0.)]).contains(Point(particle_moved[0], particle_moved[1])):
        if 5 in sco_n_1:
            stencil_flux[0, phase, 2, 1] += particle_fraction * 0.5
        else:
            pass
        return
    elif LineString([(0., 0.),(dx, 0.)]).contains(Point(particle_moved[0], particle_moved[1])):
        if 7 in sco_n_1:
            stencil_flux[0, phase, 1, 0] += particle_fraction * 0.5
        else:
            pass
        return
    elif LineString([(0., 0.),(0., -dy)]).contains(Point(particle_moved[0], particle_moved[1])):
        if 0 in sco_n_1:
            stencil_flux[0, phase, 0, 0] += particle_fraction * 0.5
        else:
            pass
        if 7 in sco_n_1:
            stencil_flux[0, phase, 1, 0] += particle_fraction * 0.5
        else:
            pass
        return
    elif LineString([(0., 0.),(-dx, 0.)]).contains(Point(particle_moved[0], particle_moved[1])):
        if 0 in sco_n_1:
            stencil_flux[0, phase, 0, 0] += particle_fraction * 0.5
        else:
            pass
        if 1 in sco_n_1:
            stencil_flux[0, phase, 0, 1] += particle_fraction * 0.5
        else:
            pass
        return
    elif LineString([(0., dy),(-dx, dy)]).contains(Point(particle_moved[0], particle_moved[1])):
        if 2 in sco_n_1:
            stencil_flux[0, phase, 0, 2] += particle_fraction * 0.5
        else:
            pass
        if 1 in sco_n_1:
            stencil_flux[0, phase, 0, 1] += particle_fraction * 0.5
        else:
            pass
        return
    elif LineString([(0., dy),(0., 2 * dy)]).contains(Point(particle_moved[0], particle_moved[1])):
        if 2 in sco_n_1:
            stencil_flux[0, phase, 0, 2] += particle_fraction * 0.5
        else:
            pass
        if 3 in sco_n_1:
            stencil_flux[0, phase, 1, 2] += particle_fraction * 0.5
        else:
            pass
        return
    elif LineString([(dx, dy),(dx, 2 * dy)]).contains(Point(particle_moved[0], particle_moved[1])):
        if 4 in sco_n_1:
            stencil_flux[0, phase, 2, 2] += particle_fraction * 0.5
        else:
            pass
        if 3 in sco_n_1:
            stencil_flux[0, phase, 1, 2] += particle_fraction * 0.5
        else:
            pass
        return
    elif LineString([(dx, dy),(2 * dx, dy)]).contains(Point(particle_moved[0], particle_moved[1])):
        if 4 in sco_n_1:
            stencil_flux[0, phase, 2, 2] += particle_fraction * 0.5
        else:
            pass
        if 5 in sco_n_1:
            stencil_flux[0, phase, 2, 1] += particle_fraction * 0.5
        else:
            pass
        return
    elif LineString([(dx, 0.),(2 * dx, 0.)]).contains(Point(particle_moved[0], particle_moved[1])):
        if 6 in sco_n_1:
            stencil_flux[0, phase, 2, 0] += particle_fraction * 0.5
        else:
            pass
        if 5 in sco_n_1:
            stencil_flux[0, phase, 2, 1] += particle_fraction * 0.5
        else:
            pass
        return
    elif LineString([(dx, 0.),(dx, -dy)]).contains(Point(particle_moved[0], particle_moved[1])):
        if 6 in sco_n_1:
            stencil_flux[0, phase, 2, 0] += particle_fraction * 0.5
        else:
            pass
        if 7 in sco_n_1:
            stencil_flux[0, phase, 1, 0] += particle_fraction * 0.5
        else:
            pass
        return
    ### JUDGE IF ON THE VERTEX
    elif particle_moved[0] == 0. and particle_moved[1] == 0.:
        if 0 in sco_n_1:
            stencil_flux[0, phase, 0, 0] += particle_fraction * 0.25
        else:
            pass
        if 1 in sco_n_1:
            stencil_flux[0, phase, 0, 1] += particle_fraction * 0.25
        else:
            pass
        if 7 in sco_n_1:
            stencil_flux[0, phase, 1, 0] += particle_fraction * 0.25
        else:
            pass
        return
    elif particle_moved[0] == 0. and particle_moved[1] == dy:
        if 2 in sco_n_1:
            stencil_flux[0, phase, 0, 2] += particle_fraction * 0.25
        else:
            pass
        if 1 in sco_n_1:
            stencil_flux[0, phase, 0, 1] += particle_fraction * 0.25
        else:
            pass
        if 3 in sco_n_1:
            stencil_flux[0, phase, 1, 2] += particle_fraction * 0.25
        else:
            pass
        return
    elif particle_moved[0] == dx and particle_moved[1] == dy:
        if 4 in sco_n_1:
            stencil_flux[0, phase, 2, 2] += particle_fraction * 0.25
        else:
            pass
        if 5 in sco_n_1:
            stencil_flux[0, phase, 2, 1] += particle_fraction * 0.25
        else:
            pass
        if 3 in sco_n_1:
            stencil_flux[0, phase, 1, 2] += particle_fraction * 0.25
        else:
            pass
        return
    elif particle_moved[0] == dx and particle_moved[1] == 0.:
        if 6 in sco_n_1:
            stencil_flux[0, phase, 2, 0] += particle_fraction * 0.25
        else:
            pass
        if 5 in sco_n_1:
            stencil_flux[0, phase, 2, 1] += particle_fraction * 0.25
        else:
            pass
        if 7 in sco_n_1:
            stencil_flux[0, phase, 1, 0] += particle_fraction * 0.25
        else:
            pass
        return
    else:
        print('reduce the CFL number!')
        return

def assign_face_velocity(U, nx, ny, face_vel_stencil, u_stencil):
    ### U_face = [left, right, bottom, top]
    U_face = np.zeros([4, nx, ny])
    for i in range(nx - 2 * (face_vel_stencil + u_stencil)):
        for j in range(ny - 2 * (face_vel_stencil + u_stencil)):
            U_face[0, i + (face_vel_stencil + u_stencil), j + (face_vel_stencil + u_stencil)] \
                = 0.5 * (U[0, i + face_vel_stencil + u_stencil - 1, j + face_vel_stencil + u_stencil] +
                         U[0, i + face_vel_stencil + u_stencil, j + face_vel_stencil + u_stencil])
            U_face[1, i + (face_vel_stencil + u_stencil), j + (face_vel_stencil + u_stencil)] \
                = 0.5 * (U[0, i + face_vel_stencil + u_stencil + 1, j + face_vel_stencil + u_stencil] +
                         U[0, i + face_vel_stencil + u_stencil, j + face_vel_stencil + u_stencil])
            U_face[2, i + (face_vel_stencil + u_stencil), j + (face_vel_stencil + u_stencil)] \
                = 0.5 * (U[1, i + face_vel_stencil + u_stencil, j + face_vel_stencil + u_stencil - 1] +
                         U[1, i + face_vel_stencil + u_stencil, j + face_vel_stencil + u_stencil])
            U_face[3, i + (face_vel_stencil + u_stencil), j + (face_vel_stencil + u_stencil)] \
                = 0.5 * (U[1, i + face_vel_stencil + u_stencil, j + face_vel_stencil + u_stencil + 1] +
                         U[1, i + face_vel_stencil + u_stencil, j + face_vel_stencil + u_stencil])
    return U_face

### ratio = void / (np.sum(in_fraction, axis=0) + 1e-8)
def redistribution_PARTICLE_uniform(PLIC_raw, in_fraction, out_fraction, nx, ny, ghost):
    n_l = [[-1, -1], [-1, 0], [-1, 1], [0, -1], [0, 1], [1, -1], [1, 0], [1, 1]]
    void = np.sum(out_fraction, axis=0)
    ratio = void / (np.sum(in_fraction, axis=0) + 1e-8)
    for i in range(nx - 2 * ghost):
        for j in range(ny - 2 * ghost):
            ### identification of overfilled cell
            if np.sum(PLIC_raw[:, i, j], axis=0) > 1.:
                ratio_over = 1. - min(ratio[i, j], 1.)
                over_fraction = ratio_over * in_fraction[:, i, j]
                # ### ADDING RANDOM ORDER TO REDISTRIBUTE EVENLY
                # bias = random.randint(0, len(over_fraction) - 1)
                ### redistribution for each phase separately
                for k in range(len(over_fraction)):
                    # k = (k + bias) % len(over_fraction)
                    ### find all the unfilled cells in the neighbors
                    d_list_1 = []
                    for n in range(len(n_l)):
                        if (np.sum(PLIC_raw[:, i + n_l[n][0], j + n_l[n][1]], axis=0) < 1. and
                                PLIC_raw[k, i + n_l[n][0], j + n_l[n][1]] > 0.01):
                            d_list_1.append(n_l[n])
                    ind = 0
                    while ind < len(d_list_1):
                        if (np.sum(PLIC_raw[:, i + d_list_1[ind][0], j + d_list_1[ind][1]], axis=0) + over_fraction[k] *
                                (1 / len(d_list_1)) > 1.):
                            d_list_1.pop(ind)
                            ind = 0
                        else:
                            ind += 1
                    if len(d_list_1) > 0:
                        ### redistribute to all the unfilled cells
                        for m in range(len(d_list_1)):
                            PLIC_raw[k, i + d_list_1[m][0], j + d_list_1[m][1]] += (1 / len(d_list_1)) * over_fraction[
                                k]
                        PLIC_raw[k, i, j] -= over_fraction[k]
                    else:
                        ### neighboring cells are all full-filled
                        pass

            else:
                pass

### THIS FUNCTION REDISTRIBUTE THE OVERFRACTION ACCORDING TO THE NEIGHBORS' VACANCY
def redistribution_PARTICLE_vacancy_target(PLIC_raw, in_fraction, out_fraction, nx, ny, ghost, tolerance):
    n_l = [[-1, -1], [-1, 0], [-1, 1], [0, -1], [0, 1], [1, -1], [1, 0], [1, 1]]
    void = np.sum(out_fraction, axis=0)
    ratio = void / (np.sum(in_fraction, axis=0) + 1e-8)
    for i in range(nx - 2 * ghost):
        for j in range(ny - 2 * ghost):
            if np.sum(PLIC_raw[:, i, j], axis=0) > 1. + tolerance:
                ratio_over = 1. - min(ratio[i, j], 1.)
                over_fraction = ratio_over * in_fraction[:, i, j]
                for k in range(len(over_fraction)):
                    vacancy_list = np.zeros([len(n_l), 2])
                    for n in range(len(n_l)):
                        if (np.sum(PLIC_raw[:, i + n_l[n][0], j + n_l[n][1]], axis=0) < 1. and
                                PLIC_raw[k, i + n_l[n][0], j + n_l[n][1]] > 0.01):
                            vacancy_list[n, 0] = 1
                            vacancy_list[n, 1] = 1 - np.sum(PLIC_raw[:, i + n_l[n][0], j + n_l[n][1]], axis=0)
                        else:
                            pass
                    for n in range(len(n_l)):
                        if vacancy_list[n, 0] == 1:
                            target_amount = over_fraction[k] * (vacancy_list[n, 1] / np.sum(vacancy_list[:, 1]))
                            dis_amount = min([target_amount, vacancy_list[n, 1]])
                            PLIC_raw[k, i + n_l[n][0], j + n_l[n][1]] += dis_amount
                            PLIC_raw[k, i, j] -= dis_amount
                            vacancy_list[n, 1] -= dis_amount
                            ### UPDATE VACANCY LIST
                            if abs(vacancy_list[n, 1]) < tolerance:
                                vacancy_list[n, 0] = 0
                            else:
                                pass
                        else:
                            pass

### THIS FUNCTION REDISTRIBUTE THE OVERFRACTION ACCORDING TO THE NEIGHBORS' VACANCY
def redistribution_PARTICLE_uni_plus_vacancy(PLIC_raw, in_fraction, out_fraction, nx, ny, ghost, tolerance):
    n_l = [[-1, -1], [-1, 0], [-1, 1], [0, -1], [0, 1], [1, -1], [1, 0], [1, 1]]
    void = np.sum(out_fraction, axis=0)
    ratio = void / (np.sum(in_fraction, axis=0) + 1e-8)
    ### UNIFORM REDISTRIBUTION
    for i in range(nx - 2 * ghost):
        for j in range(ny - 2 * ghost):
            ### identification of overfilled cell
            if np.sum(PLIC_raw[:, i, j], axis=0) > 1.:
                ratio_over = 1. - min(ratio[i, j], 1.)
                over_fraction = ratio_over * in_fraction[:, i, j]
                # ### ADDING RANDOM ORDER TO REDISTRIBUTE EVENLY
                bias = random.randint(0, len(over_fraction) - 1)
                ### redistribution for each phase separately
                for k in range(len(over_fraction)):
                    k = (k + bias) % len(over_fraction)
                    ### find all the unfilled cells in the neighbors
                    d_list_1 = []
                    for n in range(len(n_l)):
                        if (np.sum(PLIC_raw[:, i + n_l[n][0], j + n_l[n][1]], axis=0) < 1. and
                                PLIC_raw[k, i + n_l[n][0], j + n_l[n][1]] > 0.01):
                            d_list_1.append(n_l[n])
                    ind = 0
                    while ind < len(d_list_1):
                        if (np.sum(PLIC_raw[:, i + d_list_1[ind][0], j + d_list_1[ind][1]], axis=0) + over_fraction[k] *
                                (1 / len(d_list_1)) > 1.):
                            d_list_1.pop(ind)
                            ind = 0
                        else:
                            ind += 1
                    if len(d_list_1) > 0:
                        ### redistribute to all the unfilled cells
                        for m in range(len(d_list_1)):
                            PLIC_raw[k, i + d_list_1[m][0], j + d_list_1[m][1]] += (1 / len(d_list_1)) * over_fraction[
                                k]
                        PLIC_raw[k, i, j] -= over_fraction[k]
                    else:
                        ### neighboring cells are all full-filled
                        pass

            else:
                pass
    ### VACANCY TARGETED REDISTRIBUTION
    for i in range(nx - 2 * ghost):
        for j in range(ny - 2 * ghost):
            if np.sum(PLIC_raw[:, i, j], axis=0) > 1. + tolerance:
                ratio_over = 1. - min(ratio[i, j], 1.)
                over_fraction = ratio_over * in_fraction[:, i, j]
                for k in range(len(over_fraction)):
                    vacancy_list = np.zeros([len(n_l), 2])
                    for n in range(len(n_l)):
                        if (np.sum(PLIC_raw[:, i + n_l[n][0], j + n_l[n][1]], axis=0) < 1. and
                                PLIC_raw[k, i + n_l[n][0], j + n_l[n][1]] > 0.01):
                            vacancy_list[n, 0] = 1
                            vacancy_list[n, 1] = 1 - np.sum(PLIC_raw[:, i + n_l[n][0], j + n_l[n][1]], axis=0)
                        else:
                            pass
                    for n in range(len(n_l)):
                        if vacancy_list[n, 0] == 1:
                            target_amount = over_fraction[k] * (vacancy_list[n, 1] / np.sum(vacancy_list[:, 1]))
                            dis_amount = min([target_amount, vacancy_list[n, 1]])
                            PLIC_raw[k, i + n_l[n][0], j + n_l[n][1]] += dis_amount
                            PLIC_raw[k, i, j] -= dis_amount
                            vacancy_list[n, 1] -= dis_amount
                            ### UPDATE VACANCY LIST
                            if abs(vacancy_list[n, 1]) < tolerance:
                                vacancy_list[n, 0] = 0
                            else:
                                pass
                        else:
                            pass
### THIS FUNCTION IS A SIMPLIFIED VERSION OF SKIP CORE OPTIMIZATION (SCO) PROPOSED IN
### 'VOF with center of mass and Lagrangian particles (VCLP): a surface tracking and advection method for incompressible fluids'
### Richards C Sunny
### Theor. Comput. Fluid Dyn., 2022
def get_sco_tag(sf_stencil, tolerance):
    sco = 0
    num_phase = 0
    for k in range(len(sf_stencil)):
        if np.sum(sf_stencil[k, :, :]) > tolerance:
            num_phase += 1
        else:
            pass
    if num_phase > 1:
        sco = 1
    else:
        pass
    return sco

### HERE THE FUNCTION APPLIES A FILTER TO THE FIXING RATIO
def conservation_filter(conservation_r, tolerance):
    conservation_r_copy = conservation_r.copy()
    for i in range(len(conservation_r)):
        if abs(conservation_r[i]) <= tolerance:
            conservation_r_copy[i] = 0.
        else:
            pass
    return conservation_r_copy

### CALCULATE VERTEX VELOCITY USING LSR METHOD AND 3 * 3 VELOCITY STENCIL
### U_v = [u(i-0.5,j-0.5), u(i-0.5,j+0.5), u(i+0.5,j+0.5), u(i+0.5,j-0.5)]
### CAN BE OPTIMIZED BY STORING AS GLOBAL VERTEX VELOCITY FIELD, REDUCE BY 4 TIMES
def get_vertex_u_from_stencil(U_stencil, dx, dy):
    U_v = []
    ### u(i-0.5,j-0.5)
    A = np.array([[1 / (0.5 * dx), 1 / (0.5 * dy)],
                  [1 / (0.5 * dx), 1 / (-.5 * dy)],
                  [1 / (-.5 * dx), 1 / (-.5 * dy)],
                  [1 / (-.5 * dx), 1 / (0.5 * dy)]])
    b = np.array([[1 / (0.5 * dx) * U_stencil[0, 0, 0] + 1 / (0.5 * dy) * U_stencil[1, 0, 0]],
                  [1 / (0.5 * dx) * U_stencil[0, 0, 1] + 1 / (-.5 * dy) * U_stencil[1, 0, 1]],
                  [1 / (-.5 * dx) * U_stencil[0, 1, 1] + 1 / (-.5 * dy) * U_stencil[1, 1, 1]],
                  [1 / (-.5 * dx) * U_stencil[0, 1, 0] + 1 / (0.5 * dy) * U_stencil[1, 1, 0]]])
    x = np.linalg.inv(A.transpose().dot(A)).dot(A.transpose().dot(b))
    U_v.append(x)
    ### u(i-0.5,j+0.5)
    b = np.array([[1 / (0.5 * dx) * U_stencil[0, 0, 1] + 1 / (0.5 * dy) * U_stencil[1, 0, 1]],
                  [1 / (0.5 * dx) * U_stencil[0, 0, 2] + 1 / (-.5 * dy) * U_stencil[1, 0, 2]],
                  [1 / (-.5 * dx) * U_stencil[0, 1, 2] + 1 / (-.5 * dy) * U_stencil[1, 1, 2]],
                  [1 / (-.5 * dx) * U_stencil[0, 1, 1] + 1 / (0.5 * dy) * U_stencil[1, 1, 1]]])
    x = np.linalg.inv(A.transpose().dot(A)).dot(A.transpose().dot(b))
    U_v.append(x)
    ### u(i + 0.5, j + 0.5)
    b = np.array([[1 / (0.5 * dx) * U_stencil[0, 1, 1] + 1 / (0.5 * dy) * U_stencil[1, 1, 1]],
                  [1 / (0.5 * dx) * U_stencil[0, 1, 2] + 1 / (-.5 * dy) * U_stencil[1, 1, 2]],
                  [1 / (-.5 * dx) * U_stencil[0, 2, 2] + 1 / (-.5 * dy) * U_stencil[1, 2, 2]],
                  [1 / (-.5 * dx) * U_stencil[0, 2, 1] + 1 / (0.5 * dy) * U_stencil[1, 2, 1]]])
    x = np.linalg.inv(A.transpose().dot(A)).dot(A.transpose().dot(b))
    U_v.append(x)
    ### u(i+0.5,j-0.5)
    b = np.array([[1 / (0.5 * dx) * U_stencil[0, 1, 0] + 1 / (0.5 * dy) * U_stencil[1, 1, 0]],
                  [1 / (0.5 * dx) * U_stencil[0, 1, 1] + 1 / (-.5 * dy) * U_stencil[1, 1, 1]],
                  [1 / (-.5 * dx) * U_stencil[0, 2, 1] + 1 / (-.5 * dy) * U_stencil[1, 2, 1]],
                  [1 / (-.5 * dx) * U_stencil[0, 2, 0] + 1 / (0.5 * dy) * U_stencil[1, 2, 0]]])
    x = np.linalg.inv(A.transpose().dot(A)).dot(A.transpose().dot(b))
    U_v.append(x)
    return np.array(U_v)

def get_u_test(x, y, T, t):
    u = 2 * math.sin(math.pi * x) ** 2 * math.cos(math.pi * y) * math.sin(math.pi * y) * math.cos(math.pi * t / T)
    v = -2 * math.sin(math.pi * y) ** 2 * math.cos(math.pi * x) * math.sin(math.pi * x) * math.cos(math.pi * t / T)
    return u, v


# polygon = np.array([[0. , 0. ],
#                     [0.3, 0.5],
#                     [0.3, 1. ],
#                     [0. , 1. ]])
#
# ### generating random points in polygon
# points = gen_p_in_polygon(polygon, 100)
# fig, ax = plt.subplots()
# poly = Polygon(polygon, closed=True, color='orange')
# ax.add_patch(poly)
# ax.scatter(points[:, 0], points[:, 1], color='blue')
# plt.show()

# dx = 1/32
# dy = 1/32
# cells = []
# cell1 = np.array([[0.   , 0.   ],
#                   [0.   , dy   ],
#                   [.5*dx, dy   ],
#                   [.5*dx, .5*dy]])
# cell_1 = [1, cell1, 0]
# cells.append(cell_1)
# cell2 = np.array([[.5*dx, .5*dy],
#                   [.5*dx, dy   ],
#                   [dx   , dy   ],
#                   [dx   , 0.   ]])
# cell_2 = [0, cell2, 0]
# cells.append(cell_2)
# cell3 = np.array([[0.   , 0.   ],
#                   [.5*dx, .5*dy],
#                   [dx   , 0.   ]])
# cell_3 = [2, cell3, 0]
# cells.append(cell_3)
# Z = 32
# cfl = 0.1
# particles_all, particle_fractions = gen_ALL_p_in_rim(Z, cfl, dx, dy, cells)
# print(particle_fractions)
# particles_1 = np.array(particles_all[0])
# plt.scatter(particles_1[:, 0], particles_1[:, 1], color='red')
# particles_2 = np.array(particles_all[1])
# plt.scatter(particles_2[:, 0], particles_2[:, 1], color='yellow')
# particles_3 = np.array(particles_all[2])
# plt.scatter(particles_3[:, 0], particles_3[:, 1], color='blue')
# plt.show()


