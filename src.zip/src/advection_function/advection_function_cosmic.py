### created by Huang and Zhang
### HKUST FU's Lab
### 2025.01.16
import multiprocessing
from src.functions.functions import *
from src.functions.new_function import *
from multiprocessing import Queue
from src.functions.mp_function import *
from shapely.geometry.polygon import Polygon

### recons is the sub-recons ###########################################################################################

def get_flux_AX_mp2_exc(f, U, recons, dx, dy, dt, ghost, start_x, end_x, start_y, end_y):
    flux = np.zeros([4, 3, end_x - start_x, end_y - start_y])
    for i in range(end_x - start_x):
        for j in range(end_y - start_y):
            u = U[0, i + ghost + start_x, j + ghost + start_y]
            cal_cell_flux_m_mp2(f, flux, dx, dy, dt, recons, ghost, u, i, j, start_x, start_y)
            cal_cell_flux_p_mp2(f, flux, dx, dy, dt, recons, ghost, u, i, j, start_x, start_y)
    return flux

def get_flux_AY_mp2_exc(f, U, recons, dx, dy, dt, ghost, start_x, end_x, start_y, end_y):
    flux = np.zeros([4, 3, end_x - start_x, end_y - start_y])
    for i in range(end_x - start_x):
        for j in range(end_y - start_y):
            v = U[1, i + ghost + start_x, j + ghost + start_y]
            cal_cell_flux_s_mp2(f, flux, dx, dy, dt, recons, ghost, v, i, j, start_x, start_y)
            cal_cell_flux_n_mp2(f, flux, dx, dy, dt, recons, ghost, v, i, j, start_x, start_y)
    return flux

def get_flux_CX_mp2_exc(f, U, recons, dx, dy, dt, ghost, start_x, end_x, start_y, end_y):
    flux = np.zeros([4, 3, end_x - start_x, end_y - start_y])
    for i in range(end_x - start_x):
        for j in range(end_y - start_y):
            um = 0.5 * (U[0, i - 1 + ghost + start_x, j + ghost + start_y] +
                        U[0, i + ghost + start_x, j + ghost + start_y])
            cal_cell_flux_m_mp2(f, flux, dx, dy, dt, recons, ghost, um, i, j, start_x, start_y)
            up = 0.5 * (U[0, i + ghost + start_x, j + ghost + start_y] +
                        U[0, i + 1 + ghost + start_x, j + ghost + start_y])
            cal_cell_flux_p_mp2(f, flux, dx, dy, dt, recons, ghost, up, i, j, start_x, start_y)
    return flux

def get_flux_CY_mp2_exc(f, U, recons, dx, dy, dt, ghost, start_x, end_x, start_y, end_y):
    flux = np.zeros([4, 3, end_x - start_x, end_y - start_y])
    for i in range(end_x - start_x):
        for j in range(end_y - start_y):
            vs = 0.5 * (U[1, i + ghost + start_x, j + ghost + start_y] +
                        U[1, i + ghost + start_x, j - 1 + ghost + start_y])
            cal_cell_flux_s_mp2(f, flux, dx, dy, dt, recons, ghost, vs, i, j, start_x, start_y)
            vn = 0.5 * (U[1, i + ghost + start_x, j + ghost + start_y] +
                        U[1, i + ghost + start_x, j + 1 + ghost + start_y])
            cal_cell_flux_n_mp2(f, flux, dx, dy, dt, recons, ghost, vn, i, j, start_x, start_y)
    return flux

def cal_cell_flux_m_mp2(f, flux, dx, dy, dt, recons, ghost, u, i, j, start_x, start_y):
    V = dx * dy
    if u > 0:
        ### u > 0, consider the upwind grid
        ### universial coordinate
        pos = [i + start_x + ghost - 1, j + start_y + ghost]
        sf_stencil = get_sf(pos, f)
        phase_exist = judge_phase_num(sf_stencil)
        if len(phase_exist) > 1:
            normal = np.array([-1., 0.])
            loc_x = np.array([dx - u * dt, 0.])
            d = normal.dot(loc_x)
            ### because reconstruction has one more ghost layer
            cells = recons[i + 1 - 1][j + 1][1]['cells']
            for cell_ind in range(len(cells)):
                cell_info = cells[cell_ind]
                phase_ind = cell_info[0]
                cell = cell_info[1]
                intersections = plic_get_intersects(cell, normal, d)
                intersection_num = get_inters_num(intersections)
                if intersection_num < 3:
                    ### concave
                    volume = get_cut_volume_polygon_with_intersects(intersections, cell, normal, d)
                else:
                    cell_m = np.array([cell[0], cell[-1], cell[1]])
                    intersections_m = plic_get_intersects(cell_m, normal, d)
                    volume_m = get_cut_volume_polygon_with_intersects(intersections_m, cell_m, normal, d)
                    cell_p = cell[1:]
                    intersections_p = plic_get_intersects(cell_p, normal, d)
                    volume_p = get_cut_volume_polygon_with_intersects(intersections_p, cell_p, normal, d)
                    volume = volume_p - volume_m
                flux[0, phase_ind, i, j] += volume / V
        else:
            phase_ind = phase_exist[0]
            f_xm = u * dt * dy
            flux[0, phase_ind, i, j] += f_xm / V
    elif u < 0:
        ### u < 0, consider the center grid
        pos = [i + ghost + start_x, j + ghost + start_y]
        sf_stencil = get_sf(pos, f)
        phase_exist = judge_phase_num(sf_stencil)
        if len(phase_exist) > 1:
            normal = np.array([1., 0.])
            loc_x = np.array([-u * dt, 0.])
            d = normal.dot(loc_x)
            cells = recons[i + 1][j + 1][1]['cells']
            for cell_ind in range(len(cells)):
                cell_inf = cells[cell_ind]
                phase_ind = cell_inf[0]
                cell = cell_inf[1]
                intersections = plic_get_intersects(cell, normal, d)
                intersec_num = get_inters_num(intersections)
                if intersec_num < 3:
                    volume = get_cut_volume_polygon_with_intersects(intersections, cell, normal, d)
                else:
                    cell_m = np.array([cell[0], cell[-1], cell[1]])
                    intersections_m = plic_get_intersects(cell_m, normal, d)
                    volume_m = get_cut_volume_polygon_with_intersects(intersections_m, cell_m, normal, d)
                    cell_p = cell[1:]
                    intersections_p = plic_get_intersects(cell_p, normal, d)
                    volume_p = get_cut_volume_polygon_with_intersects(intersections_p, cell_p, normal, d)
                    volume = volume_p - volume_m
                flux[0, phase_ind, i, j] -= volume / V
        else:
            phase_ind = phase_exist[0]
            f_xm = -u * dt * dy
            flux[0, phase_ind, i, j] -= f_xm / V
    else:
        pass

def cal_cell_flux_p_mp2(f, flux, dx, dy, dt, recons, ghost, u, i, j, start_x, start_y):
    V = dx * dy
    if u > 0:
        ### u > 0, consider the center grid
        pos = [i + ghost + start_x, j + ghost + start_y]
        sf_stencil = get_sf(pos, f)
        phase_exist = judge_phase_num(sf_stencil)
        if len(phase_exist) > 1:
            normal = np.array([-1., 0.])
            loc_x = np.array([dx - u * dt, 0.])
            d = normal.dot(loc_x)
            cells = recons[i + 1][j + 1][1]['cells']
            for cell_ind in range(len(cells)):
                cell_inf = cells[cell_ind]
                phase_ind = cell_inf[0]
                cell = cell_inf[1]
                intersections = plic_get_intersects(cell, normal, d)
                intersec_num = get_inters_num(intersections)
                if intersec_num < 3:
                    volume = get_cut_volume_polygon_with_intersects(intersections, cell, normal, d)
                else:
                    cell_m = np.array([cell[0], cell[-1], cell[1]])
                    intersections_m = plic_get_intersects(cell_m, normal, d)
                    volume_m = get_cut_volume_polygon_with_intersects(intersections_m, cell_m, normal, d)
                    cell_p = cell[1:]
                    intersections_p = plic_get_intersects(cell_p, normal, d)
                    volume_p = get_cut_volume_polygon_with_intersects(intersections_p, cell_p, normal, d)
                    volume = volume_p - volume_m
                flux[1, phase_ind, i, j] -= volume / V
        else:
            phase_ind = phase_exist[0]
            f_xp = u * dt * dy
            flux[1, phase_ind, i, j] -= f_xp / V
    elif u < 0:
        ### u < 0, consider the downwind grid
        pos = [i + 1 + ghost + start_x, j + ghost + start_y]
        sf_stencil = get_sf(pos, f)
        phase_exist = judge_phase_num(sf_stencil)
        if len(phase_exist) > 1:
            normal = np.array([1., 0.])
            loc_x = np.array([-u * dt, 0.])
            d = normal.dot(loc_x)
            cells = recons[i + 1 + 1][j + 1][1]['cells']
            for cell_ind in range(len(cells)):
                cell_inf = cells[cell_ind]
                phase_ind = cell_inf[0]
                cell = cell_inf[1]
                intersections = plic_get_intersects(cell, normal, d)
                intersec_num = get_inters_num(intersections)
                if intersec_num < 3:
                    volume = get_cut_volume_polygon_with_intersects(intersections, cell, normal, d)
                else:
                    cell_m = np.array([cell[0], cell[-1], cell[1]])
                    intersections_m = plic_get_intersects(cell_m, normal, d)
                    volume_m = get_cut_volume_polygon_with_intersects(intersections_m, cell_m, normal, d)
                    cell_p = cell[1:]
                    intersections_p = plic_get_intersects(cell_p, normal, d)
                    volume_p = get_cut_volume_polygon_with_intersects(intersections_p, cell_p, normal, d)
                    volume = volume_p - volume_m
                flux[1, phase_ind, i, j] += volume / V
        else:
            phase_ind = phase_exist[0]
            f_xp = -u * dt * dy
            flux[1, phase_ind, i, j] += f_xp / V
    else:
        pass

def cal_cell_flux_s_mp2(f, flux, dx, dy, dt, recons, ghost, v, i, j, start_x, start_y):
    V = dx * dy
    if v > 0:
        ### v > 0, consider the upwind grid
        pos = [i + ghost + start_x, j - 1 + ghost + start_y]
        sf_stencil = get_sf(pos, f)
        phase_exist = judge_phase_num(sf_stencil)
        if len(phase_exist) > 1:
            normal = np.array([0., -1.])
            loc_x = np.array([0., dy - v * dt])
            d = normal.dot(loc_x)
            cells = recons[i + 1][j - 1 + 1][1]['cells']
            for cell_ind in range(len(cells)):
                cell_inf = cells[cell_ind]
                phase_ind = cell_inf[0]
                cell = cell_inf[1]
                intersections = plic_get_intersects(cell, normal, d)
                intersec_num = get_inters_num(intersections)
                if intersec_num < 3:
                    volume = get_cut_volume_polygon_with_intersects(intersections, cell, normal, d)
                else:
                    cell_m = np.array([cell[0], cell[-1], cell[1]])
                    intersections_m = plic_get_intersects(cell_m, normal, d)
                    volume_m = get_cut_volume_polygon_with_intersects(intersections_m, cell_m, normal, d)
                    cell_p = cell[1:]
                    intersections_p = plic_get_intersects(cell_p, normal, d)
                    volume_p = get_cut_volume_polygon_with_intersects(intersections_p, cell_p, normal, d)
                    volume = volume_p - volume_m
                flux[2, phase_ind, i, j] += volume / V
        else:
            phase_ind = phase_exist[0]
            f_ym = v * dt * dx
            flux[2, phase_ind, i, j] += f_ym / V
    elif v < 0:
        ### v < 0, consider the center grid
        pos = [i + ghost + start_x, j + ghost + start_y]
        sf_stencil = get_sf(pos, f)
        phase_exist = judge_phase_num(sf_stencil)
        if len(phase_exist) > 1:
            normal = np.array([0., 1.])
            loc_x = np.array([0., -v * dt])
            d = normal.dot(loc_x)
            cells = recons[i + 1][j + 1][1]['cells']
            for cell_ind in range(len(cells)):
                cell_inf = cells[cell_ind]
                phase_ind = cell_inf[0]
                cell = cell_inf[1]
                intersections = plic_get_intersects(cell, normal, d)
                intersec_num = get_inters_num(intersections)
                if intersec_num < 3:
                    volume = get_cut_volume_polygon_with_intersects(intersections, cell, normal, d)
                else:
                    cell_m = np.array([cell[0], cell[-1], cell[1]])
                    intersections_m = plic_get_intersects(cell_m, normal, d)
                    volume_m = get_cut_volume_polygon_with_intersects(intersections_m, cell_m, normal, d)
                    cell_p = cell[1:]
                    intersections_p = plic_get_intersects(cell_p, normal, d)
                    volume_p = get_cut_volume_polygon_with_intersects(intersections_p, cell_p, normal, d)
                    volume = volume_p - volume_m
                flux[2, phase_ind, i, j] -= volume / V
        else:
            phase_ind = phase_exist[0]
            f_ym = -v * dt * dx
            flux[2, phase_ind, i, j] -= f_ym / V
    else:
        pass

def cal_cell_flux_n_mp2(f, flux, dx, dy, dt, recons, ghost, v, i, j, start_x, start_y):
    V = dx * dy
    if v > 0:
        ### v > 0, consider the center grid
        pos = [i + ghost + start_x, j + ghost + start_y]
        sf_stencil = get_sf(pos, f)
        phase_exist = judge_phase_num(sf_stencil)
        if len(phase_exist) > 1:
            normal = np.array([0., -1.])
            loc_x = np.array([0., dy - v * dt])
            d = normal.dot(loc_x)
            # print(recons[i][j][0])
            cells = recons[i + 1][j + 1][1]['cells']
            for cell_ind in range(len(cells)):
                cell_inf = cells[cell_ind]
                phase_ind = cell_inf[0]
                cell = cell_inf[1]
                intersections = plic_get_intersects(cell, normal, d)
                intersec_num = get_inters_num(intersections)
                if intersec_num < 3:
                    volume = get_cut_volume_polygon_with_intersects(intersections, cell, normal, d)
                else:
                    cell_m = np.array([cell[0], cell[-1], cell[1]])
                    intersections_m = plic_get_intersects(cell_m, normal, d)
                    volume_m = get_cut_volume_polygon_with_intersects(intersections_m, cell_m, normal, d)
                    cell_p = cell[1:]
                    intersections_p = plic_get_intersects(cell_p, normal, d)
                    volume_p = get_cut_volume_polygon_with_intersects(intersections_p, cell_p, normal, d)
                    volume = volume_p - volume_m
                flux[3, phase_ind, i, j] -= volume / V
        else:
            phase_ind = phase_exist[0]
            f_yp = v * dt * dx
            flux[3, phase_ind, i, j] -= f_yp / V
    elif v < 0:
        ### v < 0, consider the downwind grid
        pos = [i + ghost + start_x, j + 1 + ghost + start_y]
        sf_stencil = get_sf(pos, f)
        phase_exist = judge_phase_num(sf_stencil)
        if len(phase_exist) > 1:
            normal = np.array([0., 1.])
            loc_x = np.array([0., -v * dt])
            d = normal.dot(loc_x)
            cells = recons[i + 1][j + 1 + 1][1]['cells']
            for cell_ind in range(len(cells)):
                cell_inf = cells[cell_ind]
                phase_ind = cell_inf[0]
                cell = cell_inf[1]
                intersections = plic_get_intersects(cell, normal, d)
                intersec_num = get_inters_num(intersections)
                if intersec_num < 3:
                    volume = get_cut_volume_polygon_with_intersects(intersections, cell, normal, d)
                else:
                    cell_m = np.array([cell[0], cell[-1], cell[1]])
                    intersections_m = plic_get_intersects(cell_m, normal, d)
                    volume_m = get_cut_volume_polygon_with_intersects(intersections_m, cell_m, normal, d)
                    cell_p = cell[1:]
                    intersections_p = plic_get_intersects(cell_p, normal, d)
                    volume_p = get_cut_volume_polygon_with_intersects(intersections_p, cell_p, normal, d)
                    volume = volume_p - volume_m
                flux[3, phase_ind, i, j] += volume / V
        else:
            phase_ind = phase_exist[0]
            f_yp = -v * dt * dx
            flux[3, phase_ind, i, j] += f_yp / V
    else:
        pass

########################## SHAPELY VERSION #############################################################################

def clip_polygon_shapely(polygon1, polygon2):
    polygon1 = np.array(polygon1)
    polygon_1_inp = []
    for i in range(len(polygon1)):
        polygon_1_inp.append((polygon1[i, 0], polygon1[i, 1]))
    polygon1 = Polygon(polygon_1_inp)
    polygon2 = np.array(polygon2)
    polygon_2_inp = []
    for i in range(len(polygon2)):
        polygon_2_inp.append((polygon2[i, 0], polygon2[i, 1]))
    polygon2 = Polygon(polygon_2_inp)
    intersection = polygon1.intersection(polygon2)
    return intersection

def get_flux_AX_shapely_mp2_exc(f, U, recons, dx, dy, dt, ghost, start_x, end_x, start_y, end_y):
    flux = np.zeros([4, 3, end_x - start_x, end_y - start_y])
    for i in range(end_x - start_x):
        for j in range(end_y - start_y):
            u = U[0, i + ghost + start_x, j + ghost + start_y]
            cal_cell_flux_m_shapely_mp2(f, flux, dx, dy, dt, recons, ghost, u, i, j, start_x, start_y)
            cal_cell_flux_p_shapely_mp2(f, flux, dx, dy, dt, recons, ghost, u, i, j, start_x, start_y)
    return flux

def get_flux_AY_shapely_mp2_exc(f, U, recons, dx, dy, dt, ghost, start_x, end_x, start_y, end_y):
    flux = np.zeros([4, 3, end_x - start_x, end_y - start_y])
    for i in range(end_x - start_x):
        for j in range(end_y - start_y):
            v = U[1, i + ghost + start_x, j + ghost + start_y]
            cal_cell_flux_s_shapely_mp2(f, flux, dx, dy, dt, recons, ghost, v, i, j, start_x, start_y)
            cal_cell_flux_n_shapely_mp2(f, flux, dx, dy, dt, recons, ghost, v, i, j, start_x, start_y)
    return flux

def get_flux_CX_shapely_mp2_exc(f, U, recons, dx, dy, dt, ghost, start_x, end_x, start_y, end_y):
    flux = np.zeros([4, 3, end_x - start_x, end_y - start_y])
    for i in range(end_x - start_x):
        for j in range(end_y - start_y):
            um = 0.5 * (U[0, i - 1 + ghost + start_x, j + ghost + start_y] +
                        U[0, i + ghost + start_x, j + ghost + start_y])
            cal_cell_flux_m_shapely_mp2(f, flux, dx, dy, dt, recons, ghost, um, i, j, start_x, start_y)
            up = 0.5 * (U[0, i + ghost + start_x, j + ghost + start_y] +
                        U[0, i + 1 + ghost + start_x, j + ghost + start_y])
            cal_cell_flux_p_shapely_mp2(f, flux, dx, dy, dt, recons, ghost, up, i, j, start_x, start_y)
    return flux

def get_flux_CY_shapely_mp2_exc(f, U, recons, dx, dy, dt, ghost, start_x, end_x, start_y, end_y):
    flux = np.zeros([4, 3, end_x - start_x, end_y - start_y])
    for i in range(end_x - start_x):
        for j in range(end_y - start_y):
            vs = 0.5 * (U[1, i + ghost + start_x, j + ghost + start_y] +
                        U[1, i + ghost + start_x, j - 1 + ghost + start_y])
            cal_cell_flux_s_shapely_mp2(f, flux, dx, dy, dt, recons, ghost, vs, i, j, start_x, start_y)
            vn = 0.5 * (U[1, i + ghost + start_x, j + ghost + start_y] +
                        U[1, i + ghost + start_x, j + 1 + ghost + start_y])
            cal_cell_flux_n_shapely_mp2(f, flux, dx, dy, dt, recons, ghost, vn, i, j, start_x, start_y)
    return flux

def cal_cell_flux_m_shapely_mp2(f, flux, dx, dy, dt, recons, ghost, u, i, j, start_x, start_y):
    V = dx * dy
    if u > 0:
        ### u > 0, consider the upwind grid
        ### universial coordinate
        pos = [i + start_x + ghost - 1, j + start_y + ghost]
        sf_stencil = get_sf(pos, f)
        phase_exist = judge_phase_num(sf_stencil)
        if len(phase_exist) > 1:
            do_region = np.array([[dx - u * dt, 0],
                                  [dx         , 0],
                                  [dx         , dy],
                                  [dx - u * dt, dy]])
            ### because reconstruction has one more ghost layer
            cells = recons[i + 1 - 1][j + 1][1]['cells']
            for cell_ind in range(len(cells)):
                cell_info = cells[cell_ind]
                phase_ind = cell_info[0]
                cell = cell_info[1]
                do_polygon = clip_polygon_shapely(do_region, cell)
                do_volume = do_polygon.area
                flux[0, phase_ind, i, j] += do_volume / V
        else:
            phase_ind = phase_exist[0]
            f_xm = u * dt * dy
            flux[0, phase_ind, i, j] += f_xm / V
    elif u < 0:
        ### u < 0, consider the center grid
        pos = [i + ghost + start_x, j + ghost + start_y]
        sf_stencil = get_sf(pos, f)
        phase_exist = judge_phase_num(sf_stencil)
        if len(phase_exist) > 1:
            do_region = np.array([[0.     , 0.],
                                  [-u * dt, 0.],
                                  [-u * dt, dy],
                                  [0.     , dy]])
            cells = recons[i + 1][j + 1][1]['cells']
            for cell_ind in range(len(cells)):
                cell_inf = cells[cell_ind]
                phase_ind = cell_inf[0]
                cell = cell_inf[1]
                do_polygon = clip_polygon_shapely(do_region, cell)
                do_volume = do_polygon.area
                flux[0, phase_ind, i, j] -= do_volume / V
        else:
            phase_ind = phase_exist[0]
            f_xm = -u * dt * dy
            flux[0, phase_ind, i, j] -= f_xm / V
    else:
        pass

def cal_cell_flux_p_shapely_mp2(f, flux, dx, dy, dt, recons, ghost, u, i, j, start_x, start_y):
    V = dx * dy
    if u > 0:
        ### u > 0, consider the center grid
        pos = [i + ghost + start_x, j + ghost + start_y]
        sf_stencil = get_sf(pos, f)
        phase_exist = judge_phase_num(sf_stencil)
        if len(phase_exist) > 1:
            do_region = np.array([[dx - u * dt, 0],
                                  [dx, 0],
                                  [dx, dy],
                                  [dx - u * dt, dy]])
            cells = recons[i + 1][j + 1][1]['cells']
            for cell_ind in range(len(cells)):
                cell_inf = cells[cell_ind]
                phase_ind = cell_inf[0]
                cell = cell_inf[1]
                do_polygon = clip_polygon_shapely(do_region, cell)
                do_volume = do_polygon.area
                flux[1, phase_ind, i, j] -= do_volume / V
        else:
            phase_ind = phase_exist[0]
            f_xp = u * dt * dy
            flux[1, phase_ind, i, j] -= f_xp / V
    elif u < 0:
        ### u < 0, consider the downwind grid
        pos = [i + 1 + ghost + start_x, j + ghost + start_y]
        sf_stencil = get_sf(pos, f)
        phase_exist = judge_phase_num(sf_stencil)
        if len(phase_exist) > 1:
            do_region = np.array([[0., 0.],
                                  [-u * dt, 0.],
                                  [-u * dt, dy],
                                  [0., dy]])
            cells = recons[i + 1 + 1][j + 1][1]['cells']
            for cell_ind in range(len(cells)):
                cell_inf = cells[cell_ind]
                phase_ind = cell_inf[0]
                cell = cell_inf[1]
                do_polygon = clip_polygon_shapely(do_region, cell)
                do_volume = do_polygon.area
                flux[1, phase_ind, i, j] += do_volume / V
        else:
            phase_ind = phase_exist[0]
            f_xp = -u * dt * dy
            flux[1, phase_ind, i, j] += f_xp / V
    else:
        pass

def cal_cell_flux_s_shapely_mp2(f, flux, dx, dy, dt, recons, ghost, v, i, j, start_x, start_y):
    V = dx * dy
    if v > 0:
        ### v > 0, consider the upwind grid
        pos = [i + ghost + start_x, j - 1 + ghost + start_y]
        sf_stencil = get_sf(pos, f)
        phase_exist = judge_phase_num(sf_stencil)
        if len(phase_exist) > 1:
            do_region = np.array([[0., dy - v * dt],
                                  [dx, dy - v * dt],
                                  [dx, dy],
                                  [0., dy]])
            cells = recons[i + 1][j - 1 + 1][1]['cells']
            for cell_ind in range(len(cells)):
                cell_inf = cells[cell_ind]
                phase_ind = cell_inf[0]
                cell = cell_inf[1]
                do_polygon = clip_polygon_shapely(do_region, cell)
                do_volume = do_polygon.area
                flux[2, phase_ind, i, j] += do_volume / V
        else:
            phase_ind = phase_exist[0]
            f_ym = v * dt * dx
            flux[2, phase_ind, i, j] += f_ym / V
    elif v < 0:
        ### v < 0, consider the center grid
        pos = [i + ghost + start_x, j + ghost + start_y]
        sf_stencil = get_sf(pos, f)
        phase_exist = judge_phase_num(sf_stencil)
        if len(phase_exist) > 1:
            do_region = np.array([[0., 0.],
                                  [dx, 0.],
                                  [dx, -v * dt],
                                  [0., -v * dt]])
            cells = recons[i + 1][j + 1][1]['cells']
            for cell_ind in range(len(cells)):
                cell_inf = cells[cell_ind]
                phase_ind = cell_inf[0]
                cell = cell_inf[1]
                do_polygon = clip_polygon_shapely(do_region, cell)
                do_volume = do_polygon.area
                flux[2, phase_ind, i, j] -= do_volume / V
        else:
            phase_ind = phase_exist[0]
            f_ym = -v * dt * dx
            flux[2, phase_ind, i, j] -= f_ym / V
    else:
        pass

def cal_cell_flux_n_shapely_mp2(f, flux, dx, dy, dt, recons, ghost, v, i, j, start_x, start_y):
    V = dx * dy
    if v > 0:
        ### v > 0, consider the center grid
        pos = [i + ghost + start_x, j + ghost + start_y]
        sf_stencil = get_sf(pos, f)
        phase_exist = judge_phase_num(sf_stencil)
        if len(phase_exist) > 1:
            do_region = np.array([[0., dy - v * dt],
                                  [dx, dy - v * dt],
                                  [dx, dy],
                                  [0., dy]])
            cells = recons[i + 1][j + 1][1]['cells']
            for cell_ind in range(len(cells)):
                cell_inf = cells[cell_ind]
                phase_ind = cell_inf[0]
                cell = cell_inf[1]
                do_polygon = clip_polygon_shapely(do_region, cell)
                do_volume = do_polygon.area
                flux[3, phase_ind, i, j] -= do_volume / V
        else:
            phase_ind = phase_exist[0]
            f_yp = v * dt * dx
            flux[3, phase_ind, i, j] -= f_yp / V
    elif v < 0:
        ### v < 0, consider the downwind grid
        pos = [i + ghost + start_x, j + 1 + ghost + start_y]
        sf_stencil = get_sf(pos, f)
        phase_exist = judge_phase_num(sf_stencil)
        if len(phase_exist) > 1:
            do_region = np.array([[0., 0.],
                                  [dx, 0.],
                                  [dx, -v * dt],
                                  [0., -v * dt]])
            cells = recons[i + 1][j + 1 + 1][1]['cells']
            for cell_ind in range(len(cells)):
                cell_inf = cells[cell_ind]
                phase_ind = cell_inf[0]
                cell = cell_inf[1]
                do_polygon = clip_polygon_shapely(do_region, cell)
                do_volume = do_polygon.area
                flux[3, phase_ind, i, j] += do_volume / V
        else:
            phase_ind = phase_exist[0]
            f_yp = -v * dt * dx
            flux[3, phase_ind, i, j] += f_yp / V
    else:
        pass










################################ OLD VERSION ##########################################################################

#######################################################################################################################
# def findflux_DP_PLIC(f, u, nx, ny, x, y, dx, dy, dt, ghost, toler, max_step, min_move, phase_num):
#     ### flux = [flux_x_m, flux_x_p, flux_y_m, flux_y_p]
#     flux = np.zeros([4, phase_num, nx, ny])
#     V = dx * dy
#     reconstruction = DP_PLIC_8(f, dx, dy, toler, max_step, min_move, 1, toler)
#     for i in range(2, len(x) - 2):
#         for j in range(2, len(y) - 2):
#             # print('The calculated cell is: ', [i, j])
#             if u[0] > 0:
#                 ### x- flux
#                 ### u > 0, consider the upwind grid
#                 grid_info = reconstruction[i - 1][j]
#                 phase_exist = grid_info[1]['phase_exist']
#                 if len(phase_exist) > 1:
#                     ### The grid is a multiphase grid
#                     normal = np.array([-1., 0.])
#                     ### reference to the lower-left (0, 0)
#                     loc_x = np.array([dx - u[0] * dt, 0.])
#                     # print('The advection polygon through: ', loc_x)
#                     d = normal.dot(loc_x)
#                     # print('The advection distance is: ', d)
#                     ### iterate through cells to find cut volume
#                     cells = grid_info[1]['cells']
#                     # print(cells)
#                     for cell_ind in range(len(cells)):
#                         cell_inf = cells[cell_ind]
#                         phase_ind = cell_inf[0]
#                         cell = cell_inf[1]
#                         # print('The uncut flux polygon for phase{} is: '.format(phase_ind), cell)
#                         intersections = plic_get_intersects(cell, normal, d)
#                         intersec_num = get_inters_num(intersections)
#                         if intersec_num < 3:
#                             ### if concave
#                             volume = get_cut_volume_polygon_with_intersects(intersections, cell, normal, d)
#                             # print('The flux volume for phase{} is: '.format(phase_ind), volume)
#                             flux[0, phase_ind, i, j] += volume / V
#                         else:
#                             ### if convex
#                             ### The only possible convex point is the triple point for structured mesh
#                             cell_m = np.array([cell[0], cell[-1], cell[1]])
#                             intersections_m = plic_get_intersects(cell_m, normal, d)
#                             volume_m = get_cut_volume_polygon_with_intersects(intersections_m, cell_m, normal, d)
#                             # print('The minus triangular cell is: \n', cell_m)
#                             ### construct polygon without triple point
#                             cell_p = cell[1:]
#                             intersections_p = plic_get_intersects(cell_p, normal, d)
#                             volume_p = get_cut_volume_polygon_with_intersects(intersections_p, cell_p, normal, d)
#                             # print('The fixed convex cell is: \n', cell_p)
#                             volume = volume_p - volume_m
#                             flux[0, phase_ind, i, j] += volume / V
#                             # print('The flux volume for phase{} is: '.format(phase_ind), volume)
#                 else:
#                     ### The grid is not a multiphase grid
#                     phase_ind = phase_exist[0]
#                     f_xm = u[0] * dt * dy
#                     flux[0, phase_ind, i, j] = f_xm / V
#                     # print('The flux volume for phase{} is: '.format(phase_ind), f_xm)
#                 ### x+ flux
#                 ### u > 0, consider the center grid
#                 grid_info = reconstruction[i][j]
#                 phase_exist = grid_info[1]['phase_exist']
#                 if len(phase_exist) > 1:
#                     normal = np.array([-1., 0.])
#                     loc_x = np.array([dx - u[0] * dt, 0.])
#                     # print('The advection polygon through: ', loc_x)
#                     d = normal.dot(loc_x)
#                     # print('The advection distance is: ', d)
#                     ### iterate through cells to find cut volume
#                     cells = grid_info[1]['cells']
#                     for cell_ind in range(len(cells)):
#                         cell_inf = cells[cell_ind]
#                         phase_ind = cell_inf[0]
#                         cell = cell_inf[1]
#                         # print('The uncut flux polygon for phase{} is: \n'.format(phase_ind), cell)
#                         intersections = plic_get_intersects(cell, normal, d)
#                         intersec_num = get_inters_num(intersections)
#                         if intersec_num < 3:
#                             ### if concave
#                             volume = get_cut_volume_polygon_with_intersects(intersections, cell, normal, d)
#                             # print('The flux volume for phase{} is: '.format(phase_ind), -volume)
#                             flux[1, phase_ind, i, j] -= volume / V
#                         else:
#                             ### if convex
#                             ### The only possible convex point is the triple point for structured mesh
#                             cell_m = np.array([cell[0], cell[-1], cell[1]])
#                             intersections_m = plic_get_intersects(cell_m, normal, d)
#                             volume_m = get_cut_volume_polygon_with_intersects(intersections_m, cell_m, normal, d)
#                             # print('The minus triangular cell is: \n', cell_m)
#                             ### construct polygon without triple point
#                             cell_p = cell[1:]
#                             intersections_p = plic_get_intersects(cell_p, normal, d)
#                             volume_p = get_cut_volume_polygon_with_intersects(intersections_p, cell_p, normal, d)
#                             # print('The fixed convex cell is: \n', cell_p)
#                             volume = volume_p - volume_m
#                             flux[0, phase_ind, i, j] -= volume / V
#                             # print('The flux volume for phase{} is: '.format(phase_ind), volume)
#                 else:
#                     ### The grid is not a multiphase grid
#                     phase_ind = phase_exist[0]
#                     f_xp = u[0] * dt * dy
#                     flux[1, phase_ind, i, j] = -f_xp / V
#                     # print('The flux volume for phase{} is: '.format(phase_ind), -f_xp)
#             elif u[0] < 0:
#                 ### x- flux
#                 ### u < 0, consider the center grid
#                 grid_info = reconstruction[i][j]
#                 phase_exist = grid_info[1]['phase_exist']
#                 if len(phase_exist) > 1:
#                     normal = np.array([1., 0.])
#                     ### reference to the lower-left (0, 0)
#                     loc_x = np.array([-u[0] * dt, 0.])
#                     d = normal.dot(loc_x)
#                     cells = grid_info[1]['cells']
#                     ### iterate through cells to find cut volume
#                     for cell_ind in range(len(cells)):
#                         cell_inf = cells[cell_ind]
#                         phase_ind = cell_inf[0]
#                         cell = cell_inf[1]
#                         intersections = plic_get_intersects(cell, normal, d)
#                         intersec_num = get_inters_num(intersections)
#                         if intersec_num < 3:
#                             ### if concave
#                             volume = get_cut_volume_polygon_with_intersects(intersections, cell, normal, d)
#                             flux[0, phase_ind, i, j] -= volume / V
#                         else:
#                             ### if convex
#                             ### The only possible convex point is the triple point for structured mesh
#                             cell_m = np.array([cell[0], cell[-1], cell[1]])
#                             intersections_m = plic_get_intersects(cell_m, normal, d)
#                             volume_m = get_cut_volume_polygon_with_intersects(intersections_m, cell_m, normal, d)
#                             # print('The minus triangular cell is: \n', cell_m)
#                             ### construct polygon without triple point
#                             cell_p = cell[1:]
#                             intersections_p = plic_get_intersects(cell_p, normal, d)
#                             volume_p = get_cut_volume_polygon_with_intersects(intersections_p, cell_p, normal, d)
#                             # print('The fixed convex cell is: \n', cell_p)
#                             volume = volume_p - volume_m
#                             flux[0, phase_ind, i, j] -= volume / V
#                 else:
#                     ### The grid is not a multiphase grid
#                     phase_ind = phase_exist[0]
#                     f_xm = -u[0] * dt * dy
#                     flux[0, phase_ind, i, j] = -f_xm / V
#                 ### x+ flux
#                 ### u < 0, consider the downwind grid
#                 grid_info = reconstruction[i + 1][j]
#                 phase_exist = grid_info[1]['phase_exist']
#                 if len(phase_exist) > 1:
#                     normal = np.array([1., 0.])
#                     ### reference to the lower-left (0, 0)
#                     loc_x = np.array([-u[0] * dt, 0.])
#                     d = normal.dot(loc_x)
#                     cells = grid_info[1]['cells']
#                     ### iterate through cells to find cut volume
#                     for cell_ind in range(len(cells)):
#                         cell_inf = cells[cell_ind]
#                         phase_ind = cell_inf[0]
#                         cell = cell_inf[1]
#                         intersections = plic_get_intersects(cell, normal, d)
#                         intersec_num = get_inters_num(intersections)
#                         if intersec_num < 3:
#                             ### if concave
#                             volume = get_cut_volume_polygon_with_intersects(intersections, cell, normal, d)
#                             flux[1, phase_ind, i, j] += volume / V
#                         else:
#                             ### if convex
#                             ### The only possible convex point is the triple point for structured mesh
#                             cell_m = np.array([cell[0], cell[-1], cell[1]])
#                             intersections_m = plic_get_intersects(cell_m, normal, d)
#                             volume_m = get_cut_volume_polygon_with_intersects(intersections_m, cell_m, normal, d)
#                             # print('The minus triangular cell is: \n', cell_m)
#                             ### construct polygon without triple point
#                             cell_p = cell[1:]
#                             intersections_p = plic_get_intersects(cell_p, normal, d)
#                             volume_p = get_cut_volume_polygon_with_intersects(intersections_p, cell_p, normal, d)
#                             # print('The fixed convex cell is: \n', cell_p)
#                             volume = volume_p - volume_m
#                             flux[1, phase_ind, i, j] += volume / V
#                 else:
#                     ### The grid is not a multiphase grid
#                     phase_ind = phase_exist[0]
#                     f_xp = -u[0] * dt * dy
#                     flux[1, phase_ind, i, j] = f_xp / V
#             else:
#                 pass
#             if u[1] > 0:
#                 ### y- flux
#                 ### v > 0, consider the upwind grid
#                 print(i, j)
#                 grid_info = reconstruction[i][j - 1]
#                 phase_exist = grid_info[1]['phase_exist']
#                 if len(phase_exist) > 1:
#                     normal = np.array([0., -1.])
#                     ### reference to the lower-left (0, 0)
#                     loc_x = np.array([0., dy - u[1] * dt])
#                     d = normal.dot(loc_x)
#                     cells = grid_info[1]['cells']
#                     ### iterate through cells to find cut volume
#                     for cell_ind in range(len(cells)):
#                         cell_inf = cells[cell_ind]
#                         phase_ind = cell_inf[0]
#                         cell = cell_inf[1]
#                         intersections = plic_get_intersects(cell, normal, d)
#                         intersec_num = get_inters_num(intersections)
#                         if intersec_num < 3:
#                             ### if concave
#                             volume = get_cut_volume_polygon_with_intersects(intersections, cell, normal, d)
#                             flux[2, phase_ind, i, j] += volume / V
#                         else:
#                             ### if convex
#                             ### The only possible convex point is the triple point for structured mesh
#                             cell_m = np.array([cell[0], cell[-1], cell[1]])
#                             intersections_m = plic_get_intersects(cell_m, normal, d)
#                             volume_m = get_cut_volume_polygon_with_intersects(intersections_m, cell_m, normal, d)
#                             # print('The minus triangular cell is: \n', cell_m)
#                             ### construct polygon without triple point
#                             cell_p = cell[1:]
#                             intersections_p = plic_get_intersects(cell_p, normal, d)
#                             volume_p = get_cut_volume_polygon_with_intersects(intersections_p, cell_p, normal, d)
#                             # print('The fixed convex cell is: \n', cell_p)
#                             volume = volume_p - volume_m
#                             flux[2, phase_ind, i, j] += volume / V
#                 else:
#                     ### The grid is not a multiphase grid
#                     phase_ind = phase_exist[0]
#                     f_ym = u[1] * dt * dx
#                     flux[2, phase_ind, i, j] = f_ym / V
#                 ### y+ flux
#                 ### v > 0, consider the center grid
#                 grid_info = reconstruction[i][j]
#                 phase_exist = grid_info[1]['phase_exist']
#                 if len(phase_exist) > 1:
#                     normal = np.array([0., -1.])
#                     ### reference to the lower-left (0, 0)
#                     loc_x = np.array([0., dy - u[1] * dt])
#                     d = normal.dot(loc_x)
#                     cells = grid_info[1]['cells']
#                     ### iterate through cells to find cut volume
#                     for cell_ind in range(len(cells)):
#                         cell_inf = cells[cell_ind]
#                         phase_ind = cell_inf[0]
#                         cell = cell_inf[1]
#                         intersections = plic_get_intersects(cell, normal, d)
#                         intersec_num = get_inters_num(intersections)
#                         if intersec_num < 3:
#                             ### if concave
#                             volume = get_cut_volume_polygon_with_intersects(intersections, cell, normal, d)
#                             flux[3, phase_ind, i, j] -= volume / V
#                         else:
#                             ### if convex
#                             ### The only possible convex point is the triple point for structured mesh
#                             cell_m = np.array([cell[0], cell[-1], cell[1]])
#                             intersections_m = plic_get_intersects(cell_m, normal, d)
#                             volume_m = get_cut_volume_polygon_with_intersects(intersections_m, cell_m, normal, d)
#                             # print('The minus triangular cell is: \n', cell_m)
#                             ### construct polygon without triple point
#                             cell_p = cell[1:]
#                             intersections_p = plic_get_intersects(cell_p, normal, d)
#                             volume_p = get_cut_volume_polygon_with_intersects(intersections_p, cell_p, normal, d)
#                             # print('The fixed convex cell is: \n', cell_p)
#                             volume = volume_p - volume_m
#                             flux[3, phase_ind, i, j] -= volume / V
#                 else:
#                     ### The grid is not a multiphase grid
#                     phase_ind = phase_exist[0]
#                     f_yp = u[1] * dt * dx
#                     flux[3, phase_ind, i, j] = -f_yp / V
#             elif u[1] < 0:
#                 ### y- flux
#                 ### v < 0, consider the center grid
#                 grid_info = reconstruction[i][j]
#                 phase_exist = grid_info[1]['phase_exist']
#                 if len(phase_exist) > 1:
#                     normal = np.array([0., 1.])
#                     ### reference to the lower-left (0, 0)
#                     loc_x = np.array([0., -u[1] * dt])
#                     d = normal.dot(loc_x)
#                     cells = grid_info[1]['cells']
#                     ### iterate through cells to find cut volume
#                     for cell_ind in range(len(cells)):
#                         cell_inf = cells[cell_ind]
#                         phase_ind = cell_inf[0]
#                         cell = cell_inf[1]
#                         intersections = plic_get_intersects(cell, normal, d)
#                         intersec_num = get_inters_num(intersections)
#                         if intersec_num < 3:
#                             ### if concave
#                             volume = get_cut_volume_polygon_with_intersects(intersections, cell, normal, d)
#                             flux[2, phase_ind, i, j] -= volume / V
#                         else:
#                             ### if convex
#                             ### The only possible convex point is the triple point for structured mesh
#                             cell_m = np.array([cell[0], cell[-1], cell[1]])
#                             intersections_m = plic_get_intersects(cell_m, normal, d)
#                             volume_m = get_cut_volume_polygon_with_intersects(intersections_m, cell_m, normal, d)
#                             # print('The minus triangular cell is: \n', cell_m)
#                             ### construct polygon without triple point
#                             cell_p = cell[1:]
#                             intersections_p = plic_get_intersects(cell_p, normal, d)
#                             volume_p = get_cut_volume_polygon_with_intersects(intersections_p, cell_p, normal, d)
#                             # print('The fixed convex cell is: \n', cell_p)
#                             volume = volume_p - volume_m
#                             flux[2, phase_ind, i, j] -= volume / V
#                 else:
#                     ### The grid is not a multiphase grid
#                     phase_ind = phase_exist[0]
#                     f_ym = -u[1] * dt * dx
#                     flux[2, phase_ind, i, j] = -f_ym / V
#                 ### y+ flux
#                 ### v < 0, consider the downwind grid
#                 grid_info = reconstruction[i][j + 1]
#                 phase_exist = grid_info[1]['phase_exist']
#                 if len(phase_exist) > 1:
#                     normal = np.array([0., 1.])
#                     ### reference to the lower-left (0, 0)
#                     loc_x = np.array([0., -u[1] * dt])
#                     d = normal.dot(loc_x)
#                     cells = grid_info[1]['cells']
#                     ### iterate through cells to find cut volume
#                     for cell_ind in range(len(cells)):
#                         cell_inf = cells[cell_ind]
#                         phase_ind = cell_inf[0]
#                         cell = cell_inf[1]
#                         intersections = plic_get_intersects(cell, normal, d)
#                         intersec_num = get_inters_num(intersections)
#                         if intersec_num < 3:
#                             ### if concave
#                             volume = get_cut_volume_polygon_with_intersects(intersections, cell, normal, d)
#                             flux[3, phase_ind, i, j] += volume / V
#                         else:
#                             ### if convex
#                             ### The only possible convex point is the triple point for structured mesh
#                             cell_m = np.array([cell[0], cell[-1], cell[1]])
#                             intersections_m = plic_get_intersects(cell_m, normal, d)
#                             volume_m = get_cut_volume_polygon_with_intersects(intersections_m, cell_m, normal, d)
#                             # print('The minus triangular cell is: \n', cell_m)
#                             ### construct polygon without triple point
#                             cell_p = cell[1:]
#                             intersections_p = plic_get_intersects(cell_p, normal, d)
#                             volume_p = get_cut_volume_polygon_with_intersects(intersections_p, cell_p, normal, d)
#                             # print('The fixed convex cell is: \n', cell_p)
#                             volume = volume_p - volume_m
#                             flux[3, phase_ind, i, j] += volume / V
#                 else:
#                     ### The grid is not a multiphase grid
#                     phase_ind = phase_exist[0]
#                     f_yp = -u[1] * dt * dx
#                     flux[3, phase_ind, i, j] = f_yp / V
#             else:
#                 pass
#     # print('The flux is: \n', flux[:, :, ghost:len(x) - ghost, ghost:len(y) - ghost])
#     return flux, reconstruction
#
# def findflux_PLIC(f, u, nx, ny, x, y, dx, dy, dt, ghost, toler, phase_num):
#     ### flux = [flux_x_m, flux_x_p, flux_y_m, flux_y_p]
#     reconstruction_result = np.zeros([len(f[0]), len(f[0, 0]), 1]).tolist()
#     ### first reconstruct using plic
#     for i in range(len(f[0])):
#         for j in range(len(f[0, 0])):
#             reconstruction_result[i][j].append({})
#     for i in range(1, len(f[0]) - 1):
#         for j in range(1, len(f[0, 0]) - 1):
#             pos = [i, j]
#             sf_stencil = get_sf(pos, f)
#             phase_exist = judge_phase_num(sf_stencil)
#             if len(phase_exist) > 1:
#                 # normals, ds, cells = PLIC_2d_tripleP_GSadv(sf_stencil, dx, dy, 1, 1, phase_exist, toler)
#                 normals, ds, cells = PLIC_2d_tripleP_linear(sf_stencil, dx, dy, 1, 1, phase_exist, toler)
#                 reconstruction_result[i][j][0] = 1
#                 reconstruction_result[i][j][1]['method'] = 'PLIC'
#                 reconstruction_result[i][j][1]['cells'] = cells
#                 reconstruction_result[i][j][1]['normals'] = normals
#                 reconstruction_result[i][j][1]['ds'] = ds
#
#     flux = np.zeros([4, phase_num, nx, ny])
#     V = dx * dy
#
#     for i in range(2, len(x) - 2):
#         for j in range(2, len(y) - 2):
#             # print('The calculated cell is: ', [i, j])
#             if u[0] > 0:
#                 ### x- flux
#                 ### u > 0, consider the upwind grid
#                 pos = [i - 1, j]
#                 sf_stencil = get_sf(pos, f)
#                 # print(sf_stencil)
#                 phase_exist = judge_phase_num(sf_stencil)
#                 # print('Phase import from {} is: \n'.format([i - 1, j]), phase_exist)
#                 if len(phase_exist) > 1:
#                     ### The grid is a multiphase grid
#                     normal = np.array([-1., 0.])
#                     loc_x = np.array([dx - u[0] * dt, 0.])
#                     # print('The advection polygon through: ', loc_x)
#                     d = normal.dot(loc_x)
#                     # print('The advection distance is: ', d)
#                     cells = reconstruction_result[i - 1][j][1]['cells']
#                     # print(cells)
#                     ### iterate through cells to find cut volume
#                     for cell_ind in range(len(cells)):
#                         cell_inf = cells[cell_ind]
#                         phase_ind = cell_inf[0]
#                         cell = cell_inf[1]
#                         # print('The uncut flux polygon for phase{} is: '.format(phase_ind), cell)
#                         intersections = plic_get_intersects(cell, normal, d)
#                         intersec_num = get_inters_num(intersections)
#                         if intersec_num < 3:
#                             ### if concave
#                             volume = get_cut_volume_polygon_with_intersects(intersections, cell, normal, d)
#                             # print('The flux volume for phase{} is: '.format(phase_ind), volume)
#                             flux[0, phase_ind, i, j] += volume / V
#                         else:
#                             ### if convex
#                             ### The only possible convex point is the triple point for structured mesh
#                             cell_m = np.array([cell[0], cell[-1], cell[1]])
#                             intersections_m = plic_get_intersects(cell_m, normal, d)
#                             volume_m = get_cut_volume_polygon_with_intersects(intersections_m, cell_m, normal, d)
#                             # print('The minus triangular cell is: \n', cell_m)
#                             ### construct polygon without triple point
#                             cell_p = cell[1:]
#                             intersections_p = plic_get_intersects(cell_p, normal, d)
#                             volume_p = get_cut_volume_polygon_with_intersects(intersections_p, cell_p, normal, d)
#                             # print('The fixed convex cell is: \n', cell_p)
#                             volume = volume_p - volume_m
#                             flux[0, phase_ind, i, j] += volume / V
#                             # print('The flux volume for phase{} is: '.format(phase_ind), volume)
#                 else:
#                     ### The grid is not a multiphase grid
#                     phase_ind = phase_exist[0]
#                     f_xm = u[0] * dt * dy
#                     flux[0, phase_ind, i, j] = f_xm / V
#                     # print('The flux volume for phase{} is: '.format(phase_ind), f_xm)
#                 ### x+ flux
#                 ### u > 0, consider the center grid
#                 pos = [i, j]
#                 sf_stencil = get_sf(pos, f)
#                 phase_exist = judge_phase_num(sf_stencil)
#                 # print('Phase exist from {} is: '.format([i, j]), phase_exist)
#                 if len(phase_exist) > 1:
#                     normal = np.array([-1., 0.])
#                     loc_x = np.array([dx - u[0] * dt, 0.])
#                     # print('The advection polygon through: ', loc_x)
#                     d = normal.dot(loc_x)
#                     # print('The advection distance is: ', d)
#                     cells = reconstruction_result[i][j][1]['cells']
#                     ### iterate through cells to find cut volume
#                     for cell_ind in range(len(cells)):
#                         cell_inf = cells[cell_ind]
#                         phase_ind = cell_inf[0]
#                         cell = cell_inf[1]
#                         # print('The uncut flux polygon for phase{} is: \n'.format(phase_ind), cell)
#                         intersections = plic_get_intersects(cell, normal, d)
#                         intersec_num = get_inters_num(intersections)
#                         if intersec_num < 3:
#                             ### if concave
#                             volume = get_cut_volume_polygon_with_intersects(intersections, cell, normal, d)
#                             # print('The flux volume for phase{} is: '.format(phase_ind), -volume)
#                             flux[1, phase_ind, i, j] -= volume / V
#                         else:
#                             ### if convex
#                             ### The only possible convex point is the triple point for structured mesh
#                             cell_m = np.array([cell[0], cell[-1], cell[1]])
#                             intersections_m = plic_get_intersects(cell_m, normal, d)
#                             volume_m = get_cut_volume_polygon_with_intersects(intersections_m, cell_m, normal, d)
#                             # print('The minus triangular cell is: \n', cell_m)
#                             ### construct polygon without triple point
#                             cell_p = cell[1:]
#                             intersections_p = plic_get_intersects(cell_p, normal, d)
#                             volume_p = get_cut_volume_polygon_with_intersects(intersections_p, cell_p, normal, d)
#                             # print('The fixed convex cell is: \n', cell_p)
#                             volume = volume_p - volume_m
#                             flux[0, phase_ind, i, j] -= volume / V
#                             # print('The flux volume for phase{} is: '.format(phase_ind), volume)
#                 else:
#                     ### The grid is not a multiphase grid
#                     phase_ind = phase_exist[0]
#                     f_xp = u[0] * dt * dy
#                     flux[1, phase_ind, i, j] = -f_xp / V
#                     # print('The flux volume for phase{} is: '.format(phase_ind), -f_xp)
#             elif u[0] < 0:
#                 ### x- flux
#                 ### u < 0, consider the center grid
#                 pos = [i, j]
#                 sf_stencil = get_sf(pos, f)
#                 phase_exist = judge_phase_num(sf_stencil)
#                 if len(phase_exist) > 1:
#                     normal = np.array([1., 0.])
#                     ### reference to the lower-left (0, 0)
#                     loc_x = np.array([-u[0] * dt, 0.])
#                     d = normal.dot(loc_x)
#                     cells = reconstruction_result[i][j][1]['cells']
#                     ### iterate through cells to find cut volume
#                     for cell_ind in range(len(cells)):
#                         cell_inf = cells[cell_ind]
#                         phase_ind = cell_inf[0]
#                         cell = cell_inf[1]
#                         intersections = plic_get_intersects(cell, normal, d)
#                         intersec_num = get_inters_num(intersections)
#                         if intersec_num < 3:
#                             ### if concave
#                             volume = get_cut_volume_polygon_with_intersects(intersections, cell, normal, d)
#                             flux[0, phase_ind, i, j] -= volume / V
#                         else:
#                             ### if convex
#                             ### The only possible convex point is the triple point for structured mesh
#                             cell_m = np.array([cell[0], cell[-1], cell[1]])
#                             intersections_m = plic_get_intersects(cell_m, normal, d)
#                             volume_m = get_cut_volume_polygon_with_intersects(intersections_m, cell_m, normal, d)
#                             # print('The minus triangular cell is: \n', cell_m)
#                             ### construct polygon without triple point
#                             cell_p = cell[1:]
#                             intersections_p = plic_get_intersects(cell_p, normal, d)
#                             volume_p = get_cut_volume_polygon_with_intersects(intersections_p, cell_p, normal, d)
#                             # print('The fixed convex cell is: \n', cell_p)
#                             volume = volume_p - volume_m
#                             flux[0, phase_ind, i, j] -= volume / V
#                 else:
#                     ### The grid is not a multiphase grid
#                     phase_ind = phase_exist[0]
#                     f_xm = -u[0] * dt * dy
#                     flux[0, phase_ind, i, j] = -f_xm / V
#                 ### x+ flux
#                 ### u < 0, consider the downwind grid
#                 pos = [i + 1, j]
#                 sf_stencil = get_sf(pos, f)
#                 phase_exist = judge_phase_num(sf_stencil)
#                 if len(phase_exist) > 1:
#                     ### The grid is a multiphase grid
#                     normal = np.array([1., 0.])
#                     ### reference to the lower-left (0, 0)
#                     loc_x = np.array([-u[0] * dt, 0.])
#                     d = normal.dot(loc_x)
#                     cells = reconstruction_result[i + 1][j][1]['cells']
#                     ### iterate through cells to find cut volume
#                     for cell_ind in range(len(cells)):
#                         cell_inf = cells[cell_ind]
#                         phase_ind = cell_inf[0]
#                         cell = cell_inf[1]
#                         intersections = plic_get_intersects(cell, normal, d)
#                         intersec_num = get_inters_num(intersections)
#                         if intersec_num < 3:
#                             ### if concave
#                             volume = get_cut_volume_polygon_with_intersects(intersections, cell, normal, d)
#                             flux[1, phase_ind, i, j] += volume / V
#                         else:
#                             ### if convex
#                             ### The only possible convex point is the triple point for structured mesh
#                             cell_m = np.array([cell[0], cell[-1], cell[1]])
#                             intersections_m = plic_get_intersects(cell_m, normal, d)
#                             volume_m = get_cut_volume_polygon_with_intersects(intersections_m, cell_m, normal, d)
#                             # print('The minus triangular cell is: \n', cell_m)
#                             ### construct polygon without triple point
#                             cell_p = cell[1:]
#                             intersections_p = plic_get_intersects(cell_p, normal, d)
#                             volume_p = get_cut_volume_polygon_with_intersects(intersections_p, cell_p, normal, d)
#                             # print('The fixed convex cell is: \n', cell_p)
#                             volume = volume_p - volume_m
#                             flux[1, phase_ind, i, j] += volume / V
#                 else:
#                     ### The grid is not a multiphase grid
#                     phase_ind = phase_exist[0]
#                     f_xp = -u[0] * dt * dy
#                     flux[1, phase_ind, i, j] = f_xp / V
#             else:
#                 pass
#             if u[1] > 0:
#                 ### y- flux
#                 ### v > 0, consider the upwind grid
#                 pos = [i, j - 1]
#                 sf_stencil = get_sf(pos, f)
#                 phase_exist = judge_phase_num(sf_stencil)
#                 if len(phase_exist) > 1:
#                     normal = np.array([0., -1.])
#                     ### reference to the lower-left (0, 0)
#                     loc_x = np.array([0., dy - u[1] * dt])
#                     d = normal.dot(loc_x)
#                     cells = reconstruction_result[i][j - 1][1]['cells']
#                     ### iterate through cells to find cut volume
#                     for cell_ind in range(len(cells)):
#                         cell_inf = cells[cell_ind]
#                         phase_ind = cell_inf[0]
#                         cell = cell_inf[1]
#                         intersections = plic_get_intersects(cell, normal, d)
#                         intersec_num = get_inters_num(intersections)
#                         if intersec_num < 3:
#                             ### if concave
#                             volume = get_cut_volume_polygon_with_intersects(intersections, cell, normal, d)
#                             flux[2, phase_ind, i, j] += volume / V
#                         else:
#                             ### if convex
#                             ### The only possible convex point is the triple point for structured mesh
#                             cell_m = np.array([cell[0], cell[-1], cell[1]])
#                             intersections_m = plic_get_intersects(cell_m, normal, d)
#                             volume_m = get_cut_volume_polygon_with_intersects(intersections_m, cell_m, normal, d)
#                             # print('The minus triangular cell is: \n', cell_m)
#                             ### construct polygon without triple point
#                             cell_p = cell[1:]
#                             intersections_p = plic_get_intersects(cell_p, normal, d)
#                             volume_p = get_cut_volume_polygon_with_intersects(intersections_p, cell_p, normal, d)
#                             # print('The fixed convex cell is: \n', cell_p)
#                             volume = volume_p - volume_m
#                             flux[2, phase_ind, i, j] += volume / V
#                 else:
#                     ### The grid is not a multiphase grid
#                     phase_ind = phase_exist[0]
#                     f_ym = u[1] * dt * dx
#                     flux[2, phase_ind, i, j] = f_ym / V
#                 ### y+ flux
#                 ### v > 0, consider the center grid
#                 pos = [i, j]
#                 sf_stencil = get_sf(pos, f)
#                 phase_exist = judge_phase_num(sf_stencil)
#                 if len(phase_exist) > 1:
#                     ### The grid is a multiphase grid
#                     normal = np.array([0., -1.])
#                     ### reference to the lower-left (0, 0)
#                     loc_x = np.array([0., dy - u[1] * dt])
#                     d = normal.dot(loc_x)
#                     cells = reconstruction_result[i][j][1]['cells']
#                     ### iterate through cells to find cut volume
#                     for cell_ind in range(len(cells)):
#                         cell_inf = cells[cell_ind]
#                         phase_ind = cell_inf[0]
#                         cell = cell_inf[1]
#                         intersections = plic_get_intersects(cell, normal, d)
#                         intersec_num = get_inters_num(intersections)
#                         if intersec_num < 3:
#                             ### if concave
#                             volume = get_cut_volume_polygon_with_intersects(intersections, cell, normal, d)
#                             flux[3, phase_ind, i, j] -= volume / V
#                         else:
#                             ### if convex
#                             ### The only possible convex point is the triple point for structured mesh
#                             cell_m = np.array([cell[0], cell[-1], cell[1]])
#                             intersections_m = plic_get_intersects(cell_m, normal, d)
#                             volume_m = get_cut_volume_polygon_with_intersects(intersections_m, cell_m, normal, d)
#                             # print('The minus triangular cell is: \n', cell_m)
#                             ### construct polygon without triple point
#                             cell_p = cell[1:]
#                             intersections_p = plic_get_intersects(cell_p, normal, d)
#                             volume_p = get_cut_volume_polygon_with_intersects(intersections_p, cell_p, normal, d)
#                             # print('The fixed convex cell is: \n', cell_p)
#                             volume = volume_p - volume_m
#                             flux[3, phase_ind, i, j] -= volume / V
#                 else:
#                     ### The grid is not a multiphase grid
#                     phase_ind = phase_exist[0]
#                     f_yp = u[1] * dt * dx
#                     flux[3, phase_ind, i, j] = -f_yp / V
#             elif u[1] < 0:
#                 ### y- flux
#                 ### v < 0, consider the center grid
#                 pos = [i, j]
#                 sf_stencil = get_sf(pos, f)
#                 phase_exist = judge_phase_num(sf_stencil)
#                 if len(phase_exist) > 1:
#                     ### The grid is a multiphase grid
#                     normal = np.array([0., 1.])
#                     ### reference to the lower-left (0, 0)
#                     loc_x = np.array([0., -u[1] * dt])
#                     d = normal.dot(loc_x)
#                     cells = reconstruction_result[i][j][1]['cells']
#                     ### iterate through cells to find cut volume
#                     for cell_ind in range(len(cells)):
#                         cell_inf = cells[cell_ind]
#                         phase_ind = cell_inf[0]
#                         cell = cell_inf[1]
#                         intersections = plic_get_intersects(cell, normal, d)
#                         intersec_num = get_inters_num(intersections)
#                         if intersec_num < 3:
#                             ### if concave
#                             volume = get_cut_volume_polygon_with_intersects(intersections, cell, normal, d)
#                             flux[2, phase_ind, i, j] -= volume / V
#                         else:
#                             ### if convex
#                             ### The only possible convex point is the triple point for structured mesh
#                             cell_m = np.array([cell[0], cell[-1], cell[1]])
#                             intersections_m = plic_get_intersects(cell_m, normal, d)
#                             volume_m = get_cut_volume_polygon_with_intersects(intersections_m, cell_m, normal, d)
#                             # print('The minus triangular cell is: \n', cell_m)
#                             ### construct polygon without triple point
#                             cell_p = cell[1:]
#                             intersections_p = plic_get_intersects(cell_p, normal, d)
#                             volume_p = get_cut_volume_polygon_with_intersects(intersections_p, cell_p, normal, d)
#                             # print('The fixed convex cell is: \n', cell_p)
#                             volume = volume_p - volume_m
#                             flux[2, phase_ind, i, j] -= volume / V
#                 else:
#                     ### The grid is not a multiphase grid
#                     phase_ind = phase_exist[0]
#                     f_ym = -u[1] * dt * dx
#                     flux[2, phase_ind, i, j] = -f_ym / V
#                 ### y+ flux
#                 ### v < 0, consider the downwind grid
#                 pos = [i, j + 1]
#                 sf_stencil = get_sf(pos, f)
#                 phase_exist = judge_phase_num(sf_stencil)
#                 if len(phase_exist) > 1:
#                     ### The grid is a multiphase grid
#                     normal = np.array([0., 1.])
#                     ### reference to the lower-left (0, 0)
#                     loc_x = np.array([0., -u[1] * dt])
#                     d = normal.dot(loc_x)
#                     cells = reconstruction_result[i][j + 1][1]['cells']
#                     ### iterate through cells to find cut volume
#                     for cell_ind in range(len(cells)):
#                         cell_inf = cells[cell_ind]
#                         phase_ind = cell_inf[0]
#                         cell = cell_inf[1]
#                         intersections = plic_get_intersects(cell, normal, d)
#                         intersec_num = get_inters_num(intersections)
#                         if intersec_num < 3:
#                             ### if concave
#                             volume = get_cut_volume_polygon_with_intersects(intersections, cell, normal, d)
#                             flux[3, phase_ind, i, j] += volume / V
#                         else:
#                             ### if convex
#                             ### The only possible convex point is the triple point for structured mesh
#                             cell_m = np.array([cell[0], cell[-1], cell[1]])
#                             intersections_m = plic_get_intersects(cell_m, normal, d)
#                             volume_m = get_cut_volume_polygon_with_intersects(intersections_m, cell_m, normal, d)
#                             # print('The minus triangular cell is: \n', cell_m)
#                             ### construct polygon without triple point
#                             cell_p = cell[1:]
#                             intersections_p = plic_get_intersects(cell_p, normal, d)
#                             volume_p = get_cut_volume_polygon_with_intersects(intersections_p, cell_p, normal, d)
#                             # print('The fixed convex cell is: \n', cell_p)
#                             volume = volume_p - volume_m
#                             flux[3, phase_ind, i, j] += volume / V
#                 else:
#                     ### The grid is not a multiphase grid
#                     phase_ind = phase_exist[0]
#                     f_yp = -u[1] * dt * dx
#                     flux[3, phase_ind, i, j] = f_yp / V
#             else:
#                 pass
#
#     # print('The flux is: \n', flux[:, :, ghost:len(x) - ghost, ghost:len(y) - ghost])
#     return flux, reconstruction_result

### calculate the flux across the left cell face
def cal_cell_flux_m(f, flux, u, i, j, V, dx, dy, dt, recons):
    if u > 0:
        ### u > 0, consider the upwind grid
        pos = [i - 1, j]
        sf_stencil = get_sf(pos, f)
        phase_exist = judge_phase_num(sf_stencil)
        if len(phase_exist) > 1:
            normal = np.array([-1., 0.])
            loc_x = np.array([dx - u * dt, 0.])
            d = normal.dot(loc_x)
            cells = recons[i - 1][j][1]['cells']
            for cell_ind in range(len(cells)):
                cell_info = cells[cell_ind]
                phase_ind = cell_info[0]
                cell = cell_info[1]
                intersections = plic_get_intersects(cell, normal, d)
                intersection_num = get_inters_num(intersections)
                if intersection_num < 3:
                    ### concave
                    volume = get_cut_volume_polygon_with_intersects(intersections, cell, normal, d)
                else:
                    cell_m = np.array([cell[0], cell[-1], cell[1]])
                    intersections_m = plic_get_intersects(cell_m, normal, d)
                    volume_m = get_cut_volume_polygon_with_intersects(intersections_m, cell_m, normal, d)
                    cell_p = cell[1:]
                    intersections_p = plic_get_intersects(cell_p, normal, d)
                    volume_p = get_cut_volume_polygon_with_intersects(intersections_p, cell_p, normal, d)
                    volume = volume_p - volume_m
                flux[0, phase_ind, i, j] += volume / V
        else:
            phase_ind = phase_exist[0]
            f_xm = u * dt * dy
            flux[0, phase_ind, i, j] += f_xm / V
    elif u < 0:
        ### u < 0, consider the center grid
        pos = [i, j]
        sf_stencil = get_sf(pos, f)
        phase_exist = judge_phase_num(sf_stencil)
        if len(phase_exist) > 1:
            normal = np.array([1., 0.])
            loc_x = np.array([-u * dt, 0.])
            d = normal.dot(loc_x)
            cells = recons[i][j][1]['cells']
            for cell_ind in range(len(cells)):
                cell_inf = cells[cell_ind]
                phase_ind = cell_inf[0]
                cell = cell_inf[1]
                intersections = plic_get_intersects(cell, normal, d)
                intersec_num = get_inters_num(intersections)
                if intersec_num < 3:
                    volume = get_cut_volume_polygon_with_intersects(intersections, cell, normal, d)
                else:
                    cell_m = np.array([cell[0], cell[-1], cell[1]])
                    intersections_m = plic_get_intersects(cell_m, normal, d)
                    volume_m = get_cut_volume_polygon_with_intersects(intersections_m, cell_m, normal, d)
                    cell_p = cell[1:]
                    intersections_p = plic_get_intersects(cell_p, normal, d)
                    volume_p = get_cut_volume_polygon_with_intersects(intersections_p, cell_p, normal, d)
                    volume = volume_p - volume_m
                flux[0, phase_ind, i, j] -= volume / V
        else:
            phase_ind = phase_exist[0]
            f_xm = -u * dt * dy
            flux[0, phase_ind, i, j] -= f_xm / V
    else:
        pass

### calculate the flux across the right cell face
def cal_cell_flux_p(f, flux, u, i, j, V, dx, dy, dt, recons):
    if u > 0:
        ### u > 0, consider the center grid
        pos = [i, j]
        sf_stencil = get_sf(pos, f)
        phase_exist = judge_phase_num(sf_stencil)
        if len(phase_exist) > 1:
            normal = np.array([-1., 0.])
            loc_x = np.array([dx - u * dt, 0.])
            d = normal.dot(loc_x)
            cells = recons[i][j][1]['cells']
            for cell_ind in range(len(cells)):
                cell_inf = cells[cell_ind]
                phase_ind = cell_inf[0]
                cell = cell_inf[1]
                intersections = plic_get_intersects(cell, normal, d)
                intersec_num = get_inters_num(intersections)
                if intersec_num < 3:
                    volume = get_cut_volume_polygon_with_intersects(intersections, cell, normal, d)
                else:
                    cell_m = np.array([cell[0], cell[-1], cell[1]])
                    intersections_m = plic_get_intersects(cell_m, normal, d)
                    volume_m = get_cut_volume_polygon_with_intersects(intersections_m, cell_m, normal, d)
                    cell_p = cell[1:]
                    intersections_p = plic_get_intersects(cell_p, normal, d)
                    volume_p = get_cut_volume_polygon_with_intersects(intersections_p, cell_p, normal, d)
                    volume = volume_p - volume_m
                flux[1, phase_ind, i, j] -= volume / V
        else:
            phase_ind = phase_exist[0]
            f_xp = u * dt * dy
            flux[1, phase_ind, i, j] -= f_xp / V
    elif u < 0:
        ### u < 0, consider the downwind grid
        pos = [i + 1, j]
        sf_stencil = get_sf(pos, f)
        phase_exist = judge_phase_num(sf_stencil)
        if len(phase_exist) > 1:
            normal = np.array([1., 0.])
            loc_x = np.array([-u * dt, 0.])
            d = normal.dot(loc_x)
            cells = recons[i + 1][j][1]['cells']
            for cell_ind in range(len(cells)):
                cell_inf = cells[cell_ind]
                phase_ind = cell_inf[0]
                cell = cell_inf[1]
                intersections = plic_get_intersects(cell, normal, d)
                intersec_num = get_inters_num(intersections)
                if intersec_num < 3:
                    volume = get_cut_volume_polygon_with_intersects(intersections, cell, normal, d)
                else:
                    cell_m = np.array([cell[0], cell[-1], cell[1]])
                    intersections_m = plic_get_intersects(cell_m, normal, d)
                    volume_m = get_cut_volume_polygon_with_intersects(intersections_m, cell_m, normal, d)
                    cell_p = cell[1:]
                    intersections_p = plic_get_intersects(cell_p, normal, d)
                    volume_p = get_cut_volume_polygon_with_intersects(intersections_p, cell_p, normal, d)
                    volume = volume_p - volume_m
                flux[1, phase_ind, i, j] += volume / V
        else:
            phase_ind = phase_exist[0]
            f_xp = -u * dt * dy
            flux[1, phase_ind, i, j] += f_xp / V
    else:
        pass

### calculate the flux across the south cell face
def cal_cell_flux_s(f, flux, v, i, j, V, dx, dy, dt, recons):
    if v > 0:
        ### v > 0, consider the upwind grid
        pos = [i, j - 1]
        sf_stencil = get_sf(pos, f)
        phase_exist = judge_phase_num(sf_stencil)
        if len(phase_exist) > 1:
            normal = np.array([0., -1.])
            loc_x = np.array([0., dy - v * dt])
            d = normal.dot(loc_x)
            cells = recons[i][j - 1][1]['cells']
            for cell_ind in range(len(cells)):
                cell_inf = cells[cell_ind]
                phase_ind = cell_inf[0]
                cell = cell_inf[1]
                intersections = plic_get_intersects(cell, normal, d)
                intersec_num = get_inters_num(intersections)
                if intersec_num < 3:
                    volume = get_cut_volume_polygon_with_intersects(intersections, cell, normal, d)
                else:
                    cell_m = np.array([cell[0], cell[-1], cell[1]])
                    intersections_m = plic_get_intersects(cell_m, normal, d)
                    volume_m = get_cut_volume_polygon_with_intersects(intersections_m, cell_m, normal, d)
                    cell_p = cell[1:]
                    intersections_p = plic_get_intersects(cell_p, normal, d)
                    volume_p = get_cut_volume_polygon_with_intersects(intersections_p, cell_p, normal, d)
                    volume = volume_p - volume_m
                flux[2, phase_ind, i, j] += volume / V
        else:
            phase_ind = phase_exist[0]
            f_ym = v * dt * dx
            flux[2, phase_ind, i, j] += f_ym / V
    elif v < 0:
        ### v < 0, consider the center grid
        pos = [i, j]
        sf_stencil = get_sf(pos, f)
        phase_exist = judge_phase_num(sf_stencil)
        if len(phase_exist) > 1:
            normal = np.array([0., 1.])
            loc_x = np.array([0., -v * dt])
            d = normal.dot(loc_x)
            cells = recons[i][j][1]['cells']
            for cell_ind in range(len(cells)):
                cell_inf = cells[cell_ind]
                phase_ind = cell_inf[0]
                cell = cell_inf[1]
                intersections = plic_get_intersects(cell, normal, d)
                intersec_num = get_inters_num(intersections)
                if intersec_num < 3:
                    volume = get_cut_volume_polygon_with_intersects(intersections, cell, normal, d)
                else:
                    cell_m = np.array([cell[0], cell[-1], cell[1]])
                    intersections_m = plic_get_intersects(cell_m, normal, d)
                    volume_m = get_cut_volume_polygon_with_intersects(intersections_m, cell_m, normal, d)
                    cell_p = cell[1:]
                    intersections_p = plic_get_intersects(cell_p, normal, d)
                    volume_p = get_cut_volume_polygon_with_intersects(intersections_p, cell_p, normal, d)
                    volume = volume_p - volume_m
                flux[2, phase_ind, i, j] -= volume / V
        else:
            phase_ind = phase_exist[0]
            f_ym = -v * dt * dx
            flux[2, phase_ind, i, j] -= f_ym / V
    else:
        pass

### calculate the flux across the north cell face
def cal_cell_flux_n(f, flux, v, i, j, V, dx, dy, dt, recons):
    # print(i, j)
    if v > 0:
        ### v > 0, consider the center grid
        pos = [i, j]
        sf_stencil = get_sf(pos, f)
        phase_exist = judge_phase_num(sf_stencil)
        if len(phase_exist) > 1:
            normal = np.array([0., -1.])
            loc_x = np.array([0., dy - v * dt])
            d = normal.dot(loc_x)
            # print(recons[i][j][0])
            cells = recons[i][j][1]['cells']
            for cell_ind in range(len(cells)):
                cell_inf = cells[cell_ind]
                phase_ind = cell_inf[0]
                cell = cell_inf[1]
                intersections = plic_get_intersects(cell, normal, d)
                intersec_num = get_inters_num(intersections)
                if intersec_num < 3:
                    volume = get_cut_volume_polygon_with_intersects(intersections, cell, normal, d)
                else:
                    cell_m = np.array([cell[0], cell[-1], cell[1]])
                    intersections_m = plic_get_intersects(cell_m, normal, d)
                    volume_m = get_cut_volume_polygon_with_intersects(intersections_m, cell_m, normal, d)
                    cell_p = cell[1:]
                    intersections_p = plic_get_intersects(cell_p, normal, d)
                    volume_p = get_cut_volume_polygon_with_intersects(intersections_p, cell_p, normal, d)
                    volume = volume_p - volume_m
                flux[3, phase_ind, i, j] -= volume / V
        else:
            phase_ind = phase_exist[0]
            f_yp = v * dt * dx
            flux[3, phase_ind, i, j] -= f_yp / V
    elif v < 0:
        ### v < 0, consider the downwind grid
        pos = [i, j + 1]
        sf_stencil = get_sf(pos, f)
        phase_exist = judge_phase_num(sf_stencil)
        if len(phase_exist) > 1:
            normal = np.array([0., 1.])
            loc_x = np.array([0., -v * dt])
            d = normal.dot(loc_x)
            cells = recons[i][j + 1][1]['cells']
            for cell_ind in range(len(cells)):
                cell_inf = cells[cell_ind]
                phase_ind = cell_inf[0]
                cell = cell_inf[1]
                intersections = plic_get_intersects(cell, normal, d)
                intersec_num = get_inters_num(intersections)
                if intersec_num < 3:
                    volume = get_cut_volume_polygon_with_intersects(intersections, cell, normal, d)
                else:
                    cell_m = np.array([cell[0], cell[-1], cell[1]])
                    intersections_m = plic_get_intersects(cell_m, normal, d)
                    volume_m = get_cut_volume_polygon_with_intersects(intersections_m, cell_m, normal, d)
                    cell_p = cell[1:]
                    intersections_p = plic_get_intersects(cell_p, normal, d)
                    volume_p = get_cut_volume_polygon_with_intersects(intersections_p, cell_p, normal, d)
                    volume = volume_p - volume_m
                flux[3, phase_ind, i, j] += volume / V
        else:
            phase_ind = phase_exist[0]
            f_yp = -v * dt * dx
            flux[3, phase_ind, i, j] += f_yp / V
    else:
        pass

### get the flux based on the x direction split scheme
### The advective-form operator is based on the cell-centered velocity
### and is not conservative

def get_flux_AX(f, U, dx, dy, dt, recons, V):
    flux = np.zeros([4, len(f), len(f[0]), len(f[0, 0])])
    for i in range(2, len(f[0]) - 2):
        for j in range(2, len(f[0, 0]) - 2):
            u = U[0, i, j]
            cal_cell_flux_m(f, flux, u, i, j, V, dx, dy, dt, recons)
            cal_cell_flux_p(f, flux, u, i, j, V, dx, dy, dt, recons)
    return flux

def get_flux_AY(f, U, dx, dy, dt, recons, V):
    flux = np.zeros([4, len(f), len(f[0]), len(f[0, 0])])
    for i in range(2, len(f[0]) - 2):
        for j in range(2, len(f[0, 0]) - 2):
            v = U[1, i, j]
            cal_cell_flux_s(f, flux, v, i, j, V, dx, dy, dt, recons)
            cal_cell_flux_n(f, flux, v, i, j, V, dx, dy, dt, recons)
    return flux

def get_flux_CX(f, U, dx, dy, dt, recons, V):
    flux = np.zeros([4, len(f), len(f[0]), len(f[0, 0])])
    for i in range(2, len(f[0]) - 2):
        for j in range(2, len(f[0, 0]) - 2):
            um = 0.5 * (U[0, i - 1, j] + U[0, i, j])
            cal_cell_flux_m(f, flux, um, i, j, V, dx, dy, dt, recons)
            up = 0.5 * (U[0, i, j] + U[0, i + 1, j])
            cal_cell_flux_p(f, flux, up, i, j, V, dx, dy, dt, recons)
    return flux

def get_flux_CY(f, U, dx, dy, dt, recons, V):
    flux = np.zeros([4, len(f), len(f[0]), len(f[0, 0])])
    for i in range(2, len(f[0]) - 2):
        for j in range(2, len(f[0, 0]) - 2):
            vs = 0.5 * (U[1, i, j] + U[1, i, j - 1])
            cal_cell_flux_s(f, flux, vs, i, j, V, dx, dy, dt, recons)
            vn = 0.5 * (U[1, i, j] + U[1, i, j + 1])
            cal_cell_flux_n(f, flux, vn, i, j, V, dx, dy, dt, recons)
    return flux

############################################### old multiprocessing version ###########################################
def get_flux_AX_mp(f, U, dx, dy, dt, recons, num_p):
    ### build the manager dictionary
    flux = np.zeros([4, len(f), len(f[0]), len(f[0, 0])])
    # queL = [Queue(), Queue(), Queue()]
    manager = multiprocessing.Manager()
    return_dict = manager.dict()
    return_dict['flux'] = flux
    que = Queue()
    flux_ghost = 2
    x_parts, y_parts = divide_domain(len(f[0]) - 2 * flux_ghost, len(f[0, 0]) - 2 * flux_ghost, num_p)
    info = {'f': f,
            'U': U,
            'dx': dx,
            'dy': dy,
            'dt': dt,
            'recons': recons,
            'flux_ghost': flux_ghost,
            'x_parts': x_parts,
            'y_parts': y_parts}
    processes = create_processes_flux(get_flux_AX_mp_exc, combine_results_flux, info, que, return_dict)
    flux = start_and_join_processes_flux(processes, return_dict)
    return flux

def get_flux_AX_mp_exc(info, que, start_x, end_x, start_y, end_y):
    sub_flux = np.zeros([4, 3, end_x - start_x, end_y - start_y])
    flux_ghost = info['flux_ghost']
    U = info['U']
    for i in range(end_x - start_x):
        for j in range(end_y - start_y):
            u = U[0, i + flux_ghost + start_x, j + flux_ghost + start_y]
            cal_cell_flux_m_mp(info, sub_flux, u, i, j, start_x, start_y)
            cal_cell_flux_p_mp(info, sub_flux, u, i, j, start_x, start_y)
    que.put({'sub_result': sub_flux[:, 0, :, :], 'phase': 0,
                'start_x': start_x, 'end_x': end_x, 'start_y': start_y, 'end_y': end_y})
    que.put({'sub_result': sub_flux[:, 1, :, :], 'phase': 1,
                'start_x': start_x, 'end_x': end_x, 'start_y': start_y, 'end_y': end_y})
    que.put({'sub_result': sub_flux[:, 2, :, :], 'phase': 2,
                'start_x': start_x, 'end_x': end_x, 'start_y': start_y, 'end_y': end_y})

def get_flux_AY_mp(f, U, dx, dy, dt, recons, num_p):
    ### build the manager dictionary
    flux = np.zeros([4, len(f), len(f[0]), len(f[0, 0])])
    manager = multiprocessing.Manager()
    return_dict = manager.dict()
    return_dict['flux'] = flux
    que = Queue()
    flux_ghost = 2
    x_parts, y_parts = divide_domain(len(f[0]) - 2 * flux_ghost, len(f[0, 0]) - 2 * flux_ghost, num_p)
    info = {'f': f,
            'U': U,
            'dx': dx,
            'dy': dy,
            'dt': dt,
            'recons': recons,
            'flux_ghost': flux_ghost,
            'x_parts': x_parts,
            'y_parts': y_parts}
    processes = create_processes_flux(get_flux_AY_mp_exc, combine_results_flux, info, que, return_dict)
    flux = start_and_join_processes_flux(processes, return_dict)
    return flux

def get_flux_AY_mp_exc(info, que, start_x, end_x, start_y, end_y):
    sub_flux = np.zeros([4, 3, end_x - start_x, end_y - start_y])
    flux_ghost = info['flux_ghost']
    U = info['U']
    for i in range(end_x - start_x):
        for j in range(end_y - start_y):
            v = U[1, i + flux_ghost + start_x, j + flux_ghost + start_y]
            cal_cell_flux_s_mp(info, sub_flux, v, i, j, start_x, start_y)
            cal_cell_flux_n_mp(info, sub_flux, v, i, j, start_x, start_y)
    que.put({'sub_result': sub_flux[:, 0, :, :], 'phase': 0,
                'start_x': start_x, 'end_x': end_x, 'start_y': start_y, 'end_y': end_y})
    que.put({'sub_result': sub_flux[:, 1, :, :], 'phase': 1,
                'start_x': start_x, 'end_x': end_x, 'start_y': start_y, 'end_y': end_y})
    que.put({'sub_result': sub_flux[:, 2, :, :], 'phase': 2,
                'start_x': start_x, 'end_x': end_x, 'start_y': start_y, 'end_y': end_y})

def get_flux_CX_mp(f, U, dx, dy, dt, recons, num_p):
    flux = np.zeros([4, len(f), len(f[0]), len(f[0, 0])])
    manager = multiprocessing.Manager()
    return_dict = manager.dict()
    return_dict['flux'] = flux
    que = Queue()
    flux_ghost = 2
    x_parts, y_parts = divide_domain(len(f[0]) - 2 * flux_ghost, len(f[0, 0]) - 2 * flux_ghost, num_p)
    info = {'f': f,
            'U': U,
            'dx': dx,
            'dy': dy,
            'dt': dt,
            'recons': recons,
            'flux_ghost': flux_ghost,
            'x_parts': x_parts,
            'y_parts': y_parts}
    processes = create_processes_flux(get_flux_CX_mp_exc, combine_results_flux, info, que, return_dict)
    flux = start_and_join_processes_flux(processes, return_dict)
    return flux

def get_flux_CX_mp_exc(info, que, start_x, end_x, start_y, end_y):
    sub_flux = np.zeros([4, 3, end_x - start_x, end_y - start_y])
    flux_ghost = info['flux_ghost']
    U = info['U']
    for i in range(end_x - start_x):
        for j in range(end_y - start_y):
            um = 0.5 * (U[0, i - 1 + flux_ghost + start_x, j + flux_ghost + start_y] +
                        U[0, i + flux_ghost + start_x, j + flux_ghost + start_y])
            cal_cell_flux_m_mp(info, sub_flux, um, i, j, start_x, start_y)
            up = 0.5 * (U[0, i + flux_ghost + start_x, j + flux_ghost + start_y] +
                        U[0, i + 1 + flux_ghost + start_x, j + flux_ghost + start_y])
            cal_cell_flux_p_mp(info, sub_flux, up, i, j, start_x, start_y)
    que.put({'sub_result': sub_flux[:, 0, :, :], 'phase': 0,
             'start_x': start_x, 'end_x': end_x, 'start_y': start_y, 'end_y': end_y})
    que.put({'sub_result': sub_flux[:, 1, :, :], 'phase': 1,
             'start_x': start_x, 'end_x': end_x, 'start_y': start_y, 'end_y': end_y})
    que.put({'sub_result': sub_flux[:, 2, :, :], 'phase': 2,
             'start_x': start_x, 'end_x': end_x, 'start_y': start_y, 'end_y': end_y})

def get_flux_CY_mp(f, U, dx, dy, dt, recons, num_p):
    flux = np.zeros([4, len(f), len(f[0]), len(f[0, 0])])
    manager = multiprocessing.Manager()
    return_dict = manager.dict()
    return_dict['flux'] = flux
    que = Queue()
    flux_ghost = 2
    x_parts, y_parts = divide_domain(len(f[0]) - 2 * flux_ghost, len(f[0, 0]) - 2 * flux_ghost, num_p)
    info = {'f': f,
            'U': U,
            'dx': dx,
            'dy': dy,
            'dt': dt,
            'recons': recons,
            'flux_ghost': flux_ghost,
            'x_parts': x_parts,
            'y_parts': y_parts}
    processes = create_processes_flux(get_flux_CY_mp_exc, combine_results_flux, info, que, return_dict)
    flux = start_and_join_processes_flux(processes, return_dict)
    return flux

def get_flux_CY_mp_exc(info, que, start_x, end_x, start_y, end_y):
    sub_flux = np.zeros([4, 3, end_x - start_x, end_y - start_y])
    flux_ghost = info['flux_ghost']
    U = info['U']
    for i in range(end_x - start_x):
        for j in range(end_y - start_y):
            vs = 0.5 * (U[1, i + flux_ghost + start_x, j + flux_ghost + start_y] +
                        U[1, i + flux_ghost + start_x, j - 1 + flux_ghost + start_y])
            cal_cell_flux_s_mp(info, sub_flux, vs, i, j, start_x, start_y)
            vn = 0.5 * (U[1, i + flux_ghost + start_x, j + flux_ghost + start_y] +
                        U[1, i + flux_ghost + start_x, j + 1 + flux_ghost + start_y])
            cal_cell_flux_n_mp(info, sub_flux, vn, i, j, start_x, start_y)
    que.put({'sub_result': sub_flux[:, 0, :, :], 'phase': 0,
             'start_x': start_x, 'end_x': end_x, 'start_y': start_y, 'end_y': end_y})
    que.put({'sub_result': sub_flux[:, 1, :, :], 'phase': 1,
             'start_x': start_x, 'end_x': end_x, 'start_y': start_y, 'end_y': end_y})
    que.put({'sub_result': sub_flux[:, 2, :, :], 'phase': 2,
             'start_x': start_x, 'end_x': end_x, 'start_y': start_y, 'end_y': end_y})

def cal_cell_flux_m_mp(info, flux, u, i, j, start_x, start_y):
    f = info['f']
    dx = info['dx']
    dy = info['dy']
    dt = info['dt']
    recons = info['recons']
    flux_ghost = info['flux_ghost']
    V = dx * dy
    if u > 0:
        ### u > 0, consider the upwind grid
        pos = [i - 1 + flux_ghost + start_x, j + flux_ghost + start_y]
        sf_stencil = get_sf(pos, f)
        phase_exist = judge_phase_num(sf_stencil)
        if len(phase_exist) > 1:
            normal = np.array([-1., 0.])
            loc_x = np.array([dx - u * dt, 0.])
            d = normal.dot(loc_x)
            cells = recons[i - 1 + flux_ghost + start_x][j + flux_ghost + start_y][1]['cells']
            for cell_ind in range(len(cells)):
                cell_info = cells[cell_ind]
                phase_ind = cell_info[0]
                cell = cell_info[1]
                intersections = plic_get_intersects(cell, normal, d)
                intersection_num = get_inters_num(intersections)
                if intersection_num < 3:
                    ### concave
                    volume = get_cut_volume_polygon_with_intersects(intersections, cell, normal, d)
                else:
                    cell_m = np.array([cell[0], cell[-1], cell[1]])
                    intersections_m = plic_get_intersects(cell_m, normal, d)
                    volume_m = get_cut_volume_polygon_with_intersects(intersections_m, cell_m, normal, d)
                    cell_p = cell[1:]
                    intersections_p = plic_get_intersects(cell_p, normal, d)
                    volume_p = get_cut_volume_polygon_with_intersects(intersections_p, cell_p, normal, d)
                    volume = volume_p - volume_m
                flux[0, phase_ind, i, j] += volume / V
        else:
            phase_ind = phase_exist[0]
            f_xm = u * dt * dy
            flux[0, phase_ind, i, j] += f_xm / V
    elif u < 0:
        ### u < 0, consider the center grid
        pos = [i + flux_ghost + start_x, j + flux_ghost + start_y]
        sf_stencil = get_sf(pos, f)
        phase_exist = judge_phase_num(sf_stencil)
        if len(phase_exist) > 1:
            normal = np.array([1., 0.])
            loc_x = np.array([-u * dt, 0.])
            d = normal.dot(loc_x)
            cells = recons[i + flux_ghost + start_x][j + flux_ghost + start_y][1]['cells']
            for cell_ind in range(len(cells)):
                cell_inf = cells[cell_ind]
                phase_ind = cell_inf[0]
                cell = cell_inf[1]
                intersections = plic_get_intersects(cell, normal, d)
                intersec_num = get_inters_num(intersections)
                if intersec_num < 3:
                    volume = get_cut_volume_polygon_with_intersects(intersections, cell, normal, d)
                else:
                    cell_m = np.array([cell[0], cell[-1], cell[1]])
                    intersections_m = plic_get_intersects(cell_m, normal, d)
                    volume_m = get_cut_volume_polygon_with_intersects(intersections_m, cell_m, normal, d)
                    cell_p = cell[1:]
                    intersections_p = plic_get_intersects(cell_p, normal, d)
                    volume_p = get_cut_volume_polygon_with_intersects(intersections_p, cell_p, normal, d)
                    volume = volume_p - volume_m
                flux[0, phase_ind, i, j] -= volume / V
        else:
            phase_ind = phase_exist[0]
            f_xm = -u * dt * dy
            flux[0, phase_ind, i, j] -= f_xm / V
    else:
        pass

def cal_cell_flux_p_mp(info, flux, u, i, j, start_x, start_y):
    f = info['f']
    dx = info['dx']
    dy = info['dy']
    dt = info['dt']
    recons = info['recons']
    flux_ghost = info['flux_ghost']
    V = dx * dy
    if u > 0:
        ### u > 0, consider the center grid
        pos = [i + flux_ghost + start_x, j + flux_ghost + start_y]
        sf_stencil = get_sf(pos, f)
        phase_exist = judge_phase_num(sf_stencil)
        if len(phase_exist) > 1:
            normal = np.array([-1., 0.])
            loc_x = np.array([dx - u * dt, 0.])
            d = normal.dot(loc_x)
            cells = recons[i + flux_ghost + start_x][j + flux_ghost + start_y][1]['cells']
            for cell_ind in range(len(cells)):
                cell_inf = cells[cell_ind]
                phase_ind = cell_inf[0]
                cell = cell_inf[1]
                intersections = plic_get_intersects(cell, normal, d)
                intersec_num = get_inters_num(intersections)
                if intersec_num < 3:
                    volume = get_cut_volume_polygon_with_intersects(intersections, cell, normal, d)
                else:
                    cell_m = np.array([cell[0], cell[-1], cell[1]])
                    intersections_m = plic_get_intersects(cell_m, normal, d)
                    volume_m = get_cut_volume_polygon_with_intersects(intersections_m, cell_m, normal, d)
                    cell_p = cell[1:]
                    intersections_p = plic_get_intersects(cell_p, normal, d)
                    volume_p = get_cut_volume_polygon_with_intersects(intersections_p, cell_p, normal, d)
                    volume = volume_p - volume_m
                flux[1, phase_ind, i, j] -= volume / V
        else:
            phase_ind = phase_exist[0]
            f_xp = u * dt * dy
            flux[1, phase_ind, i, j] -= f_xp / V
    elif u < 0:
        ### u < 0, consider the downwind grid
        pos = [i + 1 + flux_ghost + start_x, j + flux_ghost + start_y]
        sf_stencil = get_sf(pos, f)
        phase_exist = judge_phase_num(sf_stencil)
        if len(phase_exist) > 1:
            normal = np.array([1., 0.])
            loc_x = np.array([-u * dt, 0.])
            d = normal.dot(loc_x)
            cells = recons[i + 1 + flux_ghost + start_x][j + flux_ghost + start_y][1]['cells']
            for cell_ind in range(len(cells)):
                cell_inf = cells[cell_ind]
                phase_ind = cell_inf[0]
                cell = cell_inf[1]
                intersections = plic_get_intersects(cell, normal, d)
                intersec_num = get_inters_num(intersections)
                if intersec_num < 3:
                    volume = get_cut_volume_polygon_with_intersects(intersections, cell, normal, d)
                else:
                    cell_m = np.array([cell[0], cell[-1], cell[1]])
                    intersections_m = plic_get_intersects(cell_m, normal, d)
                    volume_m = get_cut_volume_polygon_with_intersects(intersections_m, cell_m, normal, d)
                    cell_p = cell[1:]
                    intersections_p = plic_get_intersects(cell_p, normal, d)
                    volume_p = get_cut_volume_polygon_with_intersects(intersections_p, cell_p, normal, d)
                    volume = volume_p - volume_m
                flux[1, phase_ind, i, j] += volume / V
        else:
            phase_ind = phase_exist[0]
            f_xp = -u * dt * dy
            flux[1, phase_ind, i, j] += f_xp / V
    else:
        pass

def cal_cell_flux_s_mp(info, flux, v, i, j, start_x, start_y):
    f = info['f']
    dx = info['dx']
    dy = info['dy']
    dt = info['dt']
    recons = info['recons']
    flux_ghost = info['flux_ghost']
    V = dx * dy
    if v > 0:
        ### v > 0, consider the upwind grid
        pos = [i + flux_ghost + start_x, j - 1 + flux_ghost + start_y]
        sf_stencil = get_sf(pos, f)
        phase_exist = judge_phase_num(sf_stencil)
        if len(phase_exist) > 1:
            normal = np.array([0., -1.])
            loc_x = np.array([0., dy - v * dt])
            d = normal.dot(loc_x)
            cells = recons[i + flux_ghost + start_x][j - 1 + flux_ghost + start_y][1]['cells']
            for cell_ind in range(len(cells)):
                cell_inf = cells[cell_ind]
                phase_ind = cell_inf[0]
                cell = cell_inf[1]
                intersections = plic_get_intersects(cell, normal, d)
                intersec_num = get_inters_num(intersections)
                if intersec_num < 3:
                    volume = get_cut_volume_polygon_with_intersects(intersections, cell, normal, d)
                else:
                    cell_m = np.array([cell[0], cell[-1], cell[1]])
                    intersections_m = plic_get_intersects(cell_m, normal, d)
                    volume_m = get_cut_volume_polygon_with_intersects(intersections_m, cell_m, normal, d)
                    cell_p = cell[1:]
                    intersections_p = plic_get_intersects(cell_p, normal, d)
                    volume_p = get_cut_volume_polygon_with_intersects(intersections_p, cell_p, normal, d)
                    volume = volume_p - volume_m
                flux[2, phase_ind, i, j] += volume / V
        else:
            phase_ind = phase_exist[0]
            f_ym = v * dt * dx
            flux[2, phase_ind, i, j] += f_ym / V
    elif v < 0:
        ### v < 0, consider the center grid
        pos = [i + flux_ghost + start_x, j + flux_ghost + start_y]
        sf_stencil = get_sf(pos, f)
        phase_exist = judge_phase_num(sf_stencil)
        if len(phase_exist) > 1:
            normal = np.array([0., 1.])
            loc_x = np.array([0., -v * dt])
            d = normal.dot(loc_x)
            cells = recons[i + flux_ghost + start_x][j + flux_ghost + start_y][1]['cells']
            for cell_ind in range(len(cells)):
                cell_inf = cells[cell_ind]
                phase_ind = cell_inf[0]
                cell = cell_inf[1]
                intersections = plic_get_intersects(cell, normal, d)
                intersec_num = get_inters_num(intersections)
                if intersec_num < 3:
                    volume = get_cut_volume_polygon_with_intersects(intersections, cell, normal, d)
                else:
                    cell_m = np.array([cell[0], cell[-1], cell[1]])
                    intersections_m = plic_get_intersects(cell_m, normal, d)
                    volume_m = get_cut_volume_polygon_with_intersects(intersections_m, cell_m, normal, d)
                    cell_p = cell[1:]
                    intersections_p = plic_get_intersects(cell_p, normal, d)
                    volume_p = get_cut_volume_polygon_with_intersects(intersections_p, cell_p, normal, d)
                    volume = volume_p - volume_m
                flux[2, phase_ind, i, j] -= volume / V
        else:
            phase_ind = phase_exist[0]
            f_ym = -v * dt * dx
            flux[2, phase_ind, i, j] -= f_ym / V
    else:
        pass

def cal_cell_flux_n_mp(info, flux, v, i, j, start_x, start_y):
    f = info['f']
    dx = info['dx']
    dy = info['dy']
    dt = info['dt']
    recons = info['recons']
    flux_ghost = info['flux_ghost']
    V = dx * dy
    if v > 0:
        ### v > 0, consider the center grid
        pos = [i + flux_ghost + start_x, j + flux_ghost + start_y]
        sf_stencil = get_sf(pos, f)
        phase_exist = judge_phase_num(sf_stencil)
        if len(phase_exist) > 1:
            normal = np.array([0., -1.])
            loc_x = np.array([0., dy - v * dt])
            d = normal.dot(loc_x)
            # print(recons[i][j][0])
            cells = recons[i + flux_ghost + start_x][j + flux_ghost + start_y][1]['cells']
            for cell_ind in range(len(cells)):
                cell_inf = cells[cell_ind]
                phase_ind = cell_inf[0]
                cell = cell_inf[1]
                intersections = plic_get_intersects(cell, normal, d)
                intersec_num = get_inters_num(intersections)
                if intersec_num < 3:
                    volume = get_cut_volume_polygon_with_intersects(intersections, cell, normal, d)
                else:
                    cell_m = np.array([cell[0], cell[-1], cell[1]])
                    intersections_m = plic_get_intersects(cell_m, normal, d)
                    volume_m = get_cut_volume_polygon_with_intersects(intersections_m, cell_m, normal, d)
                    cell_p = cell[1:]
                    intersections_p = plic_get_intersects(cell_p, normal, d)
                    volume_p = get_cut_volume_polygon_with_intersects(intersections_p, cell_p, normal, d)
                    volume = volume_p - volume_m
                flux[3, phase_ind, i, j] -= volume / V
        else:
            phase_ind = phase_exist[0]
            f_yp = v * dt * dx
            flux[3, phase_ind, i, j] -= f_yp / V
    elif v < 0:
        ### v < 0, consider the downwind grid
        pos = [i + flux_ghost + start_x, j + 1 + flux_ghost + start_y]
        sf_stencil = get_sf(pos, f)
        phase_exist = judge_phase_num(sf_stencil)
        if len(phase_exist) > 1:
            normal = np.array([0., 1.])
            loc_x = np.array([0., -v * dt])
            d = normal.dot(loc_x)
            cells = recons[i + flux_ghost + start_x][j + 1 + flux_ghost + start_y][1]['cells']
            for cell_ind in range(len(cells)):
                cell_inf = cells[cell_ind]
                phase_ind = cell_inf[0]
                cell = cell_inf[1]
                intersections = plic_get_intersects(cell, normal, d)
                intersec_num = get_inters_num(intersections)
                if intersec_num < 3:
                    volume = get_cut_volume_polygon_with_intersects(intersections, cell, normal, d)
                else:
                    cell_m = np.array([cell[0], cell[-1], cell[1]])
                    intersections_m = plic_get_intersects(cell_m, normal, d)
                    volume_m = get_cut_volume_polygon_with_intersects(intersections_m, cell_m, normal, d)
                    cell_p = cell[1:]
                    intersections_p = plic_get_intersects(cell_p, normal, d)
                    volume_p = get_cut_volume_polygon_with_intersects(intersections_p, cell_p, normal, d)
                    volume = volume_p - volume_m
                flux[3, phase_ind, i, j] += volume / V
        else:
            phase_ind = phase_exist[0]
            f_yp = -v * dt * dx
            flux[3, phase_ind, i, j] += f_yp / V
    else:
        pass
