### created by Zhang
### HKUST FU's Lab
### 2025.01.08

import numpy as np
import random
import matplotlib.pyplot as plt
from matplotlib.ticker import MultipleLocator
from shapely import LineString

from src.functions.functions import get_cell_volume_new
from shapely.geometry import Point
from shapely.geometry.polygon import Polygon
random.seed(0)

def point_in_polygon_shapely(point, polygon):
    point = np.array(point)
    polygon = np.array(polygon)
    ### JUDGE BY THE LARGEST CELL
    if np.max(polygon[:, 0]) < point[0]:
        return False
    elif np.min(polygon[:, 0]) > point[0]:
        return False
    elif np.max(polygon[:, 1]) < point[1]:
        return False
    elif np.min(polygon[:, 1]) > point[1]:
        return False
    elif point_on_polygon_edge(point, polygon):
        return True
    else:
        point = Point(point[0], point[1])
        polygon_inp = []
        for i in range(len(polygon)):
            polygon_inp.append((polygon[i, 0], polygon[i, 1]))
        polygon = Polygon(polygon_inp)
        result = polygon.contains(point)
        return result

def point_in_polygon(point, polygon):
    ### FIRST JUDGE THE MAXIMUM BOX
    polygon = np.array(polygon)
    if np.max(polygon[:,0]) < point[0] or np.max(polygon[:,1]) < point[1] or point[0] < np.min(polygon[:,0]) or point[1] < np.min(polygon[:,1]):
        return False
    elif point_on_polygon_edge(point, polygon):
        # print('point on edge')
        return True
    else:
        point = np.array(point)
        # print(point)
        # Calculate the boundary vector of the polygon
        vote_for_True = 0
        vote_for_False = 0
        edges = []
        for i in range(len(polygon)):
            p1 = polygon[i]
            p2 = polygon[(i + 1) % len(polygon)]
            edges.append(np.array([p1, p2]))
        edges = np.array(edges)
        # print(edges)
        # Count the number of intersections between a horizontal right-ray and a polygon
        count = 0
        for edge in edges:
            if ray_insec_edg_r(point, edge):
                count += 1
            else:
                pass
        # Determine whether a point is inside or on the border of a polygon
        if count % 2 == 1:
            vote_for_True += 1
        else:
            vote_for_False += 1
        # print(vote_for_True, vote_for_False)
        # Count the number of intersections between a horizontal left-ray and a polygon
        count = 0
        for edge in edges:
            if ray_insec_edg_l(point, edge):
                count += 1
            else:
                pass
        if count % 2 == 1:
            vote_for_True += 1
        else:
            vote_for_False += 1
        # print(vote_for_True, vote_for_False)
        # Count the number of intersections between a vertical up-ray and a polygon
        count = 0
        for edge in edges:
            if ray_insec_edg_u(point, edge):
                count += 1
            else:
                pass
        if count % 2 == 1:
            vote_for_True += 1
        else:
            vote_for_False += 1
        # print(vote_for_True, vote_for_False)
        # Count the number of intersections between a vertical down-ray and a polygon
        count = 0
        for edge in edges:
            if ray_insec_edg_d(point, edge):
                count += 1
            else:
                pass
        if count % 2 == 1:
            vote_for_True += 1
        else:
            vote_for_False += 1
        # print(vote_for_True, vote_for_False)
        ### final voting decision
        if vote_for_True >= vote_for_False:
            return True
        else:
            return False

### THIS FUNCTION IS USED TO TEST IF A POINT LIES ON THE BOUNDARY OF A GIVEN POLYGON
def point_on_polygon_edge(point, polygon):
    edges = []
    for i in range(len(polygon)):
        p1 = polygon[i]
        p2 = polygon[(i + 1) % len(polygon)]
        edges.append(np.array([p1, p2]))
    edges = np.array(edges)
    for i in range(len(edges)):
        if judge_on_line(point, edges[i, 0], edges[i, 1]):
            return True
    return False

### THIS FUNCTION RETURNS INTERSECTION CONDITION OF A HORIZONTAL RIGHT-RAY AND AN EDGE
def ray_insec_edg_r(point, edge):
    ### AVOID HORIZONTAL EDGE
    if edge[0, 1] != edge[1, 1]:
        ### MAKE SURE THE FIRST POINT IS BELOW SECOND POINT
        if edge[0, 1] < edge[1, 1]:
            pass
        else:
            edge_copy = edge.copy()
            edge_copy[0] = edge[1]
            edge_copy[1] = edge[0]
            edge = edge_copy
    else:
        if min(edge[0, 0], edge[1, 0]) <= point[0] <= max(edge[0, 0], edge[1, 0]) and point[1] == edge[0, 1]:
            return True
        else:
            return False
    # ### AVOID RAY ON THE VERTEX
    # if point[1] == edge[0, 1] or point[1] == edge[1, 1]:
    #     point[1] += 1e-8
    # else:
    #     pass
    ### JUDGE IF OUT OF RANGE
    if point[1] < edge[0, 1] or point[1] > edge[1, 1]:
        return False
    elif point[0] > max(edge[0, 0], edge[1, 0]):
        return False
    else:
        if point[0] <= min(edge[0, 0], edge[1, 0]):
            return True
        else:
            if edge[0, 0] != edge[1, 0]:
                k_edge = (edge[1, 1] - edge[0, 1]) / (edge[1, 0] - edge[0, 0])
            else:
                k_edge = float('inf')
            if point[0] != edge[0, 0]:
                k_p_edge = (point[1] - edge[0, 1]) / (point[0] - edge[0, 0])
            else:
                k_p_edge = float('inf')
            if k_p_edge >= k_edge:
                return True
            else:
                return False

### THIS FUNCTION RETURNS INTERSECTION CONDITION OF A HORIZONTAL LEFT-RAY AND AN EDGE
def ray_insec_edg_l(point, edge):
    ### AVOID HORIZONTAL EDGE
    if edge[0, 1] != edge[1, 1]:
        ### MAKE SURE THE FIRST POINT IS BELOW SECOND POINT
        if edge[0, 1] < edge[1, 1]:
            pass
        else:
            edge_copy = edge.copy()
            edge_copy[0] = edge[1]
            edge_copy[1] = edge[0]
            edge = edge_copy
    else:
        if min(edge[0, 0], edge[1, 0]) <= point[0] <= max(edge[0, 0], edge[1, 0]) and point[1] == edge[0, 1]:
            return True
        else:
            return False
    # ### AVOID RAY ON THE VERTEX
    # if point[1] == edge[0, 1] or point[1] == edge[1, 1]:
    #     point[1] += 1e-8
    # else:
    #     pass
    ### JUDGE IF OUT OF RANGE
    if point[1] < edge[0, 1] or point[1] > edge[1, 1]:
        return False
    elif point[0] < min(edge[0, 0], edge[1, 0]):
        return False
    else:
        if point[0] >= max(edge[0, 0], edge[1, 0]):
            return True
        else:
            if edge[0, 0] != edge[1, 0]:
                k_edge = (edge[1, 1] - edge[0, 1]) / (edge[1, 0] - edge[0, 0])
            else:
                k_edge = float('inf')
            if point[0] != edge[0, 0]:
                k_p_edge = (point[1] - edge[0, 1]) / (point[0] - edge[0, 0])
            else:
                k_p_edge = float('inf')
            if k_p_edge <= k_edge:
                return True
            else:
                return False

### THIS FUNCTION RETURNS INTERSECTION CONDITION OF A HORIZONTAL UP-RAY AND AN EDGE
def ray_insec_edg_u(point, edge):
    ### AVOID VERTICLE EDGE
    if edge[0, 0] != edge[1, 0]:
        # print('edge[0, 0] != edge[1, 0]')
        ### MAKE SURE THE FIRST POINT IS TO THE LEFT
        if edge[0, 0] < edge[1, 0]:
            pass
        else:
            edge_copy = edge.copy()
            edge_copy[0] = edge[1]
            edge_copy[1] = edge[0]
            edge = edge_copy
    else:
        # print('edge[0, 0] = edge[1, 0]')
        if min(edge[0, 1], edge[1, 1]) <= point[1] <= max(edge[0, 1], edge[1, 1]) and point[0] == edge[0, 0]:
            # print('min(edge[0, 1], edge[1, 1]) <= point[1] <= max(edge[0, 1], edge[1, 1]) and point[0] == edge[0, 0]')
            return True
        else:
            return False
    # print(edge)
    # ### AVOID RAY ON THE VERTEX
    # if point[0] == edge[0, 0] or point[0] == edge[1, 0]:
    #     point[0] += 1e-8
    # else:
    #     pass
    ### JUDGE IF OUT OF RANGE
    if point[0] < edge[0, 0] or point[0] > edge[1, 0]:
        return False
    elif point[1] > max(edge[0, 1], edge[1, 1]):
        return False
    else:
        if point[1] <= min(edge[0, 1], edge[1, 1]):
            # print('point[1] <= min(edge[0, 1], edge[1, 1])')
            return True
        else:
            if edge[0, 0] != edge[1, 0]:
                k_edge = (edge[1, 1] - edge[0, 1]) / (edge[1, 0] - edge[0, 0])
            else:
                if edge[0, 1] > edge[1, 1]:
                    k_edge = -float('inf')
                else:
                    k_edge = float('inf')
            if point[0] != edge[0, 0]:
                k_p_edge = (point[1] - edge[0, 1]) / (point[0] - edge[0, 0])
            else:
                if edge[0, 1] > point[1]:
                    k_p_edge = -float('inf')
                else:
                    k_p_edge = float('inf')
            if k_p_edge <= k_edge:
                # print('k_p_edge <= k_edge')
                return True
            else:
                return False

### THIS FUNCTION RETURNS INTERSECTION CONDITION OF A HORIZONTAL DOWN-RAY AND AN EDGE
def ray_insec_edg_d(point, edge):
    ### AVOID VERTICLE EDGE
    if edge[0, 0] != edge[1, 0]:
        ### MAKE SURE THE FIRST POINT IS TO THE LEFT
        if edge[0, 0] < edge[1, 0]:
            pass
        else:
            edge_copy = edge.copy()
            edge_copy[0] = edge[1]
            edge_copy[1] = edge[0]
            edge = edge_copy
    else:
        if min(edge[0, 1], edge[1, 1]) <= point[1] <= max(edge[0, 1], edge[1, 1]) and point[0] == edge[0, 0]:
            return True
        else:
            return False
    # ### AVOID RAY ON THE VERTEX
    # if point[0] == edge[0, 0] or point[0] == edge[1, 0]:
    #     point[0] += 1e-8
    # else:
    #     pass
    ### JUDGE IF OUT OF RANGE
    if point[0] < edge[0, 0] or point[0] > edge[1, 0]:
        return False
    elif point[1] < min(edge[0, 1], edge[1, 1]):
        return False
    else:
        if point[1] >= max(edge[0, 1], edge[1, 1]):
            return True
        else:
            if edge[0, 0] != edge[1, 0]:
                k_edge = (edge[1, 1] - edge[0, 1]) / (edge[1, 0] - edge[0, 0])
            else:
                if edge[0, 1] > edge[1, 1]:
                    k_edge = -float('inf')
                else:
                    k_edge = float('inf')
            if point[0] != edge[0, 0]:
                k_p_edge = (point[1] - edge[0, 1]) / (point[0] - edge[0, 0])
            else:
                if edge[0, 1] > point[1]:
                    k_p_edge = -float('inf')
                else:
                    k_p_edge = float('inf')
            if k_p_edge >= k_edge:
                return True
            else:
                return False

### This function judge if the point is on the line segment, constructed by p1 and p2:
def judge_on_line(point, p1, p2):
    def distance(p1, p2):
        return ((p1[0]-p2[0])**2 + (p1[1]-p2[1])**2)**0.5
    # Determine whether the point is on the line segment
    d1 = distance(point, p1)
    d2 = distance(point, p2)
    d3 = distance(p1, p2)
    # print(point, p1, p2, abs(d1 + d2 - d3) < 1e-8)
    return abs(d1 + d2 - d3) < 1e-8

### THIS FUNCTION CREATE BLUE NOISE STENCIL
def create_blue_noise_stencil(N, dx, dy):
    radius = dx / (np.sqrt(2) * N)
    print('radius: ', radius)
    xs = np.linspace(0., dx, N + 1)
    ys = np.linspace(0., dy, N + 1)
    X, Y = np.meshgrid(xs, ys)
    for i in range(N):
        for j in range(N):
            random_bias_x = 0.7 * (random.random() - 0.5) * (dx / N)
            random_bias_y = 0.7 * (random.random() - 0.5) * (dx / N)
            X[i, j] += random_bias_x + 0.5 * (dx / N)
            Y[i, j] += random_bias_y + 0.5 * (dy / N)

    # particles = []
    # for i in range(N):
    #     for j in range(N):
    #         particles.append(np.array([X[i, j], Y[i, j]]))
    # particles = np.array(particles)
    # fig, ax = plt.subplots(1, 1)
    # ax.scatter(particles[:, 0], particles[:, 1], color='blue', linewidths=0.1)
    # ax.set_xlim((0., dx))
    # ax.set_ylim((0., dy))
    # ax.set_aspect('equal')
    # ax.grid(linestyle='--')
    # ax.set_xticklabels([])
    # ax.set_yticklabels([])
    # ax.xaxis.set_major_locator(MultipleLocator(dx / N))
    # ax.yaxis.set_major_locator(MultipleLocator(dy / N))
    # plt.savefig('../initial_template.png', dpi=300, format='png')
    # plt.close()

    ### SHORTEST DISTANCE DISCOVERING
    for i in range(1, N - 1):
        for j in range(1, N - 1):
            if not np.isnan(X[i, j]):
                print(i, j)
                if not np.isnan(X[i - 1, j]):
                    dis_left = np.sqrt((X[i, j] - X[i - 1, j]) ** 2 + (Y[i, j] - Y[i - 1, j]) ** 2)
                    if dis_left < radius:
                        print('left: ', dis_left)
                        X[i, j] = None
                        Y[i, j] = None
                        continue
                if not np.isnan(X[i + 1, j]):
                    dis_right = np.sqrt((X[i, j] - X[i + 1, j]) ** 2 + (Y[i, j] - Y[i + 1, j]) ** 2)
                    if dis_right < radius:
                        print('right: ', dis_right)
                        X[i, j] = None
                        Y[i, j] = None
                        continue
                if not np.isnan(X[i, j - 1]):
                    dis_low = np.sqrt((X[i, j] - X[i, j - 1]) ** 2 + (Y[i, j] - Y[i, j - 1]) ** 2)
                    if dis_low < radius:
                        print('low: ', dis_low)
                        X[i, j] = None
                        Y[i, j] = None
                        continue
                if not np.isnan(X[i, j + 1]):
                    dis_up = np.sqrt((X[i, j] - X[i, j + 1]) ** 2 + (Y[i, j] - Y[i, j + 1]) ** 2)
                    if dis_up < radius:
                        print('up: ', dis_up)
                        X[i, j] = None
                        Y[i, j] = None
                        continue
                if not np.isnan(X[i - 1, j - 1]):
                    dis_lowleft = np.sqrt((X[i, j] - X[i - 1, j - 1]) ** 2 + (Y[i, j] - Y[i - 1, j - 1]) ** 2)
                    if dis_lowleft < radius:
                        print('lowleft: ', dis_lowleft)
                        X[i, j] = None
                        Y[i, j] = None
                        continue
                if not np.isnan(X[i - 1, j + 1]):
                    dis_upleft = np.sqrt((X[i, j] - X[i - 1, j + 1]) ** 2 + (Y[i, j] - Y[i - 1, j + 1]) ** 2)
                    if dis_upleft < radius:
                        print('upleft: ', dis_upleft)
                        X[i, j] = None
                        Y[i, j] = None
                        continue
                if not np.isnan(X[i + 1, j - 1]):
                    dis_lowright = np.sqrt((X[i, j] - X[i + 1, j - 1]) ** 2 + (Y[i, j] - Y[i + 1, j - 1]) ** 2)
                    if dis_lowright < radius:
                        print('lowright: ', dis_lowright)
                        X[i, j] = None
                        Y[i, j] = None
                        continue
                if not np.isnan(X[i + 1, j + 1]):
                    dis_upright = np.sqrt((X[i, j] - X[i + 1, j + 1]) ** 2 + (Y[i, j] - Y[i + 1, j + 1]) ** 2)
                    if dis_upright < radius:
                        print('upright: ', dis_upright)
                        X[i, j] = None
                        Y[i, j] = None
                        continue

    # particles = []
    # for i in range(N):
    #     for j in range(N):
    #         if not np.isnan(X[i, j]):
    #             particles.append(np.array([X[i, j], Y[i, j]]))
    # particles = np.array(particles)
    # fig, ax = plt.subplots(1, 1)
    # ax.scatter(particles[:, 0], particles[:, 1], color='blue', linewidths=0.1)
    # ax.set_xlim((0., dx))
    # ax.set_ylim((0., dy))
    # ax.set_aspect('equal')
    # ax.grid(linestyle='--')
    # ax.set_xticklabels([])
    # ax.set_yticklabels([])
    # ax.xaxis.set_major_locator(MultipleLocator(dx / N))
    # ax.yaxis.set_major_locator(MultipleLocator(dy / N))
    # plt.savefig('../deleted_template.png', dpi=300, format='png')
    # plt.close()

    X_o, Y_o = np.meshgrid(xs, ys)
    ### REASSIGN
    for i in range(1, N - 1):
        for j in range(1, N - 1):
            # print(X[i, j])
            if np.isnan(X[i, j]):
                stop = False
                while stop == False:
                    test = True
                    random_bias_x = 0.7 * (random.random() - 0.5) * (dx / N)
                    random_bias_y = 0.7 * (random.random() - 0.5) * (dx / N)
                    X[i, j] = random_bias_x + 0.5 * (dx / N) + X_o[i, j]
                    Y[i, j] = random_bias_y + 0.5 * (dy / N) + Y_o[i, j]
                    # print(X[i, j], Y[i, j])
                    if not np.isnan(X[i - 1, j]):
                        dis_left = np.sqrt((X[i, j] - X[i - 1, j]) ** 2 + (Y[i, j] - Y[i - 1, j]) ** 2)
                        if dis_left < radius:
                            test = False
                    if not np.isnan(X[i + 1, j]):
                        dis_right = np.sqrt((X[i, j] - X[i + 1, j]) ** 2 + (Y[i, j] - Y[i + 1, j]) ** 2)
                        if dis_right < radius:
                            test = False
                    if not np.isnan(X[i, j - 1]):
                        dis_low = np.sqrt((X[i, j] - X[i, j - 1]) ** 2 + (Y[i, j] - Y[i, j - 1]) ** 2)
                        if dis_low < radius:
                            test = False
                    if not np.isnan(X[i, j + 1]):
                        dis_up = np.sqrt((X[i, j] - X[i, j + 1]) ** 2 + (Y[i, j] - Y[i, j + 1]) ** 2)
                        if dis_up < radius:
                            test = False
                    if not np.isnan(X[i - 1, j - 1]):
                        dis_lowleft = np.sqrt((X[i, j] - X[i - 1, j - 1]) ** 2 + (Y[i, j] - Y[i - 1, j - 1]) ** 2)
                        if dis_lowleft < radius:
                            test = False
                    if not np.isnan(X[i - 1, j + 1]):
                        dis_upleft = np.sqrt((X[i, j] - X[i - 1, j + 1]) ** 2 + (Y[i, j] - Y[i - 1, j + 1]) ** 2)
                        if dis_upleft < radius:
                            test = False
                    if not np.isnan(X[i + 1, j - 1]):
                        dis_lowright = np.sqrt((X[i, j] - X[i + 1, j - 1]) ** 2 + (Y[i, j] - Y[i + 1, j - 1]) ** 2)
                        if dis_lowright < radius:
                            test = False
                    if not np.isnan(X[i + 1, j + 1]):
                        dis_upright = np.sqrt((X[i, j] - X[i + 1, j + 1]) ** 2 + (Y[i, j] - Y[i + 1, j + 1]) ** 2)
                        if dis_upright < radius:
                            test = False
                    if test == True:
                        stop = True
    particles = []
    for i in range(N):
        for j in range(N):
            if not np.isnan(X[i, j]):
                particles.append(np.array([X[i, j], Y[i, j]]))
    particles = np.array(particles)
    fig, ax = plt.subplots(1, 1, figsize=(10, 10))
    ax.scatter(particles[:, 0], particles[:, 1], color='blue', linewidths=0.1)
    ax.set_xlim((0., dx))
    ax.set_ylim((0., dy))
    ax.set_aspect('equal')
    ax.grid(linestyle='--')
    ax.set_xticklabels([])
    ax.set_yticklabels([])
    ax.xaxis.set_major_locator(MultipleLocator(dx / N))
    ax.yaxis.set_major_locator(MultipleLocator(dy / N))
    plt.savefig('../final_template.png', dpi=300, format='png')
    plt.close()

    np.save('../../blue_noise_template.npy', particles)

    return particles

# particles = create_blue_noise_stencil(25, 1., 1.)

def get_flux_vclp_exc(U, U_m, PLIC_recons, dx, dy, dt, ghost, start_x, end_x, start_y,
                                                  end_y, flux_stencil, bn_particles):
    ### extend one cell length to store the donating flux of the broaders
    sub_flux_mid = np.zeros([2, 3, end_x - start_x + 2 * flux_stencil, end_y - start_y + 2 * flux_stencil])
    for i in range(end_x - start_x):
        for j in range(end_y - start_y):
            flux_in_stencil = np.zeros([2, 3, 3, 3])
            cells = PLIC_recons[i + start_x + ghost][j + start_y + ghost][1]['cells']
            U_stencil = U[:                                              ,
                          i - 1 + ghost + start_x:i + 2 + ghost + start_x,
                          j - 1 + ghost + start_y:j + 2 + ghost + start_y]
            U_m_stencil = U_m[:                                              ,
                              i - 1 + ghost + start_x:i + 2 + ghost + start_x,
                              j - 1 + ghost + start_y:j + 2 + ghost + start_y]
            U_v = get_vertex_u_from_stencil(U_stencil)
            U_v_m = get_vertex_u_from_stencil(U_m_stencil)
            # print(U_v)
            # print(U_v_m)
            for k in range(len(cells)):
                phase = cells[k][0]
                cell = cells[k][1]
                flow_out = 0.
                particles, particle_f = fit_the_cell(cell, bn_particles, dx, dy)
                for q in range(len(particles)):
                    ### Taylor 2nd update
                    particle_moved = update_lag_p_pos_Taylor2nd(U_v, U_v_m, particles[q], dx, dy, dt)
                    out = accum_lag_p_flux(particle_moved, phase, flux_in_stencil, particle_f, dx, dy)
                    if out:
                        flow_out += out
                flux_in_stencil[1, phase, 1, 1] += flow_out * particle_f
                # print(flow_out)
            sub_flux_mid[:                                        ,
                         :                                        ,
                         i - 1 + flux_stencil:i + 2 + flux_stencil,
                         j - 1 + flux_stencil:j + 2 + flux_stencil] += flux_in_stencil
    return sub_flux_mid


### FIT THE BLUE NOISE STENCIL WITH GIVEN POLYHEDRON
def fit_the_cell(cell, blue_noise_particles, dx, dy):
    ### RESCALE TO THE LARGEST POLYHEDRON
    cell = np.array(cell)
    s = get_cell_volume_new(cell)
    f = s / (dx * dy)
    xs = cell[:, 0]
    ys = cell[:, 1]
    x_min = np.min(xs)
    x_max = np.max(xs)
    y_min = np.min(ys)
    y_max = np.max(ys)
    blue_noise_particles = np.array(blue_noise_particles)
    blue_noise_particles[:, 0] *= x_max - x_min
    blue_noise_particles[:, 0] += x_min
    blue_noise_particles[:, 1] *= y_max - y_min
    blue_noise_particles[:, 1] += y_min
    ### FILTERING
    particles = []
    for i in range(len(blue_noise_particles)):
        point_in_Polygon = point_in_polygon_shapely(blue_noise_particles[i], cell)
        if point_in_Polygon:
            particles.append(blue_noise_particles[i])
        else:
            pass
    particles = np.array(particles)
    particle_fraction = f / len(particles)
    return particles, particle_fraction

### INPUT U_STENCIL CONSISTS FOUR VERTEX VELOCITY OF A CELL WITH ORDER:
### [(i-0.5, j-0.5), (i-0.5, j+0.5), (i+0.5, j+0.5), (i+0.5, j-0.5)]
def update_lag_p_pos_Taylor2nd(U_v, U_v_m, particle, dx, dy, dt):
    u, a = get_particle_u_a(U_v, U_v_m, particle, dx, dy, dt)
    # print(u, a)
    particle_moved = particle + dt * u + 0.5 * dt ** 2 * a
    return particle_moved

def get_vertex_u_from_stencil(U_stencil):
    U_v = np.zeros([2, 2, 2])
    ### u(i-0.5,j-0.5)
    ux = 0.25 * U_stencil[0, 0, 0] + 0.25 * U_stencil[0, 0, 1] + 0.25 * U_stencil[0, 1, 0] + 0.25 * U_stencil[0, 1, 1]
    uy = 0.25 * U_stencil[1, 0, 0] + 0.25 * U_stencil[1, 0, 1] + 0.25 * U_stencil[1, 1, 0] + 0.25 * U_stencil[1, 1, 1]
    U_v[0, 0, 0] = ux
    U_v[1, 0, 0] = uy
    ### u(i-0.5,j+0.5)
    ux = 0.25 * U_stencil[0, 0, 1] + 0.25 * U_stencil[0, 0, 2] + 0.25 * U_stencil[0, 1, 1] + 0.25 * U_stencil[0, 1, 2]
    uy = 0.25 * U_stencil[1, 0, 1] + 0.25 * U_stencil[1, 0, 2] + 0.25 * U_stencil[1, 1, 1] + 0.25 * U_stencil[1, 1, 2]
    U_v[0, 0, 1] = ux
    U_v[1, 0, 1] = uy
    ### u(i + 0.5, j + 0.5)
    ux = 0.25 * U_stencil[0, 1, 1] + 0.25 * U_stencil[0, 1, 2] + 0.25 * U_stencil[0, 2, 2] + 0.25 * U_stencil[0, 2, 1]
    uy = 0.25 * U_stencil[1, 1, 1] + 0.25 * U_stencil[1, 1, 2] + 0.25 * U_stencil[1, 2, 2] + 0.25 * U_stencil[1, 2, 1]
    U_v[0, 1, 1] = ux
    U_v[1, 1, 1] = uy
    ### u(i+0.5,j-0.5)
    ux = 0.25 * U_stencil[0, 1, 0] + 0.25 * U_stencil[0, 1, 1] + 0.25 * U_stencil[0, 2, 1] + 0.25 * U_stencil[0, 2, 0]
    uy = 0.25 * U_stencil[1, 1, 0] + 0.25 * U_stencil[1, 1, 1] + 0.25 * U_stencil[1, 2, 1] + 0.25 * U_stencil[1, 2, 0]
    U_v[0, 1, 0] = ux
    U_v[1, 1, 0] = uy
    return np.array(U_v)

def get_particle_u_4Node(U_v, particle, dx, dy):
    x = particle[0]
    y = particle[1]
    shape_N = np.zeros([2, 2])
    shape_N[0, 0] = (1 / (dx * dy)) * (dx - x) * (dy - y)
    shape_N[0, 1] = (1 / (dx * dy)) * (dx - x) * (0. + y)
    shape_N[1, 1] = (1 / (dx * dy)) * (0. + x) * (0. + y)
    shape_N[1, 0] = (1 / (dx * dy)) * (0. + x) * (dy - y)
    # print(shape_N)
    u = (U_v[0, 0, 0] * shape_N[0, 0] + U_v[0, 0, 1] * shape_N[0, 1] +
         U_v[0, 1, 1] * shape_N[1, 1] + U_v[0, 1, 0] * shape_N[1, 0])
    v = (U_v[1, 0, 0] * shape_N[0, 0] + U_v[1, 0, 1] * shape_N[0, 1] +
         U_v[1, 1, 1] * shape_N[1, 1] + U_v[1, 1, 0] * shape_N[1, 0])
    return np.array([u, v])

### FOLLOWING SECTION 2.4.2
def get_particle_u_a(U_v, U_v_m, particle, dx, dy, dt):
    ### calculate the time derivative of the particle du/dt
    u = get_particle_u_4Node(U_v, particle, dx, dy)
    u_m = get_particle_u_4Node(U_v_m, particle, dx, dy)
    # print(u)
    dudt = (u - u_m) / dt
    ### calculate the Jacobian terms in separate directions
    Ex = (-U_v[0, 0, 0] + U_v[0, 1, 0] - U_v[0, 1, 1] + U_v[0, 0, 1])
    Ey = (-U_v[1, 0, 0] + U_v[1, 1, 0] - U_v[1, 1, 1] + U_v[1, 0, 1])
    duxdx = -(((U_v[0, 1, 0] - U_v[0, 0, 0]) / dx) + (particle[1] * Ex) / (dx * dy))
    duxdy = -(((U_v[0, 0, 1] - U_v[0, 0, 0]) / dy) + (particle[0] * Ex) / (dx * dy))
    duydx = -(((U_v[1, 1, 0] - U_v[1, 0, 0]) / dx) + (particle[1] * Ey) / (dx * dy))
    duydy = -(((U_v[1, 0, 1] - U_v[1, 0, 0]) / dy) + (particle[0] * Ey) / (dx * dy))
    ### calculate the particle compact acceleration in the Eulerian form
    ax = dudt[0] + u[0] * duxdx + u[1] * duxdy
    ay = dudt[1] + u[0] * duydx + u[1] * duydy
    return u, np.array([ax, ay])

def accum_lag_p_flux(particle_moved, phase, stencil_flux, particle_fraction, dx, dy):
    out = 1.
    ### JUDGE IF INSIDE THE ORIGINAL CELLS (BOUNDARY NOT INCLUDED)
    if 0. < particle_moved[0] < dx and 0. < particle_moved[1] < dy:
        out = 0.
        return out
    ### JUDGE IF INSIDE THE NEIGHBORING CELLS (BOUNDARY NOT INCLUDED)
    elif particle_moved[0] < 0. and particle_moved[1] < 0.:
        stencil_flux[0, phase, 0, 0] += particle_fraction
        return out
    elif particle_moved[0] < 0. < particle_moved[1] < dy:
        stencil_flux[0, phase, 0, 1] += particle_fraction
        return out
    elif particle_moved[0] < 0. and dy < particle_moved[1]:
        stencil_flux[0, phase, 0, 2] += particle_fraction
        return out
    elif 0. < particle_moved[0] < dx and dy < particle_moved[1]:
        stencil_flux[0, phase, 1, 2] += particle_fraction
        return out
    elif dx < particle_moved[0] and dy < particle_moved[1]:
        stencil_flux[0, phase, 2, 2] += particle_fraction
        return out
    elif dx < particle_moved[0] and 0. < particle_moved[1] < dy:
        stencil_flux[0, phase, 2, 1] += particle_fraction
        return out
    elif dx < particle_moved[0] and particle_moved[1] < 0.:
        stencil_flux[0, phase, 2, 0] += particle_fraction
        return out
    elif dx > particle_moved[0] > 0. > particle_moved[1]:
        stencil_flux[0, phase, 1, 0] += particle_fraction
        return out
    else:
        print('reduce the CFL number!')
        out = False
        return out

def redistribution_PARTICLE_uniform(PLIC_raw, in_fraction, out_fraction, nx, ny, ghost):
    n_l = [[-1, -1], [-1, 0], [-1, 1], [0, -1], [0, 1], [1, -1], [1, 0], [1, 1]]
    void = np.sum(out_fraction, axis=0)
    ratio = void / (np.sum(in_fraction, axis=0) + 1e-8)
    for i in range(nx - 2 * ghost):
        for j in range(ny - 2 * ghost):
            ### identification of overfilled cell
            if np.sum(PLIC_raw[:, i, j], axis=0) > 1.:
                ratio_over = 1. - min(ratio[i, j], 1.)
                over_fraction = ratio_over * in_fraction[:, i, j]
                # ### ADDING RANDOM ORDER TO REDISTRIBUTE EVENLY
                bias = random.randint(0, len(over_fraction) - 1)
                ### redistribution for each phase separately
                for k in range(len(over_fraction)):
                    k = (k + bias) % len(over_fraction)
                    ### find all the unfilled cells in the neighbors
                    d_list_1 = []
                    for n in range(len(n_l)):
                        if (np.sum(PLIC_raw[:, i + n_l[n][0], j + n_l[n][1]], axis=0) < 1. and
                                PLIC_raw[k, i + n_l[n][0], j + n_l[n][1]] > 0.01):
                            d_list_1.append(n_l[n])
                    # ind = 0
                    # while ind < len(d_list_1):
                    #     if (np.sum(PLIC_raw[:, i + d_list_1[ind][0], j + d_list_1[ind][1]], axis=0) + over_fraction[k] *
                    #             (1 / len(d_list_1)) > 1.):
                    #         d_list_1.pop(ind)
                    #         ind = 0
                    #     else:
                    #         ind += 1
                    if len(d_list_1) > 0:
                        ### redistribute to all the unfilled cells
                        for m in range(len(d_list_1)):
                            PLIC_raw[k, i + d_list_1[m][0], j + d_list_1[m][1]] += (1 / len(d_list_1)) * over_fraction[
                                k]
                        PLIC_raw[k, i, j] -= over_fraction[k]
                    else:
                        ### neighboring cells are all full-filled
                        pass

            else:
                pass

# cell = np.array([[0.05, 0],
#                  [0.1, 0.05],
#                  [0.05, 0.1],
#                  [0, 0.05]])
# bn_particles = np.load('../../blue_noise_template.npy')
# particles, particle_f = fit_the_cell(cell, bn_particles, 0.1, 0.1)
# print(particle_f)
# plt.scatter(particles[:, 0], particles[:, 1], color='blue')
# plt.show()