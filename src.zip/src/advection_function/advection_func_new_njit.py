### created by Zhang
### HKUST FU's Lab
### 2024.11.11

import math
import random
import numba as nb
import numba.np.extensions
import numpy as np
from numba import prange

@nb.jit(nopython=True)
def conservation_filter(conservation_r, tolerance):
    conservation_r_copy = conservation_r.copy()
    for i in range(len(conservation_r)):
        if abs(conservation_r[i]) < tolerance:
            conservation_r_copy[i] = 0.
        else:
            pass
    return conservation_r_copy

@nb.jit(nopython=True)
def get_cell_volume_new(cell):
    if len(cell) >= 3:
        ###the base point cell[0]
        x0 = cell[0]
        ###initialize
        vol = 0
        for i in range(len(cell) - 2):
            x1 = cell[i + 1]
            x2 = cell[i + 2]
            r1 = x1 - x0
            r2 = x2 - x0
            vol += np.abs(numba.np.extensions.cross2d(r1, r2)) / 2
        return vol
    else:
        return 0.

@nb.jit(nopython=True)
def point_in_polygon(point, polygon):
    ### JUDGE BY THE LARGEST CELL
    if np.max(polygon[:, 0]) < point[0]:
        return False
    elif np.min(polygon[:, 0]) > point[0]:
        return False
    elif np.max(polygon[:, 1]) < point[1]:
        return False
    elif np.min(polygon[:, 1]) > point[1]:
        return False
    elif point_on_polygon_edge(point, polygon):
        return True
    else:
        vote_for_True = 0
        vote_for_False = 0
        edges = np.zeros((len(polygon), 2, 2), dtype=np.float64)
        for i in range(len(polygon)):
            p1 = polygon[i]
            p2 = polygon[(i + 1) % len(polygon)]
            edges[i, 0] = p1
            edges[i, 1] = p2
        count = 0
        for edge in edges:
            if ray_insec_edg_r(point, edge):
                count += 1
            else:
                pass
        if count % 2 == 1:
            vote_for_True += 1
        else:
            vote_for_False += 1
        count = 0
        for edge in edges:
            if ray_insec_edg_l(point, edge):
                count += 1
            else:
                pass
        if count % 2 == 1:
            vote_for_True += 1
        else:
            vote_for_False += 1
        count = 0
        for edge in edges:
            if ray_insec_edg_u(point, edge):
                count += 1
            else:
                pass
        if count % 2 == 1:
            vote_for_True += 1
        else:
            vote_for_False += 1
        count = 0
        for edge in edges:
            if ray_insec_edg_d(point, edge):
                count += 1
            else:
                pass
        if count % 2 == 1:
            vote_for_True += 1
        else:
            vote_for_False += 1
        if vote_for_True >= vote_for_False:
            return True
        else:
            return False

@nb.jit(nopython=True)
def ray_insec_edg_r(point, edge):
    if edge[0, 1] != edge[1, 1]:
        if edge[0, 1] < edge[1, 1]:
            pass
        else:
            edge_copy = edge.copy()
            edge_copy[0] = edge[1]
            edge_copy[1] = edge[0]
            edge = edge_copy
    else:
        if min(edge[0, 0], edge[1, 0]) <= point[0] <= max(edge[0, 0], edge[1, 0]) and point[1] == edge[0, 1]:
            return True
        else:
            return False
    if point[1] < edge[0, 1] or point[1] > edge[1, 1]:
        return False
    elif point[0] > max(edge[0, 0], edge[1, 0]):
        return False
    else:
        if point[0] <= min(edge[0, 0], edge[1, 0]):
            return True
        else:
            if edge[0, 0] != edge[1, 0]:
                k_edge = (edge[1, 1] - edge[0, 1]) / (edge[1, 0] - edge[0, 0])
            else:
                k_edge = math.inf
            if point[0] != edge[0, 0]:
                k_p_edge = (point[1] - edge[0, 1]) / (point[0] - edge[0, 0])
            else:
                k_p_edge = math.inf
            if k_p_edge >= k_edge:
                return True
            else:
                return False

@nb.jit(nopython=True)
def ray_insec_edg_l(point, edge):
    if edge[0, 1] != edge[1, 1]:
        if edge[0, 1] < edge[1, 1]:
            pass
        else:
            edge_copy = edge.copy()
            edge_copy[0] = edge[1]
            edge_copy[1] = edge[0]
            edge = edge_copy
    else:
        if min(edge[0, 0], edge[1, 0]) <= point[0] <= max(edge[0, 0], edge[1, 0]) and point[1] == edge[0, 1]:
            return True
        else:
            return False
    if point[1] < edge[0, 1] or point[1] > edge[1, 1]:
        return False
    elif point[0] < min(edge[0, 0], edge[1, 0]):
        return False
    else:
        if point[0] >= max(edge[0, 0], edge[1, 0]):
            return True
        else:
            if edge[0, 0] != edge[1, 0]:
                k_edge = (edge[1, 1] - edge[0, 1]) / (edge[1, 0] - edge[0, 0])
            else:
                k_edge = math.inf
            if point[0] != edge[0, 0]:
                k_p_edge = (point[1] - edge[0, 1]) / (point[0] - edge[0, 0])
            else:
                k_p_edge = math.inf
            if k_p_edge <= k_edge:
                return True
            else:
                return False

@nb.jit(nopython=True)
def ray_insec_edg_u(point, edge):
    if edge[0, 0] != edge[1, 0]:
        if edge[0, 0] < edge[1, 0]:
            pass
        else:
            edge_copy = edge.copy()
            edge_copy[0] = edge[1]
            edge_copy[1] = edge[0]
            edge = edge_copy
    else:
        if min(edge[0, 1], edge[1, 1]) <= point[1] <= max(edge[0, 1], edge[1, 1]) and point[0] == edge[0, 0]:
            return True
        else:
            return False
    if point[0] < edge[0, 0] or point[0] > edge[1, 0]:
        return False
    elif point[1] > max(edge[0, 1], edge[1, 1]):
        return False
    else:
        if point[1] <= min(edge[0, 1], edge[1, 1]):
            return True
        else:
            if edge[0, 0] != edge[1, 0]:
                k_edge = (edge[1, 1] - edge[0, 1]) / (edge[1, 0] - edge[0, 0])
            else:
                if edge[0, 1] > edge[1, 1]:
                    k_edge = -math.inf
                else:
                    k_edge = math.inf
            if point[0] != edge[0, 0]:
                k_p_edge = (point[1] - edge[0, 1]) / (point[0] - edge[0, 0])
            else:
                if edge[0, 1] > point[1]:
                    k_p_edge = -math.inf
                else:
                    k_p_edge = math.inf
            if k_p_edge <= k_edge:
                return True
            else:
                return False

@nb.jit(nopython=True)
def ray_insec_edg_d(point, edge):
    if edge[0, 0] != edge[1, 0]:
        if edge[0, 0] < edge[1, 0]:
            pass
        else:
            edge_copy = edge.copy()
            edge_copy[0] = edge[1]
            edge_copy[1] = edge[0]
            edge = edge_copy
    else:
        if min(edge[0, 1], edge[1, 1]) <= point[1] <= max(edge[0, 1], edge[1, 1]) and point[0] == edge[0, 0]:
            return True
        else:
            return False
    if point[0] < edge[0, 0] or point[0] > edge[1, 0]:
        return False
    elif point[1] < min(edge[0, 1], edge[1, 1]):
        return False
    else:
        if point[1] >= max(edge[0, 1], edge[1, 1]):
            return True
        else:
            if edge[0, 0] != edge[1, 0]:
                k_edge = (edge[1, 1] - edge[0, 1]) / (edge[1, 0] - edge[0, 0])
            else:
                if edge[0, 1] > edge[1, 1]:
                    k_edge = -math.inf
                else:
                    k_edge = math.inf
            if point[0] != edge[0, 0]:
                k_p_edge = (point[1] - edge[0, 1]) / (point[0] - edge[0, 0])
            else:
                if edge[0, 1] > point[1]:
                    k_p_edge = -math.inf
                else:
                    k_p_edge = math.inf
            if k_p_edge >= k_edge:
                return True
            else:
                return False

@nb.jit(nopython=True)
def point_on_polygon_edge(point, polygon):
    for o in range(len(polygon)):
        p1 = polygon[o]
        p2 = polygon[(o + 1) % len(polygon)]
        if judge_on_line(point, p1, p2):
            return True
    return False

@nb.jit(nopython=True)
def judge_on_line(point, p1, p2):
    def distance(p1, p2):
        return ((p1[0]-p2[0])**2 + (p1[1]-p2[1])**2)**0.5
    # Determine whether the point is on the line segment
    d1 = distance(point, p1)
    d2 = distance(point, p2)
    d3 = distance(p1, p2)
    # print(point, p1, p2, abs(d1 + d2 - d3) < 1e-8)
    return abs(d1 + d2 - d3) < 1e-15

@nb.jit(nopython=True)
def gen_p_in_polygon(polygon, nn):
    ### creating the bonding box
    xs = polygon[:, 0]
    ys = polygon[:, 1]
    x_min = np.min(xs)
    x_max = np.max(xs)
    y_min = np.min(ys)
    y_max = np.max(ys)
    nn_ = 0
    points = np.zeros((nn, 2), dtype=np.float64)
    while nn_ < nn:
        x = random.random() * (x_max - x_min) + x_min
        y = random.random() * (y_max - y_min) + y_min
        point = np.array([x, y], dtype=np.float64)
        if point_in_polygon(point, polygon):
            points[nn_] = point
            nn_ += 1
        else:
            continue
    return points

@nb.jit(nopython=True)
def redistribution_PARTICLE_uni_plus_vacancy(PLIC_raw, in_fraction, out_fraction, nx, ny, ghost, tolerance):
    n_l = [[-1, -1], [-1, 0], [-1, 1], [0, -1], [0, 1], [1, -1], [1, 0], [1, 1]]
    void = np.sum(out_fraction, axis=0)
    ratio = void / (np.sum(in_fraction, axis=0) + 1e-8)
    ### UNIFORM REDISTRIBUTION
    for i in range(nx - 2 * ghost):
        for j in range(ny - 2 * ghost):
            ### identification of overfilled cell
            if np.sum(PLIC_raw[:, i, j], axis=0) > 1.:
                ratio_over = 1. - min(ratio[i, j], 1.)
                over_fraction = ratio_over * in_fraction[:, i, j]
                # ### ADDING RANDOM ORDER TO REDISTRIBUTE EVENLY
                bias = random.randint(0, len(over_fraction) - 1)
                ### redistribution for each phase separately
                for k in range(len(over_fraction)):
                    k = (k + bias) % len(over_fraction)
                    ### find all the unfilled cells in the neighbors
                    d_list_1 = []
                    for n in range(len(n_l)):
                        if (np.sum(PLIC_raw[:, i + n_l[n][0], j + n_l[n][1]], axis=0) < 1. and
                                PLIC_raw[k, i + n_l[n][0], j + n_l[n][1]] > 0.01):
                            d_list_1.append(n_l[n])
                    ind = 0
                    while ind < len(d_list_1):
                        if (np.sum(PLIC_raw[:, i + d_list_1[ind][0], j + d_list_1[ind][1]], axis=0) + over_fraction[k] *
                                (1 / len(d_list_1)) > 1.):
                            d_list_1.pop(ind)
                            ind = 0
                        else:
                            ind += 1
                    if len(d_list_1) > 0:
                        ### redistribute to all the unfilled cells
                        for m in range(len(d_list_1)):
                            PLIC_raw[k, i + d_list_1[m][0], j + d_list_1[m][1]] += (1 / len(d_list_1)) * over_fraction[
                                k]
                        PLIC_raw[k, i, j] -= over_fraction[k]
                    else:
                        ### neighboring cells are all full-filled
                        pass

            else:
                pass
    ### VACANCY TARGETED REDISTRIBUTION
    for i in range(nx - 2 * ghost):
        for j in range(ny - 2 * ghost):
            if np.sum(PLIC_raw[:, i, j], axis=0) > 1. + tolerance:
                ratio_over = 1. - min(ratio[i, j], 1.)
                over_fraction = ratio_over * in_fraction[:, i, j]
                for k in range(len(over_fraction)):
                    vacancy_list = np.zeros((len(n_l), 2), dtype=np.float64)
                    for n in range(len(n_l)):
                        if (np.sum(PLIC_raw[:, i + n_l[n][0], j + n_l[n][1]], axis=0) < 1. and
                                PLIC_raw[k, i + n_l[n][0], j + n_l[n][1]] > 0.01):
                            vacancy_list[n, 0] = 1
                            vacancy_list[n, 1] = 1 - np.sum(PLIC_raw[:, i + n_l[n][0], j + n_l[n][1]], axis=0)
                        else:
                            pass
                    for n in range(len(n_l)):
                        if vacancy_list[n, 0] == 1:
                            target_amount = over_fraction[k] * (vacancy_list[n, 1] / np.sum(vacancy_list[:, 1]))
                            dis_amount = min([target_amount, vacancy_list[n, 1]])
                            PLIC_raw[k, i + n_l[n][0], j + n_l[n][1]] += dis_amount
                            PLIC_raw[k, i, j] -= dis_amount
                            vacancy_list[n, 1] -= dis_amount
                            ### UPDATE VACANCY LIST
                            if abs(vacancy_list[n, 1]) < tolerance:
                                vacancy_list[n, 0] = 0
                            else:
                                pass
                        else:
                            pass

@nb.jit(nopython=True)
def accum_lag_p_flux_sco_1(particle_moved, phase, stencil_flux, particle_fraction, dx, dy, sco_n_1):
    out = 1.
    ### JUDGE IF INSIDE THE ORIGINAL CELLS (BOUNDARY NOT INCLUDED)
    if 0. < particle_moved[0] < dx and 0. < particle_moved[1] < dy:
        out = 0.
        return out
    ### JUDGE IF INSIDE THE NEIGHBORING CELLS (BOUNDARY NOT INCLUDED)
    elif particle_moved[0] < 0. and particle_moved[1] < 0.:
        if 0 in sco_n_1:
            stencil_flux[0, phase, 0, 0] += particle_fraction
        else:
            pass
        return out
    elif particle_moved[0] < 0. < particle_moved[1] < dy:
        if 1 in sco_n_1:
            stencil_flux[0, phase, 0, 1] += particle_fraction
        else:
            pass
        return out
    elif particle_moved[0] < 0. and dy < particle_moved[1]:
        if 2 in sco_n_1:
            stencil_flux[0, phase, 0, 2] += particle_fraction
        else:
            pass
        return out
    elif 0. < particle_moved[0] < dx and dy < particle_moved[1]:
        if 3 in sco_n_1:
            stencil_flux[0, phase, 1, 2] += particle_fraction
        else:
            pass
        return out
    elif dx < particle_moved[0] and dy < particle_moved[1]:
        if 4 in sco_n_1:
            stencil_flux[0, phase, 2, 2] += particle_fraction
        else:
            pass
        return out
    elif dx < particle_moved[0] and 0. < particle_moved[1] < dy:
        if 5 in sco_n_1:
            stencil_flux[0, phase, 2, 1] += particle_fraction
        else:
            pass
        return out
    elif dx < particle_moved[0] and particle_moved[1] < 0.:
        if 6 in sco_n_1:
            stencil_flux[0, phase, 2, 0] += particle_fraction
        else:
            pass
        return out
    elif dx > particle_moved[0] > 0. > particle_moved[1]:
        if 7 in sco_n_1:
            stencil_flux[0, phase, 1, 0] += particle_fraction
        else:
            pass
        return out
    ### JUDGE IF ON THE BOUNDARY
    elif judge_on_line(particle_moved, np.array([0., 0.], dtype=np.float64), np.array([0., dy], dtype=np.float64)):
        if 1 in sco_n_1:
            stencil_flux[0, phase, 0, 1] += particle_fraction * 0.5
        else:
            pass
        out = 0.5
        return out
    elif judge_on_line(particle_moved, np.array([0., dy], dtype=np.float64), np.array([dx, dy], dtype=np.float64)):
        if 3 in sco_n_1:
            stencil_flux[0, phase, 1, 2] += particle_fraction * 0.5
        else:
            pass
        out = 0.5
        return out
    elif judge_on_line(particle_moved, np.array([dx, dy], dtype=np.float64), np.array([dx, 0.], dtype=np.float64)):
        if 5 in sco_n_1:
            stencil_flux[0, phase, 2, 1] += particle_fraction * 0.5
        else:
            pass
        out = 0.5
        return out
    elif judge_on_line(particle_moved, np.array([0., 0.], dtype=np.float64), np.array([dx, 0.], dtype=np.float64)):
        if 7 in sco_n_1:
            stencil_flux[0, phase, 1, 0] += particle_fraction * 0.5
        else:
            pass
        out = 0.5
        return out
    elif judge_on_line(particle_moved, np.array([0., 0.], dtype=np.float64), np.array([0., -dy], dtype=np.float64)):
        if 0 in sco_n_1:
            stencil_flux[0, phase, 0, 0] += particle_fraction * 0.5
        else:
            pass
        if 7 in sco_n_1:
            stencil_flux[0, phase, 1, 0] += particle_fraction * 0.5
        else:
            pass
        return out
    elif judge_on_line(particle_moved, np.array([0., 0.], dtype=np.float64), np.array([-dx, 0.], dtype=np.float64)):
        if 0 in sco_n_1:
            stencil_flux[0, phase, 0, 0] += particle_fraction * 0.5
        else:
            pass
        if 1 in sco_n_1:
            stencil_flux[0, phase, 0, 1] += particle_fraction * 0.5
        else:
            pass
        return out
    elif judge_on_line(particle_moved, np.array([0., dy], dtype=np.float64), np.array([-dx, dy], dtype=np.float64)):
        if 2 in sco_n_1:
            stencil_flux[0, phase, 0, 2] += particle_fraction * 0.5
        else:
            pass
        if 1 in sco_n_1:
            stencil_flux[0, phase, 0, 1] += particle_fraction * 0.5
        else:
            pass
        return out
    elif judge_on_line(particle_moved, np.array([0., dy], dtype=np.float64), np.array([0., 2 * dy], dtype=np.float64)):
        if 2 in sco_n_1:
            stencil_flux[0, phase, 0, 2] += particle_fraction * 0.5
        else:
            pass
        if 3 in sco_n_1:
            stencil_flux[0, phase, 1, 2] += particle_fraction * 0.5
        else:
            pass
        return out
    elif judge_on_line(particle_moved, np.array([dx, dy], dtype=np.float64), np.array([dx, 2 * dy], dtype=np.float64)):
        if 4 in sco_n_1:
            stencil_flux[0, phase, 2, 2] += particle_fraction * 0.5
        else:
            pass
        if 3 in sco_n_1:
            stencil_flux[0, phase, 1, 2] += particle_fraction * 0.5
        else:
            pass
        return out
    elif judge_on_line(particle_moved, np.array([dx, dy], dtype=np.float64), np.array([2 * dx, dy], dtype=np.float64)):
        if 4 in sco_n_1:
            stencil_flux[0, phase, 2, 2] += particle_fraction * 0.5
        else:
            pass
        if 5 in sco_n_1:
            stencil_flux[0, phase, 2, 1] += particle_fraction * 0.5
        else:
            pass
        return out
    elif judge_on_line(particle_moved, np.array([dx, 0.], dtype=np.float64), np.array([2 * dx, 0.], dtype=np.float64)):
        if 6 in sco_n_1:
            stencil_flux[0, phase, 2, 0] += particle_fraction * 0.5
        else:
            pass
        if 5 in sco_n_1:
            stencil_flux[0, phase, 2, 1] += particle_fraction * 0.5
        else:
            pass
        return out
    elif judge_on_line(particle_moved, np.array([dx, 0.], dtype=np.float64), np.array([dx, -dy], dtype=np.float64)):
        if 6 in sco_n_1:
            stencil_flux[0, phase, 2, 0] += particle_fraction * 0.5
        else:
            pass
        if 7 in sco_n_1:
            stencil_flux[0, phase, 1, 0] += particle_fraction * 0.5
        else:
            pass
        return out
    ### JUDGE IF ON THE VERTEX
    elif particle_moved[0] == 0. and particle_moved[1] == 0.:
        if 0 in sco_n_1:
            stencil_flux[0, phase, 0, 0] += particle_fraction * 0.25
        else:
            pass
        if 1 in sco_n_1:
            stencil_flux[0, phase, 0, 1] += particle_fraction * 0.25
        else:
            pass
        if 7 in sco_n_1:
            stencil_flux[0, phase, 1, 0] += particle_fraction * 0.25
        else:
            pass
        out = 0.25
        return out
    elif particle_moved[0] == 0. and particle_moved[1] == dy:
        if 2 in sco_n_1:
            stencil_flux[0, phase, 0, 2] += particle_fraction * 0.25
        else:
            pass
        if 1 in sco_n_1:
            stencil_flux[0, phase, 0, 1] += particle_fraction * 0.25
        else:
            pass
        if 3 in sco_n_1:
            stencil_flux[0, phase, 1, 2] += particle_fraction * 0.25
        else:
            pass
        out = 0.25
        return out
    elif particle_moved[0] == dx and particle_moved[1] == dy:
        if 4 in sco_n_1:
            stencil_flux[0, phase, 2, 2] += particle_fraction * 0.25
        else:
            pass
        if 5 in sco_n_1:
            stencil_flux[0, phase, 2, 1] += particle_fraction * 0.25
        else:
            pass
        if 3 in sco_n_1:
            stencil_flux[0, phase, 1, 2] += particle_fraction * 0.25
        else:
            pass
        out = 0.25
        return out
    elif particle_moved[0] == dx and particle_moved[1] == 0.:
        if 6 in sco_n_1:
            stencil_flux[0, phase, 2, 0] += particle_fraction * 0.25
        else:
            pass
        if 5 in sco_n_1:
            stencil_flux[0, phase, 2, 1] += particle_fraction * 0.25
        else:
            pass
        if 7 in sco_n_1:
            stencil_flux[0, phase, 1, 0] += particle_fraction * 0.25
        else:
            pass
        out = 0.25
        return out
    else:
        print('reduce the CFL number!')
        out = False
        return out

@nb.jit(nopython=True)
def accum_lag_p_flux_sco_0(particle_moved, phase, stencil_flux, particle_fraction, dx, dy, sco_n_1):
    ### JUDGE IF INSIDE THE ORIGINAL CELLS (BOUNDARY NOT INCLUDED)
    if 0. < particle_moved[0] < dx and 0. < particle_moved[1] < dy:
        return
    ### JUDGE IF INSIDE THE NEIGHBORING CELLS (BOUNDARY NOT INCLUDED)
    elif particle_moved[0] < 0. and particle_moved[1] < 0.:
        if 0 in sco_n_1:
            stencil_flux[0, phase, 0, 0] += particle_fraction
        else:
            pass
        return
    elif particle_moved[0] < 0. < particle_moved[1] < dy:
        if 1 in sco_n_1:
            stencil_flux[0, phase, 0, 1] += particle_fraction
        else:
            pass
        return
    elif particle_moved[0] < 0. and dy < particle_moved[1]:
        if 2 in sco_n_1:
            stencil_flux[0, phase, 0, 2] += particle_fraction
        else:
            pass
        return
    elif 0. < particle_moved[0] < dx and dy < particle_moved[1]:
        if 3 in sco_n_1:
            stencil_flux[0, phase, 1, 2] += particle_fraction
        else:
            pass
        return
    elif dx < particle_moved[0] and dy < particle_moved[1]:
        if 4 in sco_n_1:
            stencil_flux[0, phase, 2, 2] += particle_fraction
        else:
            pass
        return
    elif dx < particle_moved[0] and 0. < particle_moved[1] < dy:
        if 5 in sco_n_1:
            stencil_flux[0, phase, 2, 1] += particle_fraction
        else:
            pass
        return
    elif dx < particle_moved[0] and particle_moved[1] < 0.:
        if 6 in sco_n_1:
            stencil_flux[0, phase, 2, 0] += particle_fraction
        else:
            pass
        return
    elif dx > particle_moved[0] > 0. > particle_moved[1]:
        if 7 in sco_n_1:
            stencil_flux[0, phase, 1, 0] += particle_fraction
        else:
            pass
        return
    ### JUDGE IF ON THE BOUNDARY
    elif judge_on_line(particle_moved, np.array([0., 0.], dtype=np.float64), np.array([0., dy], dtype=np.float64)):
        if 1 in sco_n_1:
            stencil_flux[0, phase, 0, 1] += particle_fraction * 0.5
        else:
            pass
        return
    elif judge_on_line(particle_moved, np.array([0., dy], dtype=np.float64), np.array([dx, dy], dtype=np.float64)):
        if 3 in sco_n_1:
            stencil_flux[0, phase, 1, 2] += particle_fraction * 0.5
        else:
            pass
        return
    elif judge_on_line(particle_moved, np.array([dx, dy], dtype=np.float64), np.array([dx, 0.], dtype=np.float64)):
        if 5 in sco_n_1:
            stencil_flux[0, phase, 2, 1] += particle_fraction * 0.5
        else:
            pass
        return
    elif judge_on_line(particle_moved, np.array([0., 0.], dtype=np.float64), np.array([dx, 0.], dtype=np.float64)):
        if 7 in sco_n_1:
            stencil_flux[0, phase, 1, 0] += particle_fraction * 0.5
        else:
            pass
        return
    elif judge_on_line(particle_moved, np.array([0., 0.], dtype=np.float64), np.array([0., -dy], dtype=np.float64)):
        if 0 in sco_n_1:
            stencil_flux[0, phase, 0, 0] += particle_fraction * 0.5
        else:
            pass
        if 7 in sco_n_1:
            stencil_flux[0, phase, 1, 0] += particle_fraction * 0.5
        else:
            pass
        return
    elif judge_on_line(particle_moved, np.array([0., 0.], dtype=np.float64), np.array([-dx, 0.], dtype=np.float64)):
        if 0 in sco_n_1:
            stencil_flux[0, phase, 0, 0] += particle_fraction * 0.5
        else:
            pass
        if 1 in sco_n_1:
            stencil_flux[0, phase, 0, 1] += particle_fraction * 0.5
        else:
            pass
        return
    elif judge_on_line(particle_moved, np.array([0., dy], dtype=np.float64), np.array([-dx, dy], dtype=np.float64)):
        if 2 in sco_n_1:
            stencil_flux[0, phase, 0, 2] += particle_fraction * 0.5
        else:
            pass
        if 1 in sco_n_1:
            stencil_flux[0, phase, 0, 1] += particle_fraction * 0.5
        else:
            pass
        return
    elif judge_on_line(particle_moved, np.array([0., dy], dtype=np.float64), np.array([0., 2 * dy], dtype=np.float64)):
        if 2 in sco_n_1:
            stencil_flux[0, phase, 0, 2] += particle_fraction * 0.5
        else:
            pass
        if 3 in sco_n_1:
            stencil_flux[0, phase, 1, 2] += particle_fraction * 0.5
        else:
            pass
        return
    elif judge_on_line(particle_moved, np.array([dx, dy], dtype=np.float64), np.array([dx, 2 * dy], dtype=np.float64)):
        if 4 in sco_n_1:
            stencil_flux[0, phase, 2, 2] += particle_fraction * 0.5
        else:
            pass
        if 3 in sco_n_1:
            stencil_flux[0, phase, 1, 2] += particle_fraction * 0.5
        else:
            pass
        return
    elif judge_on_line(particle_moved, np.array([dx, dy], dtype=np.float64), np.array([2 * dx, dy], dtype=np.float64)):
        if 4 in sco_n_1:
            stencil_flux[0, phase, 2, 2] += particle_fraction * 0.5
        else:
            pass
        if 5 in sco_n_1:
            stencil_flux[0, phase, 2, 1] += particle_fraction * 0.5
        else:
            pass
        return
    elif judge_on_line(particle_moved, np.array([dx, 0.], dtype=np.float64), np.array([2 * dx, 0.], dtype=np.float64)):
        if 6 in sco_n_1:
            stencil_flux[0, phase, 2, 0] += particle_fraction * 0.5
        else:
            pass
        if 5 in sco_n_1:
            stencil_flux[0, phase, 2, 1] += particle_fraction * 0.5
        else:
            pass
        return
    elif judge_on_line(particle_moved, np.array([dx, 0.], dtype=np.float64), np.array([dx, -dy], dtype=np.float64)):
        if 6 in sco_n_1:
            stencil_flux[0, phase, 2, 0] += particle_fraction * 0.5
        else:
            pass
        if 7 in sco_n_1:
            stencil_flux[0, phase, 1, 0] += particle_fraction * 0.5
        else:
            pass
        return
    ### JUDGE IF ON THE VERTEX
    elif particle_moved[0] == 0. and particle_moved[1] == 0.:
        if 0 in sco_n_1:
            stencil_flux[0, phase, 0, 0] += particle_fraction * 0.25
        else:
            pass
        if 1 in sco_n_1:
            stencil_flux[0, phase, 0, 1] += particle_fraction * 0.25
        else:
            pass
        if 7 in sco_n_1:
            stencil_flux[0, phase, 1, 0] += particle_fraction * 0.25
        else:
            pass
        return
    elif particle_moved[0] == 0. and particle_moved[1] == dy:
        if 2 in sco_n_1:
            stencil_flux[0, phase, 0, 2] += particle_fraction * 0.25
        else:
            pass
        if 1 in sco_n_1:
            stencil_flux[0, phase, 0, 1] += particle_fraction * 0.25
        else:
            pass
        if 3 in sco_n_1:
            stencil_flux[0, phase, 1, 2] += particle_fraction * 0.25
        else:
            pass
        return
    elif particle_moved[0] == dx and particle_moved[1] == dy:
        if 4 in sco_n_1:
            stencil_flux[0, phase, 2, 2] += particle_fraction * 0.25
        else:
            pass
        if 5 in sco_n_1:
            stencil_flux[0, phase, 2, 1] += particle_fraction * 0.25
        else:
            pass
        if 3 in sco_n_1:
            stencil_flux[0, phase, 1, 2] += particle_fraction * 0.25
        else:
            pass
        return
    elif particle_moved[0] == dx and particle_moved[1] == 0.:
        if 6 in sco_n_1:
            stencil_flux[0, phase, 2, 0] += particle_fraction * 0.25
        else:
            pass
        if 5 in sco_n_1:
            stencil_flux[0, phase, 2, 1] += particle_fraction * 0.25
        else:
            pass
        if 7 in sco_n_1:
            stencil_flux[0, phase, 1, 0] += particle_fraction * 0.25
        else:
            pass
        return
    else:
        print('reduce the CFL number!')
        return

@nb.jit(nopython=True)
def accum_lag_p_flux_sco_1_square(particle_moved, phase, stencil_flux, particle_fraction, dx, dy, sco_n_1):
    alpha_scale = (particle_fraction) ** 0.5
    hx_2 = dx * alpha_scale / 2
    hy_2 = dy * alpha_scale / 2
    out = 1.
    ### JUDGE IF INSIDE THE ORIGINAL CELLS
    if hx_2 <= particle_moved[0] <= dx - hx_2 and hy_2 <= particle_moved[1] <= dy - hy_2:
        out = 0.
        return out
    ### JUDGE IF INSIDE THE NEIGHBORING CELLS
    elif particle_moved[0] <= -hx_2 and particle_moved[1] <= -hy_2:
        if 0 in sco_n_1:
            stencil_flux[0, phase, 0, 0] += particle_fraction
        else:
            pass
        return out
    elif particle_moved[0] <= -hx_2 and hy_2 <= particle_moved[1] < dy - hy_2:
        if 1 in sco_n_1:
            stencil_flux[0, phase, 0, 1] += particle_fraction
        else:
            pass
        return out
    elif particle_moved[0] <= -hx_2 and dy + hy_2 <= particle_moved[1]:
        if 2 in sco_n_1:
            stencil_flux[0, phase, 0, 2] += particle_fraction
        else:
            pass
        return out
    elif hx_2 <= particle_moved[0] <= dx - hx_2 and dy + hy_2 <= particle_moved[1]:
        if 3 in sco_n_1:
            stencil_flux[0, phase, 1, 2] += particle_fraction
        else:
            pass
        return out
    elif dx + hx_2 <= particle_moved[0] and dy + hy_2 <= particle_moved[1]:
        if 4 in sco_n_1:
            stencil_flux[0, phase, 2, 2] += particle_fraction
        else:
            pass
        return out
    elif dx + hx_2 <= particle_moved[0] and hy_2 <= particle_moved[1] <= dy - hy_2:
        if 5 in sco_n_1:
            stencil_flux[0, phase, 2, 1] += particle_fraction
        else:
            pass
        return out
    elif dx + hx_2 <= particle_moved[0] and particle_moved[1] <= -hy_2:
        if 6 in sco_n_1:
            stencil_flux[0, phase, 2, 0] += particle_fraction
        else:
            pass
        return out
    elif dx - hx_2 > particle_moved[0] >= hx_2 and -hy_2 >= particle_moved[1]:
        if 7 in sco_n_1:
            stencil_flux[0, phase, 1, 0] += particle_fraction
        else:
            pass
        return out
    ### FIND THE INTERSECTED AREA
    else:
        out = 0.
        bottom_left_cell = np.array([[-dx, -dy],
                                     [-dx, 0.],
                                     [0., 0.],
                                     [0., -dy]], dtype=np.float64)
        particle_cell = np.array([[particle_moved[0] - hx_2, particle_moved[1] - hy_2],
                                  [particle_moved[0] - hx_2, particle_moved[1] + hy_2],
                                  [particle_moved[0] + hx_2, particle_moved[1] + hy_2],
                                  [particle_moved[0] + hx_2, particle_moved[1] - hy_2]], dtype=np.float64)
        ### CALCULATE THE OVERLAPPING AREA FOR EACH CELL IN THE STENCIL EXCEPT THE CENTER CELL
        for ii in range(3):
            for jj in range(3):
                if not (ii == 1 and jj == 1):
                    test_cell = (bottom_left_cell +
                                 ii * np.array([dx, 0.], dtype=np.float64) +
                                 jj * np.array([0., dy], dtype=np.float64))
                    overlap_area_test = overlap_area_rectangular(test_cell, particle_cell)
                    if overlap_area_test > 1e-15:
                        f_transport = overlap_area_test / (dx * dy)
                        stencil_flux[0, phase, ii, jj] += f_transport
                        out += (f_transport / particle_fraction)
                    else:
                        pass
                else:
                    pass
        return out

@nb.jit(nopython=True)
def accum_lag_p_flux_sco_0_square(particle_moved, phase, stencil_flux, particle_fraction, dx, dy, sco_n_1):
    alpha_scale = (particle_fraction) ** 0.5
    hx_2 = dx * alpha_scale / 2
    hy_2 = dy * alpha_scale / 2
    ### JUDGE IF INSIDE THE ORIGINAL CELLS
    if hx_2 <= particle_moved[0] <= dx - hx_2 and hy_2 <= particle_moved[1] <= dy - hy_2:
        return
    ### JUDGE IF INSIDE THE NEIGHBORING CELLS
    elif particle_moved[0] <= -hx_2 and particle_moved[1] <= -hy_2:
        if 0 in sco_n_1:
            stencil_flux[0, phase, 0, 0] += particle_fraction
        else:
            pass
        return
    elif particle_moved[0] <= -hx_2 and hy_2 <= particle_moved[1] < dy - hy_2:
        if 1 in sco_n_1:
            stencil_flux[0, phase, 0, 1] += particle_fraction
        else:
            pass
        return
    elif particle_moved[0] <= -hx_2 and dy + hy_2 <= particle_moved[1]:
        if 2 in sco_n_1:
            stencil_flux[0, phase, 0, 2] += particle_fraction
        else:
            pass
        return
    elif hx_2 <= particle_moved[0] <= dx - hx_2 and dy + hy_2 <= particle_moved[1]:
        if 3 in sco_n_1:
            stencil_flux[0, phase, 1, 2] += particle_fraction
        else:
            pass
        return
    elif dx + hx_2 <= particle_moved[0] and dy + hy_2 <= particle_moved[1]:
        if 4 in sco_n_1:
            stencil_flux[0, phase, 2, 2] += particle_fraction
        else:
            pass
        return
    elif dx + hx_2 <= particle_moved[0] and hy_2 <= particle_moved[1] <= dy - hy_2:
        if 5 in sco_n_1:
            stencil_flux[0, phase, 2, 1] += particle_fraction
        else:
            pass
        return
    elif dx + hx_2 <= particle_moved[0] and particle_moved[1] <= -hy_2:
        if 6 in sco_n_1:
            stencil_flux[0, phase, 2, 0] += particle_fraction
        else:
            pass
        return
    elif dx - hx_2 > particle_moved[0] >= hx_2 and -hy_2 >= particle_moved[1]:
        if 7 in sco_n_1:
            stencil_flux[0, phase, 1, 0] += particle_fraction
        else:
            pass
        return
    ### FIND THE INTERSECTED AREA
    else:
        bottom_left_cell = np.array([[-dx, -dy],
                                     [-dx, 0.],
                                     [0., 0.],
                                     [0., -dy]], dtype=np.float64)
        particle_cell = np.array([[particle_moved[0] - hx_2, particle_moved[1] - hy_2],
                                  [particle_moved[0] - hx_2, particle_moved[1] + hy_2],
                                  [particle_moved[0] + hx_2, particle_moved[1] + hy_2],
                                  [particle_moved[0] + hx_2, particle_moved[1] - hy_2]], dtype=np.float64)
        ### CALCULATE THE OVERLAPPING AREA FOR EACH CELL IN THE STENCIL EXCEPT THE CENTER CELL
        for ii in range(3):
            for jj in range(3):
                if not (ii == 1 and jj == 1):
                    test_cell = (bottom_left_cell +
                                 ii * np.array([dx, 0.], dtype=np.float64) +
                                 jj * np.array([0., dy], dtype=np.float64))
                    overlap_area_test = overlap_area_rectangular(test_cell, particle_cell)
                    if overlap_area_test > 1e-15:
                        f_transport = overlap_area_test / (dx * dy)
                        stencil_flux[0, phase, ii, jj] += f_transport
                    else:
                        pass
                else:
                    pass
        return

### THE TWO POLYGONS SHOULD BE RECTANGULAR
@nb.jit(nopython=True)
def overlap_area_rectangular(polygon1, polygon2):
    poly1_x1 = np.min(polygon1[:, 0])
    poly1_y1 = np.min(polygon1[:, 1])
    poly1_x2 = np.max(polygon1[:, 0])
    poly1_y2 = np.max(polygon1[:, 1])
    poly2_x1 = np.min(polygon2[:, 0])
    poly2_y1 = np.min(polygon2[:, 1])
    poly2_x2 = np.max(polygon2[:, 0])
    poly2_y2 = np.max(polygon2[:, 1])
    x_overlap = max(0., min(poly1_x2, poly2_x2) - max(poly1_x1, poly2_x1))
    y_overlap = max(0., min(poly1_y2, poly2_y2) - max(poly1_y1, poly2_y1))
    return x_overlap * y_overlap

@nb.jit(nopython=True)
def get_particle_u_4Node(U_stencil, x_loc, y_loc, dx, dy):
    if x_loc <= 0.5 * dx:
        if y_loc <= 0.5 * dy:
            xi = x_loc / dx * 2
            yita = y_loc / dy * 2
            shaped_u = np.array([U_stencil[0, 0, 0], U_stencil[0, 0, 1], U_stencil[0, 1, 1], U_stencil[0, 1, 0]], dtype=np.float64)
            shaped_v = np.array([U_stencil[1, 0, 0], U_stencil[1, 0, 1], U_stencil[1, 1, 1], U_stencil[1, 1, 0]], dtype=np.float64)
        else:
            xi = x_loc / dx * 2
            yita = (y_loc - dy) / dy * 2
            shaped_u = np.array([U_stencil[0, 0, 1], U_stencil[0, 0, 2], U_stencil[0, 1, 2], U_stencil[0, 1, 1]], dtype=np.float64)
            shaped_v = np.array([U_stencil[1, 0, 1], U_stencil[1, 0, 2], U_stencil[1, 1, 2], U_stencil[1, 1, 1]], dtype=np.float64)
    else:
        if y_loc <= 0.5 * dy:
            xi = (x_loc - dx) / dx * 2
            yita = y_loc / dy * 2
            shaped_u = np.array([U_stencil[0, 1, 0], U_stencil[0, 1, 1], U_stencil[0, 2, 1], U_stencil[0, 2, 0]], dtype=np.float64)
            shaped_v = np.array([U_stencil[1, 1, 0], U_stencil[1, 1, 1], U_stencil[1, 2, 1], U_stencil[1, 2, 0]], dtype=np.float64)
        else:
            xi = (x_loc - dx) / dx * 2
            yita = (y_loc - dy) / dy * 2
            shaped_u = np.array([U_stencil[0, 1, 1], U_stencil[0, 1, 2], U_stencil[0, 2, 2], U_stencil[0, 2, 1]], dtype=np.float64)
            shaped_v = np.array([U_stencil[1, 1, 1], U_stencil[1, 1, 2], U_stencil[1, 2, 2], U_stencil[1, 2, 1]], dtype=np.float64)
    shape_N = np.array([0.25 * (1 - xi) * (1 - yita),
                        0.25 * (1 - xi) * (1 + yita),
                        0.25 * (1 + xi) * (1 + yita),
                        0.25 * (1 + xi) * (1 - yita)], dtype=np.float64)
    u = shape_N.dot(shaped_u)
    v = shape_N.dot(shaped_v)
    return u, v

@nb.jit(nopython=True)
def truncate_cell(cell):
    truncation_ind = 0
    while truncation_ind < len(cell):
        if cell[truncation_ind, 0] < 0:
            break
        else:
            truncation_ind += 1
    cell_truncated = cell[0:truncation_ind, :]
    return cell_truncated

@nb.jit(nopython=True)
def truncate_cells(cells):
    truncation_ind = 0
    while truncation_ind < len(cells):
        if cells[truncation_ind, 0, 0] < 0:
            break
        else:
            truncation_ind += 1
    cells_truncated = cells[0:truncation_ind]
    return cells_truncated

@nb.jit(nopython=True)
def truncate_phase(phase):
    truncation_ind = 0
    while truncation_ind < len(phase):
        if phase[truncation_ind] < 0:
            break
        else:
            truncation_ind += 1
    phase_truncated = phase[0:truncation_ind]
    return phase_truncated

@nb.jit(nopython=True)
def gen_ALL_p_in_rim_2(points, Z, cfl, dx, dy, cells_L):
    particle_fraction = np.zeros(len(cells_L), dtype=np.float64)
    normal_cell = np.ones(len(cells_L), dtype=np.float64)
    ### ACTIVATION MATRIX
    activation_m = np.ones((Z, Z), dtype=np.int8)
    if cfl < 0.5:
        trunca_ind = min(int(len(activation_m) / 2) - 1, int(cfl * Z) + 2)
        activation_m[trunca_ind:(len(activation_m) - trunca_ind), trunca_ind:(len(activation_m[0]) - trunca_ind)] = (
            np.zeros((len(activation_m) - 2 * trunca_ind, len(activation_m) - 2 * trunca_ind), dtype=np.int8))
    ### LAG POINTS CLASSIFICATION MATRIX
    classification_m = np.zeros((len(cells_L), Z, Z), dtype=np.int8)
    cell_particle_num = np.zeros(len(cells_L), dtype=np.int32)
    for ii in range(Z):
        for jj in range(Z):
            for k in range(len(cells_L)):
                polygon = truncate_cell(cells_L[k])
                particle = points[:, ii, jj]
                if point_in_polygon(particle, polygon):
                    if activation_m[ii, jj]:
                        classification_m[k, ii, jj] = 1
                    cell_particle_num[k] += 1
                    break
                else:
                    pass

    cells_volume = np.zeros(len(cells_L))
    ### DEFAULT APPENDIX PARTICLE NUMBER IS NOT THE LARGEST
    particle_append = -np.ones((len(cells_L), np.max(cell_particle_num), 2), dtype=np.float64)
    max_appendix_particle_num = 0
    for ii in range(len(cells_L)):
        cell = truncate_cell(cells_L[ii])
        cell_volume = get_cell_volume_new(cell)
        cells_volume[ii] = cell_volume
        cell_particle_num_activated = np.sum(classification_m[ii, :, :])
        if cell_particle_num_activated == 0 and cell_volume > 1e-15:
            normal_cell[ii] = 0
            p_num = int((cell_volume * Z ** 2) / (dx * dy)) + 1
            if p_num > max_appendix_particle_num:
                max_appendix_particle_num = p_num
            cell_particle_num[ii] = p_num
            if p_num == 1:
                xs = cell[:, 0]
                ys = cell[:, 1]
                x_avg = 0.5 * (np.min(xs) + np.max(xs))
                y_avg = 0.5 * (np.min(ys) + np.max(ys))
                particle = np.array([x_avg, y_avg], dtype=np.float64)
                particle_append[ii, 0, :] = particle
            else:
                particles = gen_p_in_polygon(cell, p_num)
                particle_append[ii, 0:len(particles), :] = particles
            particle_fraction[ii] = (cell_volume / (dx * dy)) / p_num
        else:
            pass
    particle_append = particle_append[:, 0:(max_appendix_particle_num + 1), :]
    for ii in range(len(cells_L)):
        if normal_cell[ii] == 1:
            particle_fraction[ii] = (cells_volume[ii] / (dx * dy)) / cell_particle_num[ii]

    return classification_m, particle_fraction, normal_cell, particle_append

@nb.jit(nopython=True)
def gen_ALL_p_in_rim_3(points, Z, cfl, dx, dy, cells_L, PIRM):
    particle_fraction = np.zeros(len(cells_L), dtype=np.float64)
    normal_cell = np.ones(len(cells_L), dtype=np.int8)
    ### ACTIVATION MATRIX
    activation_m = np.ones((Z, Z), dtype=np.int8)
    if cfl < 0.5 and PIRM:
        trunca_ind = int(min(np.floor(len(activation_m) / 2), np.ceil(cfl * Z))) + 1
        if trunca_ind < (len(activation_m) - trunca_ind):
            activation_m[trunca_ind:(len(activation_m) - trunca_ind), trunca_ind:(len(activation_m[0]) - trunca_ind)] = (
                np.zeros((len(activation_m) - 2 * trunca_ind, len(activation_m) - 2 * trunca_ind), dtype=np.int8))
        else:
            pass
    ### LAG POINTS CLASSIFICATION MATRIX
    classification_m = np.zeros((len(cells_L), Z, Z), dtype=np.int8)
    cell_particle_num = np.zeros(len(cells_L), dtype=np.int32)
    for ii in range(Z):
        for jj in range(Z):
            for k in range(len(cells_L)):
                polygon = truncate_cell(cells_L[k])
                particle = points[:, ii, jj]
                if point_in_polygon(particle, polygon):
                    if activation_m[ii, jj]:
                        classification_m[k, ii, jj] = 1
                    cell_particle_num[k] += 1
                    break
                else:
                    pass

    cells_volume = np.zeros(len(cells_L))
    ### DEFAULT APPENDED PARTICLES
    particle_append = -np.ones((len(cells_L), Z, 2), dtype=np.float64)
    for ii in range(len(cells_L)):
        cell = truncate_cell(cells_L[ii])
        cell_volume = get_cell_volume_new(cell)
        cells_volume[ii] = cell_volume
        cell_particle_num_activated = np.sum(classification_m[ii, :, :])
        if cell_particle_num_activated == 0 and cell_volume > 0.:
            p_num = min(int((cell_volume * Z**2) / (dx * dy)) + 1, Z)
            cell_particle_num[ii] = p_num
            normal_cell[ii] = 0
            if p_num == 1:
                xs = cell[:, 0]
                ys = cell[:, 1]
                x_center = 0.5 * (np.min(xs) + np.max(xs))
                y_center = 0.5 * (np.min(ys) + np.max(ys))
                particle = np.array([x_center, y_center], dtype=np.float64)
                particle_append[ii, 0, :] = particle
            else:
                particles = gen_p_in_polygon(cell, p_num)
                particle_append[ii, 0:p_num, :] = particles
        else:
            pass
    for ii in range(len(cells_L)):
        particle_fraction[ii] = (cells_volume[ii] / (dx * dy)) / cell_particle_num[ii]

    return classification_m, particle_fraction, normal_cell, particle_append

@nb.jit(nopython=True)
def gen_ALL_p_in_rim_2_one_cell(Z, cfl, PIRM):
    particle_fraction = 1 / Z ** 2
    ### ACTIVATION MATRIX
    activation_m = np.ones((Z, Z), dtype=np.int8)
    if cfl < 0.5 and PIRM:
        trunca_ind = min(int(len(activation_m) / 2) - 1, int(cfl * Z) + 2)
        activation_m[trunca_ind:(len(activation_m) - trunca_ind), trunca_ind:(len(activation_m[0]) - trunca_ind)] = (
            np.zeros((len(activation_m) - 2 * trunca_ind, len(activation_m) - 2 * trunca_ind), dtype=np.int8))
    return activation_m, particle_fraction

@nb.jit(nopython=True)
def cal_flux_in_stencil_njit_wrapper_sco_1(points, flux_in_stencil, Z, cfl, dx, dy, cells_L, phase_L, dt, U_stencil,
                                           U_mid_stencil, n_l_ind, conservation_fix_r, PIRM):
    ### GET ALL THE PARTICLES IN THE ADVECTION ACTIVE RIM REGION
    classification_m, particle_fractions, normal_cell, particle_append = gen_ALL_p_in_rim_3(points, Z, cfl, dx, dy,
                                                                                            cells_L, PIRM)
    ### GET THE PARTICULIZED INFORMATION OF THE CELL POLYGONS
    for k in range(len(cells_L)):
        phase = phase_L[k]
        flow_out = 0.
        ### CONSERVATION_FIX
        if len(cells_L) > 1:
            particle_fraction_fix = particle_fractions[k] * conservation_fix_r[phase]
        else:
            particle_fraction_fix = particle_fractions[k]
        if normal_cell[k] == 1:
            classification_m_k = classification_m[k, :, :]
            for ii in range(Z):
                for jj in range(Z):
                    if classification_m_k[ii, jj]:
                        particle = points[:, ii, jj]
                        ### RK2
                        u_i, v_i = get_particle_u_4Node(U_stencil, particle[0], particle[1], dx, dy)
                        p_mid = particle + 0.5 * dt * np.array([u_i, v_i])
                        u_mid, v_mid = get_particle_u_4Node(U_mid_stencil, p_mid[0], p_mid[1], dx, dy)
                        particle_moved = particle + dt * np.array([u_mid, v_mid])
                        out = accum_lag_p_flux_sco_1_square(particle_moved, phase, flux_in_stencil,
                                                            particle_fraction_fix, dx,
                                                            dy, n_l_ind)
                        flow_out += out
                    else:
                        pass
        else:
            print('residuals compute')
            particles = particle_append[k, :, :]
            for particle in particles:
                if particle[0] >= 0.:
                    u_i, v_i = get_particle_u_4Node(U_stencil, particle[0], particle[1], dx, dy)
                    p_mid = particle + 0.5 * dt * np.array([u_i, v_i])
                    u_mid, v_mid = get_particle_u_4Node(U_mid_stencil, p_mid[0], p_mid[1], dx, dy)
                    particle_moved = particle + dt * np.array([u_mid, v_mid])
                    out = accum_lag_p_flux_sco_1_square(particle_moved, phase, flux_in_stencil, particle_fraction_fix,
                                                        dx, dy,
                                                        n_l_ind)
                    flow_out += out
                else:
                    break
        flux_in_stencil[1, phase, 1, 1] += flow_out * particle_fractions[k]
    return flux_in_stencil

@nb.jit(nopython=True)
def cal_flux_in_stencil_njit_wrapper_sco_0(points, flux_in_stencil, Z, cfl, dx, dy, phase_L, dt, U_stencil,
                                           U_mid_stencil, n_l_ind, PIRM):
    activation_m, particle_fraction_sco_0 = gen_ALL_p_in_rim_2_one_cell(Z, cfl, PIRM)
    phase = phase_L[0]
    for ii in range(Z):
        for jj in range(Z):
            if activation_m[ii, jj]:
                particle = points[:, ii, jj]
                u_i, v_i = get_particle_u_4Node(U_stencil, particle[0], particle[1], dx, dy)
                p_mid = particle + 0.5 * dt * np.array([u_i, v_i])
                u_mid, v_mid = get_particle_u_4Node(U_mid_stencil, p_mid[0], p_mid[1], dx, dy)
                particle_moved = particle + dt * np.array([u_mid, v_mid])
                accum_lag_p_flux_sco_0_square(particle_moved, phase, flux_in_stencil, particle_fraction_sco_0, dx, dy,
                                              n_l_ind)
    return flux_in_stencil

@nb.jit(nopython=True)
def meshgrid_2d(x, y):
    xx = np.empty(shape=(x.size, y.size), dtype=x.dtype)
    yy = np.empty(shape=(x.size, y.size), dtype=y.dtype)
    for j in range(y.size):
        for k in range(x.size):
            xx[k, j] = x[k]
            yy[k, j] = y[j]
    return xx, yy


@nb.jit(nopython=True)
def get_flux_particle_njit_consfix_exc(U, U_p, sco_arr, cells_arr, cells_phase_arr, dx, dy, dt, ghost, nx, ny, flux_stencil, Z,
                                       conservation_fix_r, cfl, PIRM):
    # Z_max = 300
    ### extend one cell length to store the donating flux of the broaders
    sub_flux = np.zeros((2, 3, nx - 2 * ghost + 2 * flux_stencil, ny - 2 * ghost + 2 * flux_stencil), dtype=np.float64)
    n_l = [[-1, -1], [-1, 0], [-1, 1], [0, 1], [1, 1], [1, 0], [1, -1], [0, -1]]
    ### CALCULATE THE DILATATION Z TO MAKE SURE THE NUMBER OF EFFECTIVE LAG POINTS IS NOT DECREASING
    # if cfl < 0.5:
    #     Z = min(Z_max, int(Z / (2 * cfl)))
    # else:
    #     pass

    x_a = np.linspace(dx * (0.5 / Z), dx * (1 - 0.5 / Z), Z)
    y_a = np.linspace(dy * (0.5 / Z), dy * (1 - 0.5 / Z), Z)
    # x_a = np.linspace(0., dx, Z, dtype=np.float64)
    # y_a = np.linspace(0., dy, Z, dtype=np.float64)

    ### point ~ [2, Z, Z]
    points_x, points_y = meshgrid_2d(x_a, y_a)
    points = np.zeros((2, x_a.size, y_a.size), dtype=np.float64)
    points[0, :, :] = points_x
    points[1, :, :] = points_y
    for i in prange(nx - 2 * ghost):
        for j in prange(ny - 2 * ghost):
            n_l_ind = [0, 1, 2, 3, 4, 5, 6, 7]
            sco = sco_arr[i + ghost, j + ghost]
            flux_in_stencil = np.zeros((2, 3, 3, 3), dtype=np.float64)
            ### RECORD ALL SCO=1 NEIGHBOR (CLOCKWISE)
            for o in range(len(n_l)):
                sco_n = sco_arr[i + ghost + n_l[o][0],j + ghost + n_l[o][1]]
                if sco_n == 0:
                    n_l_ind.remove(o)
                else:
                    pass
            ### CONSIDERING THE POLYGON CONSISTS AT MOST 10 VERTICES
            cells_L = cells_arr[i + ghost, j + ghost]
            cells_L = truncate_cells(cells_L)
            phase_L = cells_phase_arr[i + ghost, j + ghost]
            phase_L = truncate_phase(phase_L)
            U_stencil = U[:                                              ,
                          i - 1 + ghost:i + 2 + ghost,
                          j - 1 + ghost:j + 2 + ghost]
            U_p_stencil = U_p[:                                              ,
                              i - 1 + ghost:i + 2 + ghost,
                              j - 1 + ghost:j + 2 + ghost]
            U_mid_stencil = 0.5 * (U_stencil + U_p_stencil)
            n_l_ind = nb.typed.List(n_l_ind)
            if sco == 1:
                flux_in_stencil = cal_flux_in_stencil_njit_wrapper_sco_1(points, flux_in_stencil, Z, cfl, dx, dy,
                                                                         cells_L, phase_L, dt, U_stencil, U_mid_stencil,
                                                                         n_l_ind, conservation_fix_r, PIRM)
            else:
                if n_l_ind:
                    flux_in_stencil = cal_flux_in_stencil_njit_wrapper_sco_0(points, flux_in_stencil, Z, cfl, dx, dy,
                                                                             phase_L, dt, U_stencil, U_mid_stencil,
                                                                             n_l_ind, PIRM)
                else:
                    pass
            sub_flux[:                                        ,
                     :                                        ,
                     i - 1 + flux_stencil:i + 2 + flux_stencil,
                     j - 1 + flux_stencil:j + 2 + flux_stencil] += flux_in_stencil
    return sub_flux

# dx = 1.
# dy = 1.
# cells = []
# cell1 = np.array([[0.   , 0.   ],
#                   [0.   , dy   ],
#                   [.5*dx, dy   ],
#                   [.5*dx, .5*dy]], dtype=np.float64)
# cells.append(cell1)
# cell2 = np.array([[.5*dx, .5*dy],
#                   [.5*dx, dy   ],
#                   [dx   , dy   ],
#                   [dx   , 0.   ]], dtype=np.float64)
# cells.append(cell2)
# cell3 = np.array([[0.   , 0.   ],
#                   [.5*dx, .5*dy],
#                   [dx   , 0.   ]], dtype=np.float64)
# cells.append(cell3)
# largest_len_cells = 0
# for kk in range(len(cells)):
#     if len(cells[kk]) > largest_len_cells:
#         largest_len_cells = len(cells[kk])
#     else:
#         pass
# cells_L = -np.ones((len(cells), largest_len_cells, 2), dtype=np.float64)
# for kk in range(len(cells)):
#     cells_L[kk, 0:len(cells[kk]), :] = cells[kk]
# print(cells_L)

# Z = 20
# cfl = 0.499
# # if cfl < 0.5:
# #     Z = int(Z / (2 * cfl))
# # else:
# #     pass
# print(Z)
# x_a = np.linspace(dx * (0.5 / Z), dx * (1 - 0.5 / Z), Z, dtype=np.float64)
# y_a = np.linspace(dy * (0.5 / Z), dy * (1 - 0.5 / Z), Z, dtype=np.float64)
# points = np.meshgrid(x_a, y_a)
# points = np.array(points, dtype=np.float64)
# classification_m, particle_fractions, normal_cell, particle_append = gen_ALL_p_in_rim_3(points, Z, cfl, dx, dy, cells_L)
# print(particle_fractions)
# for i in range(len(classification_m)):
#     points_num = np.sum(classification_m[i])
#     print(points_num)
# particles_all = [[] for jj in range(len(cells_L))]
# for k in range(len(cells_L)):
#     classification_m_k = classification_m[k, :, :]
#     for i in range(len(classification_m_k)):
#         for j in range(len(classification_m_k[0])):
#             if classification_m_k[i, j]:
#                 particles_all[k].append(points[:, i, j])
# particles_1 = np.array(particles_all[0])
# plt.figure(figsize=(10, 10))
# plt.scatter(particles_1[:, 0], particles_1[:, 1], color='red', linewidths=0.1)
# particles_2 = np.array(particles_all[1])
# plt.scatter(particles_2[:, 0], particles_2[:, 1], color='yellow', linewidths=0.1)
# particles_3 = np.array(particles_all[2])
# plt.scatter(particles_3[:, 0], particles_3[:, 1], color='blue', linewidths=0.1)
# plt.grid()
# plt.show()
