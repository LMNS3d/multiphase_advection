###This is the geometric transformation toolbox for the newly designed algorithm
###creator: Zhang, HKUST

import matplotlib
import numpy as np
from matplotlib import collections as mc
from src.reconstruction.PLIC import *

plt.rc('text', usetex=True)
plt.rc('font', family='serif', size=14)
matplotlib.rcParams['axes.linewidth'] = 3

# def plot_interface_plic_adv(ax, O_position, cells, lw, dx=1., dy=1.):
#     if len(cells) > 1:
#         for i in range(len(cells)):
#             cell_i = cells[i][1]
#             for v in range(len(cell_i)):
#                 p1 = cell_i[v % len(cell_i)]
#                 p2 = cell_i[(v + 1) % len(cell_i)]
#                 # print('The two points consist the line are: ', [p1, p2])
#                 if not ((p1[0] == p2[0] and p1[0] in [0., dx]) or (p1[1] == p2[1] and p1[1] in [0., dy])):
#                     line = [[p1 + O_position, p2 + O_position]]
#                     # print('The line is: ', line)
#                     lc = mc.LineCollection(line, colors='black', linewidths=lw, label=r'\textbf{PLIC}')
#                     ax.add_collection(lc)
#                 else:
#                     pass
#     else:
#         pass

def plot_interface_plic_adv(ax, O_position, cells, lw, dx=1., dy=1.):
    # print(cells)
    if len(cells) > 1:
        for i in range(len(cells)):
            if cells[i][2] != 1:
                cell_i = cells[i][1]
                for v in range(len(cell_i)):
                    p1 = cell_i[v % len(cell_i)]
                    p2 = cell_i[(v + 1) % len(cell_i)]
                    if not (p1[0] == p2[0] and p1[0] in [0., dx]):
                        if not (p1[1] == p2[1] and p1[1] in [0., dy]):
                            # if abs(p1[1] - p2[1]) < 1e-10:
                            #     print(p1, p2)
                            #     print(dy)
                            line = [[p1 + O_position, p2 + O_position]]
                            lc = mc.LineCollection(line, colors='black', linewidths=lw, label=r'\textbf{PLIC}')
                            ax.add_collection(lc)
                    else:
                        pass
            else:
                pass
    else:
        pass

def plot_interface_plic_adv_DP(ax, O_position, cells, lw, dx=1., dy=1.):
    # print(cells)
    if len(cells) > 1:
        for i in range(len(cells)):
            if cells[i][2] != 1:
                cell_i = cells[i][1]
                for v in range(len(cell_i)):
                    p1 = cell_i[v % len(cell_i)]
                    p2 = cell_i[(v + 1) % len(cell_i)]
                    # print('The two points consist the line are: ', [p1, p2])
                    if not ((p1[0] == p2[0] and p1[0] in [0., dx]) or (p1[1] == p2[1] and p1[1] in [0., dy])):
                        line = [[p1 + O_position, p2 + O_position]]
                        # print('The line is: ', line)
                        lc = mc.LineCollection(line, colors='darkred', linewidths=lw, label=r'\textbf{DP}')
                        ax.add_collection(lc)
                    else:
                        pass
            else:
                pass
    else:
        pass

def plot_interface_3(ax, O_position, cells, color, lw, dx=1., dy=1.):
    # print(O_position)
    for i in range(len(cells)):
        sub_cell_indicator = cells[i][-1]
        if not sub_cell_indicator == 1:
            lines = []
            line1 = [cells[i][1][0] + O_position, cells[i][1][1] + O_position]
            if not judge_on_boundary(line1, O_position, dx, dy):
                lines.append(line1)
            line2 = [cells[i][1][0] + O_position, cells[i][1][-1] + O_position]
            if not judge_on_boundary(line2, O_position, dx, dy):
                lines.append(line2)
            # print(lines)
            lc = mc.LineCollection(lines, colors=color, linewidths=lw, label=r'\textbf{DP}')
            ax.add_collection(lc)

def plot_dpL(ax, O_position, posL, color):
    x1, x2, y1, y2 = [], [], [], []
    for m in range(len(posL)):
        if len(posL[m]) == 1:
            x1.append(posL[m][0][0] + O_position[0])
            y1.append(posL[m][0][1] + O_position[1])
        else:
            x2.append(posL[m][1][0] + O_position[0])
            y2.append(posL[m][1][1] + O_position[1])
    ax.plot(x1, y1, c=color, marker='o', linewidth=1, markersize=2)
    ax.plot(x2, y2, c=color, marker='*', linewidth=1, markersize=2)


def judge_on_boundary(line, position, dx=1., dy=1.):
    ### upper or lower boundary
    A = line[0][1] == line[1][1] and (line[0][1] == dy + position[1] or line[0][1] == 0. + position[1])
    B = line[0][0] == line[1][0] and (line[0][0] == dx + position[0] or line[0][0] == 0. + position[0])
    if A or B:
        return True
    else:
        return False

# ### This code is to generate 3 * 3 stencil from n * m field
# ### The center subgrid index is the position
# ### position: [i, j]
# ### Sf: n * m VF field
# def get_sf(position, Sf):
#     ### first make sure the the position is within the n * m field
#     if not ((0 < position[0] < len(Sf[0])) and (0 < position[1] < len(Sf[0][0]))):
#         return False
#     else:
#         field_position = position
#         sf_cc = Sf[:, field_position[0] - 1:field_position[0] + 2, field_position[1] - 1:field_position[1] + 2]
#     return sf_cc
