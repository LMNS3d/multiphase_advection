### created by Zhang
### HKUST FU's Lab
### 2025.1.8
### referenced to RC Sunny's article: 'VOF with center of mass and Lagrangian particles (VCLP): a surface tracking and
### advection method for incompressible fluids'

import multiprocessing
import os.path
from src.advection_function.advection_func import get_phi_mp, update_u_mp, boundary_update_3, repair4
from src.plot.plot_function import plot_interface_plic_adv
from multiprocessing import Queue
from src.initialization.static_cases import circle_mp
import pandas as pd
from src.reconstruction.PLIC import PLIC_unsplit_exact_mp
from src.functions.mp_function import divide_domain
from src.advection_function.advection_function_vclp import *
from src.functions.mp_function import create_processes_vclp_flux, combine_results_vclp_flux, start_and_join_processes_vclp_flux


def vclp_adv_PLIC_mp(f, nx, ny, u_stencil, case, ghost, CFL, tend, dx, dy, N, T, num_p):
    ### INITIALIZE VCLP BLUE NOISE STENCIL
    if os.path.exists('./blue_noise_template.npy'):
        particles = np.load('./blue_noise_template.npy')
    else:
        particles = create_blue_noise_stencil(25, dx, dy)
    manager = multiprocessing.Manager()
    dt_max = 0.05
    t = 0.
    t_L = []
    tolerance = 1e-8
    flux_stencil = 1
    conservation_f = []
    total_ratio_change_L = []
    fraction_change_ratio_L = []
    phi = get_phi_mp(nx, ny, 0., N, T, dx, dy, ghost, case, num_p)
    U = update_u_mp(phi, nx, ny, u_stencil, 0., dx, dy, case, num_p)
    dt = min(CFL * min(dx, dy) / np.max(U) , dt_max)
    phi_m = get_phi_mp(nx, ny, -dt, N, T, dx, dy, ghost, case, num_p)
    U_m = update_u_mp(phi_m, nx, ny, u_stencil, -dt, dx, dy, case, num_p)
    print('initial dt: ', dt)
    PLIC_f = f.copy()
    conservation_f_ini_ = np.sum(PLIC_f[:, ghost:len(PLIC_f[0]) - ghost, ghost:len(PLIC_f[0, 0]) - ghost], axis=1)
    conservation_f_ini = np.sum(conservation_f_ini_, axis=1)
    fraction_change_ratio = np.zeros(conservation_f_ini.shape)
    PLIC_recons = PLIC_unsplit_exact_mp(PLIC_f, dx, dy, tolerance, num_p)
    ### draw
    fig, ax = plt.subplots(1, 1, figsize=[10, 10])
    N_ax_x = len(f[0]) - 2 * ghost
    N_ax_y = len(f[0][0]) - 2 * ghost
    ax.set_aspect('equal')
    ax.grid(linestyle='--')
    ax.set_xticklabels([])
    ax.set_yticklabels([])
    ax.set_xlim([0, dx * N_ax_x])
    ax.set_ylim([0, dx * N_ax_y])
    ax.xaxis.set_major_locator(MultipleLocator(dx))
    ax.yaxis.set_major_locator(MultipleLocator(dy))
    ### PLIC-Bussmann
    for m in range(N_ax_x):
        for n in range(N_ax_y):
            O_position = np.array([m * dx, n * dy])
            grid_info = PLIC_recons[m + ghost][n + ghost]
            if grid_info[0] != 0 and grid_info[1]['method']:
                cells = grid_info[1]['cells']
                plot_interface_plic_adv(ax, O_position, cells, 2, dx, dy)
            else:
                pass
    fig.subplots_adjust(wspace=0, hspace=0)
    plt.savefig('./advection/recons/recons_{}.png'.format(t), format='png', dpi=300)
    plt.close()
    ###
    while t < tend:
        print('Time step is: ', t)
        if (t + dt) > tend:
            dt = tend - t
        print('Time interval is: ', dt)
        ### domain separation
        que = Queue()
        ### initialize the empty intermediate VOF field after AX and AY advection
        ### FLUX IN AND FLUX OUT
        flux = np.zeros([2, 3, nx, ny])
        return_dict = manager.dict()
        return_dict['flux'] = flux
        x_parts, y_parts = divide_domain(nx - 2 * ghost, ny - 2 * ghost, num_p)
        info = {'U': U,
                'U_m': U_m,
                't': t,
                'dt': dt,
                'dx': dx,
                'dy': dy,
                'x_parts': x_parts,
                'y_parts': y_parts,
                'tolerance': tolerance,
                'ghost': ghost,
                'PLIC_recons': PLIC_recons,
                'flux_stencil': flux_stencil,
                'particles': particles
                }
        ####################################################
        ### advection implementation
        processes = create_processes_vclp_flux(vclp_flux_mp_exc, combine_results_vclp_flux, info, que,
                                                   return_dict)
        flux = start_and_join_processes_vclp_flux(processes, return_dict)
        out_fraction = flux[1, :, :, :]
        in_fraction = flux[0, :, :, :]
        PLIC_raw = PLIC_f + in_fraction - out_fraction
        PLIC_raw = boundary_update_3(PLIC_raw, ghost)
        # f_err_ = 1 - np.sum(PLIC_raw[:, ghost:len(PLIC_raw[0]) - ghost, ghost:len(PLIC_raw[0, 0]) - ghost], axis=0)
        # fig, ax = plt.subplots()
        # im = ax.imshow(f_err_)
        # fig.colorbar(im, ax=ax, label='colorbar')
        # plt.savefig('./conservation/image/conservation_{}.png'.format(int(t * 100000)), format='png', dpi=300)
        # plt.close()
        ### redistribution
        redistribution_PARTICLE_uniform(PLIC_raw, in_fraction, out_fraction, nx, ny, ghost)
        PLIC_f = repair4(PLIC_raw, tolerance)

        conservation_f_i_ = np.sum(PLIC_f[:, ghost:len(PLIC_f[0]) - ghost, ghost:len(PLIC_f[0, 0]) - ghost], axis=1)
        conservation_f_i = np.sum(conservation_f_i_, axis=1)
        print('The conservatives abs: ', conservation_f_i)
        fraction_change = conservation_f_i - conservation_f_ini
        print('The conservatives rela: ', fraction_change)
        fraction_change_ratio = fraction_change / conservation_f_ini
        print('The conservation ratio: ', fraction_change_ratio)
        fraction_change_ratio_L.append(fraction_change_ratio)
        total_ratio_change = np.sum(abs(fraction_change_ratio), axis=0)
        total_ratio_change_L.append(total_ratio_change)
        conservation_f.append(conservation_f_i.tolist())
        ####################################################
        # PLIC_recons = PLIC_unsplit_mp(PLIC_f, dx, dy, tolerance, num_p)
        PLIC_recons = PLIC_unsplit_exact_mp(PLIC_f, dx, dy, tolerance, num_p)
        U_m = U.copy()
        t = dt + t
        phi = get_phi_mp(nx, ny, t, N, T, dx, dy, ghost, case, num_p)
        U = update_u_mp(phi, nx, ny, u_stencil, t, dx, dy, case, num_p)
        t_L.append(t)
        dt = min(CFL * min(dx, dy) / np.max(U), dt_max)
        ### plotting
        fig, ax = plt.subplots(1, 1, figsize=[10, 10])
        N_ax_x = len(f[0]) - 2 * ghost
        N_ax_y = len(f[0][0]) - 2 * ghost
        ax.set_aspect('equal')
        ax.grid(linestyle='--')
        ax.set_xticklabels([])
        ax.set_yticklabels([])
        ax.set_xlim([0, dx * N_ax_x])
        ax.set_ylim([0, dx * N_ax_y])
        ax.xaxis.set_major_locator(MultipleLocator(dx))
        ax.yaxis.set_major_locator(MultipleLocator(dy))
        ### PLIC-Bussmann
        for m in range(N_ax_x):
            for n in range(N_ax_y):
                # for m in range(location_x - 1, location_x + 2):
                #     for n in range(location_y - 1, location_y + 2):
                O_position = np.array([m * dx, n * dy])
        #         face_u_left_x_pos = O_position[0]
        #         face_u_left_y_pos = O_position[1] + 0.5 * dx
        #         face_u_bot_x_pos = O_position[0] + 0.5 * dx
        #         face_u_bot_y_pos = O_position[1]
        #         face_u_left_x_dir = U_face[0, m + ghost,
        #                                       n + ghost] / dx
        #         face_u_left_y_dir = 0.
        #         face_u_bot_x_dir = 0.
        #         face_u_bot_y_dir = U_face[2, m + ghost,
        #                                      n + ghost] / dx
        #         ax.quiver(face_u_left_x_pos, face_u_left_y_pos, face_u_left_x_dir, face_u_left_y_dir,
        #                   scale=1e3, width=0.002, color='red')
        #         ax.quiver(face_u_bot_x_pos, face_u_bot_y_pos, face_u_bot_x_dir, face_u_bot_y_dir,
        #                   scale=1e3, width=0.002, color='red')
                grid_info = PLIC_recons[m + ghost][n + ghost]
                if grid_info[0] != 0 and grid_info[1]['method']:
                    cells = grid_info[1]['cells']
                    plot_interface_plic_adv(ax, O_position, cells, 2, dx, dy)
                else:
                    pass
        fig.subplots_adjust(wspace=0, hspace=0)
        plt.savefig('./advection/recons/recons_{}.png'.format(int(t * 100000)), format='png', dpi=300)
        plt.close()
    ### save the conservation data
    fraction_change_ratio_L = np.array(fraction_change_ratio_L)
    conservation_f = np.array(conservation_f)
    df = pd.DataFrame(conservation_f)
    df['t'] = pd.DataFrame(t_L)
    df['total_volume_change'] = pd.DataFrame(total_ratio_change_L)
    df['ratio_0'] = fraction_change_ratio_L[:, 0]
    df['ratio_1'] = fraction_change_ratio_L[:, 1]
    df['ratio_2'] = fraction_change_ratio_L[:, 2]
    df.to_csv("./conservation/phase_conserve_quant.csv")
    ### save the conservation figure
    fig, ax = plt.subplots(1, 1, figsize=[5, 5])
    f_1 = fraction_change_ratio_L[:, 0].tolist()
    f_2 = fraction_change_ratio_L[:, 1].tolist()
    f_3 = fraction_change_ratio_L[:, 2].tolist()
    ax.plot(t_L, f_1, color='blue', label='phase 1')
    ax.plot(t_L, f_2, color='red', label='phase 2')
    ax.plot(t_L, f_3, color='green', label='phase 3')
    plt.legend()
    ax.grid(linestyle='--')
    fig.subplots_adjust(wspace=0, hspace=0)
    plt.savefig('./conservation/phase_conserve_quant.png', format='png', dpi=300)
    plt.close()
    ### CALCULATE THE L1 SHAPE ERROR
    f_err = abs(f - PLIC_f)
    np.save('./conservation/f_err.npy', f_err)
    np.save('./conservation/PLIC_f.npy', PLIC_f)
    f_err_ = np.sum(f_err[:, ghost:len(PLIC_f[0]) - ghost, ghost:len(PLIC_f[0, 0]) - ghost], axis=1)
    f_err_ = np.sum(f_err_, axis=1)
    f_err_ = np.sum(f_err_)
    print('the final shape error is: ', f_err_)

def vclp_flux_mp_exc(info, que, start_x, end_x, start_y, end_y):
    dx = info['dx']
    dy = info['dy']
    U = info['U']
    U_m = info['U_m']
    dt = info['dt']
    ghost = info['ghost']
    PLIC_recons = info['PLIC_recons']
    flux_stencil = info['flux_stencil']
    bn_particles = info['particles']
    PLIC_sub_flux_mid = get_flux_vclp_exc(U, U_m, PLIC_recons, dx, dy, dt, ghost, start_x, end_x, start_y, end_y,
                                              flux_stencil, bn_particles)
    # print(np.shape(PLIC_donating_sub_flux))
    # print('start_y: ', start_y - flux_stencil + ghost)
    # print('end_y: ', end_y + flux_stencil + ghost)
    que.put({'result': PLIC_sub_flux_mid, 'type': 'flux',
             'start_x': start_x - flux_stencil + ghost, 'end_x': end_x + flux_stencil + ghost,
             'start_y': start_y - flux_stencil + ghost, 'end_y': end_y + flux_stencil + ghost})

num_p = 12
ghost = 4
nx = 32 + 2 * ghost
ny = 32 + 2 * ghost
lx = 1.
ly = 1.
dx, dy = lx / (nx - 2 * ghost), ly / (ny - 2 * ghost)
cp = [0.5 + ghost * dx, 0.75 + ghost * dy]
dis = np.array([0., 0.])
R = 0.15
T = 2.
N = 1.
case = 2
CFL = 0.3
u_stencil = 1
if __name__ == '__main__':
    if os.path.exists('./circle_32_32_init.npy'):
        f_init = np.load('./circle_32_32_init.npy')
    else:
        f = circle_mp(cp, R, nx, ny, dx, dy, 200, num_p)
        f_init = boundary_update_3(f, ghost)
        np.save('./circle_32_32_init.npy', f_init)
    # PLIC_f = np.load('conservation/PLIC_f.npy')
    # f_err = abs(f - PLIC_f)
    # f_err_ = np.sum(f_err[:, ghost:len(PLIC_f[0]) - ghost, ghost:len(PLIC_f[0, 0]) - ghost], axis=1)
    # f_err_ = np.sum(f_err_, axis=1)
    # f_err_ = np.sum(f_err_)
    # print('the final shape error is: ', f_err_)
    vclp_adv_PLIC_mp(f_init, nx, ny, u_stencil, case, ghost, CFL, T, dx, dy, N, T, num_p)