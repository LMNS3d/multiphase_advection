### created by Zhang
### HKUST FU's Lab
### 2024.11.11
import copy
import multiprocessing
import os.path
import time
import matplotlib.pyplot as plt
import psutil
import numpy as np

from src.advection_function.advection_func import get_phi_njit, update_u_njit, boundary_update_3, repair4
from src.reconstruction.PLIC import PLIC_unsplit_exact_mp_sco, Grad_PLIC_unsplit_exact_mp_sco
from matplotlib.ticker import MultipleLocator
from src.plot.plot_function import plot_interface_plic_adv
from multiprocessing import Queue
from src.functions.mp_function import (divide_domain, create_processes_particle_flux, combine_results_particle_flux,
                                       start_and_join_processes_particle_flux)
from src.advection_function.advection_func_new_njit import get_flux_particle_njit_consfix_exc, redistribution_PARTICLE_uni_plus_vacancy, conservation_filter
from src.advection_function.advection_func_new import get_flux_particle_2_consfix_exc
from src.initialization.static_cases import circle_mp, circle_njit
from src.reconstruction.method import DP_PLIC_unsplit_exact_mp
import pandas as pd


def new_adv_PLIC_njit(f, nx, ny, u_stencil, case, ghost, CFL, tend, dx, dy, N, T, num_p, save_path, recons_method):
    record_file = open(save_path + '/output.txt', 'w')
    record_file.write('Start the geometric VOF simulation with ' + recons_method + ' method \n')
    record_file.write('nx: ' + str(nx) + ', ny: ' + str(ny) + ', CFL: ' + str(CFL) + ', num_processor: ' + str(num_p) + '\n')
    record_file.write('tend: ' + str(T) + ', dx: ' + str(dx) + ', dy: ' + str(dy) + ', T: ' + str(T) + '\n')
    time_total = 0.
    dt_max = 0.1
    t = 0.
    iter = 0
    tolerance = 1e-8
    flux_stencil = 1
    max_step = 20
    record_file.write('dt_max: ' + str(dt_max) + ', tolerance: ' + str(tolerance) + ', max_step: ' + str(max_step) +
                      '\n')
    record_file.close()
    t_L = []
    conservation_f = []
    total_ratio_change_L = []
    fraction_change_ratio_L = []
    # manager = multiprocessing.Manager()
    phi = get_phi_njit(nx, ny, 0., N, T, dx, dy, ghost, case)
    U = update_u_njit(phi, nx, ny, u_stencil, dx, dy)
    U_mag = (U[0] ** 2 + U[1] ** 2) ** 0.5
    del phi
    dt = min(CFL * min(dx, dy) / (np.max(U_mag) + 1e-8), dt_max)
    del U_mag
    PLIC_f = f.copy()
    # PLIC_f_mp = copy.deepcopy(PLIC_f)
    conservation_f_ini_ = np.sum(PLIC_f[:, ghost:len(PLIC_f[0]) - ghost, ghost:len(PLIC_f[0, 0]) - ghost], axis=1)
    conservation_f_ini = np.sum(conservation_f_ini_, axis=1)
    fraction_change_ratio = np.zeros(conservation_f_ini.shape)
    ### RECONSTRUCTION
    time_1 = time.time()
    if recons_method == 'DP':
        PLIC_recons = DP_PLIC_unsplit_exact_mp(PLIC_f, dx, dy, tolerance, max_step, num_p)
    elif recons_method == 'Choi':
        PLIC_recons = PLIC_unsplit_exact_mp_sco(PLIC_f, dx, dy, tolerance, num_p)
    elif recons_method == 'Grad':
        PLIC_recons = Grad_PLIC_unsplit_exact_mp_sco(PLIC_f, dx, dy, tolerance, num_p)
    else:
        return KeyError
    time_2 = time.time()
    time_total += time_2 - time_1
    ### draw
    fig, ax = plt.subplots(1, 1, figsize=[10, 10])
    N_ax_x = len(f[0]) - 2 * ghost
    N_ax_y = len(f[0][0]) - 2 * ghost
    ax.set_aspect('equal')
    ### 32: 0.8 64 128: 0.5
    ax.grid(linestyle='--', linewidth=0.8)
    ax.set_xticklabels([])
    ax.set_yticklabels([])
    ax.set_xlim([0, dx * N_ax_x])
    ax.set_ylim([0, dx * N_ax_y])
    ax.xaxis.set_major_locator(MultipleLocator(dx))
    ax.yaxis.set_major_locator(MultipleLocator(dy))
    ### PLIC-Bussmann
    for m in range(N_ax_x):
        for n in range(N_ax_y):
            # for m in range(location_x - 1, location_x + 2):
            #     for n in range(location_y - 1, location_y + 2):
            O_position = np.array([m * dx, n * dy], dtype=float)
            grid_info = PLIC_recons[m + ghost][n + ghost]
            sco = grid_info[1]['sco']
            if sco == 1:
                center = O_position + np.array([0.5 * dx, 0.5 * dy], dtype=float)
                ax.scatter(center[0], center[1], s=0.2, marker='*', color='red')
            if grid_info[0] != 0 and grid_info[1]['method']:
                cells = grid_info[1]['cells']
                plot_interface_plic_adv(ax, O_position, cells, 3, dx, dy)
            else:
                pass
    fig.subplots_adjust(wspace=5e-2, hspace=5e-2, bottom=1e-2, top=1 - 1e-2, left=1e-2, right=1 - 1e-2)
    plt.savefig(save_path + '/recons_{}.png'.format(t), format='png', dpi=300)
    plt.close('all')
    ###
    while t < tend:
        print('Time step is: ', t)
        if (t + dt) > tend:
            dt = tend - t
        elif t < (tend / 2) and t + dt > (tend / 2):
            dt = tend / 2 - t
        elif t < (3 * tend / 4) and t + dt > (3 * tend / 4):
            dt = 3 * tend / 4 - t
        else:
            pass
        print('Time interval is: ', dt)
        record_file = open(save_path + '/output.txt', 'a')
        record_file.write('Time step is: ' + str(t) + '\n')
        record_file.write('Time interval is: ' + str(dt) + '\n')
        record_file.close()
        ### CALCULATE U+
        phi_p = get_phi_njit(nx, ny, t + dt, N, T, dx, dy, ghost, case)
        U_p = update_u_njit(phi_p, nx, ny, u_stencil, dx, dy)
        info = {'U': U,
                'U_p': U_p,
                't': t,
                'dt': dt,
                'dx': dx,
                'dy': dy,
                'nx': nx,
                'ny': ny,
                'tolerance': tolerance,
                'ghost': ghost,
                'PLIC_recons': PLIC_recons,
                'flux_stencil': flux_stencil,
                'Z': 20,  ### default number of Lag points in a direction when CFL>0.5
                'conservation_ratio': fraction_change_ratio,
                'cfl': CFL,
                'conserve_fix': False,
                'PIRM': True,
                'CCAM': True,
                }
        ####################################################
        ### advection implementation njit
        time_1 = time.time()
        flux = new_flux_njit_exc(info)
        out_fraction = flux[1, :, :, :]
        in_fraction = flux[0, :, :, :]
        PLIC_raw = PLIC_f + in_fraction - out_fraction
        time_2 = time.time()
        time_total += time_2 - time_1
        del flux
        del info
        PLIC_raw = boundary_update_3(PLIC_raw, ghost)
        redistribution_PARTICLE_uni_plus_vacancy(PLIC_raw, in_fraction, out_fraction, nx, ny, ghost, tolerance)
        del in_fraction
        del out_fraction
        PLIC_f = repair4(PLIC_raw, tolerance)
        conservation_f_i_ = np.sum(PLIC_f[:, ghost:len(PLIC_f[0]) - ghost, ghost:len(PLIC_f[0, 0]) - ghost], axis=1)
        conservation_f_i = np.sum(conservation_f_i_, axis=1)
        print('The conservatives abs: ', conservation_f_i)
        fraction_change = conservation_f_i - conservation_f_ini
        print('The conservatives rela: ', fraction_change)
        fraction_change_ratio = fraction_change / conservation_f_ini
        print('The conservation ratio: ', fraction_change_ratio)
        record_file = open(save_path + '/output.txt', 'a')
        record_file.write('The conservatives abs: ' + str(conservation_f_i) + '\n' +
                          'The conservatives rela: ' + str(fraction_change) + '\n' +
                          'The conservation ratio: ' + str(fraction_change_ratio) + '\n')
        record_file.close()
        fraction_change_ratio_L.append(fraction_change_ratio)
        total_ratio_change = np.sum(abs(fraction_change_ratio), axis=0)
        total_ratio_change_L.append(total_ratio_change)
        conservation_f.append(conservation_f_i.tolist())
        ####################################################
        ### RECONSTRUCTION njit
        time_1 = time.time()
        if recons_method == 'DP':
            PLIC_recons = DP_PLIC_unsplit_exact_mp(PLIC_f, dx, dy, tolerance, max_step, num_p)
        elif recons_method == 'Choi':
            PLIC_recons = PLIC_unsplit_exact_mp_sco(PLIC_f, dx, dy, tolerance, num_p)
        elif recons_method == 'Grad':
            PLIC_recons = Grad_PLIC_unsplit_exact_mp_sco(PLIC_f, dx, dy, tolerance, num_p)
        else:
            return KeyError
        time_2 = time.time()
        time_total += time_2 - time_1
        ####################################################
        t = dt + t
        t_L.append(t)
        U = U_p.copy()
        U_mag = (U[0] ** 2 + U[1] ** 2) ** 0.5
        dt = min(CFL * min(dx, dy) / (np.max(U_mag) + 1e-8), dt_max)
        del U_mag
        iter += 1
        if t == tend / 2 or t == tend or iter % 100 == 0:
        # if t > 0:
        # if t == tend/2 or t == tend or iter % 20 == 1:
            ### plotting
            fig, ax = plt.subplots(1, 1, figsize=[10, 10])
            N_ax_x = len(f[0]) - 2 * ghost
            N_ax_y = len(f[0][0]) - 2 * ghost
            ax.set_aspect('equal')
            ### 32: 0.8 64 128: 0.5
            ax.grid(linestyle='--', linewidth=0.8)
            ax.set_xticklabels([])
            ax.set_yticklabels([])
            ax.set_xlim([0, dx * N_ax_x])
            ax.set_ylim([0, dx * N_ax_y])
            ax.xaxis.set_major_locator(MultipleLocator(dx))
            ax.yaxis.set_major_locator(MultipleLocator(dy))
            ### PLIC-Bussmann
            for m in range(N_ax_x):
                for n in range(N_ax_y):
                    O_position = np.array([m * dx, n * dy], dtype=float)
                    grid_info = PLIC_recons[m + ghost][n + ghost]
                    sco = grid_info[1]['sco']
                    if sco == 1:
                        center = O_position + np.array([0.5 * dx, 0.5 * dy], dtype=float)
                        ax.scatter(center[0], center[1], s=0.5, marker='*', color='red')
                    if grid_info[0] != 0 and grid_info[1]['method']:
                        cells = grid_info[1]['cells']
                        plot_interface_plic_adv(ax, O_position, cells, 3, dx, dy)
                    else:
                        pass
            fig.subplots_adjust(wspace=5e-2, hspace=5e-2, bottom=1e-2, top=1 - 1e-2, left=1e-2, right=1 - 1e-2)
            plt.savefig(save_path + '/recons_{}.png'.format(int(t * 100000)), format='png', dpi=300)
            plt.close('all')
        print_memory_usage(save_path)
    ### save the conservation data
    fraction_change_ratio_L = np.array(fraction_change_ratio_L, dtype=float)
    conservation_f = np.array(conservation_f, dtype=float)
    df = pd.DataFrame(conservation_f)
    df['t'] = pd.DataFrame(t_L)
    df['total_volume_change'] = pd.DataFrame(total_ratio_change_L)
    df['ratio_0'] = fraction_change_ratio_L[:, 0]
    df['ratio_1'] = fraction_change_ratio_L[:, 1]
    df['ratio_2'] = fraction_change_ratio_L[:, 2]
    df.to_csv(save_path + "/phase_conserve_quant.csv")
    ### save the conservation figure
    fig, ax = plt.subplots(1, 1, figsize=[5, 5])
    f_1 = fraction_change_ratio_L[:, 0].tolist()
    f_2 = fraction_change_ratio_L[:, 1].tolist()
    f_3 = fraction_change_ratio_L[:, 2].tolist()
    ax.plot(t_L, f_1, color='blue', label='phase 1')
    ax.plot(t_L, f_2, color='red', label='phase 2')
    ax.plot(t_L, f_3, color='green', label='phase 3')
    plt.legend()
    ax.grid(linestyle='--')
    fig.subplots_adjust(wspace=0, hspace=0)
    plt.savefig(save_path + '/phase_conserve_quant.png', format='png', dpi=300)
    plt.close()
    ### CALCULATE THE L1 SHAPE ERROR
    f_err = abs(f - PLIC_f)
    np.save(save_path + '/f_err.npy', f_err)
    np.save(save_path + '/PLIC_f.npy', PLIC_f)
    f_err_ = np.sum(f_err[:, ghost:len(PLIC_f[0]) - ghost, ghost:len(PLIC_f[0, 0]) - ghost], axis=1)
    f_err_ = np.sum(f_err_, axis=1)
    f_err_ = np.sum(f_err_)
    print('the final shape error is: ', f_err_)
    print('total time: ', time_total)
    record_file = open(save_path + '/output.txt', 'a')
    record_file.write('the final shape error is: ' + str(f_err_) + '\n' +
                      'total time: ' + str(time_total) + '\n' +
                      'iteration: ' + str(iter) + '\n')
    record_file.close()


def print_memory_usage(save_path):
    process = psutil.Process(os.getpid())
    print(f"内存使用: {process.memory_info().rss / 1024 / 1024:.2f} MB")
    cpu_temp = psutil.sensors_temperatures()
    print(f'cpu temperature: {cpu_temp}')
    record_file = open(save_path + '/output.txt', 'a')
    record_file.write(f"内存使用: {process.memory_info().rss / 1024 / 1024:.2f} MB" + '\n')
    record_file.write(f'cpu temperature: {cpu_temp}' + '\n')
    record_file.close()

def new_flux_njit_exc(info):
    dx = info['dx']
    dy = info['dy']
    nx = info['nx']
    ny = info['ny']
    U = info['U']
    U_p = info['U_p']
    dt = info['dt']
    ghost = info['ghost']
    PLIC_recons = info['PLIC_recons']
    flux_stencil = info['flux_stencil']
    Z = info['Z']
    conserve_fix = info['conserve_fix']
    cfl = info['cfl']
    PIRM = info['PIRM']
    CCAM = info['CCAM']
    if CCAM:
        ### reform the sco and cells
        sco_arr = np.zeros((len(PLIC_recons), len(PLIC_recons[0])), dtype=np.int8)
        for i in range(len(sco_arr) - 2 * ghost):
            for j in range(len(sco_arr[0]) - 2 * ghost):
                sco_arr[i + ghost, j + ghost] = PLIC_recons[i + ghost][j + ghost][1]['sco']
    else:
        sco_arr = np.ones((len(PLIC_recons), len(PLIC_recons[0])), dtype=np.int8)
    ### assume at most 10 subcells and 10 vertices in each subcell
    cells_arr = -np.ones((len(PLIC_recons), len(PLIC_recons[0]), 10, 10, 2), dtype=np.float64)
    cells_phase_arr = -np.zeros((len(PLIC_recons), len(PLIC_recons[0]), 10), dtype=np.int8)
    for i in range(len(sco_arr) - 2 * ghost):
        for j in range(len(sco_arr[0]) - 2 * ghost):
            cells = PLIC_recons[i + ghost][j + ghost][1]['cells']
            for cell_num in range(len(cells)):
                cell = cells[cell_num][1]
                phase = cells[cell_num][0]
                cells_phase_arr[i + ghost, j + ghost, cell_num] = phase
                for vertice_num in range(len(cell)):
                    cells_arr[i + ghost, j + ghost, cell_num, vertice_num, :] = cell[vertice_num]
    if conserve_fix:
        conservation_ratio = info['conservation_ratio']
        conservation_fix_r = (1. + conservation_filter(conservation_ratio, 1e-4) / cfl) ** -2
    else:
        conservation_fix_r = np.ones(3, dtype=np.float64)
    flux = get_flux_particle_njit_consfix_exc(U, U_p, sco_arr, cells_arr, cells_phase_arr, dx, dy, dt, ghost, nx, ny, flux_stencil, Z, conservation_fix_r, cfl, PIRM)
    flux_return = np.zeros((2, 3, nx, ny), dtype=np.float64)
    flux_return[:, :, ghost - flux_stencil:nx - ghost + flux_stencil, ghost - flux_stencil:ny - ghost + flux_stencil] = flux
    return flux_return

def new_flux_mp_exc(info, que, start_x, end_x, start_y, end_y):
    dx = info['dx']
    dy = info['dy']
    U = info['U']
    U_p = info['U_p']
    dt = info['dt']
    ghost = info['ghost']
    PLIC_recons = info['PLIC_recons']
    flux_stencil = info['flux_stencil']
    Z = info['Z']
    conserve_fix = info['conserve_fix']
    # ### EFFECT OF VOLUME RELAXATION
    # relax_coe = info['relax_coe']
    ### FRACTION_CHANGE_RATIO
    cfl = info['cfl']
    if conserve_fix:
        conservation_ratio = info['conservation_ratio']
        conservation_fix_r = (1. - conservation_filter(conservation_ratio, 1e-6) / cfl)
    else:
        conservation_fix_r = np.ones(3, dtype=np.float64)
    PLIC_sub_flux_mid = get_flux_particle_2_consfix_exc(U, U_p, PLIC_recons, dx, dy, dt, ghost, start_x, end_x, start_y,
                                                        end_y, flux_stencil, Z, conservation_fix_r, cfl)
    que.put({'result': PLIC_sub_flux_mid, 'type': 'flux',
             'start_x': start_x - flux_stencil + ghost, 'end_x': end_x + flux_stencil + ghost,
             'start_y': start_y - flux_stencil + ghost, 'end_y': end_y + flux_stencil + ghost})
    del PLIC_sub_flux_mid

num_p = 9
ghost = 4
nx = 32 + 2 * ghost
ny = 32 + 2 * ghost
lx = (nx - 2 * ghost) / (ny - 2 * ghost)
ly = 1.
dx, dy = lx/(nx - 2 * ghost), ly/(ny - 2 * ghost)
R = 0.15
T = 4.
### reversed vortex circle
cp = [0.5 + ghost * dx, 0.75 + ghost * dy]
### deformation field circle
# cp = [0.5 + ghost * dx, 0.5 + ghost * dy]
### translation 1
# cp = [0.2 + ghost * dx, 0.5 + (ghost + 0.5) * dy]
### deformation && reversed vortex
N = 1.
### translation 1
# N = 0.6 * np.pi / T
### 0 diagonal advection
### 1 horizontal advection
### 2 reverse vortex
### 3 deformation field
case = 2
CFL = 0.9
u_stencil = 1
resolution = 500

if __name__ == '__main__':
    ################################ reversed vortex ####################################
    if os.path.exists('./f_vortex_ini_32_32.npy'):
        f_init = np.load('./f_vortex_ini_32_32.npy')
    else:
        f = circle_mp(cp, R, nx, ny, dx, dy, resolution, num_p)
        f_init = boundary_update_3(f, ghost)
        np.save('./f_vortex_ini_32_32.npy', f_init)
    # if os.path.exists('./f_vortex_ini_64_64.npy'):
    #     f_init = np.load('./f_vortex_ini_64_64.npy')
    # else:
    #     f = circle_mp(cp, R, nx, ny, dx, dy, resolution, num_p)
    #     f_init = boundary_update_3(f, ghost)
    #     np.save('./f_vortex_ini_64_64.npy', f_init)
    # if os.path.exists('./f_vortex_ini_128_128.npy'):
    #     f_init = np.load('./f_vortex_ini_128_128.npy')
    # else:
    #     f = circle_mp(cp, R, nx, ny, dx, dy, resolution, num_p)
    #     f_init = boundary_update_3(f, ghost)
    #     np.save('./f_vortex_ini_128_128.npy', f_init)
    ######################################## deformation field #######################################
    ### the initial circle of the deformation field is different from the reversed vortex
    # if os.path.exists('./f_deform_ini_32_32.npy'):
    #     f_init = np.load('./f_deform_ini_32_32.npy')
    # else:
    #     cp = np.array(cp, dtype=np.float64)
    #     f = circle_njit(cp, R, nx, ny, dx, dy, resolution)
    #     f_init = boundary_update_3(f, ghost)
    #     np.save('./f_deform_ini_32_32.npy', f_init)
    # if os.path.exists('./f_deform_ini_64_64.npy'):
    #     f_init = np.load('./f_deform_ini_64_64.npy')
    # else:
    #     cp = np.array(cp, dtype=np.float64)
    #     f = circle_njit(cp, R, nx, ny, dx, dy, resolution)
    #     f_init = boundary_update_3(f, ghost)
    #     np.save('./f_deform_ini_64_64.npy', f_init)
    # if os.path.exists('./f_deform_ini_128_128.npy'):
    #     f_init = np.load('./f_deform_ini_128_128.npy')
    # else:
    #     cp = np.array(cp, dtype=np.float64)
    #     f = circle_njit(cp, R, nx, ny, dx, dy, resolution)
    #     f_init = boundary_update_3(f, ghost)
    #     np.save('./f_deform_ini_128_128.npy', f_init)
    ####################################### translation 1 ############################################
    # if os.path.exists('./f_translation1_ini_64_64.npy'):
    #     f_init = np.load('./f_translation1_ini_64_64.npy')
    # else:
    #     cp = np.array(cp, dtype=np.float64)
    #     f = circle_njit(cp, R, nx, ny, dx, dy, resolution)
    #     f_init = boundary_update_3(f, ghost)
    #     np.save('./f_translation1_ini_64_64.npy', f_init)

    save_path = './output'
    if os.path.exists(save_path):
        pass
    else:
        os.mkdir(save_path)
    # PLIC_f = np.load('conservation/PLIC_f.npy')
    # f_err = abs(f - PLIC_f)
    # f_err_ = np.sum(f_err[:, ghost:len(PLIC_f[0]) - ghost, ghost:len(PLIC_f[0, 0]) - ghost], axis=1)
    # f_err_ = np.sum(f_err_, axis=1)
    # f_err_ = np.sum(f_err_)
    # print('the final shape error is: ', f_err_)
    new_adv_PLIC_njit(f_init, nx, ny, u_stencil, case, ghost, CFL, T, dx, dy, N, T, num_p, save_path, 'Grad')
