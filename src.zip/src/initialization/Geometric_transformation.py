###This is the geometric transformation toolbox for the newly designed algorithm
###creator: Zhang, HKUST


### This function returns a volume fraction field of three phases
def T_translation(triple_point, translation_distance, n_x, n_y, dx, dy):
    ### initialization of the volume fraction field
    result = np.zeros([3, n_x, n_y])
    ### calculation the instant triple point position
    triple_point += translation_distance
    for i in range(n_x):
        for j in range(n_y):
            ### The vertex starting from lower-left point, counter-clockwise
            vertices = np.array([[i * dx, j * dy],
                                 [i * dx, (j + 1) * dy],
                                 [(i + 1) * dx, (j + 1) * dy],
                                 [(i + 1) * dx, j * dy]])
            ### first, if the grid is not a cut grid
            if vertices[1][1] <= triple_point[1]:
                result[2, i, j] = 1.
                result[1, i, j] = 0.
                result[0, i, j] = 0.
            elif vertices[2][0] <= triple_point[0] and vertices[0][1] >= triple_point[1]:
                result[0, i, j] = 1.
                result[1, i, j] = 0.
                result[2, i, j] = 0.
            elif vertices[0][0] >= triple_point[0] and vertices[0][1] >= triple_point[1]:
                result[1, i, j] = 1.
                result[0, i, j] = 0.
                result[2, i, j] = 0.
            ### second, calculated the volume fraction of cut grid
            else:
                ### 1. calculate the volume fraction of phase 3
                d_3 = triple_point[1] - vertices[0][1]
                if 0 <= d_3 <= dy:
                    result[2, i, j] = d_3 / dy
                else:
                    result[2, i, j] = 0.
                ### 2. calculate the volume fraction of phase 2
                d_2 = triple_point[0] - vertices[1][0]
                if 0 <= d_2 <= dx:
                    result[1, i, j] = (1. - result[2, i, j]) * ((dx - d_2) / dx)
                else:
                    if vertices[0][0] > triple_point[0]:
                        result[1, i, j] = 1. - result[2, i, j]
                    else:
                        pass
                ### 3. calculate the volume fraction of phase 1
                result[0, i, j] = 1. - result[1, i, j] - result[2, i, j]
    return result


### This function uses Monte Carol Method to solve for the volume fraction
def Y_rotation(triple_point, angle, n_x, n_y, dx, dy, resolution):
    ### angle 1 is the angle of the right line (initial position)
    angle_1 = (np.pi / 4) + angle
    ### angle 2 is the angle of the left line (initial position)
    angle_2 = (3 * np.pi / 4) + angle
    ### angle 3 is the angle of the lower line (initial position)
    angle_3 = (3 * np.pi / 2) + angle
    angle_list = np.array([angle_1, angle_2, angle_3])
    ### initialization of the volume fraction field
    result = np.zeros([3, n_x, n_y])
    phase_count = np.zeros([3, n_x, n_y])
    phase_list = np.array([0, 1, 2])
    ### construct MC points
    np.random.seed(0)
    x_num = n_x * resolution
    y_num = n_y * resolution
    x = np.random.uniform(0., 1., x_num)
    x *= n_x * dx
    y = np.random.uniform(0., 1., y_num)
    y *= n_y * dy
    for m in range(len(x)):
        for n in range(len(y)):
            ### construct MC points
            MC_point = np.array([x[m], y[n]])
            ### which indicates the MC angle is between -Pi/2 and Pi/2
            if MC_point[0] > triple_point[0]:
                MC_theta = np.arctan((MC_point[1] - triple_point[1]) / (MC_point[0] - triple_point[0]))
                if MC_theta >= 0:
                    pass
                else:
                    MC_theta += 2 * np.pi
            ### which indicates the MC angle is between Pi/2 and 3Pi/2
            elif MC_point[0] < triple_point[0]:
                # MC_theta = -1.
                MC_theta = np.arctan((MC_point[1] - triple_point[1]) / (MC_point[0] - triple_point[0]))
                MC_theta += np.pi
            ### if there is no atan defined
            else:
                # MC_theta = -1.
                if MC_point[1] > triple_point[1]:
                    MC_theta = np.pi / 2
                elif MC_point[1] < triple_point[1]:
                    MC_theta = 3 * np.pi / 2
                else:
                    MC_theta = -1.
            MC_phase_ind = judge(angle_list, phase_list, MC_theta)
            phase_count[MC_phase_ind, int(MC_point[0] // dx), int(MC_point[1] // dy)] += 1
    ## according to the phase_count, calculate the
    for p in range(n_x):
        for q in range(n_y):
            seq = phase_count[:, p, q]
            total_count = sum(seq)
            for u in range(len(seq)):
                result[u, p, q] = seq[u] / total_count
    return result

### This function uses Monte Carol Method to solve for the volume fraction
def Y_rotation_Bussmann(triple_point, n_x, n_y, dx, dy, resolution):
    ### angle 1 is the angle of the right line (initial position)
    angle_1 = (93.43 / 180) * np.pi
    ### angle 2 is the angle of the left line (initial position)
    angle_2 = (213.43 / 180) * np.pi
    ### angle 3 is the angle of the lower line (initial position)
    angle_3 = (333.43 / 180) * np.pi
    angle_list = np.array([angle_1, angle_2, angle_3])
    ### initialization of the volume fraction field
    result = np.zeros([3, n_x, n_y])
    phase_count = np.zeros([3, n_x, n_y])
    phase_list = np.array([0, 1, 2])
    ### construct MC points
    np.random.seed(0)
    x_num = n_x * resolution
    y_num = n_y * resolution
    x = np.random.uniform(0., 1., x_num)
    x *= n_x * dx
    y = np.random.uniform(0., 1., y_num)
    y *= n_y * dy
    ### loading system
    total = len(x) * len(y)
    cur = 0
    old_percent = 0
    for m in range(len(x)):
        for n in range(len(y)):
            percent = int((cur / total) * 100)
            if percent > old_percent:
                print('field generate process: {} %'.format(percent))
                old_percent = percent
            ### construct MC points
            MC_point = np.array([x[m], y[n]])
            ### which indicates the MC angle is between -Pi/2 and Pi/2
            if MC_point[0] > triple_point[0]:
                MC_theta = np.arctan((MC_point[1] - triple_point[1]) / (MC_point[0] - triple_point[0]))
                if MC_theta >= 0:
                    pass
                else:
                    MC_theta += 2 * np.pi
            ### which indicates the MC angle is between Pi/2 and 3Pi/2
            elif MC_point[0] < triple_point[0]:
                # MC_theta = -1.
                MC_theta = np.arctan((MC_point[1] - triple_point[1]) / (MC_point[0] - triple_point[0]))
                MC_theta += np.pi
            ### if there is no atan defined
            else:
                # MC_theta = -1.
                if MC_point[1] > triple_point[1]:
                    MC_theta = np.pi / 2
                elif MC_point[1] < triple_point[1]:
                    MC_theta = 3 * np.pi / 2
                else:
                    MC_theta = -1.
            MC_phase_ind = judge_Bussmann(angle_list, phase_list, MC_theta)
            phase_count[MC_phase_ind, int(MC_point[0] // dx), int(MC_point[1] // dy)] += 1
            cur += 1
    ## according to the phase_count, calculate the
    for p in range(n_x):
        for q in range(n_y):
            seq = phase_count[:, p, q]
            total_count = sum(seq)
            for u in range(len(seq)):
                result[u, p, q] = seq[u] / total_count
    return result

### This function uses Monte Carol Method to solve for the volume fraction
def Y_rotation_Bussmann_2(triple_point, n_x, n_y, dx, dy, resolution):
    ### angle 1 is the angle of the right line (initial position)
    angle_1 = 0.
    ### angle 2 is the angle of the left line (initial position)
    angle_2 = (120 / 180) * np.pi
    ### angle 3 is the angle of the lower line (initial position)
    angle_3 = (240 / 180) * np.pi
    angle_list = np.array([angle_1, angle_2, angle_3])
    ### initialization of the volume fraction field
    result = np.zeros([3, n_x, n_y])
    phase_count = np.zeros([3, n_x, n_y])
    phase_list = np.array([0, 1, 2])
    ### construct MC points
    np.random.seed(0)
    x_num = n_x * resolution
    y_num = n_y * resolution
    x = np.random.uniform(0., 1., x_num)
    x *= n_x * dx
    y = np.random.uniform(0., 1., y_num)
    y *= n_y * dy
    ### loading system
    total = len(x) * len(y)
    cur = 0
    old_percent = 0
    for m in range(len(x)):
        for n in range(len(y)):
            percent = int((cur / total) * 100)
            if percent > old_percent:
                print('field generate process: {} %'.format(percent))
                old_percent = percent
            ### construct MC points
            MC_point = np.array([x[m], y[n]])
            ### which indicates the MC angle is between -Pi/2 and Pi/2
            if MC_point[0] > triple_point[0]:
                MC_theta = np.arctan((MC_point[1] - triple_point[1]) / (MC_point[0] - triple_point[0]))
                if MC_theta >= 0:
                    pass
                else:
                    MC_theta += 2 * np.pi
            ### which indicates the MC angle is between Pi/2 and 3Pi/2
            elif MC_point[0] < triple_point[0]:
                # MC_theta = -1.
                MC_theta = np.arctan((MC_point[1] - triple_point[1]) / (MC_point[0] - triple_point[0]))
                MC_theta += np.pi
            ### if there is no atan defined
            else:
                # MC_theta = -1.
                if MC_point[1] > triple_point[1]:
                    MC_theta = np.pi / 2
                elif MC_point[1] < triple_point[1]:
                    MC_theta = 3 * np.pi / 2
                else:
                    MC_theta = -1.
            MC_phase_ind = judge_Bussmann_2(angle_list, phase_list, MC_theta)
            phase_count[MC_phase_ind, int(MC_point[0] // dx), int(MC_point[1] // dy)] += 1
            cur += 1
    ## according to the phase_count, calculate the
    for p in range(n_x):
        for q in range(n_y):
            seq = phase_count[:, p, q]
            total_count = sum(seq)
            for u in range(len(seq)):
                result[u, p, q] = seq[u] / total_count
    return result

def doubleline_translation(n, d1, d2, n_x, n_y, dx, dy):
    ### initialization of the volume fraction field
    result = np.zeros([3, n_x, n_y])
    for i in range(n_x):
        for j in range(n_y):
            # print('The current calculated cell is: ', [i, j])
            ### The vertex starting from lower-left point, counter-clockwise
            cell = np.array([[i * dx, j * dy],
                             [i * dx, (j + 1) * dy],
                             [(i + 1) * dx, (j + 1) * dy],
                             [(i + 1) * dx, j * dy]])
            if not judge_outside_line(cell, n, d1):
                cell_remain = plic_cell_remain_general(n, d1, dx, dy, cell[0])
                # print('The remain cell is: ', cell_remain)
                intersects = plic_get_intersects(cell, n, d1)
                volume_1 = get_cut_volume_polygon_with_intersects(intersects, cell, n, d1)
                result[0, i, j] = volume_1 / dx * dy
            else:
                cell_remain = cell
                # print('The remain cell is (outside): ', cell_remain)
                result[0, i, j] = 0.
            if not judge_outside_line(cell, n, d2):
                intersects = plic_get_intersects(cell_remain, n, d2)
                volume_2 = get_cut_volume_polygon_with_intersects(intersects, cell_remain, n, d2)
                result[1, i, j] = volume_2 / dx * dy
            else:
                result[1, i, j] = 0.
            result[2, i, j] = min(1., max(0., 1. - result[0, i, j] - result[1, i, j]))
    return result


# ### test of double line
# n = np.array([np.sqrt(2) / 2, np.sqrt(2) / 2])
# d1 = (2 / 2) * np.sqrt(2)
# d2 = (3 / 2) * np.sqrt(2)
# sf = doubleline_translation(n, d1, d2, 4, 4, 1., 1.)
# print(sf)

### This function is used to judge the phase the MC angle lies in
### 0~angle1: phase1; angle1~angle2: phase2; angle2~angle3: phase3; angle3 ~ 2Pi: phase1
### output
### phase_ind
def judge(angle_list, phase_list, angle):
    if 0 <= angle < angle_list[0] or angle_list[2] <= angle <= 2 * np.pi:
        return phase_list[0]
    elif angle_list[0] <= angle < angle_list[1]:
        return phase_list[1]
    else:
        return phase_list[2]

def judge_Bussmann(angle_list, phase_list, angle):
    if 0 <= angle < angle_list[0] or angle_list[2] <= angle <= 2 * np.pi:
        return phase_list[0]
    elif angle_list[0] <= angle < angle_list[1]:
        return phase_list[1]
    else:
        return phase_list[2]

def judge_Bussmann_2(angle_list, phase_list, angle):
    if angle_list[0] <= angle < angle_list[1]:
        return phase_list[0]
    elif angle_list[1] <= angle < angle_list[2]:
        return phase_list[1]
    else:
        return phase_list[2]
# angle_incre = np.pi / 18
# ind_list = []
# for k in range(36):
#     angle_k = k * angle_incre
#     angle_1 = (np.pi / 4)
#     angle_2 = (3 * np.pi / 4)
#     angle_3 = (3 * np.pi / 2)
#     angle_list = np.array([angle_1, angle_2, angle_3])
#     phase_list = np.array([0, 1, 2])
#     ju = judge(angle_list, phase_list, angle_k)
#     ind_list.append([ju, angle_k * (180 / np.pi)])
# for kk in range(len(ind_list)):
#     print(ind_list[kk])

### This function is used to judge the number of phase in the reconstructed sub-grid
def judge_phase_num(sf):
    center_sf = sf[:, 1, 1]
    num = []
    for ii in range(len(center_sf)):
        if center_sf[ii] != 0:
            num.append(ii)
    # print(num)
    return num

# triple = np.array([3.5, 3.5])
# dis = np.array([0.04, 0.0])
#
# angle = 0.
# angle_incre = np.pi / 180
#
# normal = np.array([np.sqrt(3) / 2, np.sqrt(1) / 2])
# normal = np.array([1., 0.])

# nx = 10
# ny = 10
# ghost = 1
# dx = 1.
# dy = 1.
# colors = ['red', 'blue', 'white']
# cell = np.array([[0., 0.], [0., dy / 2], [0., dy], [dx / 2, dy], [dx, dy], [dx, dy / 2], [dx, 0.], [dx / 2, 0.]])
# cell_plic = np.array([[0., 0.], [0., dy], [dx, dy], [dx, 0.]])
# plic_resolution = 100
# plic_err = 0.001

# ### This is for DP method
# for i in range(10):
#
#     # ### translate the triple point
#     t_dis = dis
#     Sf = T_translation(triple, t_dis, nx, ny, dx, dy)
#     ### rotate the Y shape
#     # angle = angle_incre * i
#     # Sf = Y_rotation(triple, angle, nx, ny, dx, dy, 100)
#     # print(Sf)
#
#     N_ax_x = len(Sf[0]) - 2
#     N_ax_y = len(Sf[0][0]) - 2
#     fig, ax = plt.subplots(N_ax_x, N_ax_y, figsize=[3 * N_ax_x, 3 * N_ax_y])
#     for m in range(N_ax_x):
#         for n in range(N_ax_y):
#             ax_pos = [m, n]
#             print('The time and plot index is: ', i, ax_pos)
#             sf_center_pos = [n + 1, len(Sf[0]) - 2 - m]
#             sf = get_sf(sf_center_pos, Sf)
#             sf = np.round(sf, decimals=4)
#             phase_exist = judge_phase_num(sf)
#             count = len(phase_exist)
#             if count > 1:
#                 (pos,
#                  posL,
#                  base_line,
#                  base_vector,
#                  cells,
#                  volumes,
#                  errors,
#                  error,
#                  step,
#                  step_size,
#                  ver_tag) = Dynamic_Point_3(sf, dx, dy, 1, 1, 0.001, 15, 0.01)
#                 # print('The final position is: ', pos)
#                 # print('The vf field is: \n', sf)
#                 # print('The center vf is: ', sf[:, 1, 1])
#                 # print('The errors are: ', errors)
#                 # print('The total step is: ', step)
#                 # print('The tags are: ', ver_tag)
#                 # print('The cells are: ', cells)
#                 # plot_cells(ax, ax_pos, cells, colors, posL)
#                 plot_interface(ax, ax_pos, cells)
#             else:
#                 # plot_no_cells(ax, ax_pos, cell, phase_exist, colors)
#                 plot_no_interface(ax, ax_pos)
#                 # pass
#     fig.subplots_adjust(wspace=0, hspace=0)
#     plt.savefig('./T_translation/DP3_T_translation_{}.png'.format(i), format='png', dpi=500)
#     # plt.savefig('./Y_rotation/DP3_Y_rotation_{}.png'.format(i), format='png', dpi=500)

# ### This is single plot version
# for t in range(25):
#
#     # ### translate the triple point
#     # t_dis = dis
#     # Sf = T_translation(triple, t_dis, nx, ny, dx, dy)
#     ### rotate the Y shape
#     # angle = angle_incre * t
#     # Sf = Y_rotation(triple, angle, nx, ny, dx, dy, 100)
#
#     d1 = d1 + t * 0.01 * np.sqrt(2) / 2
#     d2 = d1 + np.sqrt(2) / 2
#     Sf = doubleline_translation(normal, d1, d2, nx, ny, dx, dy)
#
#     # print(np.round(Sf,decimals=2))
#     #
#     N_ax_x = len(Sf[0]) - 2
#     N_ax_y = len(Sf[0][0]) - 2
#     fig, ax = plt.subplots(1, 1, figsize=[2 + N_ax_x, 2 + N_ax_y])
#     ax.set_aspect('equal')
#     ax.grid(linestyle='--')
#     ax.set_xlim([0, dx * N_ax_x])
#     ax.set_ylim([0, dx * N_ax_y])
#     reconstruct = np.zeros([N_ax_x, N_ax_y])
#     for m in range(N_ax_x):
#         for n in range(N_ax_y):
#             O_position = np.array([m * dx, n * dy])
#             print('The time and plot index is: ', t, m, n)
#             sf_center_pos = [m + 1, n + 1]
#             sf = get_sf(sf_center_pos, Sf)
#             sf = np.round(sf, decimals=4)
#             phase_exist = judge_phase_num(sf)
#             count = len(phase_exist)
#             if count > 1:
#                 (pos,
#                  posL,
#                  base_line,
#                  base_vector,
#                  cells,
#                  volumes,
#                  errors,
#                  error,
#                  step,
#                  step_size,
#                  ver_tag) = Dynamic_Point_3(sf, dx, dy, 1, 1, 0.001, 15, 0.01)
#                 # print('The baselines are: ', base_line)
#                 # print('The base vectors are: ', base_vector)
#                 # print('The final position is: ', pos)
#                 # print('The vf field is: \n', sf)
#                 # print('The center vf is: ', sf[:, 1, 1])
#                 # print('The errors are: ', errors)
#                 # print('The error is: ', error)
#                 # print('The total step is: ', step)
#                 # print('The tags are: ', ver_tag)
#                 # print('The cells are: ', cells)
#                 # plot_cells(ax, ax_pos, cells, colors, posL)
#                 plot_interface_2(ax, O_position, cells)
#             else:
#                 pass
#
#     # fig.subplots_adjust(wspace=0, hspace=0)
#     # plt.savefig('./T_translation/diagonal/DP3_T_translation_diagonal_{}.png'.format(t), format='png', dpi=300)
#     # plt.savefig('./Y_translation/horizontal/DP3_Y_translation_horizontal_{}.png'.format(t), format='png', dpi=300)
#     # plt.savefig('./Y_translation/diagonal/DP3_Y_translation_diagonal_{}.png'.format(t), format='png', dpi=300)
#     # plt.savefig('./T_translation/horizontal/DP3_T_translation_horizontal_{}.png'.format(t), format='png', dpi=300)
#     # plt.savefig('./Y_rotation/DP3_Y_rotation_{}.png'.format(t), format='png', dpi=300)
#     # plt.savefig('./layer_translation/DP3_layer_translation_{}.png'.format(t), format='png', dpi=300)
#     plt.savefig('./T_translation/test/DP3_test_{}.png'.format(t), format='png', dpi=300)
#     plt.close()


# ### This is for PLIC method
# for t in range(1):
#
#     # ### translate the triple point
#     t_dis = dis
#     Sf = T_translation(triple, t_dis, nx, ny, dx, dy)
#     ### rotate the Y shape
#     # angle = angle_incre * t
#     # Sf = Y_rotation(triple, angle, nx, ny, dx, dy, 100)
#
#     # d1 = d1 + t * 0.01 * np.sqrt(2) / 2
#     # d2 = d1 + np.sqrt(2) / 2
#     # Sf = doubleline_translation(normal, d1, d2, nx, ny, dx, dy)
#
#     print(np.round(Sf, decimals=3))
#     #
#     N_ax_x = len(Sf[0]) - 2
#     N_ax_y = len(Sf[0][0]) - 2
#     fig, ax = plt.subplots(1, 1, figsize=[2 + N_ax_x, 2 + N_ax_y])
#     ax.set_aspect('equal')
#     ax.grid(linestyle='--')
#     ax.set_xlim([0, dx * N_ax_x])
#     ax.set_ylim([0, dx * N_ax_y])
#     for m in range(N_ax_x):
#         for n in range(N_ax_y):
#             O_position = np.array([m * dx, n * dy])
#             print('The time and plot index is: ', t, m, n)
#             sf_center_pos = [m + 1, n + 1]
#             sf = get_sf(sf_center_pos, Sf)
#             sf = np.round(sf, decimals=4)
#             print('The stencil is: \n', sf)
#             phase_exist = judge_phase_num(sf)
#             print('phase existence condition is: ', phase_exist)
#             count = len(phase_exist)
#             print('The number of phase is: ', count)
#             if count > 1:
#                 normals, ds = PLIC_2d_tripleP(sf, dx, dy, 1, 1, phase_exist)
#                 print(normals, ds)
#                 if len(normals) < 2:
#                     cell_1 = plic_cell_remain_general(normals[0], ds[0], dx, dy, np.array([0., 0.]))
#                     cell_2 = plic_cell_remain_general(-normals[0], -ds[0], dx, dy, np.array([0., 0.]))
#                     cells = [cell_1, cell_2]
#                     # print('The cells are: ', cells)
#                     plot_interface_plic(ax, O_position, cells)
#                 else:
#                     cell_1 = plic_cell_remain_general(-normals[0], -ds[0], dx, dy, np.array([0., 0.]))
#                     cell_1_ = plic_cell_remain_general(normals[0], ds[0], dx, dy, np.array([0., 0.]))
#                     # print('The remain cell cut by I1 is: ', cell_1_)
#                     intersects_2 = plic_get_intersects(cell_1_, normals[1], ds[1])
#                     cell_2 = get_cut_polygon_2(intersects_2, cell_1_, normals[1], ds[1])
#                     cell_3 = get_cut_polygon_2(intersects_2, cell_1_, -normals[1], -ds[1])
#                     cells = [cell_1, cell_2, cell_3]
#                     # print('The cells are: ', cells)
#                     plot_interface_plic(ax, O_position, cells)
#             else:
#                 pass
#
#     fig.subplots_adjust(wspace=0, hspace=0)
#     plt.savefig('./T_translation/test/PLIC_test_{}.png'.format(t), format='png', dpi=300)

# ### This is a mixed method
# for t in range(25):
#
#     # ### translate the triple point
#     t_dis = dis
#     Sf = T_translation(triple, t_dis, nx, ny, dx, dy)
#     ### rotate the Y shape
#     # angle = angle_incre * t
#     # Sf = Y_rotation(triple, angle, nx, ny, dx, dy, 100)
#
#     # d1 = 3 + t * 0.1
#     # d2 = d1 + 0.5
#     # Sf = doubleline_translation(normal, d1, d2, nx, ny, dx, dy)
#
#     print(np.round(Sf, decimals=3))
#     #
#     N_ax_x = len(Sf[0]) - 2
#     N_ax_y = len(Sf[0][0]) - 2
#     fig, ax = plt.subplots(1, 1, figsize=[2 + N_ax_x, 2 + N_ax_y])
#     ax.set_aspect('equal')
#     ax.grid(linestyle='--')
#     ax.set_xlim([0, dx * N_ax_x])
#     ax.set_ylim([0, dx * N_ax_y])
#     for m in range(N_ax_x):
#         for n in range(N_ax_y):
#             O_position = np.array([m * dx, n * dy])
#             print('The time and plot index is: ', t, m, n)
#             sf_center_pos = [m + 1, n + 1]
#             sf = get_sf(sf_center_pos, Sf)
#             sf = np.round(sf, decimals=4)
#             print('The stencil is: \n', sf)
#             phase_exist = judge_phase_num(sf)
#             print('phase existence condition is: ', phase_exist)
#             count = len(phase_exist)
#             print('The number of phase is: ', count)
#             if count == 2:
#                 normals, ds = PLIC_2d_tripleP(sf, dx, dy, 1, 1, phase_exist)
#                 print(normals, ds)
#                 if len(normals) < 2:
#                     cell_1 = plic_cell_remain_general(normals[0], ds[0], dx, dy, np.array([0., 0.]))
#                     cell_2 = plic_cell_remain_general(-normals[0], -ds[0], dx, dy, np.array([0., 0.]))
#                     cells = [cell_1, cell_2]
#                     # print('The cells are: ', cells)
#                     plot_interface_plic(ax, O_position, cells)
#                 else:
#                     cell_1 = plic_cell_remain_general(-normals[0], -ds[0], dx, dy, np.array([0., 0.]))
#                     cell_1_ = plic_cell_remain_general(normals[0], ds[0], dx, dy, np.array([0., 0.]))
#                     # print('The remain cell cut by I1 is: ', cell_1_)
#                     intersects_2 = plic_get_intersects(cell_1_, normals[1], ds[1])
#                     cell_2 = get_cut_polygon_2(intersects_2, cell_1_, normals[1], ds[1])
#                     cell_3 = get_cut_polygon_2(intersects_2, cell_1_, -normals[1], -ds[1])
#                     cells = [cell_1, cell_2, cell_3]
#                     # print('The cells are: ', cells)
#                     plot_interface_plic(ax, O_position, cells)
#             elif count > 2:
#                 # (pos,
#                 #  posL,
#                 #  base_line,
#                 #  base_vector,
#                 #  cells,
#                 #  volumes,
#                 #  errors,
#                 #  error,
#                 #  step,
#                 #  step_size,
#                 #  ver_tag) = Dynamic_Point_3(sf, dx, dy, 1, 1, 0.001, 15, 0.01)
#                 (pos,
#                  posL,
#                  base_line,
#                  base_vector,
#                  cells,
#                  volumes,
#                  errors,
#                  error,
#                  step,
#                  step_size,
#                  ver_tag) = Dynamic_Point_4(sf, dx, dy, 1, 1, 0.001, 15, 0.01)
#                 print('The baselines are: ', base_line)
#                 print('The base vectors are: ', base_vector)
#                 print('The final position is: ', pos)
#                 # print('The vf field is: \n', sf)
#                 print('The center vf is: ', sf[:, 1, 1])
#                 print('The errors are: ', errors)
#                 print('The error is: ', error)
#                 print('The total step is: ', step)
#                 print('The tags are: ', ver_tag)
#                 print('The cells are: ', cells)
#                 plot_interface_2(ax, O_position, cells)
#             else:
#                 pass
#
#     fig.subplots_adjust(wspace=0, hspace=0)
#     plt.savefig('./T_translation/test/mixed_test_{}.png'.format(t), format='png', dpi=300)

# ### This is a mixed strategy
# for t in range(25):
#
#     # ### translate the triple point
#     # t_dis = dis
#     # Sf = T_translation(triple, t_dis, nx, ny, dx, dy)
#     ## rotate the Y shape
#     # angle = angle_incre * t
#     # Sf = Y_rotation(triple, angle, nx, ny, dx, dy, 200)
#
#     d1 = 2.7 + t * 0.05
#     d2 = d1 + 0.5
#     Sf = doubleline_translation(normal, d1, d2, nx, ny, dx, dy)
#     # print(Sf)
#     print(np.round(Sf, decimals=3))
#     #
#     N_ax_x = len(Sf[0]) - 2 * ghost
#     N_ax_y = len(Sf[0][0]) - 2 * ghost
#     fig, ax = plt.subplots(1, 1, figsize=[2 + N_ax_x, 2 + N_ax_y])
#     ax.set_aspect('equal')
#     ax.grid(linestyle='--')
#     ax.set_xlim([0, dx * N_ax_x])
#     ax.set_ylim([0, dx * N_ax_y])
#     # reconstruction = DP_PLIC_2(Sf, dx, dy, 0.001, 15, 0.01, ghost, plic_resolution)
#     # reconstruction = DP_PLIC_3(Sf, dx, dy, 0.001, 15, 0.01, ghost, plic_err)
#     reconstruction = DP_PLIC_4(Sf, dx, dy, 0.001, 15, 0.01, ghost, plic_err)
#     method_matrix = np.zeros([N_ax_x, N_ax_y])
#     error_matrix = np.zeros([N_ax_x, N_ax_y])
#     for m in range(N_ax_x):
#         for n in range(N_ax_y):
#             print('The time and plot index is: ', t, m, n)
#             O_position = np.array([m * dx, n * dy])
#             grid_info = reconstruction[m + ghost][n + ghost]
#             if grid_info[0] != 0 and grid_info[1]['method']:
#                 Cells = grid_info[1]['cells']
#                 if grid_info[1]['method'] == 'PLIC':
#                     print('PLIC')
#                     plot_interface_plic(ax, O_position, Cells)
#                     method_matrix[m, n] = 1
#                 elif grid_info[1]['method'] == 'DP':
#                     plot_interface_2(ax, O_position, Cells)
#                     print('DP')
#                     method_matrix[m, n] = 2
#                 else:
#                     method_matrix[m, n] = 0
#                     pass
#             else:
#                 pass
#     fig.subplots_adjust(wspace=0, hspace=0)
#     plt.savefig('./T_translation/test/mixed_test_{}.png'.format(t), format='png', dpi=300)
#     plt.close()

# ### This is a mixed strategy for comparison
# for t in range(25):
#
#     # ### translate the triple point
#     # t_dis = dis
#     # Sf = T_translation(triple, t_dis, nx, ny, dx, dy)
#     ## rotate the Y shape
#     # angle = angle_incre * t
#     # Sf = Y_rotation(triple, angle, nx, ny, dx, dy, 200)
#
#     d1 = 2.7 + t * 0.05
#     d2 = d1 + 0.5
#     Sf = doubleline_translation(normal, d1, d2, nx, ny, dx, dy)
#     # print(Sf)
#     print(np.round(Sf, decimals=3))
#     #
#     N_ax_x = len(Sf[0]) - 2 * ghost
#     N_ax_y = len(Sf[0][0]) - 2 * ghost
#     fig, ax = plt.subplots(1, 2, figsize=[2.2 * (2 + N_ax_x), 1. * (2 + N_ax_y)])
#     for sub_ax in ax:
#         sub_ax.set_aspect('equal')
#         sub_ax.grid(linestyle='--')
#         sub_ax.set_xlim([0, dx * N_ax_x])
#         sub_ax.set_ylim([0, dx * N_ax_y])
#     # reconstruction = DP_PLIC_2(Sf, dx, dy, 0.001, 15, 0.01, ghost, plic_resolution)
#     reconstruction_DP5 = DP_PLIC_3(Sf, dx, dy, 0.001, 15, 0.01, ghost, plic_err)
#     reconstruction_DP6 = DP_PLIC_4(Sf, dx, dy, 0.001, 15, 0.01, ghost, plic_err)
#     method_matrix = np.zeros([N_ax_x, N_ax_y])
#     error_matrix = np.zeros([N_ax_x, N_ax_y])
#     for m in range(N_ax_x):
#         for n in range(N_ax_y):
#             print('The time and plot index is: ', t, m, n)
#             O_position = np.array([m * dx, n * dy])
#             grid_info_DP5 = reconstruction_DP5[m + ghost][n + ghost]
#             grid_info_DP6 = reconstruction_DP6[m + ghost][n + ghost]
#             if grid_info_DP5[0] != 0 and grid_info_DP5[1]['method']:
#                 Cells_DP5 = grid_info_DP5[1]['cells']
#                 Cells_DP6 = grid_info_DP6[1]['cells']
#                 if grid_info_DP5[1]['method'] == 'PLIC':
#                     print('PLIC')
#                     plot_interface_plic(ax[0], O_position, Cells_DP5)
#                     plot_interface_plic(ax[1], O_position, Cells_DP5)
#                     method_matrix[m, n] = 1
#                 elif grid_info_DP5[1]['method'] == 'DP':
#                     plot_interface_3(ax[0], O_position, Cells_DP5, 'black')
#                     plot_interface_3(ax[1], O_position, Cells_DP6, 'red')
#                     print('DP')
#                     print(grid_info_DP6[1]['smoothed'])
#                     print(grid_info_DP5[1]['error'])
#                     print(grid_info_DP6[1]['error'])
#                     method_matrix[m, n] = 2
#                 else:
#                     method_matrix[m, n] = 0
#                     pass
#             else:
#                 pass
#     fig.subplots_adjust(wspace=0, hspace=0)
#     plt.savefig('./T_translation/test/mixed_test_{}.png'.format(t), format='png', dpi=300)
#     plt.close()

# ### This is a mixed strategy for comparison PLIC
# for t in range(25):
#
#     ### translate the triple point
#     # t_dis = dis
#     # if t == 0:
#     #     t_dis = 0.
#     # Sf_ = T_translation(triple, t_dis, nx, ny, dx, dy)
#     # Sf = copy.deepcopy(Sf_)
#     # Sf[0] = Sf_[2]
#     # Sf[1] = Sf_[0]
#     # Sf[2] = Sf_[1]
#     ## rotate the Y shape
#     # angle = angle_incre * t
#     # Sf = Y_rotation(triple, angle, nx, ny, dx, dy, 200)
#
#     normal = np.array([np.sqrt(3) / 2, np.sqrt(1) / 2])
#     d1 = 5.7 + t * 0.05
#     d2 = d1 + 0.5
#     Sf = doubleline_translation(normal, d1, d2, nx, ny, dx, dy)
#     # print(Sf)
#     # print(np.round(Sf, decimals=3))
#     #
#     N_ax_x = len(Sf[0]) - 2 * ghost
#     N_ax_y = len(Sf[0][0]) - 2 * ghost
#     fig, ax = plt.subplots(1, 2, figsize=[2.2 * (2 + N_ax_x), 1. * (2 + N_ax_y)])
#     for sub_ax in ax:
#         sub_ax.set_aspect('equal')
#         sub_ax.grid(linestyle='--')
#         sub_ax.set_xlim([0, dx * N_ax_x])
#         sub_ax.set_ylim([0, dx * N_ax_y])
#     # reconstruction = DP_PLIC_2(Sf, dx, dy, 0.001, 15, 0.01, ghost, plic_resolution)
#     # reconstruction_DP5 = DP_PLIC_3(Sf, dx, dy, 0.001, 15, 0.01, ghost, plic_err)
#     reconstruction = DP_PLIC_7(Sf, dx, dy, 0.001, 20, 0.01, ghost, plic_err)
#     method_matrix = np.zeros([N_ax_x, N_ax_y])
#     error_matrix = np.zeros([N_ax_x, N_ax_y])
#     ### DP-PLIC
#     for m in range(N_ax_x):
#         for n in range(N_ax_y):
#             print('The time and plot index is: ', t, m, n)
#             O_position = np.array([m * dx, n * dy])
#             # grid_info_DP5 = reconstruction_DP5[m + ghost][n + ghost]
#             grid_info = reconstruction[m + ghost][n + ghost]
#             if grid_info[0] != 0 and grid_info[1]['method']:
#                 Cells = grid_info[1]['cells']
#                 if grid_info[1]['method'] == 'PLIC':
#                     print('PLIC')
#                     plot_interface_plic_adv(ax[1], O_position, Cells)
#                     method_matrix[m, n] = 1
#                 elif grid_info[1]['method'] == 'DP':
#                     plot_interface_3(ax[1], O_position, Cells, 'red')
#                     print('DP')
#                     print(grid_info[1]['smoothed'])
#                     print(grid_info[1]['error'])
#                     method_matrix[m, n] = 2
#                 else:
#                     method_matrix[m, n] = 0
#                     pass
#             else:
#                 pass
#     ### PLIC-Bussmann
#     for m in range(N_ax_x):
#         for n in range(N_ax_y):
#             print('The time and plot index is: ', t, m, n)
#             O_position = np.array([m * dx, n * dy])
#             sf_center_pos = [m + 1, n + 1]
#             sf = get_sf(sf_center_pos, Sf)
#             phase_exist = judge_phase_num(sf)
#             count = len(phase_exist)
#             if count > 1:
#                 normals, ds = PLIC_2d_tripleP_GS(sf, dx, dy, 1, 1, phase_exist, plic_err)
#                 # print(normals)
#                 if len(normals) < 2:
#                     cell_1 = plic_cell_remain_general(normals[0], ds[0], dx, dy, np.array([0., 0.]))
#                     cell_2 = plic_cell_remain_general(-normals[0], -ds[0], dx, dy, np.array([0., 0.]))
#                     cells = [cell_1, cell_2]
#                     plot_interface_plic(ax[0], O_position, cells)
#                 else:
#                     cell_1 = plic_cell_remain_general(-normals[0], -ds[0], dx, dy, np.array([0., 0.]))
#                     cell_1_ = plic_cell_remain_general(normals[0], ds[0], dx, dy, np.array([0., 0.]))
#                     intersects_2 = plic_get_intersects(cell_1_, normals[1], ds[1])
#                     cell_2 = get_cut_polygon_2(intersects_2, cell_1_, normals[1], ds[1])
#                     cell_3 = get_cut_polygon_2(intersects_2, cell_1_, -normals[1], -ds[1])
#                     cells = [cell_1, cell_2, cell_3]
#                     plot_interface_plic(ax[0], O_position, cells)
#             else:
#                 pass
#
#     fig.subplots_adjust(wspace=0, hspace=0)
#     plt.savefig('./T_translation/test/mixed_test_{}.png'.format(t), format='png', dpi=300)
#     plt.close()


# DP_time = 0.
# PLIC_time = 0.
#
# ### This is for time and error comparison
# for t in range(25):
#
#     ### translate the triple point
#     t_dis = dis
#     if t == 0:
#         t_dis = 0.
#     Sf_ = T_translation(triple, t_dis, nx, ny, dx, dy)
#     Sf = copy.deepcopy(Sf_)
#     Sf[0] = Sf_[2]
#     Sf[1] = Sf_[0]
#     Sf[2] = Sf_[1]
#     ## rotate the Y shape
#     # angle = angle_incre * t
#     # Sf = Y_rotation(triple, angle, nx, ny, dx, dy, 200)
#
#     # normal = np.array([np.sqrt(3) / 2, np.sqrt(1) / 2])
#     # d1 = 5.7 + t * 0.05
#     # d2 = d1 + 0.5
#     # Sf = doubleline_translation(normal, d1, d2, nx, ny, dx, dy)
#     # print(Sf)
#     # print(np.round(Sf, decimals=3))
#     #
#     N_ax_x = len(Sf[0]) - 2 * ghost
#     N_ax_y = len(Sf[0][0]) - 2 * ghost
#
#     time_DP_1 = time.time()
#     reconstruction = DP_PLIC_5(Sf, dx, dy, 0.001, 15, 0.01, ghost, plic_err)
#     time_DP_2 = time.time()
#     DP_time += (time_DP_2 - time_DP_1)
#
#     time_PLIC_1 = time.time()
#     for m in range(N_ax_x):
#         for n in range(N_ax_y):
#             O_position = np.array([m * dx, n * dy])
#             sf_center_pos = [m + 1, n + 1]
#             sf = get_sf(sf_center_pos, Sf)
#             phase_exist = judge_phase_num(sf)
#             count = len(phase_exist)
#             if count > 1:
#                 normals, ds = PLIC_2d_tripleP_GS(sf, dx, dy, 1, 1, phase_exist, plic_err)
#             else:
#                 pass
#     time_PLIC_2 = time.time()
#     PLIC_time += (time_PLIC_2 - time_PLIC_1)
#
# print(DP_time, PLIC_time)


