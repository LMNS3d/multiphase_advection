###This is the geometric transformation toolbox for the newly designed algorithm
###creator: Zhang, HKUST
### last modified: 2025/02/17

import copy
import random
import time

import numpy as np
from matplotlib.ticker import MultipleLocator
import matplotlib.patches as patches
from src.functions.functions import *
from multiprocessing import Queue
from src.functions.mp_function import *
import multiprocessing
import numba as nb
from numba import prange
import matplotlib.pyplot as plt
from src.reconstruction.method import DP_PLIC_exact
from src.plot.plot_function import plot_interface_plic_adv, plot_interface_plic_adv_DP
from src.functions.new_function import get_sf, judge_phase_num
from src.reconstruction.PLIC import PLIC_2d_tripleP_GSadv
from src.reconstruction.YOUNGS import Youngs_2d


# nx = 10
# ny = 10
# ghost = 1
# dx = 1.
# dy = 1.
# resolution = 200
# plic_err = 0.001
### circle

def repair_static(f, ghost, nx, ny, phase_num, tolerance):
    ### first apply the [0, 1] constraint
    for i in range(ghost, nx - ghost):
        for j in range(ghost, ny - ghost):
            for p in range(phase_num):
                f[p, i, j] = min(1., max(0., f[p, i, j]))
    ### then apply the tolerance threshold
    for i in range(ghost, nx - ghost):
        for j in range(ghost, ny - ghost):
            for p in range(phase_num):
                if f[p, i, j] - 0. < tolerance:
                    f[p, i, j] = 0.
                else:
                    pass
                if 1 - f[p, i, j] < tolerance:
                    f[p, i, j] = 1.
                else:
                    pass
    ### then apply the noramlization
    for i in range(ghost, nx - ghost):
        for j in range(ghost, ny - ghost):
            sum_ = sum(f[:, i, j])
            for p in range(phase_num):
                f[p, i, j] = f[p, i, j] / sum_
    return f


def circle(cp, R, n_x, n_y, dx, dy, resolution):
    ### initialization of the volume fraction field
    result = np.zeros([3, n_x, n_y])
    phase_count = np.zeros([3, n_x, n_y])
    phase_list = np.array([0, 1, 2])
    ### construct MC points
    np.random.seed(0)
    x_num = n_x * resolution
    y_num = n_y * resolution
    x = np.random.uniform(0., 1., x_num)
    x *= n_x * dx
    y = np.random.uniform(0., 1., y_num)
    y *= n_y * dy
    ### loading system
    total = len(x) * len(y)
    cur = 0
    old_percent = 0
    for m in range(len(x)):
        for n in range(len(y)):
            percent = int((cur / total) * 100)
            if percent > old_percent:
                # print('field generate process: {} %'.format(percent))
                old_percent = percent
            ### construct MC points
            MC_point = np.array([x[m], y[n]])
            ### patch 1: circle
            r = np.sqrt((MC_point[0] - cp[0]) ** 2 + (MC_point[1] - cp[1]) ** 2)
            if r < R:
                if MC_point[0] > cp[0]:
                    MC_phase_ind = 2
                else:
                    MC_phase_ind = 1
            else:
                MC_phase_ind = 0
            phase_count[MC_phase_ind, int(MC_point[0] // dx), int(MC_point[1] // dy)] += 1
            cur += 1
    ## according to the phase_count, calculate the
    for p in range(n_x):
        for q in range(n_y):
            seq = phase_count[:, p, q]
            total_count = sum(seq)
            for u in range(len(seq)):
                result[u, p, q] = seq[u] / total_count
    return result


def circle_mp(cp, R, n_x, n_y, dx, dy, resolution, num_p=12):
    # np.random.seed(0)
    ### initialization of the volume fraction field
    que = Queue()
    result = np.zeros([3, n_x, n_y])
    x_parts, y_parts = divide_domain(n_x, n_y, num_p)
    # print(x_parts, y_parts)
    manager = multiprocessing.Manager()
    return_dict = manager.dict()
    return_dict['f'] = result
    info = {'cp': cp,
            'R': R,
            'dx': dx,
            'dy': dy,
            'resolution': resolution,
            'x_parts': x_parts,
            'y_parts': y_parts}
    processes = create_processes_circle(circle_mp_exc, combine_results_circle, info, que, return_dict)
    f = start_and_join_processes_circle(processes, return_dict)
    return f


def circle_mp_exc(info, que, start_x, end_x, start_y, end_y):
    np.random.seed(0)
    cp = info['cp']
    R = info['R']
    resolution = info['resolution']
    dx, dy = info['dx'], info['dy']
    n_x = end_x - start_x
    n_y = end_y - start_y
    sub_result = np.zeros([3, end_x - start_x, end_y - start_y])
    sub_phase_count = np.zeros([3, end_x - start_x, end_y - start_y])
    ### construct MC points
    x_num = n_x * resolution
    y_num = n_y * resolution
    x = np.random.uniform(0., 1., x_num)
    x *= n_x * dx
    x += start_x * dx
    y = np.random.uniform(0., 1., y_num)
    y *= n_y * dy
    y += start_y * dy
    ### loading system
    total = len(x) * len(y)
    cur = 0
    old_percent = 0
    for m in range(len(x)):
        for n in range(len(y)):
            percent = int((cur / total) * 100)
            if percent > old_percent:
                old_percent = percent
            ### construct MC points
            MC_point = np.array([x[m], y[n]])
            ### patch 1: circle
            r = np.sqrt((MC_point[0] - cp[0]) ** 2 + (MC_point[1] - cp[1]) ** 2)
            if r < R:
                if MC_point[1] > cp[1]:
                    MC_phase_ind = 2
                else:
                    MC_phase_ind = 1
            else:
                MC_phase_ind = 0
            sub_phase_count[MC_phase_ind, int((MC_point[0] - start_x * dx) // dx),
            int((MC_point[1] - start_y * dy) // dy)] += 1
            cur += 1
    ## according to the phase_count, calculate the
    for p in range(n_x):
        for q in range(n_y):
            seq = sub_phase_count[:, p, q]
            total_count = sum(seq)
            for u in range(len(seq)):
                sub_result[u, p, q] = seq[u] / (total_count + 1e-8)
    que.put({'result': sub_result, 'start_x': start_x, 'end_x': end_x, 'start_y': start_y, 'end_y': end_y})

########################################## numba njit generation #############################
@nb.jit(nopython=True)
def circle_njit(cp, R, n_x, n_y, dx, dy, resolution):
    result = np.zeros((3, n_x, n_y), dtype=np.float64)
    phase_count = np.zeros((3, n_x, n_y), dtype=np.float64)
    ### construct MC points
    x_num = n_x * resolution
    y_num = n_y * resolution
    x = np.random.uniform(0., 1., x_num)
    x *= n_x * dx
    y = np.random.uniform(0., 1., y_num)
    y *= n_y * dy
    ### loading system
    total = len(x) * len(y)
    cur = 0
    old_percent = 0
    for m in prange(len(x)):
        for n in prange(len(y)):
            percent = int((cur / total) * 100)
            if percent > old_percent:
                old_percent = percent
            ### construct MC points
            MC_point = np.array([x[m], y[n]])
            ### patch 1: circle
            r = math.sqrt((MC_point[0] - cp[0]) ** 2 + (MC_point[1] - cp[1]) ** 2)
            if r < R:
                if MC_point[1] > cp[1]:
                    MC_phase_ind = 2
                else:
                    MC_phase_ind = 1
            else:
                MC_phase_ind = 0
            phase_count[MC_phase_ind, int((MC_point[0]) // dx), int((MC_point[1]) // dy)] += 1
            cur += 1
    ## according to the phase_count, calculate the
    for p in range(n_x):
        for q in range(n_y):
            seq = phase_count[:, p, q]
            total_count = sum(seq)
            for u in range(len(seq)):
                result[u, p, q] = seq[u] / (total_count + 1e-8)
    return result


def circle_adv_mp(cp, R, n_x, n_y, dx, dy, resolution, num_p=12):
    # np.random.seed(0)
    ### initialization of the volume fraction field
    que = Queue()
    result = np.zeros([3, n_x, n_y])
    x_parts, y_parts = divide_domain(n_x, n_y, num_p)
    # print(x_parts, y_parts)
    manager = multiprocessing.Manager()
    return_dict = manager.dict()
    return_dict['f'] = result
    info = {'cp': cp,
            'R': R,
            'dx': dx,
            'dy': dy,
            'resolution': resolution,
            'x_parts': x_parts,
            'y_parts': y_parts}
    processes = create_processes_circle(circle_adv_mp_exc, combine_results_circle, info, que, return_dict)
    f = start_and_join_processes_circle(processes, return_dict)
    return f


def circle_adv_mp_exc(info, que, start_x, end_x, start_y, end_y):
    np.random.seed(0)
    cp = info['cp']
    R = info['R']
    resolution = info['resolution']
    dx, dy = info['dx'], info['dy']
    n_x = end_x - start_x
    n_y = end_y - start_y
    sub_result = np.zeros([3, end_x - start_x, end_y - start_y])
    sub_phase_count = np.zeros([3, end_x - start_x, end_y - start_y])
    ### THE SUB-DOMAIN DOES NOT CONTAINS THE CIRCLE
    if start_x * dx >= cp[0] + R:
        sub_result[0] = np.ones([n_x, n_y])
    elif start_y * dy >= cp[1] + R:
        sub_result[0] = np.ones([n_x, n_y])
    elif end_x * dx <= cp[0] - R:
        sub_result[0] = np.ones([n_x, n_y])
    elif end_y * dy <= cp[1] - R:
        sub_result[0] = np.ones([n_x, n_y])
    else:
        print('build the field')
        print(start_x, end_x, start_y, end_y)
        ### construct MC points
        x_num = n_x * resolution
        y_num = n_y * resolution
        x = np.random.uniform(0., 1., x_num)
        x *= n_x * dx
        x += start_x * dx
        y = np.random.uniform(0., 1., y_num)
        y *= n_y * dy
        y += start_y * dy
        ### loading system
        total = len(x) * len(y)
        cur = 0
        old_percent = 0
        for m in range(len(x)):
            for n in range(len(y)):
                percent = int((cur / total) * 100)
                if percent > old_percent:
                    old_percent = percent
                ### construct MC points
                MC_point = np.array([x[m], y[n]])
                ### patch 1: circle
                r = np.sqrt((MC_point[0] - cp[0]) ** 2 + (MC_point[1] - cp[1]) ** 2)
                if r < R:
                    if MC_point[0] > cp[0]:
                        MC_phase_ind = 2
                    else:
                        MC_phase_ind = 1
                else:
                    MC_phase_ind = 0
                sub_phase_count[MC_phase_ind, int((MC_point[0] - start_x * dx) // dx),
                int((MC_point[1] - start_y * dy) // dy)] += 1
                cur += 1
        ## according to the phase_count, calculate the
        for p in range(n_x):
            for q in range(n_y):
                seq = sub_phase_count[:, p, q]
                total_count = sum(seq)
                for u in range(len(seq)):
                    sub_result[u, p, q] = seq[u] / (total_count + 1e-8)
    que.put({'result': sub_result, 'start_x': start_x, 'end_x': end_x, 'start_y': start_y, 'end_y': end_y})


def T_shape_mp(triple_point, n_x, n_y, dx, dy, num_p=12):
    np.random.seed(0)
    ### initialization of the volume fraction field
    que = Queue()
    result = np.zeros([3, n_x, n_y])
    x_parts, y_parts = divide_domain(n_x, n_y, num_p)
    manager = multiprocessing.Manager()
    return_dict = manager.dict()
    return_dict['f'] = result
    info = {'triple_point': triple_point,
            'dx': dx,
            'dy': dy,
            'x_parts': x_parts,
            'y_parts': y_parts}
    processes = create_processes_circle(T_shape_mp_exc, combine_results_circle, info, que, return_dict)
    f = start_and_join_processes_circle(processes, return_dict)
    return f


def T_shape_mp_exc(info, que, start_x, end_x, start_y, end_y):
    dx, dy = info['dx'], info['dy']
    triple_point = info['triple_point']
    n_x = end_x - start_x
    n_y = end_y - start_y
    ### initialization of the volume fraction field
    result = np.zeros([3, n_x, n_y])
    ### calculation the instant triple point position
    for i in range(n_x):
        for j in range(n_y):
            ### The vertex starting from lower-left point, counter-clockwise
            vertices = np.array([[(i + start_x) * dx, (j + start_y) * dy],
                                 [(i + start_x) * dx, (j + 1 + start_y) * dy],
                                 [(i + 1 + start_x) * dx, (j + 1 + start_y) * dy],
                                 [(i + 1 + start_x) * dx, (j + start_y) * dy]])
            ### first, if the grid is not a cut grid
            if vertices[1][1] <= triple_point[1]:
                result[2, i, j] = 1.
                result[1, i, j] = 0.
                result[0, i, j] = 0.
            elif vertices[2][0] <= triple_point[0] and vertices[0][1] >= triple_point[1]:
                result[0, i, j] = 1.
                result[1, i, j] = 0.
                result[2, i, j] = 0.
            elif vertices[0][0] >= triple_point[0] and vertices[0][1] >= triple_point[1]:
                result[1, i, j] = 1.
                result[0, i, j] = 0.
                result[2, i, j] = 0.
            ### second, calculated the volume fraction of cut grid
            else:
                ### 1. calculate the volume fraction of phase 3
                d_3 = triple_point[1] - vertices[0][1]
                if 0 <= d_3 <= dy:
                    result[2, i, j] = d_3 / dy
                else:
                    result[2, i, j] = 0.
                ### 2. calculate the volume fraction of phase 2
                d_2 = triple_point[0] - vertices[1][0]
                if 0 <= d_2 <= dx:
                    result[1, i, j] = (1. - result[2, i, j]) * ((dx - d_2) / dx)
                else:
                    if vertices[0][0] > triple_point[0]:
                        result[1, i, j] = 1. - result[2, i, j]
                    else:
                        pass
                ### 3. calculate the volume fraction of phase 1
                result[0, i, j] = 1. - result[1, i, j] - result[2, i, j]
    result_out = result.copy()
    for k in range(len(result)):
        result_out[k] = result[k - 1]
    que.put({'result': result_out, 'start_x': start_x, 'end_x': end_x, 'start_y': start_y, 'end_y': end_y})


def Y_shape_mp(triple, angle, n_x, n_y, dx, dy, resolution, num_p=12):
    np.random.seed(0)
    ### initialization of the volume fraction field
    que = Queue()
    result = np.zeros([3, n_x, n_y])
    x_parts, y_parts = divide_domain(n_x, n_y, num_p)
    manager = multiprocessing.Manager()
    return_dict = manager.dict()
    return_dict['f'] = result
    info = {'triple_point': triple,
            'angle': angle,
            'resolution': resolution,
            'dx': dx,
            'dy': dy,
            'x_parts': x_parts,
            'y_parts': y_parts}
    processes = create_processes_circle(Y_shape_mp_exc, combine_results_circle, info, que, return_dict)
    f = start_and_join_processes_circle(processes, return_dict)
    return f


def Y_shape_mp_exc(info, que, start_x, end_x, start_y, end_y):
    def judge(angle_list, phase_list, angle):
        if 0 <= angle < angle_list[0] or angle_list[2] <= angle <= 2 * np.pi:
            return phase_list[1]
        elif angle_list[0] <= angle < angle_list[1]:
            return phase_list[2]
        else:
            return phase_list[0]

    n_x = end_x - start_x
    n_y = end_y - start_y
    resolution = info['resolution']
    triple_point = info['triple_point']
    angle = info['angle']
    dx = info['dx']
    dy = info['dy']

    ### angle 1 is the angle of the right line (initial position)
    angle_1 = (np.pi / 4) + angle
    ### angle 2 is the angle of the left line (initial position)
    angle_2 = (3 * np.pi / 4) + angle
    ### angle 3 is the angle of the lower line (initial position)
    angle_3 = (3 * np.pi / 2) + angle
    angle_list = np.array([angle_1, angle_2, angle_3])
    ### initialization of the volume fraction field
    result = np.zeros([3, n_x, n_y])
    phase_count = np.zeros([3, n_x, n_y])
    phase_list = np.array([0, 1, 2])
    ### construct MC points
    np.random.seed(0)
    x_num = n_x * resolution
    y_num = n_y * resolution
    x = np.random.uniform(0., 1., x_num)
    x *= n_x * dx
    x += start_x
    y = np.random.uniform(0., 1., y_num)
    y *= n_y * dy
    y += start_y
    for m in range(len(x)):
        for n in range(len(y)):
            ### construct MC points
            MC_point = np.array([x[m], y[n]])
            ### which indicates the MC angle is between -Pi/2 and Pi/2
            if MC_point[0] > triple_point[0]:
                MC_theta = np.arctan((MC_point[1] - triple_point[1]) / (MC_point[0] - triple_point[0]))
                if MC_theta >= 0:
                    pass
                else:
                    MC_theta += 2 * np.pi
            ### which indicates the MC angle is between Pi/2 and 3Pi/2
            elif MC_point[0] < triple_point[0]:
                # MC_theta = -1.
                MC_theta = np.arctan((MC_point[1] - triple_point[1]) / (MC_point[0] - triple_point[0]))
                MC_theta += np.pi
            ### if there is no atan defined
            else:
                # MC_theta = -1.
                if MC_point[1] > triple_point[1]:
                    MC_theta = np.pi / 2
                elif MC_point[1] < triple_point[1]:
                    MC_theta = 3 * np.pi / 2
                else:
                    MC_theta = -1.
            MC_phase_ind = judge(angle_list, phase_list, MC_theta)
            phase_count[MC_phase_ind, int(MC_point[0] // dx) - start_x, int(MC_point[1] // dy) - start_y] += 1
    ## according to the phase_count, calculate the
    for p in range(n_x):
        for q in range(n_y):
            seq = phase_count[:, p, q]
            total_count = sum(seq)
            for u in range(len(seq)):
                result[u, p, q] = seq[u] / total_count
    que.put({'result': result, 'start_x': start_x, 'end_x': end_x, 'start_y': start_y, 'end_y': end_y})


def Y_shape_exact(triple, angle, n_x, n_y, dx, dy):
    ### relocate the triple point
    triple_point = triple + np.array([1, 1])
    # print(triple_point, angle, n_x, n_y, dx, dy)
    true_reconstruction = true_reconstruction_Y_shape(triple_point, angle, n_x + 2, n_y + 2, dx, dy, 1)
    result = np.zeros([3, n_x, n_y])
    for u in range(n_x):
        for v in range(n_y):
            recons_info = true_reconstruction[u + 1][v + 1]
            cells = recons_info[1]['cells']
            # if len(cells) > 2:
            # print(cells)
            for k in range(len(cells)):
                phase_ind = cells[k][0]
                cell_k = cells[k][1]
                area = get_cell_volume_shapely(cell_k)
                fraction = area / (dx * dy)
                result[phase_ind, u, v] = fraction
    return result


def Y_shape_adv_exact(triple, angle, n_x, n_y, dx, dy):
    ### relocate the triple point
    triple_point = triple + np.array([1, 1])
    # print(triple_point, angle, n_x, n_y, dx, dy)
    true_reconstruction = true_reconstruction_Y_shape_adv(triple_point, angle, n_x + 2, n_y + 2, dx, dy, 1)
    result = np.zeros([3, n_x, n_y])
    for u in range(n_x):
        for v in range(n_y):
            recons_info = true_reconstruction[u + 1][v + 1]
            cells = recons_info[1]['cells']
            # if len(cells) > 2:
            # print(cells)
            for k in range(len(cells)):
                phase_ind = cells[k][0]
                cell_k = cells[k][1]
                area = get_cell_volume_shapely(cell_k)
                fraction = area / (dx * dy)
                result[phase_ind, u, v] = fraction
    return result


def circle1_mp(cp, R, n_x, n_y, dx, dy, resolution, num_p=12):
    ### initialization of the volume fraction field
    que = Queue()
    result = np.zeros([3, n_x, n_y])
    x_parts, y_parts = divide_domain(n_x, n_y, num_p)
    manager = multiprocessing.Manager()
    return_dict = manager.dict()
    return_dict['f'] = result
    info = {'cp': cp,
            'R': R,
            'dx': dx,
            'dy': dy,
            'resolution': resolution,
            'x_parts': x_parts,
            'y_parts': y_parts}
    processes = create_processes_circle(circle1_mp_exc, combine_results_circle, info, que, return_dict)
    f = start_and_join_processes_circle(processes, return_dict)
    return f


def circle1_mp_exc(info, que, start_x, end_x, start_y, end_y):
    cp = info['cp']
    R = info['R']
    resolution = info['resolution']
    dx, dy = info['dx'], info['dy']
    n_x = end_x - start_x
    n_y = end_y - start_y
    sub_result = np.zeros([3, end_x - start_x, end_y - start_y])
    sub_phase_count = np.zeros([3, end_x - start_x, end_y - start_y])
    ### construct MC points
    np.random.seed(0)
    x_num = n_x * resolution
    y_num = n_y * resolution
    x = np.random.uniform(0., 1., x_num)
    x *= n_x * dx
    x += start_x * dx
    y = np.random.uniform(0., 1., y_num)
    y *= n_y * dy
    y += start_y * dy
    ### loading system
    total = len(x) * len(y)
    cur = 0
    old_percent = 0
    for m in range(len(x)):
        for n in range(len(y)):
            ### construct MC points
            MC_point = np.array([x[m], y[n]])
            ### patch 1: circle
            r = np.sqrt((MC_point[0] - cp[0]) ** 2 + (MC_point[1] - cp[1]) ** 2)
            if r < R:
                if MC_point[0] > cp[0]:
                    MC_phase_ind = 2
                else:
                    MC_phase_ind = 1
            else:
                MC_phase_ind = 0
            sub_phase_count[MC_phase_ind, int((MC_point[0] - start_x * dx) // dx),
            int((MC_point[1] - start_y * dy) // dy)] += 1
            cur += 1
    ## according to the phase_count, calculate the
    for p in range(n_x):
        for q in range(n_y):
            seq = sub_phase_count[:, p, q]
            total_count = sum(seq)
            for u in range(len(seq)):
                sub_result[u, p, q] = seq[u] / (total_count + 1e-8)
    que.put({'result': sub_result, 'start_x': start_x, 'end_x': end_x, 'start_y': start_y, 'end_y': end_y})


def circle2_mp(cp1, R1, cp2, R2, n_x, n_y, dx, dy, resolution, num_p=12):
    ### initialization of the volume fraction field
    que = Queue()
    result = np.zeros([3, n_x, n_y])
    x_parts, y_parts = divide_domain(n_x, n_y, num_p)
    manager = multiprocessing.Manager()
    return_dict = manager.dict()
    return_dict['f'] = result
    info = {'cp1': cp1,
            'R1': R1,
            'cp2': cp2,
            'R2': R2,
            'dx': dx,
            'dy': dy,
            'resolution': resolution,
            'x_parts': x_parts,
            'y_parts': y_parts}
    processes = create_processes_circle(circle2_mp_exc, combine_results_circle, info, que, return_dict)
    f = start_and_join_processes_circle(processes, return_dict)
    return f


def circle2_mp_exc(info, que, start_x, end_x, start_y, end_y):
    cp1 = info['cp1']
    R1 = info['R1']
    cp2 = info['cp2']
    R2 = info['R2']
    resolution = info['resolution']
    dx, dy = info['dx'], info['dy']
    n_x = end_x - start_x
    n_y = end_y - start_y
    sub_result = np.zeros([3, end_x - start_x, end_y - start_y])
    phase_count = np.zeros([3, end_x - start_x, end_y - start_y])
    ### construct MC points
    np.random.seed(0)
    x_num = n_x * resolution
    y_num = n_y * resolution
    x = np.random.uniform(0., 1., x_num)
    x *= n_x * dx
    x += start_x * dx
    y = np.random.uniform(0., 1., y_num)
    y *= n_y * dy
    y += start_y * dy
    ### loading system
    cur = 0
    for m in range(len(x)):
        for n in range(len(y)):
            ### construct MC points
            MC_point = np.array([x[m], y[n]])
            ### patch 1: circle 1, large
            r1 = np.sqrt((MC_point[0] - cp1[0]) ** 2 + (MC_point[1] - cp1[1]) ** 2)
            if r1 < R1:
                r2 = np.sqrt((MC_point[0] - cp2[0]) ** 2 + (MC_point[1] - cp2[1]) ** 2)
                if r2 < R2:
                    MC_phase_ind = 2
                else:
                    MC_phase_ind = 1
            else:
                MC_phase_ind = 0
            phase_count[MC_phase_ind, int((MC_point[0] - start_x * dx) // dx), int((MC_point[1] - start_y * dy) // dy)] \
                += 1
            cur += 1
    ## according to the phase_count, calculate the
    for p in range(n_x):
        for q in range(n_y):
            seq = phase_count[:, p, q]
            total_count = sum(seq)
            for u in range(len(seq)):
                sub_result[u, p, q] = seq[u] / (total_count + 1e-8)
    que.put({'result': sub_result, 'start_x': start_x, 'end_x': end_x, 'start_y': start_y, 'end_y': end_y})


### phi1 > phi2
def snake(A, omega, phi1, phi2, n_x, n_y, dx, dy, resolution):
    def sin_func(A, omega, phi, x):
        ### parameter 1
        # return A * np.sin(omega * (x - 1.05)) + phi
        ### parameter 2
        # return A * np.sin(omega * (x - 1.)) + phi
        return A * np.sin(omega * (x - 1.)) + phi

    ### initialization of the volume fraction field
    result = np.zeros([3, n_x, n_y])
    phase_count = np.zeros([3, n_x, n_y])
    phase_list = np.array([0, 1, 2])
    ### construct MC points
    np.random.seed(0)
    x_num = n_x * resolution
    y_num = n_y * resolution
    x = np.random.uniform(0., 1., x_num)
    x *= n_x * dx
    y = np.random.uniform(0., 1., y_num)
    y *= n_y * dy
    for m in range(len(x)):
        for n in range(len(y)):
            ### construct MC points
            MC_point = np.array([x[m], y[n]])
            ### patch 1: circle
            if MC_point[1] < sin_func(A, omega, phi1, MC_point[0]):
                if MC_point[1] > sin_func(A, omega, phi2, MC_point[0]):
                    MC_phase_ind = 2
                else:
                    MC_phase_ind = 1
            else:
                MC_phase_ind = 0
            phase_count[MC_phase_ind, int(MC_point[0] // dx), int(MC_point[1] // dy)] += 1
    ## according to the phase_count, calculate the
    for p in range(n_x):
        for q in range(n_y):
            seq = phase_count[:, p, q]
            total_count = sum(seq)
            for u in range(len(seq)):
                result[u, p, q] = seq[u] / total_count
    return result


def snake_mp(A, omega, phi1, phi2, n_x, n_y, dx, dy, resolution, num_p=12):
    ### initialization of the volume fraction field
    que = Queue()
    result = np.zeros([3, n_x, n_y])
    x_parts, y_parts = divide_domain(n_x, n_y, num_p)
    manager = multiprocessing.Manager()
    return_dict = manager.dict()
    return_dict['f'] = result
    info = {'A': A,
            'omega': omega,
            'phi1': phi1,
            'phi2': phi2,
            'dx': dx,
            'dy': dy,
            'resolution': resolution,
            'x_parts': x_parts,
            'y_parts': y_parts}
    processes = create_processes_circle(snake_mp_exc, combine_results_circle, info, que, return_dict)
    f = start_and_join_processes_circle(processes, return_dict)
    return f


def snake_mp_exc(info, que, start_x, end_x, start_y, end_y):

    def sin_func(A, omega, phi, x):
        return A * np.sin(omega * (x - 1.)) + phi

    A = info['A']
    omega = info['omega']
    phi1 = info['phi1']
    phi2 = info['phi2']
    resolution = info['resolution']
    dx, dy = info['dx'], info['dy']
    n_x = end_x - start_x
    n_y = end_y - start_y
    sub_result = np.zeros([3, end_x - start_x, end_y - start_y])
    phase_count = np.zeros([3, end_x - start_x, end_y - start_y])
    ### construct MC points
    np.random.seed(0)
    x_num = n_x * resolution
    y_num = n_y * resolution
    x = np.random.uniform(0., 1., x_num)
    x *= n_x * dx
    x += start_x * dx
    y = np.random.uniform(0., 1., y_num)
    y *= n_y * dy
    y += start_y * dy
    ### loading system
    cur = 0
    for m in range(len(x)):
        for n in range(len(y)):
            ### construct MC points
            MC_point = np.array([x[m], y[n]])
            ### patch 1: circle
            if MC_point[1] < sin_func(A, omega, phi1, MC_point[0]):
                if MC_point[1] > sin_func(A, omega, phi2, MC_point[0]):
                    MC_phase_ind = 2
                else:
                    MC_phase_ind = 1
            else:
                MC_phase_ind = 0
            phase_count[MC_phase_ind, int((MC_point[0] - start_x * dx) // dx), int((MC_point[1] - start_y * dy) // dy)] \
                += 1
            cur += 1
    ## according to the phase_count, calculate the
    for p in range(n_x):
        for q in range(n_y):
            seq = phase_count[:, p, q]
            total_count = sum(seq)
            for u in range(len(seq)):
                sub_result[u, p, q] = seq[u] / (total_count + 1e-8)
    que.put({'result': sub_result, 'start_x': start_x, 'end_x': end_x, 'start_y': start_y, 'end_y': end_y})


### circle 2 inside circle 1, R1 > R2
def double_circle(cp1, R1, cp2, R2, n_x, n_y, dx, dy, resolution):
    ### initialization of the volume fraction field
    result = np.zeros([3, n_x, n_y])
    phase_count = np.zeros([3, n_x, n_y])
    phase_list = np.array([0, 1, 2])
    ### construct MC points
    np.random.seed(0)
    x_num = n_x * resolution
    y_num = n_y * resolution
    x = np.random.uniform(0., 1., x_num)
    x *= n_x * dx
    y = np.random.uniform(0., 1., y_num)
    y *= n_y * dy
    ### loading system
    total = len(x) * len(y)
    cur = 0
    old_percent = 0
    for m in range(len(x)):
        for n in range(len(y)):
            percent = int((cur / total) * 100)
            if percent > old_percent:
                # print('field generate process: {} %'.format(percent))
                old_percent = percent
            ### construct MC points
            MC_point = np.array([x[m], y[n]])
            ### patch 1: circle 1, large
            r1 = np.sqrt((MC_point[0] - cp1[0]) ** 2 + (MC_point[1] - cp1[1]) ** 2)
            if r1 < R1:
                r2 = np.sqrt((MC_point[0] - cp2[0]) ** 2 + (MC_point[1] - cp2[1]) ** 2)
                if r2 < R2:
                    MC_phase_ind = 2
                else:
                    MC_phase_ind = 1
            else:
                MC_phase_ind = 0
            phase_count[MC_phase_ind, int(MC_point[0] // dx), int(MC_point[1] // dy)] += 1
            cur += 1
    ## according to the phase_count, calculate the
    for p in range(n_x):
        for q in range(n_y):
            seq = phase_count[:, p, q]
            total_count = sum(seq)
            for u in range(len(seq)):
                result[u, p, q] = seq[u] / total_count
    return result


def doubleline_translation(n, d1, d2, n_x, n_y, dx, dy):
    ### initialization of the volume fraction field
    result = np.zeros([3, n_x, n_y])
    for i in range(n_x):
        for j in range(n_y):
            # print('The current calculated cell is: ', [i, j])
            ### The vertex starting from lower-left point, counter-clockwise
            cell = np.array([[i * dx, j * dy],
                             [i * dx, (j + 1) * dy],
                             [(i + 1) * dx, (j + 1) * dy],
                             [(i + 1) * dx, j * dy]])
            if not judge_outside_line(cell, n, d1):
                cell_remain = plic_cell_remain_general(n, d1, dx, dy, cell[0])
                # print('The remain cell is: ', cell_remain)
                intersects = plic_get_intersects(cell, n, d1)
                volume_1 = get_cut_volume_polygon_with_intersects(intersects, cell, n, d1)
                result[0, i, j] = volume_1 / dx * dy
            else:
                cell_remain = cell
                # print('The remain cell is (outside): ', cell_remain)
                result[0, i, j] = 0.
            if not judge_outside_line(cell, n, d2) and len(cell_remain) > 2:
                intersects = plic_get_intersects(cell_remain, n, d2)
                volume_2 = get_cut_volume_polygon_with_intersects(intersects, cell_remain, n, d2)
                result[1, i, j] = volume_2 / dx * dy
            else:
                result[1, i, j] = 0.
            remain_fraction = 1. - float(result[0, i, j] + result[1, i, j])
            result[2, i, j] = min(1., max(0., remain_fraction))
    return result


### THIS METHOD CALCULATES THE SYMMETRIC-DIFFERENCE ERROR OF GIVEN RECONSTRUCTION RESULTS
### cellA is the true polygon, cellB is the predicted polygon
def get_symmetric_difference_error(cellA, cellB):
    intersection_polygon = clip_polygon_shapely(cellA, cellB)
    intersect_area = intersection_polygon.area
    true_area = get_cell_volume_shapely(cellA)
    delta_omega = 2 * (true_area - intersect_area)
    return delta_omega


### THIS METHOD CALCULATES THE CUMULATIVE SYMMETRIC-DIFFERENCE ERROR OF GIVEN CELL
### CELLSA IS THE TRUE RECONSTRUCTION, CELLSB IS THE PREDICTED RECONSTRUCTION
def get_cumulative_symmetric_difference_error(cells_A, cells_B):
    csde = 0.
    for i in range(len(cells_A)):
        cell_A_i = cells_A[i]
        phase_ind_A = cell_A_i[0]
        cell_A = cell_A_i[1]
        csde_i = []
        for j in range(len(cells_B)):
            cell_B_i = cells_B[j]
            phase_ind_B = cell_B_i[0]
            cell_B = cell_B_i[1]
            if phase_ind_B == phase_ind_A:
                csde_i_ = get_symmetric_difference_error(cell_A, cell_B)
                csde_i.append(abs(csde_i_))
            else:
                pass
        if not len(csde_i) == 0:
            csde_i_final = np.min(np.array(csde_i))
        else:
            csde_i_final = 2 * get_cell_volume_shapely(cell_A)
        csde += csde_i_final ** 2
    return np.sqrt(csde)


### THIS FUNCTION RETURNS THE TRUE RECONSTRUCTION RESULT OF T-SHAPE
def true_reconstruction_T_shape(triple, nx, ny, dx, dy, ghost):
    reconstruction_true = np.zeros([nx, ny, 1]).tolist()
    ### nx-d=0
    normal_1 = np.array([0., 1.])
    normal_2 = np.array([1., 0.])
    d1 = triple[1] - ghost * dy
    d2 = triple[0] - ghost * dx
    for i in range(nx):
        for j in range(ny):
            reconstruction_true[i][j].append({})
    for i in range(nx - 2 * ghost):
        for j in range(ny - 2 * ghost):
            cells = []
            reconstruction_true[i + ghost][j + ghost][0] = 1
            O_position = np.array([i * dx, j * dy])
            cell_remain = plic_cell_remain_general(normal_1, d1, dx, dy, O_position)
            cell_1 = plic_cell_remain_general(-normal_1, -d1, dx, dy, O_position)
            if len(cell_1) > 2:
                cell_1 -= O_position
                cells.append([0, cell_1, 0])
            else:
                pass
            second_intersects = plic_get_intersects(cell_remain, normal_2, d2)
            cell_3 = plic_cell_remain_with_intersects(normal_2, d2, cell_remain, second_intersects)
            if len(cell_3) > 2:
                cells.append([2, cell_3 - O_position, 0])
            else:
                pass
            cell_2 = plic_cell_remain_with_intersects(-normal_2, -d2, cell_remain, second_intersects)
            if len(cell_2) > 2:
                cells.append([1, cell_2 - O_position, 0])
            else:
                pass
            reconstruction_true[i + ghost][j + ghost][1]['cells'] = cells
    return reconstruction_true


### THIS FUNCTION RETURNS THE TRUE RECONSTRUCTION RESULT OF Y-SHAPE
### THE TRIPLE POINT SHOULD BE ON THE Y=X LINE
def true_reconstruction_Y_shape(triple, angle, nx, ny, dx, dy, ghost):
    reconstruction_true = np.zeros([nx, ny, 1]).tolist()
    triple_real = triple - np.array([ghost, ghost])
    domain = np.array([[0., 0.],
                       [0., (ny - 2 * ghost) * dy],
                       [(nx - 2 * ghost) * dx, (ny - 2 * ghost) * dy],
                       [(nx - 2 * ghost) * dx, 0.]])
    if point_in_polygon_shapely(triple_real, domain):
        ### CONSTRUCT THE LARGE Y SHAPE POLYGON
        angle_right = (np.pi / 4) + angle
        normal_right = np.array([-np.sin(angle_right), np.cos(angle_right)])
        d_right = normal_right.dot(triple_real)
        intersections_right = plic_get_intersects(domain, normal_right, d_right)
        angle_left = (3 * np.pi / 4) + angle
        normal_left = np.array([-np.sin(angle_left), np.cos(angle_left)])
        d_left = normal_left.dot(triple_real)
        # intersections_left = plic_get_intersects(domain, normal_left, d_left)
        angle_down = (3 * np.pi / 2) + angle
        normal_down = np.array([-np.sin(angle_down), np.cos(angle_down)])
        d_down = normal_down.dot(triple_real)
        intersections_down = plic_get_intersects(domain, normal_down, d_down)
        cell_a = plic_cell_remain_with_intersects(normal_right, d_right, domain, intersections_right)
        intersections_right_b = plic_get_intersects(domain, -normal_right, -d_right)
        cell_b = plic_cell_remain_with_intersects(-normal_right, -d_right, domain, intersections_right_b)
        # print(intersections_right_b, domain, cell_b)
        intersects_cell_b = plic_get_intersects(cell_b, normal_down, d_down)
        polygon_right = plic_cell_remain_with_intersects(normal_down, d_down, cell_b, intersects_cell_b)
        intersects_cell_a = plic_get_intersects(cell_a, normal_left, d_left)
        polygon_up = plic_cell_remain_with_intersects(-normal_left, -d_left, cell_a, intersects_cell_a)
        cell_c = plic_cell_remain_with_intersects(-normal_down, -d_down, domain, intersections_down)
        intersects_cell_c = plic_get_intersects(cell_c, normal_left, d_left)
        polygon_left = plic_cell_remain_with_intersects(normal_left, d_left, cell_c, intersects_cell_c)
        # print(polygon_left, polygon_up, polygon_right)
        for p in range(nx):
            for q in range(ny):
                reconstruction_true[p][q].append({})
        for p in range(nx - 2 * ghost):
            for q in range(ny - 2 * ghost):
                cells = []
                reconstruction_true[p + ghost][q + ghost][0] = 1
                O_position = np.array([p * dx, q * dy])
                cell_local = np.array([[0., 0.],
                                       [0., dy],
                                       [dx, dy],
                                       [dx, 0.]])
                cell_local = cell_local + O_position
                cell_0_shapely = clip_polygon_shapely(polygon_left, cell_local)
                if isinstance(cell_0_shapely, Polygon) and cell_0_shapely.area > 1e-12:
                    cell_0_ = np.array(cell_0_shapely.exterior.coords)
                    cell_0_ -= O_position
                    cell_0 = [0, cell_0_, 0]
                    cells.append(cell_0)
                else:
                    pass
                cell_1_shapely = clip_polygon_shapely(polygon_up, cell_local)
                if isinstance(cell_1_shapely, Polygon) and cell_1_shapely.area > 1e-12:
                    cell_1_ = np.array(cell_1_shapely.exterior.coords)
                    cell_1_ -= O_position
                    cell_1 = [2, cell_1_, 0]
                    cells.append(cell_1)
                else:
                    pass
                cell_2_shapely = clip_polygon_shapely(polygon_right, cell_local)
                if isinstance(cell_2_shapely, Polygon) and cell_2_shapely.area > 1e-12:
                    cell_2_ = np.array(cell_2_shapely.exterior.coords)
                    cell_2_ -= O_position
                    cell_2 = [1, cell_2_, 0]
                    cells.append(cell_2)
                else:
                    pass
                reconstruction_true[p + ghost][q + ghost][1]['cells'] = cells
    else:
        print('triple point outside domain!')
    return reconstruction_true


def true_reconstruction_Y_shape_adv(triple, angle, nx, ny, dx, dy, ghost):
    reconstruction_true = np.zeros([nx, ny, 1]).tolist()
    triple_real = triple - np.array([ghost, ghost])
    domain = np.array([[0., 0.],
                       [0., (ny - 2 * ghost) * dy],
                       [(nx - 2 * ghost) * dx, (ny - 2 * ghost) * dy],
                       [(nx - 2 * ghost) * dx, 0.]])
    if point_in_polygon_shapely(triple_real, domain):
        ### CONSTRUCT THE LARGE Y SHAPE POLYGON
        angle_right = (np.pi / 6) + angle
        normal_right = np.array([-np.sin(angle_right), np.cos(angle_right)])
        d_right = normal_right.dot(triple_real)
        intersections_right = plic_get_intersects(domain, normal_right, d_right)
        angle_left = (5 * np.pi / 6) + angle
        normal_left = np.array([-np.sin(angle_left), np.cos(angle_left)])
        d_left = normal_left.dot(triple_real)
        # intersections_left = plic_get_intersects(domain, normal_left, d_left)
        angle_down = (3 * np.pi / 2) + angle
        normal_down = np.array([-np.sin(angle_down), np.cos(angle_down)])
        d_down = normal_down.dot(triple_real)
        intersections_down = plic_get_intersects(domain, normal_down, d_down)
        cell_a = plic_cell_remain_with_intersects(normal_right, d_right, domain, intersections_right)
        intersections_right_b = plic_get_intersects(domain, -normal_right, -d_right)
        cell_b = plic_cell_remain_with_intersects(-normal_right, -d_right, domain, intersections_right_b)
        # print(intersections_right_b, domain, cell_b)
        intersects_cell_b = plic_get_intersects(cell_b, normal_down, d_down)
        polygon_right = plic_cell_remain_with_intersects(normal_down, d_down, cell_b, intersects_cell_b)
        intersects_cell_a = plic_get_intersects(cell_a, normal_left, d_left)
        polygon_up = plic_cell_remain_with_intersects(-normal_left, -d_left, cell_a, intersects_cell_a)
        cell_c = plic_cell_remain_with_intersects(-normal_down, -d_down, domain, intersections_down)
        intersects_cell_c = plic_get_intersects(cell_c, normal_left, d_left)
        polygon_left = plic_cell_remain_with_intersects(normal_left, d_left, cell_c, intersects_cell_c)
        # print(polygon_left, polygon_up, polygon_right)
        for p in range(nx):
            for q in range(ny):
                reconstruction_true[p][q].append({})
        for p in range(nx - 2 * ghost):
            for q in range(ny - 2 * ghost):
                cells = []
                reconstruction_true[p + ghost][q + ghost][0] = 1
                O_position = np.array([p * dx, q * dy])
                cell_local = np.array([[0., 0.],
                                       [0., dy],
                                       [dx, dy],
                                       [dx, 0.]])
                cell_local = cell_local + O_position
                cell_0_shapely = clip_polygon_shapely(polygon_left, cell_local)
                if isinstance(cell_0_shapely, Polygon) and cell_0_shapely.area > 1e-12:
                    cell_0_ = np.array(cell_0_shapely.exterior.coords)
                    cell_0_ -= O_position
                    cell_0 = [0, cell_0_, 0]
                    cells.append(cell_0)
                else:
                    pass
                cell_1_shapely = clip_polygon_shapely(polygon_up, cell_local)
                if isinstance(cell_1_shapely, Polygon) and cell_1_shapely.area > 1e-12:
                    cell_1_ = np.array(cell_1_shapely.exterior.coords)
                    cell_1_ -= O_position
                    cell_1 = [2, cell_1_, 0]
                    cells.append(cell_1)
                else:
                    pass
                cell_2_shapely = clip_polygon_shapely(polygon_right, cell_local)
                if isinstance(cell_2_shapely, Polygon) and cell_2_shapely.area > 1e-12:
                    cell_2_ = np.array(cell_2_shapely.exterior.coords)
                    cell_2_ -= O_position
                    cell_2 = [1, cell_2_, 0]
                    cells.append(cell_2)
                else:
                    pass
                reconstruction_true[p + ghost][q + ghost][1]['cells'] = cells
    else:
        print('triple point outside domain!')
    return reconstruction_true


def true_reconstruction_L_shape(n, d1, d2, n_x, n_y, dx, dy, ghost):
    reconstruction_true = np.zeros([n_x, n_y, 1]).tolist()
    for p in range(n_x):
        for q in range(n_y):
            reconstruction_true[p][q].append({})
    for p in range(n_x - 2 * ghost):
        for q in range(n_y - 2 * ghost):
            ### The vertex starting from lower-left point, counter-clockwise
            cell = np.array([[(p + ghost) * dx, (q + ghost) * dy],
                             [(p + ghost) * dx, (q + 1 + ghost) * dy],
                             [(p + 1 + ghost) * dx, (q + 1 + ghost) * dy],
                             [(p + 1 + ghost) * dx, (q + ghost) * dy]])
            cells = []
            if not judge_outside_line(cell, n, d1):
                cell_remain = plic_cell_remain_general(n, d1, dx, dy, cell[0])
                cell_0 = plic_cell_remain_general(-n, -d1, dx, dy, cell[0])
                if len(cell_0) > 2:
                    cells.append([0, cell_0 - cell[0], 0])
            else:
                cell_remain = cell
            if not judge_outside_line(cell, n, d2) and len(cell_remain) > 2:
                intersects = plic_get_intersects(cell_remain, n, d2)
                cell_1 = plic_cell_remain_with_intersects(-n, -d2, cell_remain, intersects)
                if len(cell_1) > 2:
                    cells.append([1, cell_1 - cell[0], 0])
            else:
                pass
            intersects = plic_get_intersects(cell_remain, n, d2)
            cell_2 = plic_cell_remain_with_intersects(n, d2, cell_remain, intersects)
            if len(cell_2) > 2:
                cells.append([2, cell_2 - cell[0], 0])
            reconstruction_true[p + ghost][q + ghost][1]['cells'] = cells
    return reconstruction_true


### THIS FUNCTION USES MONTE CAROL METHOD TO CALCULATE THE CUMULATIVE SYMMETRIC-DIFFERENCE AREA OF THREE-PHASE CIRCLE
def get_csde_circle1(cp, R, dx, dy, cells_obj, resolution, O_position):
    np.random.seed(0)
    ### construct MC points
    x = np.random.uniform(0., dx, resolution)
    x += O_position[0]
    y = np.random.uniform(0., dy, resolution)
    y += O_position[1]
    ### initialization
    AND_count = np.zeros([3])
    true_count = np.zeros([3])
    for p in range(len(x)):
        for q in range(len(y)):
            MC_p = np.array([x[p], y[q]])
            r = np.sqrt((MC_p[0] - cp[0]) ** 2 + (MC_p[1] - cp[1]) ** 2)
            if r < R:
                if MC_p[0] > cp[0]:
                    true_count[2] += 1
                    for k in range(len(cells_obj)):
                        phase_ind = cells_obj[k][0]
                        cell = cells_obj[k][1] + O_position
                        if phase_ind == 2 and point_in_polygon_shapely(MC_p, cell):
                            AND_count[2] += 1
                            break
                        else:
                            pass
                else:
                    true_count[1] += 1
                    for k in range(len(cells_obj)):
                        phase_ind = cells_obj[k][0]
                        cell = cells_obj[k][1] + O_position
                        if phase_ind == 1 and point_in_polygon_shapely(MC_p, cell):
                            AND_count[1] += 1
                            break
                        else:
                            pass
            else:
                true_count[0] += 1
                for k in range(len(cells_obj)):
                    phase_ind = cells_obj[k][0]
                    cell = cells_obj[k][1] + O_position
                    if phase_ind == 0 and point_in_polygon_shapely(MC_p, cell):
                        AND_count[0] += 1
                        break
                    else:
                        pass
    true_area = (true_count * dx * dy) / (len(x) * len(y))
    AND_area = (AND_count * dx * dy) / (len(x) * len(y))
    delta_omega = 2 * (true_area - AND_area)
    delta_omega_square = delta_omega * delta_omega
    delta_omega_square_sum = np.sum(delta_omega_square)
    return np.sqrt(delta_omega_square_sum)


### THIS FUNCTION IS USED TO CALCULATE THE ACSDE
def get_acsde_circle1_mp(cp, R, dx, dy, nx, ny, ghost, Grad_recons, Choi_recons, DP_recons, resolution, num_p=12):
    que = Queue()
    manager = multiprocessing.Manager()
    return_dict = manager.dict()
    return_dict['DP'] = 0.
    return_dict['Choi'] = 0.
    return_dict['Grad'] = 0.
    return_dict['count'] = 0
    x_parts, y_parts = divide_domain(nx - 2 * ghost, ny - 2 * ghost, num_p)
    info = {'cp': cp,
            'R': R,
            'dx': dx,
            'dy': dy,
            'nx': nx,
            'ny': ny,
            'resolution': resolution,
            'x_parts': x_parts,
            'y_parts': y_parts,
            'Grad_recons': Grad_recons,
            'Choi_recons': Choi_recons,
            'DP_recons': DP_recons,
            'ghost': ghost}
    processes = create_processes_acsde(get_acsde_circle1_mp_exc, combine_results_acsde, info, que, return_dict)
    DP, Choi, Grad, count = start_and_join_p_acsde(processes, return_dict)
    return DP, Choi, Grad, count


def get_acsde_circle1_mp_exc(info, que, start_x, end_x, start_y, end_y):
    csde_total_DP = 0.
    csde_total_Choi = 0.
    csde_total_Grad = 0.
    csde_count = 0
    reconstruction = info['DP_recons']
    reconstruction_PLIC = info['Choi_recons']
    reconstruction_PLIC_2 = info['Grad_recons']
    resolution = info['resolution']
    ghost = info['ghost']
    dx = info['dx']
    dy = info['dy']
    R = info['R']
    cp_cur = info['cp']
    for m in range(end_x - start_x):
        for n in range(end_y - start_y):
            phase_num = reconstruction[m + ghost + start_x][n + ghost + start_y][1]['phase_num']
            if phase_num > 1:
                O_position = np.array([(m + ghost + start_x) * dx, (n + ghost + start_y) * dy])
                ### AVERAGED CUMULATIVE SYMMETRIC-DIFFERENCE ERROR
                csde_count = csde_count + 1
                ### DP
                DP_cells = reconstruction[m + ghost + start_x][n + ghost + start_y][1]['cells']
                DP_csde_err = get_csde_circle1(cp_cur, R, dx, dy, DP_cells, resolution, O_position)
                csde_total_DP += DP_csde_err
                ### Choi
                Choi_cells = reconstruction_PLIC[m + ghost + start_x][n + ghost + start_y][1]['cells']
                Choi_csde_err = get_csde_circle1(cp_cur, R, dx, dy, Choi_cells, resolution, O_position)
                csde_total_Choi += Choi_csde_err
                ### Grad
                Grad_cells = reconstruction_PLIC_2[m + ghost + start_x][n + ghost + start_y][1]['cells']
                Grad_csde_err = get_csde_circle1(cp_cur, R, dx, dy, Grad_cells, resolution, O_position)
                csde_total_Grad += Grad_csde_err
            else:
                pass
    que.put({'DP': csde_total_DP, 'Choi': csde_total_Choi, 'Grad': csde_total_Grad, 'count': csde_count,
             'start_x': start_x, 'end_x': end_x, 'start_y': start_y, 'end_y': end_y})


### THIS FUNCTION USES MONTE CAROL METHOD TO CALCULATE THE CUMULATIVE SYMMETRIC-DIFFERENCE AREA OF DOUBLE CIRCLE
def get_csde_circle2(cp1, R1, cp2, R2, dx, dy, cells_obj, resolution, O_position):
    np.random.seed(0)
    ### construct MC points
    x = np.random.uniform(0., dx, resolution)
    x += O_position[0]
    y = np.random.uniform(0., dy, resolution)
    y += O_position[1]
    ### initialization
    AND_count = np.zeros([3])
    true_count = np.zeros([3])

    for p in range(len(x)):
        for q in range(len(y)):
            MC_p = np.array([x[p], y[q]])
            r1 = np.sqrt((MC_p[0] - cp1[0]) ** 2 + (MC_p[1] - cp1[1]) ** 2)
            if r1 < R1:
                r2 = np.sqrt((MC_p[0] - cp2[0]) ** 2 + (MC_p[1] - cp2[1]) ** 2)
                if r2 < R2:
                    true_count[2] += 1
                    for k in range(len(cells_obj)):
                        phase_ind = cells_obj[k][0]
                        cell = cells_obj[k][1] + O_position
                        if phase_ind == 2 and point_in_polygon_shapely(MC_p, cell):
                            AND_count[2] += 1
                            break
                        else:
                            pass
                else:
                    true_count[1] += 1
                    for k in range(len(cells_obj)):
                        phase_ind = cells_obj[k][0]
                        cell = cells_obj[k][1] + O_position
                        if phase_ind == 1 and point_in_polygon_shapely(MC_p, cell):
                            AND_count[1] += 1
                            break
                        else:
                            pass
            else:
                true_count[0] += 1
                for k in range(len(cells_obj)):
                    phase_ind = cells_obj[k][0]
                    cell = cells_obj[k][1] + O_position
                    if phase_ind == 0 and point_in_polygon_shapely(MC_p, cell):
                        AND_count[0] += 1
                        break
                    else:
                        pass

    true_area = (true_count * dx * dy) / (len(x) * len(y))
    AND_area = (AND_count * dx * dy) / (len(x) * len(y))
    delta_omega = 2 * (true_area - AND_area)
    delta_omega_square = delta_omega * delta_omega
    delta_omega_square_sum = np.sum(delta_omega_square)
    return np.sqrt(delta_omega_square_sum)


### THIS FUNCTION IS USED TO CALCULATE THE ACSDE
def get_acsde_circle2_mp(cp1, R1, cp2, R2, dx, dy, nx, ny, ghost, Grad_recons, Choi_recons, DP_recons, resolution,
                         num_p=12):
    que = Queue()
    manager = multiprocessing.Manager()
    return_dict = manager.dict()
    return_dict['DP'] = 0.
    return_dict['Choi'] = 0.
    return_dict['Grad'] = 0.
    return_dict['count'] = 0
    x_parts, y_parts = divide_domain(nx - 2 * ghost, ny - 2 * ghost, num_p)
    info = {'cp1': cp1,
            'R1': R1,
            'cp2': cp2,
            'R2': R2,
            'dx': dx,
            'dy': dy,
            'nx': nx,
            'ny': ny,
            'resolution': resolution,
            'x_parts': x_parts,
            'y_parts': y_parts,
            'Grad_recons': Grad_recons,
            'Choi_recons': Choi_recons,
            'DP_recons': DP_recons,
            'ghost': ghost}
    processes = create_processes_acsde(get_acsde_circle2_mp_exc, combine_results_acsde, info, que, return_dict)
    DP, Choi, Grad, count = start_and_join_p_acsde(processes, return_dict)
    return DP, Choi, Grad, count


def get_acsde_circle2_mp_exc(info, que, start_x, end_x, start_y, end_y):
    csde_total_DP = 0.
    csde_total_Choi = 0.
    csde_total_Grad = 0.
    csde_count = 0
    reconstruction = info['DP_recons']
    reconstruction_PLIC = info['Choi_recons']
    reconstruction_PLIC_2 = info['Grad_recons']
    resolution = info['resolution']
    ghost = info['ghost']
    dx = info['dx']
    dy = info['dy']
    R1 = info['R1']
    R2 = info['R2']
    cp1 = info['cp1']
    cp2 = info['cp2']

    for m in range(end_x - start_x):
        for n in range(end_y - start_y):
            phase_num = reconstruction[m + ghost + start_x][n + ghost + start_y][1]['phase_num']
            if phase_num > 1:
                O_position = np.array([(m + ghost + start_x) * dx, (n + ghost + start_y) * dy])
                ### AVERAGED CUMULATIVE SYMMETRIC-DIFFERENCE ERROR
                csde_count = csde_count + 1
                ### DP
                DP_cells = reconstruction[m + ghost + start_x][n + ghost + start_y][1]['cells']
                DP_csde_err = get_csde_circle2(cp1, R1, cp2, R2, dx, dy, DP_cells, resolution, O_position)
                csde_total_DP += DP_csde_err
                ### Choi
                Choi_cells = reconstruction_PLIC[m + ghost + start_x][n + ghost + start_y][1]['cells']
                Choi_csde_err = get_csde_circle2(cp1, R1, cp2, R2, dx, dy, Choi_cells, resolution, O_position)
                csde_total_Choi += Choi_csde_err
                ### Grad
                Grad_cells = reconstruction_PLIC_2[m + ghost + start_x][n + ghost + start_y][1]['cells']
                Grad_csde_err = get_csde_circle2(cp1, R1, cp2, R2, dx, dy, Grad_cells, resolution, O_position)
                csde_total_Grad += Grad_csde_err
            else:
                pass
    que.put({'DP': csde_total_DP, 'Choi': csde_total_Choi, 'Grad': csde_total_Grad, 'count': csde_count,
             'start_x': start_x, 'end_x': end_x, 'start_y': start_y, 'end_y': end_y})


### THIS FUNCTION USES MONTE CAROL METHOD TO CALCULATE THE CUMULATIVE SYMMETRIC-DIFFERENCE AREA OF SNAKE SHAPE
def get_csde_snake(A, omega, phi1, phi2, dx, dy, cells_obj, resolution, O_position):
    def sin_func(A, omega, phi, x):
        return A * np.sin(omega * (x - 1.)) + phi

    np.random.seed(0)
    ### construct MC points
    x = np.random.uniform(0., dx, resolution)
    x += O_position[0]
    y = np.random.uniform(0., dy, resolution)
    y += O_position[1]
    ### initialization
    AND_count = np.zeros([3])
    true_count = np.zeros([3])

    for p in range(len(x)):
        for q in range(len(y)):
            MC_p = np.array([x[p], y[q]])
            if MC_p[1] < sin_func(A, omega, phi1, MC_p[0]):
                if MC_p[1] > sin_func(A, omega, phi2, MC_p[0]):
                    true_count[2] += 1
                    for k in range(len(cells_obj)):
                        phase_ind = cells_obj[k][0]
                        cell = cells_obj[k][1] + O_position
                        if phase_ind == 2 and point_in_polygon_shapely(MC_p, cell):
                            AND_count[2] += 1
                            break
                        else:
                            pass
                else:
                    true_count[1] += 1
                    for k in range(len(cells_obj)):
                        phase_ind = cells_obj[k][0]
                        cell = cells_obj[k][1] + O_position
                        if phase_ind == 1 and point_in_polygon_shapely(MC_p, cell):
                            AND_count[1] += 1
                            break
                        else:
                            pass
            else:
                true_count[0] += 1
                for k in range(len(cells_obj)):
                    phase_ind = cells_obj[k][0]
                    cell = cells_obj[k][1] + O_position
                    if phase_ind == 0 and point_in_polygon_shapely(MC_p, cell):
                        AND_count[0] += 1
                        break
                    else:
                        pass

    true_area = (true_count * dx * dy) / (len(x) * len(y))
    AND_area = (AND_count * dx * dy) / (len(x) * len(y))
    delta_omega = 2 * (true_area - AND_area)
    delta_omega_square = delta_omega * delta_omega
    delta_omega_square_sum = np.sum(delta_omega_square)
    return np.sqrt(delta_omega_square_sum)


### THIS FUNCTION IS USED TO CALCULATE THE ACSDE
def get_acsde_snake_mp(A, omega, phi1, phi2, dx, dy, nx, ny, ghost, Grad_recons, Choi_recons, DP_recons, resolution,
                       num_p=12):
    que = Queue()
    manager = multiprocessing.Manager()
    return_dict = manager.dict()
    return_dict['DP'] = 0.
    return_dict['Choi'] = 0.
    return_dict['Grad'] = 0.
    return_dict['count'] = 0
    x_parts, y_parts = divide_domain(nx - 2 * ghost, ny - 2 * ghost, num_p)
    info = {'A': A,
            'omega': omega,
            'phi1': phi1,
            'phi2': phi2,
            'dx': dx,
            'dy': dy,
            'nx': nx,
            'ny': ny,
            'resolution': resolution,
            'x_parts': x_parts,
            'y_parts': y_parts,
            'Grad_recons': Grad_recons,
            'Choi_recons': Choi_recons,
            'DP_recons': DP_recons,
            'ghost': ghost}
    processes = create_processes_acsde(get_acsde_snake_mp_exc, combine_results_acsde, info, que, return_dict)
    DP, Choi, Grad, count = start_and_join_p_acsde(processes, return_dict)
    return DP, Choi, Grad, count


def get_acsde_snake_mp_exc(info, que, start_x, end_x, start_y, end_y):
    csde_total_DP = 0.
    csde_total_Choi = 0.
    csde_total_Grad = 0.
    csde_count = 0
    reconstruction = info['DP_recons']
    reconstruction_PLIC = info['Choi_recons']
    reconstruction_PLIC_2 = info['Grad_recons']
    resolution = info['resolution']
    ghost = info['ghost']
    dx = info['dx']
    dy = info['dy']
    A = info['A']
    omega = info['omega']
    phi1 = info['phi1']
    phi2 = info['phi2']

    for m in range(end_x - start_x):
        for n in range(end_y - start_y):
            phase_num = reconstruction[m + ghost + start_x][n + ghost + start_y][1]['phase_num']
            if phase_num > 1:
                O_position = np.array([(m + ghost + start_x) * dx, (n + ghost + start_y) * dy])
                ### AVERAGED CUMULATIVE SYMMETRIC-DIFFERENCE ERROR
                csde_count = csde_count + 1
                ### DP
                DP_cells = reconstruction[m + ghost + start_x][n + ghost + start_y][1]['cells']
                DP_csde_err = get_csde_snake(A, omega, phi1, phi2, dx, dy, DP_cells, resolution, O_position)
                csde_total_DP += DP_csde_err
                ### Choi
                Choi_cells = reconstruction_PLIC[m + ghost + start_x][n + ghost + start_y][1]['cells']
                Choi_csde_err = get_csde_snake(A, omega, phi1, phi2, dx, dy, Choi_cells, resolution, O_position)
                csde_total_Choi += Choi_csde_err
                ### Grad
                Grad_cells = reconstruction_PLIC_2[m + ghost + start_x][n + ghost + start_y][1]['cells']
                Grad_csde_err = get_csde_snake(A, omega, phi1, phi2, dx, dy, Grad_cells, resolution, O_position)
                csde_total_Grad += Grad_csde_err
            else:
                pass
    que.put({'DP': csde_total_DP, 'Choi': csde_total_Choi, 'Grad': csde_total_Grad, 'count': csde_count,
             'start_x': start_x, 'end_x': end_x, 'start_y': start_y, 'end_y': end_y})

# #### JCP circle
# nx = 11
# ny = 11
# ghost = 1
# dx = 1 / (nx - 2 * ghost)
# dy = dx
# tolerance = 1e-6
# max_step = 20
# cp = [(nx * dx) / 2 + 0. * dx, (ny * dy) / 2 + 0. * dy]
# delta_x = [0., 0.2 * dx, 0.4 * dx]
# R = 0.35 * min(nx * dx, ny * dy)
# resolution = 500
# num_p = 9
# fig, ax = plt.subplots(3, 4, figsize=[25, 19])
# for sub_ax in ax:
#     for subsub_ax in sub_ax:
#         subsub_ax.set_aspect('equal')
#         subsub_ax.grid(linestyle='--')
#         subsub_ax.xaxis.set_major_locator(MultipleLocator(1))
#         subsub_ax.yaxis.set_major_locator(MultipleLocator(1))
#         subsub_ax.set_xticklabels([])
#         subsub_ax.set_yticklabels([])
# ### grad-choi-dp
# time_ = np.zeros([3, 3])
# cons = np.zeros([3, 3])
# acsde = np.zeros([3, 3])
# for i in range(len(delta_x)):
#     print(delta_x[i])
#     cp_cur = [cp[0] + delta_x[i], cp[1] + delta_x[i]]
#     Sf = circle1_mp(cp_cur, R, nx, ny, dx, dy, resolution, num_p)
#     N_ax_x = len(Sf[0]) - 2 * ghost
#     N_ax_y = len(Sf[0][0]) - 2 * ghost
#     ax[i, 0].set_xlim([0, dx * N_ax_x])
#     ax[i, 0].set_ylim([0, dx * N_ax_y])
#     ax[i, 1].set_xlim([0, dx * N_ax_x])
#     ax[i, 1].set_ylim([0, dx * N_ax_y])
#     ax[i, 2].set_xlim([0, dx * N_ax_x])
#     ax[i, 2].set_ylim([0, dx * N_ax_y])
#     ax[i, 3].set_xlim([0, dx * N_ax_x])
#     ax[i, 3].set_ylim([0, dx * N_ax_y])
#     ### DP-PLIC
#     time_DP_1 = time.time()
#     reconstruction = DP_PLIC_exact(Sf, dx, dy, tolerance, max_step)
#     time_DP_2 = time.time()
#     time_DP = time_DP_2 - time_DP_1
#     for m in range(N_ax_x):
#         for n in range(N_ax_y):
#             O_position = np.array([m * dx, n * dy])
#             grid_info = reconstruction[m + ghost][n + ghost]
#             if grid_info[0] != 0 and grid_info[1]['method']:
#                 Cells = grid_info[1]['cells']
#                 if grid_info[1]['method'] == 'PLIC':
#                     # print('PLIC')
#                     plot_interface_plic_adv(ax[i, 3], O_position, Cells, 2)
#                 elif grid_info[1]['method'] == 'YOUNGS':
#                     plot_interface_plic_adv(ax[i, 3], O_position, Cells, 2)
#                     errors = grid_info[1]['errors']
#                     # print('YOUNGS', errors)
#                 else:
#                     # print(m,n,Cells)
#                     plot_interface_plic_adv_DP(ax[i, 3], O_position, Cells, 2, dx, dy)
#                     errors = grid_info[1]['errors']
#                     # print('DP', errors)
#             else:
#                 pass
#     ### Choi-PLIC
#     time_PLIC = 0.
#     time_PLIC_1 = time.time()
#     reconstruction_PLIC = np.zeros([len(Sf[0]), len(Sf[0, 0]), 1]).tolist()
#     for m in range(len(Sf[0])):
#         for n in range(len(Sf[0, 0])):
#             reconstruction_PLIC[m][n].append({})
#     for m in range(N_ax_x):
#         for n in range(N_ax_y):
#             O_position = np.array([m * dx, n * dy])
#             sf_center_pos = [m + ghost, n + ghost]
#             sf = get_sf(sf_center_pos, Sf)
#             phase_exist = judge_phase_num(sf)
#             count = len(phase_exist)
#             reconstruction_PLIC[m + ghost][n + ghost][1]['phase_num'] = count
#             if count > 1:
#                 normals, d, cells, errors, error = PLIC_2d_tripleP_GSadv(sf, dx, dy, phase_exist, tolerance)
#                 reconstruction_PLIC[m + ghost][n + ghost][0] = 1
#                 reconstruction_PLIC[m + ghost][n + ghost][1]['method'] = 'PLIC'
#                 reconstruction_PLIC[m + ghost][n + ghost][1]['cells'] = cells
#                 reconstruction_PLIC[m + ghost][n + ghost][1]['normals'] = normals
#                 reconstruction_PLIC[m + ghost][n + ghost][1]['ds'] = d
#                 reconstruction_PLIC[m + ghost][n + ghost][1]['errors'] = errors
#                 reconstruction_PLIC[m + ghost][n + ghost][1]['error'] = error
#                 if error > tolerance * 10:
#                     normals, ds, cells, errors, error = Youngs_2d(sf, dx, dy, tolerance, phase_exist)
#                     reconstruction_PLIC[m + ghost][n + ghost][0] = 1
#                     reconstruction_PLIC[m + ghost][n + ghost][1]['method'] = 'YOUNGS'
#                     reconstruction_PLIC[m + ghost][n + ghost][1]['cells'] = cells
#                     reconstruction_PLIC[m + ghost][n + ghost][1]['normals'] = normals
#                     reconstruction_PLIC[m + ghost][n + ghost][1]['ds'] = ds
#                     reconstruction_PLIC[m + ghost][n + ghost][1]['errors'] = errors
#                     reconstruction_PLIC[m + ghost][n + ghost][1]['error'] = error
#                 else:
#                     pass
#             else:
#                 pass
#     time_PLIC_2 = time.time()
#     time_PLIC += (time_PLIC_2 - time_PLIC_1)
#     for m in range(N_ax_x):
#         for n in range(N_ax_y):
#             O_position = np.array([m * dx, n * dy])
#             sf_center_pos = [m + ghost, n + ghost]
#             sf = get_sf(sf_center_pos, Sf)
#             phase_exist = judge_phase_num(sf)
#             count = len(phase_exist)
#             if count > 1:
#                 cells = reconstruction_PLIC[m + ghost][n + ghost][1]['cells']
#                 plot_interface_plic_adv(ax[i, 2], O_position, cells, 2)
#                 if count > 2:
#                     errors = reconstruction_PLIC[m + ghost][n + ghost][1]['errors']
#                     # print('Choi-PLIC', errors)
#     ### Grad-PLIC
#     time_Grad_PLIC = 0.
#     time_Grad_PLIC_1 = time.time()
#     reconstruction_PLIC_2 = np.zeros([len(Sf[0]), len(Sf[0, 0]), 1]).tolist()
#     for m in range(len(Sf[0])):
#         for n in range(len(Sf[0, 0])):
#             reconstruction_PLIC_2[m][n].append({})
#     for m in range(N_ax_x):
#         for n in range(N_ax_y):
#             O_position = np.array([m * dx, n * dy])
#             sf_center_pos = [m + ghost, n + ghost]
#             sf = get_sf(sf_center_pos, Sf)
#             phase_exist = judge_phase_num(sf)
#             count = len(phase_exist)
#             reconstruction_PLIC_2[m + ghost][n + ghost][1]['phase_num'] = count
#             if count > 1:
#                 normals, d, cells, errors, error = Youngs_2d(sf, dx, dy, tolerance, phase_exist)
#                 reconstruction_PLIC_2[m + ghost][n + ghost][0] = 1
#                 reconstruction_PLIC_2[m + ghost][n + ghost][1]['method'] = 'PLIC'
#                 reconstruction_PLIC_2[m + ghost][n + ghost][1]['cells'] = cells
#                 reconstruction_PLIC_2[m + ghost][n + ghost][1]['normals'] = normals
#                 reconstruction_PLIC_2[m + ghost][n + ghost][1]['ds'] = d
#                 reconstruction_PLIC_2[m + ghost][n + ghost][1]['errors'] = errors
#                 reconstruction_PLIC_2[m + ghost][n + ghost][1]['error'] = error
#             else:
#                 pass
#     time_Grad_PLIC_2 = time.time()
#     time_Grad_PLIC += (time_Grad_PLIC_2 - time_Grad_PLIC_1)
#     for m in range(N_ax_x):
#         for n in range(N_ax_y):
#             O_position = np.array([m * dx, n * dy])
#             sf_center_pos = [m + ghost, n + ghost]
#             sf = get_sf(sf_center_pos, Sf)
#             phase_exist = judge_phase_num(sf)
#             count = len(phase_exist)
#             if count > 1:
#                 cells = reconstruction_PLIC_2[m + ghost][n + ghost][1]['cells']
#                 plot_interface_plic_adv(ax[i, 1], O_position, cells, 2)
#                 if count > 2:
#                     errors = reconstruction_PLIC_2[m + ghost][n + ghost][1]['errors']
#                     # print('Grad-PLIC', errors)
#     print('DP time: ', time_DP, 'Choi time: ', time_PLIC, 'Grad time: ', time_Grad_PLIC)
#     time_[i] = np.array([time_Grad_PLIC, time_PLIC, time_DP])
#     ### true-reconstruction
#     ### DRAW THE CIRCLE FIRST
#     circle_true = patches.Circle((cp_cur[0] - ghost * dx, cp_cur[1] - ghost * dy), radius=R, edgecolor='black', facecolor='none',
#                                  linewidth=2)
#     ax[i, 0].add_patch(circle_true)
#     ### THEN DRAW THE LINE
#     ax[i, 0].plot([cp_cur[0] - ghost * dx, cp_cur[0] - ghost * dx], [cp_cur[1] + R - ghost * dy, cp_cur[1] - R - ghost * dy], color='black',
#                   linewidth=2)
#     ### CALCULATION OF AVERAGED CUMULATIVE SYMMETRIC-DIFFERENCE ERROR USING THE MONTE CAROL METHOD
#     csde_total_DP, csde_total_Choi, csde_total_Grad, csde_count = get_acsde_circle1_mp(cp_cur, R, dx, dy, nx, ny, ghost,
#                                                                                        reconstruction_PLIC_2,
#                                                                                        reconstruction_PLIC,
#                                                                                        reconstruction, resolution,
#                                                                                        num_p)
#     cons_DP = np.zeros([3])
#     cons_Choi = np.zeros([3])
#     cons_Grad = np.zeros([3])
#     for m in range(nx - 2 * ghost):
#         for n in range(ny - 2 * ghost):
#             phase_num = reconstruction[m + ghost][n + ghost][1]['phase_num']
#             if phase_num > 1:
#                 ### CONSERVATION ERROR
#                 ### DP
#                 errors_DP = reconstruction[m + ghost][n + ghost][1]['errors']
#                 cons_DP = cons_DP + errors_DP
#                 ### Choi
#                 errors_Choi = reconstruction_PLIC[m + ghost][n + ghost][1]['errors']
#                 cons_Choi = cons_Choi + errors_Choi
#                 ### Grad
#                 errors_Grad = reconstruction_PLIC_2[m + ghost][n + ghost][1]['errors']
#                 cons_Grad = cons_Grad + errors_Grad
#             else:
#                 pass
#     avg_csde_DP = csde_total_DP / csde_count
#     avg_csde_Choi = csde_total_Choi / csde_count
#     avg_csde_Grad = csde_total_Grad / csde_count
#     print('DP acsde err: ', avg_csde_DP, 'Choi acsde err: ', avg_csde_Choi, 'Grad acsde err: ', avg_csde_Grad)
#     conservation_error_DP = np.sum(abs(cons_DP))
#     conservation_error_Choi = np.sum(abs(cons_Choi))
#     conservation_error_Grad = np.sum(abs(cons_Grad))
#     print('DP cons: ', conservation_error_DP, 'Choi cons: ', conservation_error_Choi, 'Grad cons: ',
#           conservation_error_Grad)
#     cons[i] = np.array([conservation_error_Grad, conservation_error_Choi, conservation_error_DP])
#     acsde[i] = np.array([avg_csde_Grad, avg_csde_Choi, avg_csde_DP])
# #
# handles, labels = plt.gca().get_legend_handles_labels()
# by_label = dict(zip(labels, handles))
# ax[0, 3].legend(by_label.values(), by_label.keys(), fontsize="20")
# ### Y LABEL
# ax[0, 0].set_ylabel('(1)', fontsize=40)
# ax[1, 0].set_ylabel('(2)', fontsize=40)
# ax[2, 0].set_ylabel('(3)', fontsize=40)
# ### X LABEL
# ax[0, 0].set_title('(a) true layout', fontsize=40)
# ax[0, 1].set_title('(b) Grad-PLIC', fontsize=40)
# ax[0, 2].set_title('(c) Choi-PLIC', fontsize=40)
# ax[0, 3].set_title('(d) DP-PLIC', fontsize=40)
# fig.subplots_adjust(wspace=5e-2, hspace=5e-2, bottom=5e-2, top=1 - 5e-2, left=5e-2, right=1 - 5e-2)
# plt.savefig('./static_cases/Circle1.png', format='png', dpi=400)
# plt.close()
#
# print('Summary')
# print('time')
# print('Grad: ', np.average(time_[:, 0]), 'Choi: ', np.average(time_[:, 1]), 'DP: ', np.average(time_[:, 2]))
# print('conservation')
# print('Grad: ', np.average(cons[:, 0]), 'Choi: ', np.average(cons[:, 1]), 'DP: ', np.average(cons[:, 2]))
# print('acsde')
# print('Grad: ', np.average(acsde[:, 0]), 'Choi: ', np.average(acsde[:, 1]), 'DP: ', np.average(acsde[:, 2]))

# ### JCP_dcircle
# ghost = 1
# dx = 1.
# dy = 1.
# tolerance = 1e-6
# max_step = 20
# L = [15, 17, 18]
# resolution = 500
# num_p = 9
# fig, ax = plt.subplots(3, 4, figsize=[25, 19])
# for sub_ax in ax:
#     for subsub_ax in sub_ax:
#         subsub_ax.set_aspect('equal')
#         subsub_ax.grid(linestyle='--')
#         subsub_ax.xaxis.set_major_locator(MultipleLocator(1))
#         subsub_ax.yaxis.set_major_locator(MultipleLocator(1))
#         subsub_ax.set_xticklabels([])
#         subsub_ax.set_yticklabels([])
# ### grad-choi-dp
# time_ = np.zeros([3, 3])
# cons = np.zeros([3, 3])
# acsde = np.zeros([3, 3])
# for i in range(len(L)):
#     print(L[i])
#     nx, ny = L[i], L[i]
#     cp1 = [(nx * dx) / 2, (ny * dy) / 2]
#     R1 = 0.4 * min(nx * dx, ny * dy)
#     cp2 = [cp1[0], cp1[1] + R1 / 2]
#     R2 = R1 / 2 - 0.6 * dx
#     Sf = circle2_mp(cp1, R1, cp2, R2, nx, ny, dx, dy, resolution, num_p)
#     N_ax_x = len(Sf[0]) - 2 * ghost
#     N_ax_y = len(Sf[0][0]) - 2 * ghost
#     ax[i, 0].set_xlim([0, dx * N_ax_x])
#     ax[i, 0].set_ylim([0, dx * N_ax_y])
#     ax[i, 1].set_xlim([0, dx * N_ax_x])
#     ax[i, 1].set_ylim([0, dx * N_ax_y])
#     ax[i, 2].set_xlim([0, dx * N_ax_x])
#     ax[i, 2].set_ylim([0, dx * N_ax_y])
#     ax[i, 3].set_xlim([0, dx * N_ax_x])
#     ax[i, 3].set_ylim([0, dx * N_ax_y])
#     ### DP-PLIC
#     time_DP_1 = time.time()
#     reconstruction = DP_PLIC_exact(Sf, dx, dy, tolerance, max_step)
#     time_DP_2 = time.time()
#     time_DP = time_DP_2 - time_DP_1
#     for m in range(N_ax_x):
#         for n in range(N_ax_y):
#             O_position = np.array([m * dx, n * dy])
#             grid_info = reconstruction[m + ghost][n + ghost]
#             if grid_info[0] != 0 and grid_info[1]['method']:
#                 Cells = grid_info[1]['cells']
#                 if grid_info[1]['method'] == 'PLIC':
#                     # print('PLIC')
#                     plot_interface_plic_adv(ax[i, 3], O_position, Cells, 2)
#                 elif grid_info[1]['method'] == 'YOUNGS':
#                     plot_interface_plic_adv(ax[i, 3], O_position, Cells, 2)
#                     errors = grid_info[1]['errors']
#                     # print('YOUNGS', errors)
#                 else:
#                     # print(m,n,Cells)
#                     plot_interface_plic_adv_DP(ax[i, 3], O_position, Cells, 2, dx, dy)
#                     errors = grid_info[1]['errors']
#                     # print('DP', errors)
#             else:
#                 pass
#     ### Choi-PLIC
#     time_PLIC = 0.
#     time_PLIC_1 = time.time()
#     reconstruction_PLIC = np.zeros([len(Sf[0]), len(Sf[0, 0]), 1]).tolist()
#     for m in range(len(Sf[0])):
#         for n in range(len(Sf[0, 0])):
#             reconstruction_PLIC[m][n].append({})
#     for m in range(N_ax_x):
#         for n in range(N_ax_y):
#             O_position = np.array([m * dx, n * dy])
#             sf_center_pos = [m + ghost, n + ghost]
#             sf = get_sf(sf_center_pos, Sf)
#             phase_exist = judge_phase_num(sf)
#             count = len(phase_exist)
#             reconstruction_PLIC[m + ghost][n + ghost][1]['phase_num'] = count
#             if count > 1:
#                 normals, d, cells, errors, error = PLIC_2d_tripleP_GSadv(sf, dx, dy, phase_exist, tolerance)
#                 reconstruction_PLIC[m + ghost][n + ghost][0] = 1
#                 reconstruction_PLIC[m + ghost][n + ghost][1]['method'] = 'PLIC'
#                 reconstruction_PLIC[m + ghost][n + ghost][1]['cells'] = cells
#                 reconstruction_PLIC[m + ghost][n + ghost][1]['normals'] = normals
#                 reconstruction_PLIC[m + ghost][n + ghost][1]['ds'] = d
#                 reconstruction_PLIC[m + ghost][n + ghost][1]['errors'] = errors
#                 reconstruction_PLIC[m + ghost][n + ghost][1]['error'] = error
#                 if error > tolerance * 10:
#                     normals, ds, cells, errors, error = Youngs_2d(sf, dx, dy, tolerance, phase_exist)
#                     reconstruction_PLIC[m + ghost][n + ghost][0] = 1
#                     reconstruction_PLIC[m + ghost][n + ghost][1]['method'] = 'YOUNGS'
#                     reconstruction_PLIC[m + ghost][n + ghost][1]['cells'] = cells
#                     reconstruction_PLIC[m + ghost][n + ghost][1]['normals'] = normals
#                     reconstruction_PLIC[m + ghost][n + ghost][1]['ds'] = ds
#                     reconstruction_PLIC[m + ghost][n + ghost][1]['errors'] = errors
#                     reconstruction_PLIC[m + ghost][n + ghost][1]['error'] = error
#                 else:
#                     pass
#             else:
#                 pass
#     time_PLIC_2 = time.time()
#     time_PLIC += (time_PLIC_2 - time_PLIC_1)
#     for m in range(N_ax_x):
#         for n in range(N_ax_y):
#             O_position = np.array([m * dx, n * dy])
#             sf_center_pos = [m + ghost, n + ghost]
#             sf = get_sf(sf_center_pos, Sf)
#             phase_exist = judge_phase_num(sf)
#             count = len(phase_exist)
#             if count > 1:
#                 cells = reconstruction_PLIC[m + ghost][n + ghost][1]['cells']
#                 plot_interface_plic_adv(ax[i, 2], O_position, cells, 2)
#                 if count > 2:
#                     errors = reconstruction_PLIC[m + ghost][n + ghost][1]['errors']
#                     # print('Choi-PLIC', errors)
#     ### Grad-PLIC
#     time_Grad_PLIC = 0.
#     time_Grad_PLIC_1 = time.time()
#     reconstruction_PLIC_2 = np.zeros([len(Sf[0]), len(Sf[0, 0]), 1]).tolist()
#     for m in range(len(Sf[0])):
#         for n in range(len(Sf[0, 0])):
#             reconstruction_PLIC_2[m][n].append({})
#     for m in range(N_ax_x):
#         for n in range(N_ax_y):
#             O_position = np.array([m * dx, n * dy])
#             sf_center_pos = [m + ghost, n + ghost]
#             sf = get_sf(sf_center_pos, Sf)
#             phase_exist = judge_phase_num(sf)
#             count = len(phase_exist)
#             reconstruction_PLIC_2[m + ghost][n + ghost][1]['phase_num'] = count
#             if count > 1:
#                 normals, d, cells, errors, error = Youngs_2d(sf, dx, dy, tolerance, phase_exist)
#                 reconstruction_PLIC_2[m + ghost][n + ghost][0] = 1
#                 reconstruction_PLIC_2[m + ghost][n + ghost][1]['method'] = 'PLIC'
#                 reconstruction_PLIC_2[m + ghost][n + ghost][1]['cells'] = cells
#                 reconstruction_PLIC_2[m + ghost][n + ghost][1]['normals'] = normals
#                 reconstruction_PLIC_2[m + ghost][n + ghost][1]['ds'] = d
#                 reconstruction_PLIC_2[m + ghost][n + ghost][1]['errors'] = errors
#                 reconstruction_PLIC_2[m + ghost][n + ghost][1]['error'] = error
#             else:
#                 pass
#     time_Grad_PLIC_2 = time.time()
#     time_Grad_PLIC += (time_Grad_PLIC_2 - time_Grad_PLIC_1)
#     for m in range(N_ax_x):
#         for n in range(N_ax_y):
#             O_position = np.array([m * dx, n * dy])
#             sf_center_pos = [m + ghost, n + ghost]
#             sf = get_sf(sf_center_pos, Sf)
#             phase_exist = judge_phase_num(sf)
#             count = len(phase_exist)
#             if count > 1:
#                 cells = reconstruction_PLIC_2[m + ghost][n + ghost][1]['cells']
#                 plot_interface_plic_adv(ax[i, 1], O_position, cells, 2)
#                 if count > 2:
#                     errors = reconstruction_PLIC_2[m + ghost][n + ghost][1]['errors']
#                     # print('Grad-PLIC', errors)
#     print('DP time: ', time_DP, 'Choi time: ', time_PLIC, 'Grad time: ', time_Grad_PLIC)
#     time_[i] = np.array([time_Grad_PLIC, time_PLIC, time_DP])
#     ### true-reconstruction
#     ### DRAW THE CIRCLE
#     circle_true_1 = patches.Circle((cp1[0] - ghost, cp1[1] - ghost), radius=R1, edgecolor='black', facecolor='none',
#                                    linewidth=2)
#     ax[i, 0].add_patch(circle_true_1)
#     circle_true_2 = patches.Circle((cp2[0] - ghost, cp2[1] - ghost), radius=R2, edgecolor='black', facecolor='none',
#                                    linewidth=2)
#     ax[i, 0].add_patch(circle_true_2)
#     ### CALCULATION OF AVERAGED CUMULATIVE SYMMETRIC-DIFFERENCE ERROR USING THE MONTE CAROL METHOD
#     csde_total_DP, csde_total_Choi, csde_total_Grad, csde_count = get_acsde_circle2_mp(
#         cp1, R1, cp2, R2, dx, dy, nx, ny, ghost, reconstruction_PLIC_2, reconstruction_PLIC, reconstruction, resolution,
#         num_p)
#     cons_DP = np.zeros([3])
#     cons_Choi = np.zeros([3])
#     cons_Grad = np.zeros([3])
#     for m in range(nx - 2 * ghost):
#         for n in range(ny - 2 * ghost):
#             phase_num = reconstruction[m + ghost][n + ghost][1]['phase_num']
#             if phase_num > 1:
#                 ### CONSERVATION ERROR
#                 ### DP
#                 errors_DP = reconstruction[m + ghost][n + ghost][1]['errors']
#                 cons_DP = cons_DP + errors_DP
#                 ### Choi
#                 errors_Choi = reconstruction_PLIC[m + ghost][n + ghost][1]['errors']
#                 cons_Choi = cons_Choi + errors_Choi
#                 ### Grad
#                 errors_Grad = reconstruction_PLIC_2[m + ghost][n + ghost][1]['errors']
#                 cons_Grad = cons_Grad + errors_Grad
#             else:
#                 pass
#     avg_csde_DP = csde_total_DP / csde_count
#     avg_csde_Choi = csde_total_Choi / csde_count
#     avg_csde_Grad = csde_total_Grad / csde_count
#     print('DP acsde err: ', avg_csde_DP, 'Choi acsde err: ', avg_csde_Choi, 'Grad acsde err: ', avg_csde_Grad)
#     conservation_error_DP = np.sum(abs(cons_DP))
#     conservation_error_Choi = np.sum(abs(cons_Choi))
#     conservation_error_Grad = np.sum(abs(cons_Grad))
#     print('DP cons: ', conservation_error_DP, 'Choi cons: ', conservation_error_Choi, 'Grad cons: ',
#           conservation_error_Grad)
#     cons[i] = np.array([conservation_error_Grad, conservation_error_Choi, conservation_error_DP])
#     acsde[i] = np.array([avg_csde_Grad, avg_csde_Choi, avg_csde_DP])
# # #
# handles, labels = plt.gca().get_legend_handles_labels()
# by_label = dict(zip(labels, handles))
# ax[0, 3].legend(by_label.values(), by_label.keys(), fontsize="20")
# ### Y LABEL
# ax[0, 0].set_ylabel('(1)', fontsize=40)
# ax[1, 0].set_ylabel('(2)', fontsize=40)
# ax[2, 0].set_ylabel('(3)', fontsize=40)
# ### X LABEL
# ax[0, 0].set_title('(a) true layout', fontsize=40)
# ax[0, 1].set_title('(b) Grad-PLIC', fontsize=40)
# ax[0, 2].set_title('(c) Choi-PLIC', fontsize=40)
# ax[0, 3].set_title('(d) DP-PLIC', fontsize=40)
# fig.subplots_adjust(wspace=5e-2, hspace=5e-2, bottom=5e-2, top=1 - 5e-2, left=5e-2, right=1 - 5e-2)
# plt.savefig('./static_cases/Circle2.png', format='png', dpi=400)
# plt.close()
# #
# print('Summary')
# print('time')
# print('Grad: ', np.average(time_[:, 0]), 'Choi: ', np.average(time_[:, 1]), 'DP: ', np.average(time_[:, 2]))
# print('conservation')
# print('Grad: ', np.average(cons[:, 0]), 'Choi: ', np.average(cons[:, 1]), 'DP: ', np.average(cons[:, 2]))
# print('acsde')
# print('Grad: ', np.average(acsde[:, 0]), 'Choi: ', np.average(acsde[:, 1]), 'DP: ', np.average(acsde[:, 2]))

### JCP_snakes
# nx = 10
# ny = 10
# ghost = 1
# dx = 1.
# dy = 1.
# tolerance = 1e-6
# max_step = 20
# L = [0.4, 0.6]
# resolution = 500
# num_p = 9
# def sin_func(A, omega, phi, x):
#     return A * np.sin(omega * (x - 1.)) + phi
#
# fig, ax = plt.subplots(2, 4, figsize=[25, 13])
# for sub_ax in ax:
#     for subsub_ax in sub_ax:
#         subsub_ax.set_aspect('equal')
#         subsub_ax.grid(linestyle='--')
#         subsub_ax.xaxis.set_major_locator(MultipleLocator(1))
#         subsub_ax.yaxis.set_major_locator(MultipleLocator(1))
#         subsub_ax.set_xticklabels([])
#         subsub_ax.set_yticklabels([])
# ### grad-choi-dp
# time_ = np.zeros([2, 3])
# cons = np.zeros([2, 3])
# acsde = np.zeros([2, 3])
# for i in range(len(L)):
#     print(L[i])
#     A = 2.4
#     omega = 2 * np.pi / ((nx - 2 * ghost) * dx)
#     phi2 = ny * dy * 0.5 - L[i] * dy
#     phi1 = phi2 + 2 * L[i] * dy
#     Sf = snake_mp(A, omega, phi1, phi2, nx, ny, dx, dy, resolution, num_p)
#     N_ax_x = len(Sf[0]) - 2 * ghost
#     N_ax_y = len(Sf[0][0]) - 2 * ghost
#     ax[i, 0].set_xlim([0, dx * N_ax_x])
#     ax[i, 0].set_ylim([0, dx * N_ax_y])
#     ax[i, 1].set_xlim([0, dx * N_ax_x])
#     ax[i, 1].set_ylim([0, dx * N_ax_y])
#     ax[i, 2].set_xlim([0, dx * N_ax_x])
#     ax[i, 2].set_ylim([0, dx * N_ax_y])
#     ax[i, 3].set_xlim([0, dx * N_ax_x])
#     ax[i, 3].set_ylim([0, dx * N_ax_y])
#     ### DP-PLIC
#     time_DP_1 = time.time()
#     reconstruction = DP_PLIC_exact(Sf, dx, dy, tolerance, max_step)
#     time_DP_2 = time.time()
#     time_DP = time_DP_2 - time_DP_1
#     for m in range(N_ax_x):
#         for n in range(N_ax_y):
#             O_position = np.array([m * dx, n * dy])
#             grid_info = reconstruction[m + ghost][n + ghost]
#             if grid_info[0] != 0 and grid_info[1]['method']:
#                 Cells = grid_info[1]['cells']
#                 if grid_info[1]['method'] == 'PLIC':
#                     # print('PLIC')
#                     plot_interface_plic_adv(ax[i, 3], O_position, Cells, 2)
#                 elif grid_info[1]['method'] == 'YOUNGS':
#                     plot_interface_plic_adv(ax[i, 3], O_position, Cells, 2)
#                     errors = grid_info[1]['errors']
#                     # print('YOUNGS', errors)
#                 else:
#                     # print(m,n,Cells)
#                     plot_interface_plic_adv_DP(ax[i, 3], O_position, Cells, 2, dx, dy)
#                     errors = grid_info[1]['errors']
#                     # print('DP', errors)
#             else:
#                 pass
#     ### Choi-PLIC
#     time_PLIC = 0.
#     time_PLIC_1 = time.time()
#     reconstruction_PLIC = np.zeros([len(Sf[0]), len(Sf[0, 0]), 1]).tolist()
#     for m in range(len(Sf[0])):
#         for n in range(len(Sf[0, 0])):
#             reconstruction_PLIC[m][n].append({})
#     for m in range(N_ax_x):
#         for n in range(N_ax_y):
#             O_position = np.array([m * dx, n * dy])
#             sf_center_pos = [m + ghost, n + ghost]
#             sf = get_sf(sf_center_pos, Sf)
#             phase_exist = judge_phase_num(sf)
#             count = len(phase_exist)
#             reconstruction_PLIC[m + ghost][n + ghost][1]['phase_num'] = count
#             if count > 1:
#                 normals, d, cells, errors, error = PLIC_2d_tripleP_GSadv(sf, dx, dy, phase_exist, tolerance)
#                 reconstruction_PLIC[m + ghost][n + ghost][0] = 1
#                 reconstruction_PLIC[m + ghost][n + ghost][1]['method'] = 'PLIC'
#                 reconstruction_PLIC[m + ghost][n + ghost][1]['cells'] = cells
#                 reconstruction_PLIC[m + ghost][n + ghost][1]['normals'] = normals
#                 reconstruction_PLIC[m + ghost][n + ghost][1]['ds'] = d
#                 reconstruction_PLIC[m + ghost][n + ghost][1]['errors'] = errors
#                 reconstruction_PLIC[m + ghost][n + ghost][1]['error'] = error
#                 if error > tolerance * 10:
#                     normals, ds, cells, errors, error = Youngs_2d(sf, dx, dy, tolerance, phase_exist)
#                     reconstruction_PLIC[m + ghost][n + ghost][0] = 1
#                     reconstruction_PLIC[m + ghost][n + ghost][1]['method'] = 'YOUNGS'
#                     reconstruction_PLIC[m + ghost][n + ghost][1]['cells'] = cells
#                     reconstruction_PLIC[m + ghost][n + ghost][1]['normals'] = normals
#                     reconstruction_PLIC[m + ghost][n + ghost][1]['ds'] = ds
#                     reconstruction_PLIC[m + ghost][n + ghost][1]['errors'] = errors
#                     reconstruction_PLIC[m + ghost][n + ghost][1]['error'] = error
#                 else:
#                     pass
#             else:
#                 pass
#     time_PLIC_2 = time.time()
#     time_PLIC += (time_PLIC_2 - time_PLIC_1)
#     for m in range(N_ax_x):
#         for n in range(N_ax_y):
#             O_position = np.array([m * dx, n * dy])
#             sf_center_pos = [m + ghost, n + ghost]
#             sf = get_sf(sf_center_pos, Sf)
#             phase_exist = judge_phase_num(sf)
#             count = len(phase_exist)
#             if count > 1:
#                 cells = reconstruction_PLIC[m + ghost][n + ghost][1]['cells']
#                 plot_interface_plic_adv(ax[i, 2], O_position, cells, 2)
#                 if count > 2:
#                     errors = reconstruction_PLIC[m + ghost][n + ghost][1]['errors']
#                     # print('Choi-PLIC', errors)
#     ### Grad-PLIC
#     time_Grad_PLIC = 0.
#     time_Grad_PLIC_1 = time.time()
#     reconstruction_PLIC_2 = np.zeros([len(Sf[0]), len(Sf[0, 0]), 1]).tolist()
#     for m in range(len(Sf[0])):
#         for n in range(len(Sf[0, 0])):
#             reconstruction_PLIC_2[m][n].append({})
#     for m in range(N_ax_x):
#         for n in range(N_ax_y):
#             O_position = np.array([m * dx, n * dy])
#             sf_center_pos = [m + ghost, n + ghost]
#             sf = get_sf(sf_center_pos, Sf)
#             phase_exist = judge_phase_num(sf)
#             count = len(phase_exist)
#             reconstruction_PLIC_2[m + ghost][n + ghost][1]['phase_num'] = count
#             if count > 1:
#                 normals, d, cells, errors, error = Youngs_2d(sf, dx, dy, tolerance, phase_exist)
#                 reconstruction_PLIC_2[m + ghost][n + ghost][0] = 1
#                 reconstruction_PLIC_2[m + ghost][n + ghost][1]['method'] = 'PLIC'
#                 reconstruction_PLIC_2[m + ghost][n + ghost][1]['cells'] = cells
#                 reconstruction_PLIC_2[m + ghost][n + ghost][1]['normals'] = normals
#                 reconstruction_PLIC_2[m + ghost][n + ghost][1]['ds'] = d
#                 reconstruction_PLIC_2[m + ghost][n + ghost][1]['errors'] = errors
#                 reconstruction_PLIC_2[m + ghost][n + ghost][1]['error'] = error
#             else:
#                 pass
#     time_Grad_PLIC_2 = time.time()
#     time_Grad_PLIC += (time_Grad_PLIC_2 - time_Grad_PLIC_1)
#     for m in range(N_ax_x):
#         for n in range(N_ax_y):
#             O_position = np.array([m * dx, n * dy])
#             sf_center_pos = [m + ghost, n + ghost]
#             sf = get_sf(sf_center_pos, Sf)
#             phase_exist = judge_phase_num(sf)
#             count = len(phase_exist)
#             if count > 1:
#                 cells = reconstruction_PLIC_2[m + ghost][n + ghost][1]['cells']
#                 plot_interface_plic_adv(ax[i, 1], O_position, cells, 2)
#                 if count > 2:
#                     errors = reconstruction_PLIC_2[m + ghost][n + ghost][1]['errors']
#                     # print('Grad-PLIC', errors)
#     print('DP time: ', time_DP, 'Choi time: ', time_PLIC, 'Grad time: ', time_Grad_PLIC)
#     time_[i] = np.array([time_Grad_PLIC, time_PLIC, time_DP])
#     ### true-reconstruction
#     ### DRAW THE SINE FUNCTION
#     x = np.linspace(0., (nx - 2 * ghost) * dx, 1000)
#     y1 = sin_func(A, omega, phi1, x + ghost * dx) - ghost * dx
#     ax[i, 0].plot(x, y1, color='black', linewidth=2)
#     y2 = sin_func(A, omega, phi2, x + ghost * dx) - ghost * dx
#     ax[i, 0].plot(x, y2, color='black', linewidth=2)
#     ### CALCULATION OF AVERAGED CUMULATIVE SYMMETRIC-DIFFERENCE ERROR USING THE MONTE CAROL METHOD
#     csde_total_DP, csde_total_Choi, csde_total_Grad, csde_count = get_acsde_snake_mp(A, omega, phi1, phi2, dx, dy, nx,
#                                                                                      ny, ghost, reconstruction_PLIC_2,
#                                                                                      reconstruction_PLIC,
#                                                                                      reconstruction,
#                                                                                      resolution,
#                                                                                      num_p)
#     cons_DP = np.zeros([3])
#     cons_Choi = np.zeros([3])
#     cons_Grad = np.zeros([3])
#     for m in range(nx - 2 * ghost):
#         for n in range(ny - 2 * ghost):
#             phase_num = reconstruction[m + ghost][n + ghost][1]['phase_num']
#             if phase_num > 1:
#                 ### CONSERVATION ERROR
#                 ### DP
#                 errors_DP = reconstruction[m + ghost][n + ghost][1]['errors']
#                 cons_DP = cons_DP + errors_DP
#                 ### Choi
#                 errors_Choi = reconstruction_PLIC[m + ghost][n + ghost][1]['errors']
#                 cons_Choi = cons_Choi + errors_Choi
#                 ### Grad
#                 errors_Grad = reconstruction_PLIC_2[m + ghost][n + ghost][1]['errors']
#                 cons_Grad = cons_Grad + errors_Grad
#             else:
#                 pass
#     avg_csde_DP = csde_total_DP / csde_count
#     avg_csde_Choi = csde_total_Choi / csde_count
#     avg_csde_Grad = csde_total_Grad / csde_count
#     print('DP acsde err: ', avg_csde_DP, 'Choi acsde err: ', avg_csde_Choi, 'Grad acsde err: ', avg_csde_Grad)
#     conservation_error_DP = np.sum(abs(cons_DP))
#     conservation_error_Choi = np.sum(abs(cons_Choi))
#     conservation_error_Grad = np.sum(abs(cons_Grad))
#     print('DP cons: ', conservation_error_DP, 'Choi cons: ', conservation_error_Choi, 'Grad cons: ',
#           conservation_error_Grad)
#     cons[i] = np.array([conservation_error_Grad, conservation_error_Choi, conservation_error_DP])
#     acsde[i] = np.array([avg_csde_Grad, avg_csde_Choi, avg_csde_DP])
# #
# handles, labels = plt.gca().get_legend_handles_labels()
# by_label = dict(zip(labels, handles))
# ax[0, 3].legend(by_label.values(), by_label.keys(), fontsize="20")
# ### Y LABEL
# ax[0, 0].set_ylabel('(1)', fontsize=40)
# ax[1, 0].set_ylabel('(2)', fontsize=40)
# ### X LABEL
# ax[0, 0].set_title('(a) true layout', fontsize=40)
# ax[0, 1].set_title('(b) Grad-PLIC', fontsize=40)
# ax[0, 2].set_title('(c) Choi-PLIC', fontsize=40)
# ax[0, 3].set_title('(d) DP-PLIC', fontsize=40)
# fig.subplots_adjust(wspace=5e-2, hspace=5e-2, bottom=5e-2, top=1 - 5e-2, left=5e-2, right=1 - 5e-2)
# plt.savefig('./static_cases/Snake.png', format='png', dpi=400)
# plt.close()
#
# print('Summary')
# print('time')
# print('Grad: ', np.average(time_[:, 0]), 'Choi: ', np.average(time_[:, 1]), 'DP: ', np.average(time_[:, 2]))
# print('conservation')
# print('Grad: ', np.average(cons[:, 0]), 'Choi: ', np.average(cons[:, 1]), 'DP: ', np.average(cons[:, 2]))
# print('acsde')
# print('Grad: ', np.average(acsde[:, 0]), 'Choi: ', np.average(acsde[:, 1]), 'DP: ', np.average(acsde[:, 2]))

### JCP_T
# nx = 10
# ny = 10
# ghost = 1
# dx = 1 / (nx - 2 * ghost)
# dy = dx
# tolerance = 1e-6
# max_step = 20
# triple_ini = np.array([3.5 * dx, 3.5 * dy])
# fig, ax = plt.subplots(4, 4, figsize=[25, 25])
# for sub_ax in ax:
#     for subsub_ax in sub_ax:
#         subsub_ax.set_aspect('equal')
#         subsub_ax.grid(linestyle='--')
#         subsub_ax.xaxis.set_major_locator(MultipleLocator(1))
#         subsub_ax.yaxis.set_major_locator(MultipleLocator(1))
#         subsub_ax.set_xticklabels([])
#         subsub_ax.set_yticklabels([])
# L = [0.0, 0.4 * dx, 0.6 * dx, 0.8 * dx]
# ### grad-choi-dp
# time_ = np.zeros([4, 3])
# cons = np.zeros([4, 3])
# acsde = np.zeros([4, 3])
# for i in range(len(L)):
#     triple = triple_ini + np.array([L[i], L[i]])
#     print(triple)
#     Sf_ = T_shape_mp(triple, nx, ny, dx, dy, num_p=1)
#     Sf_ = repair_static(Sf_, ghost, nx, ny, 3, tolerance)
#     Sf = copy.deepcopy(Sf_)
#     N_ax_x = len(Sf[0]) - 2 * ghost
#     N_ax_y = len(Sf[0][0]) - 2 * ghost
#     ax[i, 0].set_xlim([0, dx * N_ax_x])
#     ax[i, 0].set_ylim([0, dx * N_ax_y])
#     ax[i, 1].set_xlim([0, dx * N_ax_x])
#     ax[i, 1].set_ylim([0, dx * N_ax_y])
#     ax[i, 2].set_xlim([0, dx * N_ax_x])
#     ax[i, 2].set_ylim([0, dx * N_ax_y])
#     ax[i, 3].set_xlim([0, dx * N_ax_x])
#     ax[i, 3].set_ylim([0, dx * N_ax_y])
#     ### DP-PLIC
#     time_DP_1 = time.time()
#     reconstruction = DP_PLIC_exact(Sf, dx, dy, tolerance, max_step)
#     time_DP_2 = time.time()
#     time_DP = time_DP_2 - time_DP_1
#     for m in range(N_ax_x):
#         for n in range(N_ax_y):
#             O_position = np.array([m * dx, n * dy])
#             grid_info = reconstruction[m + ghost][n + ghost]
#             if grid_info[0] != 0 and grid_info[1]['method']:
#                 Cells = grid_info[1]['cells']
#                 if grid_info[1]['method'] == 'PLIC':
#                     # print('PLIC')
#                     plot_interface_plic_adv(ax[i, 3], O_position, Cells, 2)
#                 elif grid_info[1]['method'] == 'YOUNGS':
#                     plot_interface_plic_adv(ax[i, 3], O_position, Cells, 2)
#                     errors = grid_info[1]['errors']
#                     # print('YOUNGS', errors)
#                 else:
#                     # print(m,n,Cells)
#                     plot_interface_plic_adv_DP(ax[i, 3], O_position, Cells, 2, dx, dy)
#                     errors = grid_info[1]['errors']
#                     # print('DP', errors)
#             else:
#                 pass
#     ### Choi-PLIC
#     time_PLIC = 0.
#     time_PLIC_1 = time.time()
#     reconstruction_PLIC = np.zeros([len(Sf[0]), len(Sf[0, 0]), 1]).tolist()
#     for m in range(len(Sf[0])):
#         for n in range(len(Sf[0, 0])):
#             reconstruction_PLIC[m][n].append({})
#     for m in range(N_ax_x):
#         for n in range(N_ax_y):
#             O_position = np.array([m * dx, n * dy])
#             sf_center_pos = [m + ghost, n + ghost]
#             sf = get_sf(sf_center_pos, Sf)
#             phase_exist = judge_phase_num(sf)
#             count = len(phase_exist)
#             reconstruction_PLIC[m + ghost][n + ghost][1]['phase_num'] = count
#             if count > 1:
#                 normals, d, cells, errors, error = PLIC_2d_tripleP_GSadv(sf, dx, dy, phase_exist, tolerance)
#                 reconstruction_PLIC[m + ghost][n + ghost][0] = 1
#                 reconstruction_PLIC[m + ghost][n + ghost][1]['method'] = 'PLIC'
#                 reconstruction_PLIC[m + ghost][n + ghost][1]['cells'] = cells
#                 reconstruction_PLIC[m + ghost][n + ghost][1]['normals'] = normals
#                 reconstruction_PLIC[m + ghost][n + ghost][1]['ds'] = d
#                 reconstruction_PLIC[m + ghost][n + ghost][1]['errors'] = errors
#                 reconstruction_PLIC[m + ghost][n + ghost][1]['error'] = error
#             else:
#                 pass
#     time_PLIC_2 = time.time()
#     time_PLIC += (time_PLIC_2 - time_PLIC_1)
#     for m in range(N_ax_x):
#         for n in range(N_ax_y):
#             O_position = np.array([m * dx, n * dy])
#             sf_center_pos = [m + ghost, n + ghost]
#             sf = get_sf(sf_center_pos, Sf)
#             phase_exist = judge_phase_num(sf)
#             count = len(phase_exist)
#             if count > 1:
#                 cells = reconstruction_PLIC[m + ghost][n + ghost][1]['cells']
#                 plot_interface_plic_adv(ax[i, 2], O_position, cells, 2)
#                 if count > 2:
#                     errors = reconstruction_PLIC[m + ghost][n + ghost][1]['errors']
#                     # print('Choi-PLIC', errors)
#     ### Grad-PLIC
#     time_Grad_PLIC = 0.
#     time_Grad_PLIC_1 = time.time()
#     reconstruction_PLIC_2 = np.zeros([len(Sf[0]), len(Sf[0, 0]), 1]).tolist()
#     for m in range(len(Sf[0])):
#         for n in range(len(Sf[0, 0])):
#             reconstruction_PLIC_2[m][n].append({})
#     for m in range(N_ax_x):
#         for n in range(N_ax_y):
#             O_position = np.array([m * dx, n * dy])
#             sf_center_pos = [m + ghost, n + ghost]
#             sf = get_sf(sf_center_pos, Sf)
#             phase_exist = judge_phase_num(sf)
#             count = len(phase_exist)
#             reconstruction_PLIC_2[m + ghost][n + ghost][1]['phase_num'] = count
#             if count > 1:
#                 normals, d, cells, errors, error = Youngs_2d(sf, dx, dy, tolerance, phase_exist)
#                 reconstruction_PLIC_2[m + ghost][n + ghost][0] = 1
#                 reconstruction_PLIC_2[m + ghost][n + ghost][1]['method'] = 'PLIC'
#                 reconstruction_PLIC_2[m + ghost][n + ghost][1]['cells'] = cells
#                 reconstruction_PLIC_2[m + ghost][n + ghost][1]['normals'] = normals
#                 reconstruction_PLIC_2[m + ghost][n + ghost][1]['ds'] = d
#                 reconstruction_PLIC_2[m + ghost][n + ghost][1]['errors'] = errors
#                 reconstruction_PLIC_2[m + ghost][n + ghost][1]['error'] = error
#             else:
#                 pass
#     time_Grad_PLIC_2 = time.time()
#     time_Grad_PLIC += (time_Grad_PLIC_2 - time_Grad_PLIC_1)
#     for m in range(N_ax_x):
#         for n in range(N_ax_y):
#             O_position = np.array([m * dx, n * dy])
#             sf_center_pos = [m + ghost, n + ghost]
#             sf = get_sf(sf_center_pos, Sf)
#             phase_exist = judge_phase_num(sf)
#             count = len(phase_exist)
#             if count > 1:
#                 cells = reconstruction_PLIC_2[m + ghost][n + ghost][1]['cells']
#                 plot_interface_plic_adv(ax[i, 1], O_position, cells, 2)
#                 if count > 2:
#                     errors = reconstruction_PLIC_2[m + ghost][n + ghost][1]['errors']
#                     # print('Grad-PLIC', errors)
#     print('DP time: ', time_DP, 'Choi time: ', time_PLIC, 'Grad time: ', time_Grad_PLIC)
#     time_[i] = np.array([time_Grad_PLIC, time_PLIC, time_DP])
#     ### true-reconstruction
#     reconstruction_true = true_reconstruction_T_shape(triple, nx, ny, dx, dy, ghost)
#     # print(reconstruction_true)
#     for m in range(N_ax_x):
#         for n in range(N_ax_y):
#             O_position = np.array([m * dx, n * dy])
#             cells = reconstruction_true[m + ghost][n + ghost][1]['cells']
#             if len(cells) > 1:
#                 plot_interface_plic_adv(ax[i, 0], O_position, cells, 2, dx, dy)
#             else:
#                 pass
#     ### CALCULATION OF AVERAGED CUMULATIVE SYMMETRIC-DIFFERENCE ERROR
#     csde_total_DP = 0.
#     csde_total_Choi = 0.
#     csde_total_Grad = 0.
#     cons_DP = np.zeros([3])
#     cons_Choi = np.zeros([3])
#     cons_Grad = np.zeros([3])
#     csde_count = 0
#     for m in range(nx - 2 * ghost):
#         for n in range(ny - 2 * ghost):
#             phase_num = reconstruction[m + ghost][n + ghost][1]['phase_num']
#             if phase_num > 1:
#                 ### AVERAGED CUMULATIVE SYMMETRIC-DIFFERENCE ERROR
#                 csde_count = csde_count + 1
#                 true_cells = reconstruction_true[m + ghost][n + ghost][1]['cells']
#                 ### DP
#                 DP_cells = reconstruction[m + ghost][n + ghost][1]['cells']
#                 DP_csde_err = get_cumulative_symmetric_difference_error(true_cells, DP_cells)
#                 csde_total_DP += DP_csde_err
#                 ### Choi
#                 Choi_cells = reconstruction_PLIC[m + ghost][n + ghost][1]['cells']
#                 Choi_csde_err = get_cumulative_symmetric_difference_error(true_cells, Choi_cells)
#                 csde_total_Choi += Choi_csde_err
#                 ### Grad
#                 Grad_cells = reconstruction_PLIC_2[m + ghost][n + ghost][1]['cells']
#                 Grad_csde_err = get_cumulative_symmetric_difference_error(true_cells, Grad_cells)
#                 csde_total_Grad += Grad_csde_err
#
#                 ### CONSERVATION ERROR
#                 ### DP
#                 errors_DP = reconstruction[m + ghost][n + ghost][1]['errors']
#                 cons_DP = cons_DP + errors_DP
#                 ### Choi
#                 errors_Choi = reconstruction_PLIC[m + ghost][n + ghost][1]['errors']
#                 cons_Choi = cons_Choi + errors_Choi
#                 ### Grad
#                 errors_Grad = reconstruction_PLIC_2[m + ghost][n + ghost][1]['errors']
#                 cons_Grad = cons_Grad + errors_Grad
#             else:
#                 pass
#     avg_csde_DP = csde_total_DP / csde_count
#     avg_csde_Choi = csde_total_Choi / csde_count
#     avg_csde_Grad = csde_total_Grad / csde_count
#     print('DP acsde err: ', avg_csde_DP, 'Choi acsde err: ', avg_csde_Choi, 'Grad acsde err: ', avg_csde_Grad)
#     conservation_error_DP = np.sum(abs(cons_DP))
#     conservation_error_Choi = np.sum(abs(cons_Choi))
#     conservation_error_Grad = np.sum(abs(cons_Grad))
#     print('DP cons: ', conservation_error_DP, 'Choi cons: ', conservation_error_Choi, 'Grad cons: ', conservation_error_Grad)
#     cons[i] = np.array([conservation_error_Grad, conservation_error_Choi, conservation_error_DP])
#     acsde[i] = np.array([avg_csde_Grad, avg_csde_Choi, avg_csde_DP])
#
# handles, labels = plt.gca().get_legend_handles_labels()
# by_label = dict(zip(labels, handles))
# ax[0, len(L) - 1].legend(by_label.values(), by_label.keys(), fontsize="20")
# ### Y LABEL
# ax[0, 0].set_ylabel('(1)', fontsize=40)
# ax[1, 0].set_ylabel('(2)', fontsize=40)
# ax[2, 0].set_ylabel('(3)', fontsize=40)
# ax[3, 0].set_ylabel('(4)', fontsize=40)
# ### X LABEL
# ax[0, 0].set_title('(a) true layout', fontsize=40)
# ax[0, 1].set_title('(b) Grad-PLIC', fontsize=40)
# ax[0, 2].set_title('(c) Choi-PLIC', fontsize=40)
# ax[0, 3].set_title('(d) DP-PLIC', fontsize=40)
# fig.subplots_adjust(wspace=5e-2, hspace=5e-2, bottom=5e-2, top=1 - 5e-2, left=5e-2, right=1 - 5e-2)
# # plt.savefig('./static_cases/T.png', format='png', dpi=400)
# plt.close()
#
# print('Summary')
# print('time')
# print('Grad: ', np.average(time_[:, 0]), 'Choi: ', np.average(time_[:, 1]), 'DP: ', np.average(time_[:, 2]))
# print('conservation')
# print('Grad: ', np.average(cons[:, 0]), 'Choi: ', np.average(cons[:, 1]), 'DP: ', np.average(cons[:, 2]))
# print('acsde')
# print('Grad: ', np.average(acsde[:, 0]), 'Choi: ', np.average(acsde[:, 1]), 'DP: ', np.average(acsde[:, 2]))

# ## JCP_Y
# nx = 10
# ny = 10
# ghost = 1
# dx = 1.
# dy = 1.
# tolerance = 1e-6
# max_step = 20
# angle = 0
# triple_ini = np.array([3.3, 3.5])
# fig, ax = plt.subplots(4, 4, figsize=[25, 25])
# for sub_ax in ax:
#     for subsub_ax in sub_ax:
#         subsub_ax.set_aspect('equal')
#         subsub_ax.grid(linestyle='--')
#         subsub_ax.xaxis.set_major_locator(MultipleLocator(1))
#         subsub_ax.yaxis.set_major_locator(MultipleLocator(1))
#         subsub_ax.set_xticklabels([])
#         subsub_ax.set_yticklabels([])
# L = [0.0, 0.2, 0.4, 0.6]
# ### grad-choi-dp
# time_ = np.zeros([4, 3])
# cons = np.zeros([4, 3])
# acsde = np.zeros([4, 3])
# for i in range(len(L)):
#     triple = triple_ini + np.array([L[i], 0.])
#     Sf_ = Y_shape_exact(triple, angle, nx, ny, dx, dy)
#     Sf_ = repair_static(Sf_, ghost, nx, ny, 3, tolerance)
#     Sf = copy.deepcopy(Sf_)
#     N_ax_x = len(Sf[0]) - 2 * ghost
#     N_ax_y = len(Sf[0][0]) - 2 * ghost
#     ax[i, 0].set_xlim([0, dx * N_ax_x])
#     ax[i, 0].set_ylim([0, dx * N_ax_y])
#     ax[i, 1].set_xlim([0, dx * N_ax_x])
#     ax[i, 1].set_ylim([0, dx * N_ax_y])
#     ax[i, 2].set_xlim([0, dx * N_ax_x])
#     ax[i, 2].set_ylim([0, dx * N_ax_y])
#     ax[i, 3].set_xlim([0, dx * N_ax_x])
#     ax[i, 3].set_ylim([0, dx * N_ax_y])
#     ### DP-PLIC
#     time_DP_1 = time.time()
#     reconstruction = DP_PLIC_exact(Sf, dx, dy, tolerance, max_step)
#     time_DP_2 = time.time()
#     time_DP = time_DP_2 - time_DP_1
#     for m in range(N_ax_x):
#         for n in range(N_ax_y):
#             O_position = np.array([m * dx, n * dy])
#             grid_info = reconstruction[m + ghost][n + ghost]
#             if grid_info[0] != 0 and grid_info[1]['method']:
#                 Cells = grid_info[1]['cells']
#                 if grid_info[1]['method'] == 'PLIC':
#                     # print('PLIC')
#                     plot_interface_plic_adv(ax[i, 3], O_position, Cells, 2)
#                 elif grid_info[1]['method'] == 'YOUNGS':
#                     plot_interface_plic_adv(ax[i, 3], O_position, Cells, 2)
#                     errors = grid_info[1]['errors']
#                     # print('YOUNGS', errors)
#                 else:
#                     # print(m,n,Cells)
#                     plot_interface_plic_adv_DP(ax[i, 3], O_position, Cells, 2, dx, dy)
#                     errors = grid_info[1]['errors']
#                     # print('DP', errors)
#             else:
#                 pass
#     ### Choi-PLIC
#     time_PLIC = 0.
#     time_PLIC_1 = time.time()
#     reconstruction_PLIC = np.zeros([len(Sf[0]), len(Sf[0, 0]), 1]).tolist()
#     for m in range(len(Sf[0])):
#         for n in range(len(Sf[0, 0])):
#             reconstruction_PLIC[m][n].append({})
#     for m in range(N_ax_x):
#         for n in range(N_ax_y):
#             O_position = np.array([m * dx, n * dy])
#             sf_center_pos = [m + ghost, n + ghost]
#             sf = get_sf(sf_center_pos, Sf)
#             phase_exist = judge_phase_num(sf)
#             count = len(phase_exist)
#             reconstruction_PLIC[m + ghost][n + ghost][1]['phase_num'] = count
#             if count > 1:
#                 normals, d, cells, errors, error = PLIC_2d_tripleP_GSadv(sf, dx, dy, phase_exist, tolerance)
#                 reconstruction_PLIC[m + ghost][n + ghost][0] = 1
#                 reconstruction_PLIC[m + ghost][n + ghost][1]['method'] = 'PLIC'
#                 reconstruction_PLIC[m + ghost][n + ghost][1]['cells'] = cells
#                 reconstruction_PLIC[m + ghost][n + ghost][1]['normals'] = normals
#                 reconstruction_PLIC[m + ghost][n + ghost][1]['ds'] = d
#                 reconstruction_PLIC[m + ghost][n + ghost][1]['errors'] = errors
#                 reconstruction_PLIC[m + ghost][n + ghost][1]['error'] = error
#                 if error > tolerance * 10:
#                     normals, ds, cells, errors, error = Youngs_2d(sf, dx, dy, tolerance, phase_exist)
#                     reconstruction_PLIC[m + ghost][n + ghost][0] = 1
#                     reconstruction_PLIC[m + ghost][n + ghost][1]['method'] = 'YOUNGS'
#                     reconstruction_PLIC[m + ghost][n + ghost][1]['cells'] = cells
#                     reconstruction_PLIC[m + ghost][n + ghost][1]['normals'] = normals
#                     reconstruction_PLIC[m + ghost][n + ghost][1]['ds'] = ds
#                     reconstruction_PLIC[m + ghost][n + ghost][1]['errors'] = errors
#                     reconstruction_PLIC[m + ghost][n + ghost][1]['error'] = error
#                 else:
#                     pass
#             else:
#                 pass
#     time_PLIC_2 = time.time()
#     time_PLIC += (time_PLIC_2 - time_PLIC_1)
#     for m in range(N_ax_x):
#         for n in range(N_ax_y):
#             O_position = np.array([m * dx, n * dy])
#             sf_center_pos = [m + ghost, n + ghost]
#             sf = get_sf(sf_center_pos, Sf)
#             phase_exist = judge_phase_num(sf)
#             count = len(phase_exist)
#             if count > 1:
#                 cells = reconstruction_PLIC[m + ghost][n + ghost][1]['cells']
#                 plot_interface_plic_adv(ax[i, 2], O_position, cells, 2)
#                 if count > 2:
#                     errors = reconstruction_PLIC[m + ghost][n + ghost][1]['errors']
#                     # print('Choi-PLIC', errors)
#     ### Grad-PLIC
#     time_Grad_PLIC = 0.
#     time_Grad_PLIC_1 = time.time()
#     reconstruction_PLIC_2 = np.zeros([len(Sf[0]), len(Sf[0, 0]), 1]).tolist()
#     for m in range(len(Sf[0])):
#         for n in range(len(Sf[0, 0])):
#             reconstruction_PLIC_2[m][n].append({})
#     for m in range(N_ax_x):
#         for n in range(N_ax_y):
#             O_position = np.array([m * dx, n * dy])
#             sf_center_pos = [m + ghost, n + ghost]
#             sf = get_sf(sf_center_pos, Sf)
#             phase_exist = judge_phase_num(sf)
#             count = len(phase_exist)
#             reconstruction_PLIC_2[m + ghost][n + ghost][1]['phase_num'] = count
#             if count > 1:
#                 normals, d, cells, errors, error = Youngs_2d(sf, dx, dy, tolerance, phase_exist)
#                 reconstruction_PLIC_2[m + ghost][n + ghost][0] = 1
#                 reconstruction_PLIC_2[m + ghost][n + ghost][1]['method'] = 'PLIC'
#                 reconstruction_PLIC_2[m + ghost][n + ghost][1]['cells'] = cells
#                 reconstruction_PLIC_2[m + ghost][n + ghost][1]['normals'] = normals
#                 reconstruction_PLIC_2[m + ghost][n + ghost][1]['ds'] = d
#                 reconstruction_PLIC_2[m + ghost][n + ghost][1]['errors'] = errors
#                 reconstruction_PLIC_2[m + ghost][n + ghost][1]['error'] = error
#             else:
#                 pass
#     time_Grad_PLIC_2 = time.time()
#     time_Grad_PLIC += (time_Grad_PLIC_2 - time_Grad_PLIC_1)
#     for m in range(N_ax_x):
#         for n in range(N_ax_y):
#             O_position = np.array([m * dx, n * dy])
#             sf_center_pos = [m + ghost, n + ghost]
#             sf = get_sf(sf_center_pos, Sf)
#             phase_exist = judge_phase_num(sf)
#             count = len(phase_exist)
#             if count > 1:
#                 cells = reconstruction_PLIC_2[m + ghost][n + ghost][1]['cells']
#                 plot_interface_plic_adv(ax[i, 1], O_position, cells, 2)
#                 if count > 2:
#                     errors = reconstruction_PLIC_2[m + ghost][n + ghost][1]['errors']
#                     # print('Grad-PLIC', errors)
#     print('DP time: ', time_DP, 'Choi time: ', time_PLIC, 'Grad time: ', time_Grad_PLIC)
#     time_[i] = np.array([time_Grad_PLIC, time_PLIC, time_DP])
#     ### true-reconstruction
#     reconstruction_true = true_reconstruction_Y_shape(triple, angle, nx, ny, dx, dy, ghost)
#     # print(reconstruction_true)
#     for m in range(N_ax_x):
#         for n in range(N_ax_y):
#             O_position = np.array([m * dx, n * dy])
#             cells = reconstruction_true[m + ghost][n + ghost][1]['cells']
#             if len(cells) > 1:
#                 plot_interface_plic_adv(ax[i, 0], O_position, cells, 2, dx, dy)
#             else:
#                 pass
#     ### CALCULATION OF AVERAGED CUMULATIVE SYMMETRIC-DIFFERENCE ERROR
#     csde_total_DP = 0.
#     csde_total_Choi = 0.
#     csde_total_Grad = 0.
#     cons_DP = np.zeros([3])
#     cons_Choi = np.zeros([3])
#     cons_Grad = np.zeros([3])
#     csde_count = 0
#     for m in range(nx - 2 * ghost):
#         for n in range(ny - 2 * ghost):
#             phase_num = reconstruction[m + ghost][n + ghost][1]['phase_num']
#             if phase_num > 1:
#                 ### AVERAGED CUMULATIVE SYMMETRIC-DIFFERENCE ERROR
#                 csde_count = csde_count + 1
#                 true_cells = reconstruction_true[m + ghost][n + ghost][1]['cells']
#                 ### DP
#                 DP_cells = reconstruction[m + ghost][n + ghost][1]['cells']
#                 DP_csde_err = get_cumulative_symmetric_difference_error(true_cells, DP_cells)
#                 csde_total_DP += DP_csde_err
#                 ### Choi
#                 Choi_cells = reconstruction_PLIC[m + ghost][n + ghost][1]['cells']
#                 Choi_csde_err = get_cumulative_symmetric_difference_error(true_cells, Choi_cells)
#                 csde_total_Choi += Choi_csde_err
#                 ### Grad
#                 Grad_cells = reconstruction_PLIC_2[m + ghost][n + ghost][1]['cells']
#                 Grad_csde_err = get_cumulative_symmetric_difference_error(true_cells, Grad_cells)
#                 csde_total_Grad += Grad_csde_err
#
#                 ### CONSERVATION ERROR
#                 ### DP
#                 errors_DP = reconstruction[m + ghost][n + ghost][1]['errors']
#                 cons_DP = cons_DP + errors_DP
#                 ### Choi
#                 errors_Choi = reconstruction_PLIC[m + ghost][n + ghost][1]['errors']
#                 cons_Choi = cons_Choi + errors_Choi
#                 ### Grad
#                 errors_Grad = reconstruction_PLIC_2[m + ghost][n + ghost][1]['errors']
#                 cons_Grad = cons_Grad + errors_Grad
#             else:
#                 pass
#     avg_csde_DP = csde_total_DP / csde_count
#     avg_csde_Choi = csde_total_Choi / csde_count
#     avg_csde_Grad = csde_total_Grad / csde_count
#     print('DP acsde err: ', avg_csde_DP, 'Choi acsde err: ', avg_csde_Choi, 'Grad acsde err: ', avg_csde_Grad)
#     conservation_error_DP = np.sum(abs(cons_DP))
#     conservation_error_Choi = np.sum(abs(cons_Choi))
#     conservation_error_Grad = np.sum(abs(cons_Grad))
#     print('DP cons: ', conservation_error_DP, 'Choi cons: ', conservation_error_Choi, 'Grad cons: ',
#           conservation_error_Grad)
#     cons[i] = np.array([conservation_error_Grad, conservation_error_Choi, conservation_error_DP])
#     acsde[i] = np.array([avg_csde_Grad, avg_csde_Choi, avg_csde_DP])
#
# handles, labels = plt.gca().get_legend_handles_labels()
# by_label = dict(zip(labels, handles))
# ax[0, len(L) - 1].legend(by_label.values(), by_label.keys(), fontsize="20")
# ### Y LABEL
# ax[0, 0].set_ylabel('(1)', fontsize=40)
# ax[1, 0].set_ylabel('(2)', fontsize=40)
# ax[2, 0].set_ylabel('(3)', fontsize=40)
# ax[3, 0].set_ylabel('(4)', fontsize=40)
# ### X LABEL
# ax[0, 0].set_title('(a) true layout', fontsize=40)
# ax[0, 1].set_title('(b) Grad-PLIC', fontsize=40)
# ax[0, 2].set_title('(c) Choi-PLIC', fontsize=40)
# ax[0, 3].set_title('(d) DP-PLIC', fontsize=40)
# fig.subplots_adjust(wspace=5e-2, hspace=5e-2, bottom=5e-2, top=1 - 5e-2, left=5e-2, right=1 - 5e-2)
# plt.savefig('./static_cases/Y1.png', format='png', dpi=400)
# plt.close()
#
# print('Summary')
# print('time')
# print('Grad: ', np.average(time_[:, 0]), 'Choi: ', np.average(time_[:, 1]), 'DP: ', np.average(time_[:, 2]))
# print('conservation')
# print('Grad: ', np.average(cons[:, 0]), 'Choi: ', np.average(cons[:, 1]), 'DP: ', np.average(cons[:, 2]))
# print('acsde')
# print('Grad: ', np.average(acsde[:, 0]), 'Choi: ', np.average(acsde[:, 1]), 'DP: ', np.average(acsde[:, 2]))

# ### JCP_Y_rotation
# nx = 10
# ny = 10
# ghost = 1
# dx = 1.
# dy = 1.
# tolerance = 1e-6
# max_step = 20
# angle = 0
# triple_ini = np.array([3.5, 3.5])
# fig, ax = plt.subplots(4, 4, figsize=[25, 25])
# for sub_ax in ax:
#     for subsub_ax in sub_ax:
#         subsub_ax.set_aspect('equal')
#         subsub_ax.grid(linestyle='--')
#         subsub_ax.xaxis.set_major_locator(MultipleLocator(1))
#         subsub_ax.yaxis.set_major_locator(MultipleLocator(1))
#         subsub_ax.set_xticklabels([])
#         subsub_ax.set_yticklabels([])
# L = [0., (10./180.) * np.pi, (30./180.) * np.pi, (60./180.) * np.pi]
# ### grad-choi-dp
# time_ = np.zeros([4, 3])
# cons = np.zeros([4, 3])
# acsde = np.zeros([4, 3])
# for i in range(len(L)):
#     print(L[i])
#     triple = triple_ini
#     angle = 0. + L[i]
#     Sf_ = Y_shape_exact(triple, angle, nx, ny, dx, dy)
#     Sf_ = repair_static(Sf_, ghost, nx, ny, 3, tolerance)
#     Sf = copy.deepcopy(Sf_)
#     N_ax_x = len(Sf[0]) - 2 * ghost
#     N_ax_y = len(Sf[0][0]) - 2 * ghost
#     ax[i, 0].set_xlim([0, dx * N_ax_x])
#     ax[i, 0].set_ylim([0, dx * N_ax_y])
#     ax[i, 1].set_xlim([0, dx * N_ax_x])
#     ax[i, 1].set_ylim([0, dx * N_ax_y])
#     ax[i, 2].set_xlim([0, dx * N_ax_x])
#     ax[i, 2].set_ylim([0, dx * N_ax_y])
#     ax[i, 3].set_xlim([0, dx * N_ax_x])
#     ax[i, 3].set_ylim([0, dx * N_ax_y])
#     ### DP-PLIC
#     time_DP_1 = time.time()
#     reconstruction = DP_PLIC_exact(Sf, dx, dy, tolerance, max_step)
#     time_DP_2 = time.time()
#     time_DP = time_DP_2 - time_DP_1
#     for m in range(N_ax_x):
#         for n in range(N_ax_y):
#             O_position = np.array([m * dx, n * dy])
#             grid_info = reconstruction[m + ghost][n + ghost]
#             if grid_info[0] != 0 and grid_info[1]['method']:
#                 Cells = grid_info[1]['cells']
#                 if grid_info[1]['method'] == 'PLIC':
#                     # print('PLIC')
#                     plot_interface_plic_adv(ax[i, 3], O_position, Cells, 2)
#                 elif grid_info[1]['method'] == 'YOUNGS':
#                     plot_interface_plic_adv(ax[i, 3], O_position, Cells, 2)
#                     errors = grid_info[1]['errors']
#                     # print('YOUNGS', errors)
#                 else:
#                     # print(m,n,Cells)
#                     plot_interface_plic_adv_DP(ax[i, 3], O_position, Cells, 2, dx, dy)
#                     errors = grid_info[1]['errors']
#                     # print('DP', errors)
#             else:
#                 pass
#     ### Choi-PLIC
#     time_PLIC = 0.
#     time_PLIC_1 = time.time()
#     reconstruction_PLIC = np.zeros([len(Sf[0]), len(Sf[0, 0]), 1]).tolist()
#     for m in range(len(Sf[0])):
#         for n in range(len(Sf[0, 0])):
#             reconstruction_PLIC[m][n].append({})
#     for m in range(N_ax_x):
#         for n in range(N_ax_y):
#             O_position = np.array([m * dx, n * dy])
#             sf_center_pos = [m + ghost, n + ghost]
#             sf = get_sf(sf_center_pos, Sf)
#             phase_exist = judge_phase_num(sf)
#             count = len(phase_exist)
#             reconstruction_PLIC[m + ghost][n + ghost][1]['phase_num'] = count
#             if count > 1:
#                 normals, d, cells, errors, error = PLIC_2d_tripleP_GSadv(sf, dx, dy, phase_exist, tolerance)
#                 reconstruction_PLIC[m + ghost][n + ghost][0] = 1
#                 reconstruction_PLIC[m + ghost][n + ghost][1]['method'] = 'PLIC'
#                 reconstruction_PLIC[m + ghost][n + ghost][1]['cells'] = cells
#                 reconstruction_PLIC[m + ghost][n + ghost][1]['normals'] = normals
#                 reconstruction_PLIC[m + ghost][n + ghost][1]['ds'] = d
#                 reconstruction_PLIC[m + ghost][n + ghost][1]['errors'] = errors
#                 reconstruction_PLIC[m + ghost][n + ghost][1]['error'] = error
#                 if error > tolerance * 10:
#                     normals, ds, cells, errors, error = Youngs_2d(sf, dx, dy, tolerance, phase_exist)
#                     reconstruction_PLIC[m + ghost][n + ghost][0] = 1
#                     reconstruction_PLIC[m + ghost][n + ghost][1]['method'] = 'YOUNGS'
#                     reconstruction_PLIC[m + ghost][n + ghost][1]['cells'] = cells
#                     reconstruction_PLIC[m + ghost][n + ghost][1]['normals'] = normals
#                     reconstruction_PLIC[m + ghost][n + ghost][1]['ds'] = ds
#                     reconstruction_PLIC[m + ghost][n + ghost][1]['errors'] = errors
#                     reconstruction_PLIC[m + ghost][n + ghost][1]['error'] = error
#                 else:
#                     pass
#             else:
#                 pass
#     time_PLIC_2 = time.time()
#     time_PLIC += (time_PLIC_2 - time_PLIC_1)
#     for m in range(N_ax_x):
#         for n in range(N_ax_y):
#             O_position = np.array([m * dx, n * dy])
#             sf_center_pos = [m + ghost, n + ghost]
#             sf = get_sf(sf_center_pos, Sf)
#             phase_exist = judge_phase_num(sf)
#             count = len(phase_exist)
#             if count > 1:
#                 cells = reconstruction_PLIC[m + ghost][n + ghost][1]['cells']
#                 plot_interface_plic_adv(ax[i, 2], O_position, cells, 2)
#                 if count > 2:
#                     errors = reconstruction_PLIC[m + ghost][n + ghost][1]['errors']
#                     # print('Choi-PLIC', errors)
#     ### Grad-PLIC
#     time_Grad_PLIC = 0.
#     time_Grad_PLIC_1 = time.time()
#     reconstruction_PLIC_2 = np.zeros([len(Sf[0]), len(Sf[0, 0]), 1]).tolist()
#     for m in range(len(Sf[0])):
#         for n in range(len(Sf[0, 0])):
#             reconstruction_PLIC_2[m][n].append({})
#     for m in range(N_ax_x):
#         for n in range(N_ax_y):
#             O_position = np.array([m * dx, n * dy])
#             sf_center_pos = [m + ghost, n + ghost]
#             sf = get_sf(sf_center_pos, Sf)
#             phase_exist = judge_phase_num(sf)
#             count = len(phase_exist)
#             reconstruction_PLIC_2[m + ghost][n + ghost][1]['phase_num'] = count
#             if count > 1:
#                 normals, d, cells, errors, error = Youngs_2d(sf, dx, dy, tolerance, phase_exist)
#                 reconstruction_PLIC_2[m + ghost][n + ghost][0] = 1
#                 reconstruction_PLIC_2[m + ghost][n + ghost][1]['method'] = 'PLIC'
#                 reconstruction_PLIC_2[m + ghost][n + ghost][1]['cells'] = cells
#                 reconstruction_PLIC_2[m + ghost][n + ghost][1]['normals'] = normals
#                 reconstruction_PLIC_2[m + ghost][n + ghost][1]['ds'] = d
#                 reconstruction_PLIC_2[m + ghost][n + ghost][1]['errors'] = errors
#                 reconstruction_PLIC_2[m + ghost][n + ghost][1]['error'] = error
#             else:
#                 pass
#     time_Grad_PLIC_2 = time.time()
#     time_Grad_PLIC += (time_Grad_PLIC_2 - time_Grad_PLIC_1)
#     for m in range(N_ax_x):
#         for n in range(N_ax_y):
#             O_position = np.array([m * dx, n * dy])
#             sf_center_pos = [m + ghost, n + ghost]
#             sf = get_sf(sf_center_pos, Sf)
#             phase_exist = judge_phase_num(sf)
#             count = len(phase_exist)
#             if count > 1:
#                 cells = reconstruction_PLIC_2[m + ghost][n + ghost][1]['cells']
#                 plot_interface_plic_adv(ax[i, 1], O_position, cells, 2)
#                 if count > 2:
#                     errors = reconstruction_PLIC_2[m + ghost][n + ghost][1]['errors']
#                     # print('Grad-PLIC', errors)
#     print('DP time: ', time_DP, 'Choi time: ', time_PLIC, 'Grad time: ', time_Grad_PLIC)
#     time_[i] = np.array([time_Grad_PLIC, time_PLIC, time_DP])
#     ### true-reconstruction
#     reconstruction_true = true_reconstruction_Y_shape(triple, angle, nx, ny, dx, dy, ghost)
#     # print(reconstruction_true)
#     for m in range(N_ax_x):
#         for n in range(N_ax_y):
#             O_position = np.array([m * dx, n * dy])
#             cells = reconstruction_true[m + ghost][n + ghost][1]['cells']
#             if len(cells) > 1:
#                 plot_interface_plic_adv(ax[i, 0], O_position, cells, 2, dx, dy)
#             else:
#                 pass
#     ### CALCULATION OF AVERAGED CUMULATIVE SYMMETRIC-DIFFERENCE ERROR
#     csde_total_DP = 0.
#     csde_total_Choi = 0.
#     csde_total_Grad = 0.
#     cons_DP = np.zeros([3])
#     cons_Choi = np.zeros([3])
#     cons_Grad = np.zeros([3])
#     csde_count = 0
#     for m in range(nx - 2 * ghost):
#         for n in range(ny - 2 * ghost):
#             phase_num = reconstruction[m + ghost][n + ghost][1]['phase_num']
#             if phase_num > 1:
#                 ### AVERAGED CUMULATIVE SYMMETRIC-DIFFERENCE ERROR
#                 csde_count = csde_count + 1
#                 true_cells = reconstruction_true[m + ghost][n + ghost][1]['cells']
#                 ### DP
#                 DP_cells = reconstruction[m + ghost][n + ghost][1]['cells']
#                 DP_csde_err = get_cumulative_symmetric_difference_error(true_cells, DP_cells)
#                 csde_total_DP += DP_csde_err
#                 ### Choi
#                 Choi_cells = reconstruction_PLIC[m + ghost][n + ghost][1]['cells']
#                 Choi_csde_err = get_cumulative_symmetric_difference_error(true_cells, Choi_cells)
#                 csde_total_Choi += Choi_csde_err
#                 ### Grad
#                 Grad_cells = reconstruction_PLIC_2[m + ghost][n + ghost][1]['cells']
#                 Grad_csde_err = get_cumulative_symmetric_difference_error(true_cells, Grad_cells)
#                 csde_total_Grad += Grad_csde_err
#
#                 ### CONSERVATION ERROR
#                 ### DP
#                 errors_DP = reconstruction[m + ghost][n + ghost][1]['errors']
#                 cons_DP = cons_DP + errors_DP
#                 ### Choi
#                 errors_Choi = reconstruction_PLIC[m + ghost][n + ghost][1]['errors']
#                 cons_Choi = cons_Choi + errors_Choi
#                 ### Grad
#                 errors_Grad = reconstruction_PLIC_2[m + ghost][n + ghost][1]['errors']
#                 cons_Grad = cons_Grad + errors_Grad
#             else:
#                 pass
#     avg_csde_DP = csde_total_DP / csde_count
#     avg_csde_Choi = csde_total_Choi / csde_count
#     avg_csde_Grad = csde_total_Grad / csde_count
#     print('DP acsde err: ', avg_csde_DP, 'Choi acsde err: ', avg_csde_Choi, 'Grad acsde err: ', avg_csde_Grad)
#     conservation_error_DP = np.sum(abs(cons_DP))
#     conservation_error_Choi = np.sum(abs(cons_Choi))
#     conservation_error_Grad = np.sum(abs(cons_Grad))
#     print('DP cons: ', conservation_error_DP, 'Choi cons: ', conservation_error_Choi, 'Grad cons: ',
#           conservation_error_Grad)
#     cons[i] = np.array([conservation_error_Grad, conservation_error_Choi, conservation_error_DP])
#     acsde[i] = np.array([avg_csde_Grad, avg_csde_Choi, avg_csde_DP])
#
# handles, labels = plt.gca().get_legend_handles_labels()
# by_label = dict(zip(labels, handles))
# ax[0, len(L) - 1].legend(by_label.values(), by_label.keys(), fontsize="20")
# ### Y LABEL
# ax[0, 0].set_ylabel('(1)', fontsize=40)
# ax[1, 0].set_ylabel('(2)', fontsize=40)
# ax[2, 0].set_ylabel('(3)', fontsize=40)
# ax[3, 0].set_ylabel('(4)', fontsize=40)
# ### X LABEL
# ax[0, 0].set_title('(a) true layout', fontsize=40)
# ax[0, 1].set_title('(b) Grad-PLIC', fontsize=40)
# ax[0, 2].set_title('(c) Choi-PLIC', fontsize=40)
# ax[0, 3].set_title('(d) DP-PLIC', fontsize=40)
# fig.subplots_adjust(wspace=5e-2, hspace=5e-2, bottom=5e-2, top=1 - 5e-2, left=5e-2, right=1 - 5e-2)
# plt.savefig('./static_cases/Y2.png', format='png', dpi=400)
# plt.close()
#
# print('Summary')
# print('time')
# print('Grad: ', np.average(time_[:, 0]), 'Choi: ', np.average(time_[:, 1]), 'DP: ', np.average(time_[:, 2]))
# print('conservation')
# print('Grad: ', np.average(cons[:, 0]), 'Choi: ', np.average(cons[:, 1]), 'DP: ', np.average(cons[:, 2]))
# print('acsde')
# print('Grad: ', np.average(acsde[:, 0]), 'Choi: ', np.average(acsde[:, 1]), 'DP: ', np.average(acsde[:, 2]))

# ### JCP_layer
# nx = 10
# ny = 10
# ghost = 1
# dx = 1.
# dy = 1.
# tolerance = 1e-6
# max_step = 20
# fig, ax = plt.subplots(3, 4, figsize=[25, 19])
# for sub_ax in ax:
#     for subsub_ax in sub_ax:
#         subsub_ax.set_aspect('equal')
#         subsub_ax.grid(linestyle='--')
#         subsub_ax.xaxis.set_major_locator(MultipleLocator(1))
#         subsub_ax.yaxis.set_major_locator(MultipleLocator(1))
#         subsub_ax.set_xticklabels([])
#         subsub_ax.set_yticklabels([])
# L = [0, 20, 40]
# ### grad-choi-dp
# time_ = np.zeros([3, 3])
# cons = np.zeros([3, 3])
# acsde = np.zeros([3, 3])
# for i in range(len(L)):
#     print(L[i])
#     normal = np.array([np.sqrt(3) / 2, np.sqrt(1) / 2])
#     d1 = 5.7 + L[i] * 0.05
#     d2 = d1 + 0.5
#     Sf_ = doubleline_translation(normal, d1, d2, nx, ny, dx, dy)
#     Sf_ = repair_static(Sf_, ghost, nx, ny, 3, tolerance)
#     Sf = copy.deepcopy(Sf_)
#     N_ax_x = len(Sf[0]) - 2 * ghost
#     N_ax_y = len(Sf[0][0]) - 2 * ghost
#     ax[i, 0].set_xlim([0, dx * N_ax_x])
#     ax[i, 0].set_ylim([0, dx * N_ax_y])
#     ax[i, 1].set_xlim([0, dx * N_ax_x])
#     ax[i, 1].set_ylim([0, dx * N_ax_y])
#     ax[i, 2].set_xlim([0, dx * N_ax_x])
#     ax[i, 2].set_ylim([0, dx * N_ax_y])
#     ax[i, 3].set_xlim([0, dx * N_ax_x])
#     ax[i, 3].set_ylim([0, dx * N_ax_y])
#     ### DP-PLIC
#     time_DP_1 = time.time()
#     reconstruction = DP_PLIC_exact(Sf, dx, dy, tolerance, max_step)
#     time_DP_2 = time.time()
#     time_DP = time_DP_2 - time_DP_1
#     for m in range(N_ax_x):
#         for n in range(N_ax_y):
#             O_position = np.array([m * dx, n * dy])
#             grid_info = reconstruction[m + ghost][n + ghost]
#             if grid_info[0] != 0 and grid_info[1]['method']:
#                 Cells = grid_info[1]['cells']
#                 if grid_info[1]['method'] == 'PLIC':
#                     # print('PLIC')
#                     plot_interface_plic_adv(ax[i, 3], O_position, Cells, 2)
#                 elif grid_info[1]['method'] == 'YOUNGS':
#                     plot_interface_plic_adv(ax[i, 3], O_position, Cells, 2)
#                     errors = grid_info[1]['errors']
#                     # print('YOUNGS', errors)
#                 else:
#                     # print(m,n,Cells)
#                     plot_interface_plic_adv_DP(ax[i, 3], O_position, Cells, 2, dx, dy)
#                     errors = grid_info[1]['errors']
#                     # print('DP', errors)
#             else:
#                 pass
#     ### Choi-PLIC
#     time_PLIC = 0.
#     time_PLIC_1 = time.time()
#     reconstruction_PLIC = np.zeros([len(Sf[0]), len(Sf[0, 0]), 1]).tolist()
#     for m in range(len(Sf[0])):
#         for n in range(len(Sf[0, 0])):
#             reconstruction_PLIC[m][n].append({})
#     for m in range(N_ax_x):
#         for n in range(N_ax_y):
#             O_position = np.array([m * dx, n * dy])
#             sf_center_pos = [m + ghost, n + ghost]
#             sf = get_sf(sf_center_pos, Sf)
#             phase_exist = judge_phase_num(sf)
#             count = len(phase_exist)
#             reconstruction_PLIC[m + ghost][n + ghost][1]['phase_num'] = count
#             if count > 1:
#                 normals, d, cells, errors, error = PLIC_2d_tripleP_GSadv(sf, dx, dy, phase_exist, tolerance)
#                 reconstruction_PLIC[m + ghost][n + ghost][0] = 1
#                 reconstruction_PLIC[m + ghost][n + ghost][1]['method'] = 'PLIC'
#                 reconstruction_PLIC[m + ghost][n + ghost][1]['cells'] = cells
#                 reconstruction_PLIC[m + ghost][n + ghost][1]['normals'] = normals
#                 reconstruction_PLIC[m + ghost][n + ghost][1]['ds'] = d
#                 reconstruction_PLIC[m + ghost][n + ghost][1]['errors'] = errors
#                 reconstruction_PLIC[m + ghost][n + ghost][1]['error'] = error
#                 if error > tolerance * 10:
#                     normals, ds, cells, errors, error = Youngs_2d(sf, dx, dy, tolerance, phase_exist)
#                     reconstruction_PLIC[m + ghost][n + ghost][0] = 1
#                     reconstruction_PLIC[m + ghost][n + ghost][1]['method'] = 'YOUNGS'
#                     reconstruction_PLIC[m + ghost][n + ghost][1]['cells'] = cells
#                     reconstruction_PLIC[m + ghost][n + ghost][1]['normals'] = normals
#                     reconstruction_PLIC[m + ghost][n + ghost][1]['ds'] = ds
#                     reconstruction_PLIC[m + ghost][n + ghost][1]['errors'] = errors
#                     reconstruction_PLIC[m + ghost][n + ghost][1]['error'] = error
#                 else:
#                     pass
#             else:
#                 pass
#     time_PLIC_2 = time.time()
#     time_PLIC += (time_PLIC_2 - time_PLIC_1)
#     for m in range(N_ax_x):
#         for n in range(N_ax_y):
#             O_position = np.array([m * dx, n * dy])
#             sf_center_pos = [m + ghost, n + ghost]
#             sf = get_sf(sf_center_pos, Sf)
#             phase_exist = judge_phase_num(sf)
#             count = len(phase_exist)
#             if count > 1:
#                 cells = reconstruction_PLIC[m + ghost][n + ghost][1]['cells']
#                 plot_interface_plic_adv(ax[i, 2], O_position, cells, 2)
#                 if count > 2:
#                     errors = reconstruction_PLIC[m + ghost][n + ghost][1]['errors']
#                     # print('Choi-PLIC', errors)
#     ### Grad-PLIC
#     time_Grad_PLIC = 0.
#     time_Grad_PLIC_1 = time.time()
#     reconstruction_PLIC_2 = np.zeros([len(Sf[0]), len(Sf[0, 0]), 1]).tolist()
#     for m in range(len(Sf[0])):
#         for n in range(len(Sf[0, 0])):
#             reconstruction_PLIC_2[m][n].append({})
#     for m in range(N_ax_x):
#         for n in range(N_ax_y):
#             O_position = np.array([m * dx, n * dy])
#             sf_center_pos = [m + ghost, n + ghost]
#             sf = get_sf(sf_center_pos, Sf)
#             phase_exist = judge_phase_num(sf)
#             count = len(phase_exist)
#             reconstruction_PLIC_2[m + ghost][n + ghost][1]['phase_num'] = count
#             if count > 1:
#                 normals, d, cells, errors, error = Youngs_2d(sf, dx, dy, tolerance, phase_exist)
#                 reconstruction_PLIC_2[m + ghost][n + ghost][0] = 1
#                 reconstruction_PLIC_2[m + ghost][n + ghost][1]['method'] = 'PLIC'
#                 reconstruction_PLIC_2[m + ghost][n + ghost][1]['cells'] = cells
#                 reconstruction_PLIC_2[m + ghost][n + ghost][1]['normals'] = normals
#                 reconstruction_PLIC_2[m + ghost][n + ghost][1]['ds'] = d
#                 reconstruction_PLIC_2[m + ghost][n + ghost][1]['errors'] = errors
#                 reconstruction_PLIC_2[m + ghost][n + ghost][1]['error'] = error
#             else:
#                 pass
#     time_Grad_PLIC_2 = time.time()
#     time_Grad_PLIC += (time_Grad_PLIC_2 - time_Grad_PLIC_1)
#     for m in range(N_ax_x):
#         for n in range(N_ax_y):
#             O_position = np.array([m * dx, n * dy])
#             sf_center_pos = [m + ghost, n + ghost]
#             sf = get_sf(sf_center_pos, Sf)
#             phase_exist = judge_phase_num(sf)
#             count = len(phase_exist)
#             if count > 1:
#                 cells = reconstruction_PLIC_2[m + ghost][n + ghost][1]['cells']
#                 plot_interface_plic_adv(ax[i, 1], O_position, cells, 2)
#                 if count > 2:
#                     errors = reconstruction_PLIC_2[m + ghost][n + ghost][1]['errors']
#                     # print('Grad-PLIC', errors)
#     print('DP time: ', time_DP, 'Choi time: ', time_PLIC, 'Grad time: ', time_Grad_PLIC)
#     time_[i] = np.array([time_Grad_PLIC, time_PLIC, time_DP])
#     ### true-reconstruction
#     reconstruction_true = true_reconstruction_L_shape(normal, d1, d2, nx, ny, dx, dy, ghost)
#     # print(reconstruction_true)
#     for m in range(N_ax_x):
#         for n in range(N_ax_y):
#             O_position = np.array([m * dx, n * dy])
#             cells = reconstruction_true[m + ghost][n + ghost][1]['cells']
#             if len(cells) > 1:
#                 plot_interface_plic_adv(ax[i, 0], O_position, cells, 2, dx, dy)
#             else:
#                 pass
#     ### CALCULATION OF AVERAGED CUMULATIVE SYMMETRIC-DIFFERENCE ERROR
#     csde_total_DP = 0.
#     csde_total_Choi = 0.
#     csde_total_Grad = 0.
#     cons_DP = np.zeros([3])
#     cons_Choi = np.zeros([3])
#     cons_Grad = np.zeros([3])
#     csde_count = 0
#     for m in range(nx - 2 * ghost):
#         for n in range(ny - 2 * ghost):
#             phase_num = reconstruction[m + ghost][n + ghost][1]['phase_num']
#             if phase_num > 1:
#                 ### AVERAGED CUMULATIVE SYMMETRIC-DIFFERENCE ERROR
#                 csde_count = csde_count + 1
#                 true_cells = reconstruction_true[m + ghost][n + ghost][1]['cells']
#                 ### DP
#                 DP_cells = reconstruction[m + ghost][n + ghost][1]['cells']
#                 DP_csde_err = get_cumulative_symmetric_difference_error(true_cells, DP_cells)
#                 csde_total_DP += DP_csde_err
#                 ### Choi
#                 Choi_cells = reconstruction_PLIC[m + ghost][n + ghost][1]['cells']
#                 Choi_csde_err = get_cumulative_symmetric_difference_error(true_cells, Choi_cells)
#                 csde_total_Choi += Choi_csde_err
#                 ### Grad
#                 Grad_cells = reconstruction_PLIC_2[m + ghost][n + ghost][1]['cells']
#                 Grad_csde_err = get_cumulative_symmetric_difference_error(true_cells, Grad_cells)
#                 csde_total_Grad += Grad_csde_err
#
#                 ### CONSERVATION ERROR
#                 ### DP
#                 errors_DP = reconstruction[m + ghost][n + ghost][1]['errors']
#                 cons_DP = cons_DP + errors_DP
#                 ### Choi
#                 errors_Choi = reconstruction_PLIC[m + ghost][n + ghost][1]['errors']
#                 cons_Choi = cons_Choi + errors_Choi
#                 ### Grad
#                 errors_Grad = reconstruction_PLIC_2[m + ghost][n + ghost][1]['errors']
#                 cons_Grad = cons_Grad + errors_Grad
#             else:
#                 pass
#     avg_csde_DP = csde_total_DP / csde_count
#     avg_csde_Choi = csde_total_Choi / csde_count
#     avg_csde_Grad = csde_total_Grad / csde_count
#     print('DP acsde err: ', avg_csde_DP, 'Choi acsde err: ', avg_csde_Choi, 'Grad acsde err: ', avg_csde_Grad)
#     conservation_error_DP = np.sum(abs(cons_DP))
#     conservation_error_Choi = np.sum(abs(cons_Choi))
#     conservation_error_Grad = np.sum(abs(cons_Grad))
#     print('DP cons: ', conservation_error_DP, 'Choi cons: ', conservation_error_Choi, 'Grad cons: ',
#           conservation_error_Grad)
#     cons[i] = np.array([conservation_error_Grad, conservation_error_Choi, conservation_error_DP])
#     acsde[i] = np.array([avg_csde_Grad, avg_csde_Choi, avg_csde_DP])
#
# handles, labels = plt.gca().get_legend_handles_labels()
# by_label = dict(zip(labels, handles))
# ax[0, 3].legend(by_label.values(), by_label.keys(), fontsize="20")
# ### Y LABEL
# ax[0, 0].set_ylabel('(1)', fontsize=40)
# ax[1, 0].set_ylabel('(2)', fontsize=40)
# ax[2, 0].set_ylabel('(3)', fontsize=40)
# ### X LABEL
# ax[0, 0].set_title('(a) true layout', fontsize=40)
# ax[0, 1].set_title('(b) Grad-PLIC', fontsize=40)
# ax[0, 2].set_title('(c) Choi-PLIC', fontsize=40)
# ax[0, 3].set_title('(d) DP-PLIC', fontsize=40)
# fig.subplots_adjust(wspace=5e-2, hspace=5e-2, bottom=5e-2, top=1 - 5e-2, left=5e-2, right=1 - 5e-2)
# plt.savefig('./static_cases/Layer.png', format='png', dpi=400)
# plt.close()
#
# print('Summary')
# print('time')
# print('Grad: ', np.average(time_[:, 0]), 'Choi: ', np.average(time_[:, 1]), 'DP: ', np.average(time_[:, 2]))
# print('conservation')
# print('Grad: ', np.average(cons[:, 0]), 'Choi: ', np.average(cons[:, 1]), 'DP: ', np.average(cons[:, 2]))
# print('acsde')
# print('Grad: ', np.average(acsde[:, 0]), 'Choi: ', np.average(acsde[:, 1]), 'DP: ', np.average(acsde[:, 2]))

