###This is a script contains pathak's methods
###creator: Zhang, HKUST 2025.03.07
### A three-dimensional volume-of-fluid method for reconstructing and advecting three-material
### interfaces forming contact lines

from src.functions.functions import *
def Pathak_2d(sf, dx, dy, tolerance, phase_exis):
    normals = []
    d = []
    cells = []
    ###
    sf_1 = sf[phase_exis[0]]
    grads = gradient_point(sf_1, 1, 1, dx, dy)
    normal_1 = -grads
    normals.append(normal_1)
    d_1 = get_d_lineSearch_DP5(normal_1, dx, dy, sf_1[1, 1], tolerance)
    d.append(d_1)
    count = len(phase_exis)
    errors = np.zeros([len(sf)])
    cell_remain = plic_cell_remain(normal_1, d_1, dx, dy)
    cell_1 = plic_cell_remain(-normal_1, -d_1, dx, dy)
    if len(cell_1) > 2:
        cell_1 = [phase_exis[0], cell_1, 0]
        cells.append(cell_1)
        vol_1 = get_cell_volume_new(cell_1[1])
        error_1 = sf[phase_exis[0], 1, 1] - vol_1 / (dx * dy)
        errors[phase_exis[0]] = error_1
    else:
        vol_1 = 0
        error_1 = sf[phase_exis[0], 1, 1] - vol_1 / (dx * dy)
        errors[phase_exis[0]] = error_1
    if count > 2:
