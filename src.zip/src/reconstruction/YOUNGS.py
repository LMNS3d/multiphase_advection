###This is a script contains Youngs methods
###creator: Zhang, HKUST 2024.12.04
import copy

### THIS METHOD FOLLOWS THE METHOD IN
### Time-Dependent Multi-material Flow with Large Fluid Distortion, Youngs, 1982

from src.functions.functions import *

def Youngs_2d(sf, dx, dy, tolerance, phase_exis):
    # print('Youngs')
    normals = []
    d = []
    cells = []
    ###
    sf_1 = sf[phase_exis[0]]
    grads = gradient_point(sf_1, 1, 1, dx, dy)
    normal_1 = -grads
    normals.append(normal_1)
    d_1 = get_d_lineSearch_DP5(normal_1, dx, dy, sf_1[1, 1], tolerance)
    d.append(d_1)
    count = len(phase_exis)
    errors = np.zeros([len(sf)])
    cell_remain = plic_cell_remain(normal_1, d_1, dx, dy)
    cell_1 = plic_cell_remain(-normal_1, -d_1, dx, dy)

    if len(cell_1) > 2:
        cell_1 = [phase_exis[0], cell_1, 0]
        cells.append(cell_1)
        vol_1 = get_cell_volume_new(cell_1[1])
        error_1 = sf[phase_exis[0], 1, 1] - vol_1 / (dx * dy)
        errors[phase_exis[0]] = error_1
    else:
        # cell_1 = [phase_exis[0], np.array([None, None]), 0]
        # cells.append(cell_1)
        vol_1 = 0
        error_1 = sf[phase_exis[0], 1, 1] - vol_1 / (dx * dy)
        errors[phase_exis[0]] = error_1
    if count > 2 and len(cell_remain) >= 3:
        ################################## LINEAR SEARCH : NARROW THE GOLDEN SEARCH RANGE ##############################
        sf_2 = sf[phase_exis[1]]
        sf_3 = sf[phase_exis[2]]
        grads_2 = gradient_point(sf_2, 1, 1, dx, dy)
        normal_2 = -grads_2
        # print('normal_2', normal_2)
        grads_3 = gradient_point(sf_3, 1, 1, dx, dy)
        normal_3 = -grads_3
        # print('normal_3', normal_3)
        ### POINTING OUTWARDS PHASE2 TO PHASE3
        n_23_ = normal_2 - normal_3
        n_23 = copy.deepcopy(n_23_)
        n_23[0] = n_23_[0] / (n_23_[0] ** 2 + n_23_[1] ** 2) ** 0.5
        n_23[1] = n_23_[1] / (n_23_[0] ** 2 + n_23_[1] ** 2) ** 0.5
        # print(n_23)
        d_23 = get_d_lineSearch_general(cell_remain, n_23, dx, dy, sf_2[1, 1], tolerance)
        normals.append(n_23)
        d.append(d_23)
        intersects = plic_get_intersects(cell_remain, n_23, d_23)
        cell_2 = plic_cell_remain_with_intersects(n_23, d_23, cell_remain, intersects)
        if len(cell_2) > 2:
            cell_2 = [phase_exis[2], cell_2, 0]
            cells.append(cell_2)
            vol_2 = get_cell_volume_new(cell_2[1])
            error_2 = sf[phase_exis[2], 1, 1] - vol_2 / (dx * dy)
            errors[phase_exis[2]] = error_2
        else:
            # cell_2 = [phase_exis[2], np.array([None, None]), 0]
            # cells.append(cell_2)
            vol_2 = 0
            error_2 = sf[phase_exis[2], 1, 1] - vol_2 / (dx * dy)
            errors[phase_exis[2]] = error_2
        cell_3 = plic_cell_remain_with_intersects(-n_23, -d_23, cell_remain, intersects)
        if len(cell_3) > 2:
            cell_3 = [phase_exis[1], cell_3, 0]
            cells.append(cell_3)
            vol_3 = dx * dy - (vol_1 + vol_2)
            error_3 = sf[phase_exis[1], 1, 1] - vol_3 / (dx * dy)
            errors[phase_exis[1]] = error_3
        else:
            # cell_3 = [phase_exis[1], np.array([None, None]), 0]
            # cells.append(cell_3)
            vol_3 = 0
            error_3 = sf[phase_exis[1], 1, 1] - vol_3 / (dx * dy)
            errors[phase_exis[1]] = error_3
        error = abs(errors[0]) + abs(errors[1]) + abs(errors[2])
    else:
        cell_2 = cell_remain
        if len(cell_2) > 2:
            cell_2 = [phase_exis[1], cell_2, 0]
            cells.append(cell_2)
            vol_2 = dx * dy - vol_1
            error_2 = sf[phase_exis[1], 1, 1] - vol_2 / (dx * dy)
            errors[phase_exis[1]] = error_2
        else:
            # cell_2 = [phase_exis[1], np.array([None, None]), 0]
            # cells.append(cell_2)
            vol_2 = 0
            error_2 = sf[phase_exis[1], 1, 1] - vol_2 / (dx * dy)
            errors[phase_exis[1]] = error_2
        error = abs(errors[0]) + abs(errors[1])
        # print(error)

    return normals, d, cells, errors, error

def Youngs2P_2d(sf, dx, dy, tolerance, phase_exis):
    cells = []
    ###
    sf_1 = sf[phase_exis[0]]
    grads = gradient_point(sf_1, 1, 1, dx, dy)
    normal_1 = -grads
    d_1 = get_d_lineSearch_DP5(normal_1, dx, dy, sf_1[1, 1], tolerance)
    phase_ind1 = phase_exis[0]
    phase_ind2 = phase_exis[1]
    errors = np.zeros([len(sf)])
    cell_remain = plic_cell_remain(normal_1, d_1, dx, dy)
    cell_1 = plic_cell_remain(-normal_1, -d_1, dx, dy)

    if len(cell_1) > 2:
        cell_1 = [phase_ind1, cell_1, 0]
        cells.append(cell_1)
        vol_1 = get_cell_volume_new(cell_1[1])
        error_1 = sf[phase_ind1, 1, 1] - vol_1 / (dx * dy)
        errors[phase_ind1] = error_1
    else:
        vol_1 = 0
        error_1 = sf[phase_ind1, 1, 1] - vol_1 / (dx * dy)
        errors[phase_ind1] = error_1
    cell_2 = cell_remain
    if len(cell_2) > 2:
        cell_2 = [phase_ind2, cell_2, 0]
        cells.append(cell_2)
        vol_2 = dx * dy - vol_1
        error_2 = sf[phase_ind2, 1, 1] - vol_2 / (dx * dy)
        errors[phase_ind2] = error_2
    else:
        vol_2 = 0
        error_2 = sf[phase_ind2, 1, 1] - vol_2 / (dx * dy)
        errors[phase_ind2] = error_2
    error = abs(errors[0]) + abs(errors[1])

    return normal_1, d_1, cells, errors, error

def Youngs_1982(sf, dx, dy, tolerance, phase_exis):
    pass

