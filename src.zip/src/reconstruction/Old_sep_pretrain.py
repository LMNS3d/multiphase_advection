### HKUST Fu's Lab
### Zeyu Zhang

import copy
import numpy as np

###This function to find the cut point for each cell boundary
###If the cell boundary is in between two same phase dominated vertice, no cut point is needed
###The cut point is too reach a balance between two different phases' influence
###input
###sub_sf: the subcell volume of fraction field, get from get_local_field
###dx, dy: grid intervals
###vertice_tag: the dominate tags on each vertice, get from get_vertice_tag
###output
###points: record the local coordinates of the cut point on each cell boundary, if no cut point takes None
###                      tag(0,2)---sep(2)---tag(1,2)---sep(3)---tag(2,2)
###                      |                                       |
###                      sep(1)                                  sep(4)
###                      |                                       |
###                      tag(0,1)            tag(1,1)            tag(2,1)
###                      |                                       |
###                      sep(0)                                  sep(5)
###                      |                                       |
###                      tag(0,0)---sep(7)---tag(1,0)---sep(6)---tag(2,0)
def get_sep_points_DP5(sub_sf, sub_sf_2, v_tag, dx, dy, neigh_sep, sep_tags, neigh_sep_un, sep_tags_un, sep_left):
    ###initialize
    result = copy.deepcopy(neigh_sep)
    epsilon = 1e-1
    ###cell boundary x- lower
    if sep_left[0] == 1 and v_tag[0, 0] - v_tag[0, 1] != 0:
        ###The influence calculation, epsilon is the denominator positive preserving factor
        influence_1, influence_2 = get_vertex_influence_7([0, 1], [0, 0], epsilon, v_tag, sub_sf, sub_sf_2, dx, dy)
        ###follows (y - 0) / (0.5dy - y) = influence_2 / influence_1
        y = ((influence_2 / influence_1) * 0.5 * dy) / (1 + (influence_2 / influence_1))
        x = 0.
        result[0, 0] = x
        result[0, 1] = y
    else:
        if (not np.isnan(neigh_sep[0]).all()) and v_tag[0, 0] - v_tag[0, 1] != 0:
            sep_tag = sep_tags[0].tolist()
            if (v_tag[0, 0] in sep_tag) and (v_tag[0, 1] in sep_tag):
                pass
            else:
                influence_1, influence_2 = get_vertex_influence_7([0, 1], [0, 0], epsilon, v_tag, sub_sf, sub_sf_2, dx, dy)
                y = ((influence_2 / influence_1) * 0.5 * dy) / (1 + (influence_2 / influence_1))
                x = 0.
                result[0, 0] = x
                result[0, 1] = y
        elif v_tag[0, 0] - v_tag[0, 1] != 0 and np.isnan(neigh_sep[0]).all():
            sep_tag_un = sep_tags_un[0].tolist()
            if (not np.isnan(neigh_sep_un[0]).all()) and (v_tag[0, 0] in sep_tag_un) and (v_tag[0, 1] in sep_tag_un):
                # move the intersection to the boundary
                result[0, 0] = 0.
                result[0, 1] = min(0.5 * dy, max(0., neigh_sep_un[0, 1]))
                # if v_tag[0, 1] - v_tag[0, 2] != 0:
                #     ### keep the intersection as the upper part intersection
                #     pass
                # else:
                #     ### move the upper part intersection to the lower part
                #     result[1].fill(np.nan)
            else:
                influence_1, influence_2 = get_vertex_influence_7([0, 1], [0, 0], epsilon, v_tag, sub_sf, sub_sf_2, dx, dy)
                y = ((influence_2 / influence_1) * 0.5 * dy) / (1 + (influence_2 / influence_1))
                x = 0.
                result[0, 0] = x
                result[0, 1] = y
        elif v_tag[0, 0] - v_tag[0, 1] == 0:
            result[0, 0] = None
            result[0, 1] = None
        else:
            influence_1, influence_2 = get_vertex_influence_7([0, 1], [0, 0], epsilon, v_tag, sub_sf, sub_sf_2, dx, dy)
            y = ((influence_2 / influence_1) * 0.5 * dy) / (1 + (influence_2 / influence_1))
            x = 0.
            result[0, 0] = x
            result[0, 1] = y

    ###cell boundary x- upper
    if sep_left[1] == 1 and v_tag[0, 1] - v_tag[0, 2] != 0:
        influence_1, influence_2 = get_vertex_influence_7([0, 1], [0, 2], epsilon, v_tag, sub_sf, sub_sf_2, dx, dy)
        ###follows (y - 0.5dy) / (dy - y) = influence_1 / influence_2
        y = (((influence_1 / influence_2) + 0.5) * dy) / (1 + (influence_1 / influence_2))
        x = 0.
        result[1, 0] = x
        result[1, 1] = y
    else:
        if (not np.isnan(neigh_sep[1]).all()) and v_tag[0, 1] - v_tag[0, 2] != 0:
            sep_tag = sep_tags[1].tolist()
            if (v_tag[0, 1] in sep_tag) and (v_tag[0, 2] in sep_tag):
                pass
            else:
                influence_1, influence_2 = get_vertex_influence_7([0, 1], [0, 2], epsilon, v_tag, sub_sf, sub_sf_2, dx, dy)
                ###follows (y - 0.5dy) / (dy - y) = influence_1 / influence_2
                y = (((influence_1 / influence_2) + 0.5) * dy) / (1 + (influence_1 / influence_2))
                x = 0.
                result[1, 0] = x
                result[1, 1] = y
        elif v_tag[0, 1] - v_tag[0, 2] != 0 and np.isnan(neigh_sep[1]).all():
            sep_tag_un = sep_tags_un[1].tolist()
            if (not np.isnan(neigh_sep_un[1]).all()) and (v_tag[0, 1] in sep_tag_un) and (v_tag[0, 2] in sep_tag_un):
                result[1, 0] = 0.
                result[1, 1] = min(dy, max(0.5 * dy, neigh_sep_un[1, 1]))
                # if v_tag[0, 1] - v_tag[0, 2] != 0:
                #     pass
                # else:
                #     result[0].fill(np.nan)
            else:
                influence_1, influence_2 = get_vertex_influence_7([0, 1], [0, 2], epsilon, v_tag, sub_sf, sub_sf_2, dx, dy)
                ###follows (y - 0.5dy) / (dy - y) = influence_1 / influence_2
                y = (((influence_1 / influence_2) + 0.5) * dy) / (1 + (influence_1 / influence_2))
                x = 0.
                result[1, 0] = x
                result[1, 1] = y
        elif v_tag[0, 1] - v_tag[0, 2] == 0:
            result[1, 0] = None
            result[1, 1] = None
        else:
            influence_1, influence_2 = get_vertex_influence_7([0, 1], [0, 2], epsilon, v_tag, sub_sf, sub_sf_2, dx, dy)
            ###follows (y - 0.5dy) / (dy - y) = influence_1 / influence_2
            y = (((influence_1 / influence_2) + 0.5) * dy) / (1 + (influence_1 / influence_2))
            x = 0.
            result[1, 0] = x
            result[1, 1] = y

    ###cell boundary x+ lower
    if sep_left[5] == 1 and v_tag[2, 0] - v_tag[2, 1] != 0:
        influence_1, influence_2 = get_vertex_influence_7([2, 1], [2, 0], epsilon, v_tag, sub_sf, sub_sf_2, dx, dy)
        ###follows (y - 0) / (0.5dy - y) = influence_2 / influence_1
        y = ((influence_2 / influence_1) * 0.5 * dy) / (1 + (influence_2 / influence_1))
        x = dx
        result[5, 0] = x
        result[5, 1] = y
    else:
        if (not np.isnan(neigh_sep[5]).all()) and v_tag[2, 0] - v_tag[2, 1] != 0:
            sep_tag = sep_tags[5].tolist()
            if (v_tag[2, 0] in sep_tag) and (v_tag[2, 1] in sep_tag):
                pass
            else:
                influence_1, influence_2 = get_vertex_influence_7([2, 1], [2, 0], epsilon, v_tag, sub_sf, sub_sf_2, dx, dy)
                ###follows (y - 0) / (0.5dy - y) = influence_2 / influence_1
                y = ((influence_2 / influence_1) * 0.5 * dy) / (1 + (influence_2 / influence_1))
                x = dx
                result[5, 0] = x
                result[5, 1] = y
        elif v_tag[2, 0] - v_tag[2, 1] != 0 and np.isnan(neigh_sep[5]).all():
            sep_tag_un = sep_tags_un[5].tolist()
            if (not np.isnan(neigh_sep_un[5]).all()) and (v_tag[2, 0] in sep_tag_un) and (v_tag[2, 1] in sep_tag_un):
                result[5, 0] = dx
                result[5, 1] = min(0.5 * dy, max(0., neigh_sep_un[5, 1]))
                # if v_tag[2, 1] - v_tag[2, 2] != 0:
                #     pass
                # else:
                #     result[4].fill(np.nan)
            else:
                influence_1, influence_2 = get_vertex_influence_7([2, 1], [2, 0], epsilon, v_tag, sub_sf, sub_sf_2, dx, dy)
                ###follows (y - 0) / (0.5dy - y) = influence_2 / influence_1
                y = ((influence_2 / influence_1) * 0.5 * dy) / (1 + (influence_2 / influence_1))
                x = dx
                result[5, 0] = x
                result[5, 1] = y
        elif v_tag[2, 0] - v_tag[2, 1] == 0:
            result[5, 0] = None
            result[5, 1] = None
        else:
            influence_1, influence_2 = get_vertex_influence_7([2, 1], [2, 0], epsilon, v_tag, sub_sf, sub_sf_2, dx, dy)
            ###follows (y - 0) / (0.5dy - y) = influence_2 / influence_1
            y = ((influence_2 / influence_1) * 0.5 * dy) / (1 + (influence_2 / influence_1))
            x = dx
            result[5, 0] = x
            result[5, 1] = y

    ###cell boundary x+ upper
    if sep_left[4] == 1 and v_tag[2, 1] - v_tag[2, 2] != 0:
        influence_1, influence_2 = get_vertex_influence_7([2, 1], [2, 2], epsilon, v_tag, sub_sf, sub_sf_2, dx, dy)
        ###follows (y - 0.5dy) / (dy - y) = influence_1 / influence_2
        y = (((influence_1 / influence_2) + 0.5) * dy) / (1 + (influence_1 / influence_2))
        x = dx
        result[4, 0] = x
        result[4, 1] = y
    else:
        if (not np.isnan(neigh_sep[4]).all()) and v_tag[2, 1] - v_tag[2, 2] != 0:
            sep_tag = sep_tags[4].tolist()
            if (v_tag[2, 1] in sep_tag) and (v_tag[2, 2] in sep_tag):
                pass
            else:
                influence_1, influence_2 = get_vertex_influence_7([2, 1], [2, 2], epsilon, v_tag, sub_sf, sub_sf_2, dx, dy)
                ###follows (y - 0.5dy) / (dy - y) = influence_1 / influence_2
                y = (((influence_1 / influence_2) + 0.5) * dy) / (1 + (influence_1 / influence_2))
                x = dx
                result[4, 0] = x
                result[4, 1] = y
        elif v_tag[2, 1] - v_tag[2, 2] != 0 and np.isnan(neigh_sep[4]).all():
            sep_tag_un = sep_tags_un[4].tolist()
            if (not np.isnan(neigh_sep_un[4]).all()) and (v_tag[2, 1] in sep_tag_un) and (v_tag[2, 2] in sep_tag_un):
                result[4, 0] = dx
                result[4, 1] = min(dy, max(0.5 * dy, neigh_sep_un[4, 1]))
                # if v_tag[2, 0] - v_tag[2, 1] != 0:
                #     pass
                # else:
                #     result[5].fill(np.nan)
            else:
                influence_1, influence_2 = get_vertex_influence_7([2, 1], [2, 2], epsilon, v_tag, sub_sf, sub_sf_2, dx, dy)
                ###follows (y - 0.5dy) / (dy - y) = influence_1 / influence_2
                y = (((influence_1 / influence_2) + 0.5) * dy) / (1 + (influence_1 / influence_2))
                x = dx
                result[4, 0] = x
                result[4, 1] = y
        elif v_tag[2, 1] - v_tag[2, 2] == 0:
            result[4, 0] = None
            result[4, 1] = None
        else:
            influence_1, influence_2 = get_vertex_influence_7([2, 1], [2, 2], epsilon, v_tag, sub_sf, sub_sf_2, dx, dy)
            ###follows (y - 0.5dy) / (dy - y) = influence_1 / influence_2
            y = (((influence_1 / influence_2) + 0.5) * dy) / (1 + (influence_1 / influence_2))
            x = dx
            result[4, 0] = x
            result[4, 1] = y

    ###cell boundary y- left
    if sep_left[7] == 1 and v_tag[0, 0] - v_tag[1, 0] != 0:
        influence_1, influence_2 = get_vertex_influence_7([1, 0], [0, 0], epsilon, v_tag, sub_sf, sub_sf_2, dx, dy)
        ###follows (x - 0) / (0.5dx - x) = influence_2 / influence_1
        x = ((influence_2 / influence_1) * 0.5 * dx) / (1 + (influence_2 / influence_1))
        y = 0.
        result[7, 0] = x
        result[7, 1] = y
    else:
        if (not np.isnan(neigh_sep[7]).all()) and v_tag[0, 0] - v_tag[1, 0] != 0:
            sep_tag = sep_tags[7].tolist()
            if (v_tag[0, 0] in sep_tag) and (v_tag[1, 0] in sep_tag):
                pass
            else:
                influence_1, influence_2 = get_vertex_influence_7([1, 0], [0, 0], epsilon, v_tag, sub_sf, sub_sf_2, dx,
                                                                  dy)
                ###follows (x - 0) / (0.5dx - x) = influence_2 / influence_1
                x = ((influence_2 / influence_1) * 0.5 * dx) / (1 + (influence_2 / influence_1))
                y = 0.
                result[7, 0] = x
                result[7, 1] = y
        elif v_tag[0, 0] - v_tag[1, 0] != 0 and np.isnan(neigh_sep[7]).all():
            sep_tag_un = sep_tags_un[7].tolist()
            if (not np.isnan(neigh_sep_un[7]).all()) and (v_tag[0, 0] in sep_tag_un) and (v_tag[1, 0] in sep_tag_un):
                result[7, 0] = min(0.5 * dx, max(0., neigh_sep_un[7, 0]))
                result[7, 1] = 0.
                # if v_tag[1, 0] - v_tag[2, 0] != 0:
                #     pass
                # else:
                #     result[6].fill(np.nan)
            else:
                influence_1, influence_2 = get_vertex_influence_7([1, 0], [0, 0], epsilon, v_tag, sub_sf, sub_sf_2, dx,
                                                                  dy)
                ###follows (x - 0) / (0.5dx - x) = influence_2 / influence_1
                x = ((influence_2 / influence_1) * 0.5 * dx) / (1 + (influence_2 / influence_1))
                y = 0.
                result[7, 0] = x
                result[7, 1] = y
        elif v_tag[0, 0] - v_tag[1, 0] == 0:
            result[7, 0] = None
            result[7, 1] = None
        else:
            influence_1, influence_2 = get_vertex_influence_7([1, 0], [0, 0], epsilon, v_tag, sub_sf, sub_sf_2, dx, dy)
            ###follows (x - 0) / (0.5dx - x) = influence_2 / influence_1
            x = ((influence_2 / influence_1) * 0.5 * dx) / (1 + (influence_2 / influence_1))
            y = 0.
            result[7, 0] = x
            result[7, 1] = y

    ###cell boundary y- right
    if sep_left[6] == 1 and v_tag[1, 0] - v_tag[2, 0] != 0:
        influence_1, influence_2 = get_vertex_influence_7([1, 0], [2, 0], epsilon, v_tag, sub_sf, sub_sf_2, dx, dy)
        ###follows (x - 0.5dx) / (dx - x) = influence_1 / influence_2
        x = (((influence_1 / influence_2) + 0.5) * dx) / (1 + (influence_1 / influence_2))
        y = 0.
        result[6, 0] = x
        result[6, 1] = y
    else:
        if (not np.isnan(neigh_sep[6]).all()) and v_tag[2, 0] - v_tag[1, 0] != 0:
            sep_tag = sep_tags[6].tolist()
            if (v_tag[2, 0] in sep_tag) and (v_tag[1, 0] in sep_tag):
                pass
            else:
                influence_1, influence_2 = get_vertex_influence_7([1, 0], [2, 0], epsilon, v_tag, sub_sf, sub_sf_2, dx,
                                                                  dy)
                ###follows (x - 0.5dx) / (dx - x) = influence_1 / influence_2
                x = (((influence_1 / influence_2) + 0.5) * dx) / (1 + (influence_1 / influence_2))
                y = 0.
                result[6, 0] = x
                result[6, 1] = y
        elif v_tag[2, 0] - v_tag[1, 0] != 0 and np.isnan(neigh_sep[6]).all():
            sep_tag_un = sep_tags_un[6].tolist()
            if (not np.isnan(neigh_sep_un[6]).all()) and (v_tag[2, 0] in sep_tag_un) and (v_tag[1, 0] in sep_tag_un):
                result[6, 0] = min(dx, max(0.5 * dx, neigh_sep_un[6, 0]))
                result[6, 1] = 0.
                # if v_tag[0, 0] - v_tag[1, 0] != 0:
                #     pass
                # else:
                #     result[7].fill(np.nan)
            else:
                influence_1, influence_2 = get_vertex_influence_7([1, 0], [2, 0], epsilon, v_tag, sub_sf, sub_sf_2, dx,
                                                                  dy)
                ###follows (x - 0.5dx) / (dx - x) = influence_1 / influence_2
                x = (((influence_1 / influence_2) + 0.5) * dx) / (1 + (influence_1 / influence_2))
                y = 0.
                result[6, 0] = x
                result[6, 1] = y
        elif v_tag[1, 0] - v_tag[2, 0] == 0:
            result[6, 0] = None
            result[6, 1] = None
        else:
            influence_1, influence_2 = get_vertex_influence_7([1, 0], [2, 0], epsilon, v_tag, sub_sf, sub_sf_2, dx, dy)
            ###follows (x - 0.5dx) / (dx - x) = influence_1 / influence_2
            x = (((influence_1 / influence_2) + 0.5) * dx) / (1 + (influence_1 / influence_2))
            y = 0.
            result[6, 0] = x
            result[6, 1] = y

    ###cell boundary y+ left
    if sep_left[2] == 1 and v_tag[0, 2] - v_tag[1, 2] != 0:
        influence_1, influence_2 = get_vertex_influence_7([1, 2], [0, 2], epsilon, v_tag, sub_sf, sub_sf_2, dx, dy)
        ###follows (x - 0) / (0.5dx - x) = influence_2 / influence_1
        x = ((influence_2 / influence_1) * 0.5 * dx) / (1 + (influence_2 / influence_1))
        y = dy
        result[2, 0] = x
        result[2, 1] = y
    else:
        if (not np.isnan(neigh_sep[2]).all()) and v_tag[0, 2] - v_tag[1, 2] != 0:
            sep_tag = sep_tags[2].tolist()
            if (v_tag[0, 2] in sep_tag) and (v_tag[1, 2] in sep_tag):
                pass
            else:
                influence_1, influence_2 = get_vertex_influence_7([1, 2], [0, 2], epsilon, v_tag, sub_sf, sub_sf_2, dx,
                                                                  dy)
                ###follows (x - 0) / (0.5dx - x) = influence_2 / influence_1
                x = ((influence_2 / influence_1) * 0.5 * dx) / (1 + (influence_2 / influence_1))
                y = dy
                result[2, 0] = x
                result[2, 1] = y
        elif v_tag[0, 2] - v_tag[1, 2] != 0 and np.isnan(neigh_sep[2]).all():
            sep_tag_un = sep_tags_un[2].tolist()
            if (not np.isnan(neigh_sep_un[2]).all()) and (v_tag[0, 2] in sep_tag_un) and (v_tag[1, 2] in sep_tag_un):
                result[2, 0] = min(0.5 * dx, max(0., neigh_sep_un[2, 0]))
                result[2, 1] = dy
                # if v_tag[1, 2] - v_tag[2, 2] != 0:
                #     pass
                # else:
                #     result[3].fill(np.nan)
            else:
                influence_1, influence_2 = get_vertex_influence_7([1, 2], [0, 2], epsilon, v_tag, sub_sf, sub_sf_2, dx,
                                                                  dy)
                ###follows (x - 0) / (0.5dx - x) = influence_2 / influence_1
                x = ((influence_2 / influence_1) * 0.5 * dx) / (1 + (influence_2 / influence_1))
                y = dy
                result[2, 0] = x
                result[2, 1] = y
        elif v_tag[0, 2] - v_tag[1, 2] == 0:
            result[2, 0] = None
            result[2, 1] = None
        else:
            influence_1, influence_2 = get_vertex_influence_7([1, 2], [0, 2], epsilon, v_tag, sub_sf, sub_sf_2, dx, dy)
            ###follows (x - 0) / (0.5dx - x) = influence_2 / influence_1
            x = ((influence_2 / influence_1) * 0.5 * dx) / (1 + (influence_2 / influence_1))
            y = dy
            result[2, 0] = x
            result[2, 1] = y

    ###cell boundary y+ right
    if sep_left[3] == 1 and v_tag[1, 2] - v_tag[2, 2] != 0:
        ###The influence is defined line summation
        influence_1, influence_2 = get_vertex_influence_7([1, 2], [2, 2], epsilon, v_tag, sub_sf, sub_sf_2, dx, dy)
        ###follows (x - 0.5dx) / (dx - x) = influence_1 / influence_2
        x = (((influence_1 / influence_2) + 0.5) * dx) / (1 + (influence_1 / influence_2))
        y = dy
        result[3, 0] = x
        result[3, 1] = y
    else:
        if (not np.isnan(neigh_sep[3]).all()) and v_tag[2, 2] - v_tag[1, 2] != 0:
            sep_tag = sep_tags[3].tolist()
            if (v_tag[2, 2] in sep_tag) and (v_tag[1, 2] in sep_tag):
                pass
            else:
                influence_1, influence_2 = get_vertex_influence_7([1, 2], [2, 2], epsilon, v_tag, sub_sf, sub_sf_2, dx,
                                                                  dy)
                ###follows (x - 0.5dx) / (dx - x) = influence_1 / influence_2
                x = (((influence_1 / influence_2) + 0.5) * dx) / (1 + (influence_1 / influence_2))
                y = dy
                result[3, 0] = x
                result[3, 1] = y
        elif v_tag[2, 2] - v_tag[1, 2] != 0 and np.isnan(neigh_sep[3]).all():
            sep_tag_un = sep_tags_un[3].tolist()
            if (not np.isnan(neigh_sep_un[3]).all()) and (v_tag[2, 2] in sep_tag_un) and (v_tag[1, 2] in sep_tag_un):
                result[3, 0] = min(dx, max(0.5 * dx, neigh_sep_un[3, 0]))
                result[3, 1] = dy
                # if v_tag[0, 2] - v_tag[1, 2] != 0:
                #     pass
                # else:
                #     result[2].fill(np.nan)
            else:
                influence_1, influence_2 = get_vertex_influence_7([1, 2], [2, 2], epsilon, v_tag, sub_sf, sub_sf_2, dx,
                                                                  dy)
                ###follows (x - 0.5dx) / (dx - x) = influence_1 / influence_2
                x = (((influence_1 / influence_2) + 0.5) * dx) / (1 + (influence_1 / influence_2))
                y = dy
                result[3, 0] = x
                result[3, 1] = y
        elif v_tag[1, 2] - v_tag[2, 2] == 0:
            result[3, 0] = None
            result[3, 1] = None
        else:
            influence_1, influence_2 = get_vertex_influence_7([1, 2], [2, 2], epsilon, v_tag, sub_sf, sub_sf_2, dx, dy)
            ###follows (x - 0.5dx) / (dx - x) = influence_1 / influence_2
            x = (((influence_1 / influence_2) + 0.5) * dx) / (1 + (influence_1 / influence_2))
            y = dy
            result[3, 0] = x
            result[3, 1] = y

    return result

### This is the aux function to get_sep_points_DP3_3
### input
### v1, v2: v1 = [v1x, v1y], v1x, v1y = 0, 1, 2
### epsilon: denominator positivity preserving factor
### v_tag, sub_sf
### output
### influence1, influence2: the larger the influence, the further the separation point
### influence_1 : 1 / (|volume fraction difference| + epsilon) at V2
### influence_2 : 1 / (|volume fraction difference| + epsilon) at V1

def get_vertex_influence_7(v1, v2, epsilon, v_tag, sub_sf, sub_sf_2, dx, dy):
    influence_2 = (2. / (
            abs(sub_sf[v_tag[v1[0], v1[1]], v1[0], v1[1]] - sub_sf[v_tag[v2[0], v2[1]], v1[0], v1[1]]) + epsilon) +
                   activation_tanh(sub_sf[v_tag[v1[0], v1[1]], v2[0], v2[1]], offset=0.001 * min(dx, dy)) / (
                           sub_sf[v_tag[v1[0], v1[1]], v2[0], v2[1]] + epsilon ** 3))
    influence_1 = (1. / (
            abs(sub_sf[v_tag[v1[0], v1[1]], v2[0], v2[1]] - sub_sf[v_tag[v2[0], v2[1]], v2[0], v2[1]]) + epsilon) +
                   activation_tanh(sub_sf[v_tag[v2[0], v2[1]], v1[0], v1[1]], offset=0.001 * min(dx, dy)) / (
                           sub_sf[v_tag[v2[0], v2[1]], v1[0], v1[1]] + epsilon ** 3) +
                   activation_tanh(sub_sf_2[v_tag[v2[0], v2[1]], v1[0], v1[1]], offset=0.001 * min(dx, dy)) / (
                           sub_sf_2[v_tag[v2[0], v2[1]], v1[0], v1[1]] + epsilon ** 3))
    # print(influence_1, influence_2)
    return influence_1, influence_2

### This function act as a activation function that activate when the volume fraction is very small
### return scale(tanh(steep(-(x-offset))) + 1)
def activation_tanh(f, scale=0.02, steep=10, offset=0.001):
    return scale * (np.tanh(steep * - (f - offset)) + 1)
### 0.06 10 0.15
### 0.03 10 0.001
### 0.02 10 0.001

def rotate_counterclk(sf):
    sf_1 = sf.transpose()
    sf_2 = sf_1[[2, 1, 0], :]
    return sf_2

def rotate_clk(sf):
    sf_1 = sf.transpose()
    sf_2 = sf_1[:, [2, 1, 0]]
    return sf_2
### v1 controid