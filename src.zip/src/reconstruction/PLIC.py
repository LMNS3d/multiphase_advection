###This is a script contains PLIC methods
###creator: Zhang, HKUST

### THIS METHOD FOLLOWS THE METHOD IN 10.1002/fld.1317
### A piecewise linear approach to volume tracking a triple point

import matplotlib.pyplot as plt
# from Geometric_transformation import *
import math
from src.functions.new_function import get_sf, judge_phase_num, stencil_eliminate
from src.functions.mp_function import *
from multiprocessing import Queue
import multiprocessing as mp
from src.reconstruction.YOUNGS import Youngs_2d
from src.advection_function.advection_func_new import get_sco_tag
from src.functions.functions import *

def PLIC_2d_tripleP_GSadv(sf, dx, dy, phase_exis, tolerance):
    normals = []
    d = []
    cells = []
    gr = (math.sqrt(5) + 1) / 2
    errors = np.zeros([len(sf)])
    count = len(phase_exis)
    ###
    sf_1 = sf[phase_exis[0]]
    grads = gradient_point(sf_1, 1, 1, dx, dy)
    normal_1 = -grads
    normals.append(normal_1)
    d_1 = get_d_lineSearch_DP5(normal_1, dx, dy, sf_1[1, 1], tolerance)
    d.append(d_1)
    cell_remain = plic_cell_remain(normal_1, d_1, dx, dy)
    cell_1 = plic_cell_remain(-normal_1, -d_1, dx, dy)
    if len(cell_1) > 2:
        cell_1 = [phase_exis[0], cell_1, 0]
        cells.append(cell_1)
        vol_1 = get_cell_volume_new(cell_1[1])
        error_1 = sf[phase_exis[0], 1, 1] - vol_1 / (dx * dy)
        errors[phase_exis[0]] = error_1
    else:
        vol_1 = 0
        error_1 = sf[phase_exis[0], 1, 1] - vol_1 / (dx * dy)
        errors[phase_exis[0]] = error_1
    if count > 2:
        # print(sf[:, 1, 1])
        sf_2 = sf[phase_exis[1]]
        sf_3 = sf[phase_exis[2]]
        z_avg = np.sqrt(dx * dy)
        min_inter_l = tolerance
        tp_l = np.array([0., 0.])
        tp_s = np.array([0., 0.])
        if abs(normal_1[1]) >= abs(normal_1[0]):
            ### identification of the start point
            ### compare intersection with x=0(y=d/n2) and y=0(x=d/n1)
            ang_cos = abs(normal_1[1])
            x_large = 9 * z_avg * ang_cos
            x_small = -9 * z_avg * ang_cos
            y_large = (d_1 - normal_1[0] * x_large) / normal_1[1]
            y_small = (d_1 - normal_1[0] * x_small) / normal_1[1]
        else:
            ang_cos = abs(normal_1[0])
            y_large = 9 * z_avg * ang_cos
            x_large = (d_1 - normal_1[1] * y_large) / normal_1[0]
            y_small = -9 * z_avg * ang_cos
            x_small = (d_1 - normal_1[1] * y_small) / normal_1[0]
        tp_l[0] = x_large
        tp_l[1] = y_large
        tp_s[0] = x_small
        tp_s[1] = y_small
        interval = tp_l - tp_s
        interval_l = np.sqrt(interval[0] ** 2 + interval[1] ** 2)
        while interval_l > min_inter_l:
            tp_mid1 = tp_l - (tp_l - tp_s) / gr
            tp_mid2 = tp_s + (tp_l - tp_s) / gr
            # print(tp_mid1, tp_mid2)
            normal_mid1_1, _, normal_mid1_2, _ = get_normal_angleSearch_GS(cell_remain, tp_mid1, sf_2, dx, dy, tolerance, normal_1)
            if not np.isnan(normal_mid1_1).all():
                error_mid1_1 = get_er_choi(tp_mid1, normal_1, d_1, normal_mid1_1, sf_2, sf_3, dx, dy)
            else:
                error_mid1_1 = float('inf')
            if not np.isnan(normal_mid1_2).all():
                error_mid1_2 = get_er_choi(tp_mid1, normal_1, d_1, normal_mid1_2, sf_2, sf_3, dx, dy)
            else:
                error_mid1_2 = float('inf')
            error_mid1 = min(error_mid1_1, error_mid1_2)
            normal_mid2_1, _, normal_mid2_2, _ = get_normal_angleSearch_GS(cell_remain, tp_mid2, sf_2, dx, dy, tolerance, normal_1)
            if not np.isnan(normal_mid2_1).all():
                error_mid2_1 = get_er_choi(tp_mid2, normal_1, d_1, normal_mid2_1, sf_2, sf_3, dx, dy)
            else:
                error_mid2_1 = float('inf')
            if not np.isnan(normal_mid2_2).all():
                error_mid2_2 = get_er_choi(tp_mid2, normal_1, d_1, normal_mid2_2, sf_2, sf_3, dx, dy)
            else:
                error_mid2_2 = float('inf')
            error_mid2 = min(error_mid2_1, error_mid2_2)
            if error_mid1 < error_mid2:
                tp_l = tp_mid2
            else:
                tp_s = tp_mid1
            interval = tp_l - tp_s
            interval_l = np.sqrt(interval[0] ** 2 + interval[1] ** 2)
            # print(error_mid1, error_mid2)
        tp = 0.5 * (tp_s + tp_l)
        normal1, _, normal2, _ = get_normal_angleSearch_GS(cell_remain, tp, sf_2, dx, dy, tolerance, normal_1)
        error_choi_1 = get_er_choi(tp, normal_1, d_1, normal1, sf_2, sf_3, dx, dy)
        error_choi_2 = get_er_choi(tp, normal_1, d_1, normal2, sf_2, sf_3, dx, dy)
        if error_choi_1 >= error_choi_2:
            normal = normal2
        else:
            normal = normal1
        normals.append(normal)
        d_23 = normal.dot(tp)
        d.append(d_23)
        intersects = plic_get_intersects(cell_remain, normal, d_23)
        cell_2 = plic_cell_remain_with_intersects(normal, d_23, cell_remain, intersects)
        if len(cell_2) > 2:
            cell_2 = [phase_exis[2], cell_2, 0]
            cells.append(cell_2)
            vol_2 = get_cell_volume_new(cell_2[1])
            error_2 = sf[phase_exis[2], 1, 1] - vol_2 / (dx * dy)
            errors[phase_exis[2]] = error_2
        else:
            vol_2 = 0
            error_2 = sf[phase_exis[2], 1, 1] - vol_2 / (dx * dy)
            errors[phase_exis[2]] = error_2
        cell_3 = plic_cell_remain_with_intersects(-normal, -d_23, cell_remain, intersects)
        if len(cell_3) > 2:
            cell_3 = [phase_exis[1], cell_3, 0]
            cells.append(cell_3)
            vol_3 = dx * dy - (vol_1 + vol_2)
            error_3 = sf[phase_exis[1], 1, 1] - vol_3 / (dx * dy)
            errors[phase_exis[1]] = error_3
        else:
            vol_3 = 0
            error_3 = sf[phase_exis[1], 1, 1] - vol_3 / (dx * dy)
            errors[phase_exis[1]] = error_3
        error = abs(errors[0]) + abs(errors[1]) + abs(errors[2])
    else:
        cell_2 = cell_remain
        if len(cell_2) > 2:
            cell_2 = [phase_exis[1], cell_2, 0]
            cells.append(cell_2)
            vol_2 = dx * dy - vol_1
            error_2 = sf[phase_exis[1], 1, 1] - vol_2 / (dx * dy)
            errors[phase_exis[1]] = error_2
        else:
            vol_2 = 0
            error_2 = sf[phase_exis[1], 1, 1] - vol_2 / (dx * dy)
            errors[phase_exis[1]] = error_2
        error = abs(errors[0]) + abs(errors[1])
    return normals, d, cells, errors, error

### THIS FUNCTION DIRECTLY CALCULATE THE RANGE OF THE GOLDEN SEARCH
def PLIC_2d_tripleP_GS(sf, dx, dy, phase_exis, tolerance):
    normals = []
    d = []
    cells = []
    gr = (math.sqrt(5) + 1) / 2
    errors = np.zeros([len(sf)])
    count = len(phase_exis)
    ###
    sf_1 = sf[phase_exis[0]]
    grads = gradient_point(sf_1, 1, 1, dx, dy)
    normal_1 = -grads
    normals.append(normal_1)
    d_1 = get_d_lineSearch_DP5(normal_1, dx, dy, sf_1[1, 1], tolerance)
    d.append(d_1)
    cell_remain = plic_cell_remain(normal_1, d_1, dx, dy)
    cell_1 = plic_cell_remain(-normal_1, -d_1, dx, dy)
    if len(cell_1) > 2:
        cell_1 = [phase_exis[0], cell_1, 0]
        cells.append(cell_1)
        vol_1 = get_cell_volume_new(cell_1[1])
        error_1 = sf[phase_exis[0], 1, 1] - vol_1 / (dx * dy)
        errors[phase_exis[0]] = error_1
    else:
        vol_1 = 0
        error_1 = sf[phase_exis[0], 1, 1] - vol_1 / (dx * dy)
        errors[phase_exis[0]] = error_1
    if count > 2:
        # print(sf[:, 1, 1])
        sf_2 = sf[phase_exis[1]]
        sf_3 = sf[phase_exis[2]]
        z_avg = np.sqrt(dx * dy)
        min_inter_l = tolerance
        tp_l = np.array([0., 0.])
        tp_s = np.array([0., 0.])
        if abs(normal_1[1]) >= abs(normal_1[0]):
            ### identification of the start point
            ### compare intersection with x=0(y=d/n2) and y=0(x=d/n1)
            ang_cos = abs(normal_1[1])
            x_large = 9 * z_avg * ang_cos
            x_small = -9 * z_avg * ang_cos
            y_large = (d_1 - normal_1[0] * x_large) / normal_1[1]
            y_small = (d_1 - normal_1[0] * x_small) / normal_1[1]
        else:
            ang_cos = abs(normal_1[0])
            y_large = 9 * z_avg * ang_cos
            x_large = (d_1 - normal_1[1] * y_large) / normal_1[0]
            y_small = -9 * z_avg * ang_cos
            x_small = (d_1 - normal_1[1] * y_small) / normal_1[0]
        tp_l[0] = x_large
        tp_l[1] = y_large
        tp_s[0] = x_small
        tp_s[1] = y_small
        interval = tp_l - tp_s
        interval_l = np.sqrt(interval[0] ** 2 + interval[1] ** 2)
        while interval_l > min_inter_l:
            tp_mid1 = tp_l - (tp_l - tp_s) / gr
            tp_mid2 = tp_s + (tp_l - tp_s) / gr
            # print(tp_mid1, tp_mid2)
            normal_mid1_1, _, normal_mid1_2, _ = get_normal_angleSearch_GS_direct(cell_remain, tp_mid1, sf_2, dx, dy, tolerance, normal_1)
            if not np.isnan(normal_mid1_1).all():
                error_mid1_1 = get_er_choi(tp_mid1, normal_1, d_1, normal_mid1_1, sf_2, sf_3, dx, dy)
            else:
                error_mid1_1 = float('inf')
            if not np.isnan(normal_mid1_2).all():
                error_mid1_2 = get_er_choi(tp_mid1, normal_1, d_1, normal_mid1_2, sf_2, sf_3, dx, dy)
            else:
                error_mid1_2 = float('inf')
            error_mid1 = min(error_mid1_1, error_mid1_2)
            normal_mid2_1, _, normal_mid2_2, _ = get_normal_angleSearch_GS_direct(cell_remain, tp_mid2, sf_2, dx, dy, tolerance, normal_1)
            if not np.isnan(normal_mid2_1).all():
                error_mid2_1 = get_er_choi(tp_mid2, normal_1, d_1, normal_mid2_1, sf_2, sf_3, dx, dy)
            else:
                error_mid2_1 = float('inf')
            if not np.isnan(normal_mid2_2).all():
                error_mid2_2 = get_er_choi(tp_mid2, normal_1, d_1, normal_mid2_2, sf_2, sf_3, dx, dy)
            else:
                error_mid2_2 = float('inf')
            error_mid2 = min(error_mid2_1, error_mid2_2)
            if error_mid1 < error_mid2:
                tp_l = tp_mid2
            else:
                tp_s = tp_mid1
            interval = tp_l - tp_s
            interval_l = np.sqrt(interval[0] ** 2 + interval[1] ** 2)
            # print(error_mid1, error_mid2)
        tp = 0.5 * (tp_s + tp_l)
        normal1, _, normal2, _ = get_normal_angleSearch_GS_direct(cell_remain, tp, sf_2, dx, dy, tolerance, normal_1)
        error_choi_1 = get_er_choi(tp, normal_1, d_1, normal1, sf_2, sf_3, dx, dy)
        error_choi_2 = get_er_choi(tp, normal_1, d_1, normal2, sf_2, sf_3, dx, dy)
        if error_choi_1 >= error_choi_2:
            normal = normal2
        else:
            normal = normal1
        normals.append(normal)
        d_23 = normal.dot(tp)
        d.append(d_23)
        intersects = plic_get_intersects(cell_remain, normal, d_23)
        cell_2 = plic_cell_remain_with_intersects(normal, d_23, cell_remain, intersects)
        if len(cell_2) > 2:
            cell_2 = [phase_exis[2], cell_2, 0]
            cells.append(cell_2)
            vol_2 = get_cell_volume_new(cell_2[1])
            error_2 = sf[phase_exis[2], 1, 1] - vol_2 / (dx * dy)
            errors[phase_exis[2]] = error_2
        else:
            vol_2 = 0
            error_2 = sf[phase_exis[2], 1, 1] - vol_2 / (dx * dy)
            errors[phase_exis[2]] = error_2
        cell_3 = plic_cell_remain_with_intersects(-normal, -d_23, cell_remain, intersects)
        if len(cell_3) > 2:
            cell_3 = [phase_exis[1], cell_3, 0]
            cells.append(cell_3)
            vol_3 = dx * dy - (vol_1 + vol_2)
            error_3 = sf[phase_exis[1], 1, 1] - vol_3 / (dx * dy)
            errors[phase_exis[1]] = error_3
        else:
            vol_3 = 0
            error_3 = sf[phase_exis[1], 1, 1] - vol_3 / (dx * dy)
            errors[phase_exis[1]] = error_3
        error = abs(errors[0]) + abs(errors[1]) + abs(errors[2])
    else:
        cell_2 = cell_remain
        if len(cell_2) > 2:
            cell_2 = [phase_exis[1], cell_2, 0]
            cells.append(cell_2)
            vol_2 = dx * dy - vol_1
            error_2 = sf[phase_exis[1], 1, 1] - vol_2 / (dx * dy)
            errors[phase_exis[1]] = error_2
        else:
            vol_2 = 0
            error_2 = sf[phase_exis[1], 1, 1] - vol_2 / (dx * dy)
            errors[phase_exis[1]] = error_2
        error = abs(errors[0]) + abs(errors[1])
    return normals, d, cells, errors, error

def PLIC_2d_tripleP_linear(sf, dx, dy, i, j, phase_exis, plic_err):
    normals = []
    d = []
    ###
    sf_1 = sf[phase_exis[0]]
    grads = gradient_point(sf_1, i, j, dx, dy)
    normal_1 = -grads
    normals.append(normal_1)
    d_1 = get_d_lineSearch_DP5(normal_1, dx, dy, sf_1[i, j], plic_err)
    d.append(d_1)
    count = len(phase_exis)
    errors = np.zeros([len(sf)])
    cell_remain = plic_cell_remain(normal_1, d_1, dx, dy)
    cell_1 = plic_cell_remain(-normal_1, -d_1, dx, dy)
    cell_1 = [phase_exis[0], cell_1, 0]
    if count > 2:
        sf_2 = sf[phase_exis[1]]
        sf_3 = sf[phase_exis[2]]
        grads_2 = gradient_point(sf_2, i, j, dx, dy)
        normal_2 = -grads_2
        grads_3 = gradient_point(sf_3, i, j, dx, dy)
        normal_3 = -grads_3
        dir = normal_2 - normal_3
        z_avg = np.sqrt(dx * dy)
        error_L = []
        error_min = float('inf')
        tp_p = np.array([0., 0.])
        normal_p = np.array([0., 0.])
        if abs(normal_1[1]) >= abs(normal_1[0]):
            ang_cos = abs(normal_1[1])
            z_L = np.linspace(-9 * z_avg * ang_cos, 9 * z_avg * ang_cos, 180)
            for iz in range(len(z_L)):
                z = z_L[iz]
                tp = np.array([0., 0.])
                x = z
                y = (d_1 - normal_1[0] * x) / normal_1[1]
                tp[0] = x
                tp[1] = y
                # normal, vol = get_normal_angleSearch_GS(cell_remain, tp, sf_2, dir, i, j, dx, dy)
                normal, vol = get_normal_angleSearch(cell_remain, tp, sf_2, dir, i, j, dx, dy)
                if normal[0] is not None and normal[1] is not None:
                    error = get_er_choi(tp, normal_1, d_1, normal, sf_2, sf_3, dx, dy)
                else:
                    error = float('inf')
                ###note the least error condition
                if error < error_min:
                    error_min = error
                    tp_p = tp
                    normal_p = normal
                    # print(x, y, normal, error)
                error_L.append(error)
        else:
            ang_cos = abs(normal_1[0])
            z_L = np.linspace(-9 * z_avg * ang_cos, 9 * z_avg * ang_cos, 180)
            for iz in range(len(z_L)):
                z = z_L[iz]
                tp = np.array([0., 0.])
                y = z
                x = (d_1 - normal_1[1] * y) / normal_1[0]
                tp[0] = x
                tp[1] = y
                # normal, vol = get_normal_angleSearch_GS(cell_remain, tp, sf_2, dir, i, j, dx, dy)
                normal, vol = get_normal_angleSearch(cell_remain, tp, sf_2, dir, i, j, dx, dy)
                if normal[0] is not None and normal[1] is not None:
                    error = get_er_choi(tp, normal_1, d_1, normal, sf_2, sf_3, dx, dy)
                else:
                    error = float('inf')
                if error < error_min:
                    error_min = error
                    tp_p = tp
                    normal_p = normal
                error_L.append(error)
        # print('the minimum error is: ', error_min)
        normals.append(normal_p)
        d_23 = normal_p.dot(tp_p)
        d.append(d_23)
        # plt.figure()
        # plt.plot(z_L, error_L)
        # plt.show()
        intersects = plic_get_intersects(cell_remain, normal_p, d_23)
        cell_2 = plic_cell_remain_with_intersects(normal_p, d_23, cell_remain, intersects)
        cell_2 = [phase_exis[2], cell_2, 0]
        cell_3 = plic_cell_remain_with_intersects(-normal_p, -d_23, cell_remain, intersects)
        cell_3 = [phase_exis[1], cell_3, 0]
        cells = [cell_1, cell_2, cell_3]
        # plt.savefig('./err_{}.png'.format(time.time()), format='png', dpi=100)
        vol_1 = get_cell_volume_new(cell_1[1])
        error_1 = sf[phase_exis[0], i, j] - vol_1 / (dx * dy)
        errors[phase_exis[0]] = error_1
        vol_2 = get_cell_volume_new(cell_2[1])
        error_2 = sf[phase_exis[2], i, j] - vol_2 / (dx * dy)
        errors[phase_exis[2]] = error_2
        vol_3 = dx * dy - (vol_1 + vol_2)
        error_3 = sf[phase_exis[1], i, j] - vol_3 / (dx * dy)
        errors[phase_exis[1]] = error_3
        error = abs(errors[0]) + abs(errors[1]) + abs(errors[2])
    else:
        cell_2 = cell_remain
        cell_2 = [phase_exis[1], cell_2, 0]
        cells = [cell_1, cell_2]
        ### calculate the reconstruction errors
        vol_1 = get_cell_volume_new(cell_1[1])
        error_1 = sf[phase_exis[0], i, j] - vol_1 / (dx * dy)
        errors[phase_exis[0]] = error_1
        vol_2 = dx * dy - vol_1
        error_2 = sf[phase_exis[1], i, j] - vol_2 / (dx * dy)
        errors[phase_exis[1]] = error_2
        error = abs(errors[0]) + abs(errors[1])
    return normals, d, cells, errors, error

### copy
def PLIC_2d_tripleP_Dichotomy_copy(sf, dx, dy, i, j, phase_exis, plic_err):
    normals = []
    d = []
    ###
    sf_1 = sf[phase_exis[0]]
    grads = gradient_point(sf_1, i, j, dx, dy)
    normal_1 = -grads
    normals.append(normal_1)
    d_1 = get_d_lineSearch_DP5(normal_1, dx, dy, sf_1[i, j], plic_err)
    d.append(d_1)
    count = len(phase_exis)
    cell_remain = plic_cell_remain(normal_1, d_1, dx, dy)
    if count > 2:
        sf_2 = sf[phase_exis[1]]
        sf_3 = sf[phase_exis[2]]
        grads_2 = gradient_point(sf_2, i, j, dx, dy)
        normal_2 = -grads_2
        grads_3 = gradient_point(sf_3, i, j, dx, dy)
        normal_3 = -grads_3
        dir = normal_2 - normal_3
        z_avg = np.sqrt(dx * dy)
        z_L = np.linspace(-9 * z_avg, 9 * z_avg, 180)
        error_L = []
        error_min = float('inf')
        tp_p = np.array([0., 0.])
        normal_p = np.array([0., 0.])
        for iz in range(len(z_L)):
            z = z_L[iz]
            tp = np.array([0., 0.])
            if normal_1[1] != 0:
                x = z
                y = (d_1 - normal_1[0] * z) / normal_1[1]
                tp[0] = x
                tp[1] = y
            else:
                y = z
                x = (d_1 - normal_1[1] * z) / normal_1[0]
                tp[0] = x
                tp[1] = y
            # print(tp)
            normal, volume = get_normal_angleSearch(cell_remain, tp, sf_2, dir, i, j, dx, dy)
            # print(normal)
            if normal[0] is not None and normal[1] is not None:
                error = get_er_choi(tp, normal_1, d_1, normal, sf_2, sf_3, dx, dy)
            else:
                error = float('inf')
            ###note the least error condition
            if error < error_min:
                error_min = error
                tp_p = tp
                normal_p = normal
            error_L.append(error)
        normals.append(normal_p)
        d_23 = normal_p.dot(tp_p)
        d.append(d_23)
        plt.figure()
        plt.plot(z_L, error_L)
        plt.savefig('errors.png')
        plt.close()
        # plt.show()
    else:
        pass
    return normals, d

def PLIC_2d_hybrid(sf, dx, dy, phase_exis, tolerance):
    normals = []
    d = []
    cells = []
    sep = 361
    count = len(phase_exis)
    errors = np.zeros([len(sf)])
    ###
    if count == 2:
        # sf_eliminated = stencil_eliminate(sf, phase_exis)
        sf_1 = sf[phase_exis[0]]
        # sf_1_eli = sf_eliminated[phase_exis[0]]
        grads = gradient_point(sf_1, 1, 1, dx, dy)
        normal_1 = -grads
        normals.append(normal_1)
        d_1 = get_d_lineSearch_DP5(normal_1, dx, dy, sf_1[1, 1], tolerance)
        d.append(d_1)
        cell_remain = plic_cell_remain(normal_1, d_1, dx, dy)
        cell_1 = plic_cell_remain(-normal_1, -d_1, dx, dy)
        if len(cell_1) > 2:
            cell_1 = [phase_exis[0], cell_1, 0]
            cells.append(cell_1)
            vol_1 = get_cell_volume_shapely(cell_1[1])
            error_1 = sf[phase_exis[0], 1, 1] - vol_1 / (dx * dy)
            errors[phase_exis[0]] = error_1
        else:
            vol_1 = 0
            error_1 = sf[phase_exis[0], 1, 1] - vol_1 / (dx * dy)
            errors[phase_exis[0]] = error_1
        cell_2 = cell_remain
        if len(cell_2) > 2:
            cell_2 = [phase_exis[1], cell_2, 0]
            cells.append(cell_2)
            vol_2 = dx * dy - vol_1
            error_2 = sf[phase_exis[1], 1, 1] - vol_2 / (dx * dy)
            errors[phase_exis[1]] = error_2
        else:
            vol_2 = 0
            error_2 = sf[phase_exis[1], 1, 1] - vol_2 / (dx * dy)
            errors[phase_exis[1]] = error_2
        error = abs(errors[0]) + abs(errors[1])
    elif count > 2:
        sf_1 = sf[phase_exis[0]]
        grads = gradient_point(sf_1, 1, 1, dx, dy)
        normal_1 = -grads
        normals.append(normal_1)
        d_1 = get_d_lineSearch_DP5(normal_1, dx, dy, sf_1[1, 1], tolerance)
        d.append(d_1)
        cell_remain = plic_cell_remain(normal_1, d_1, dx, dy)
        cell_1 = plic_cell_remain(-normal_1, -d_1, dx, dy)
        if len(cell_1) > 2:
            cell_1 = [phase_exis[0], cell_1, 0]
            cells.append(cell_1)
            vol_1 = get_cell_volume_shapely(cell_1[1])
            error_1 = sf[phase_exis[0], 1, 1] - vol_1 / (dx * dy)
            # print(error_1)
            errors[phase_exis[0]] = error_1
        else:
            # cell_1 = [phase_exis[0], np.array([None, None]), 0]
            # cells.append(cell_1)
            # print('here, cell1')
            vol_1 = 0
            error_1 = sf[phase_exis[0], 1, 1] - vol_1 / (dx * dy)
            errors[phase_exis[0]] = error_1
        ################################## LINEAR SEARCH : NARROW THE GOLDEN SEARCH RANGE ##############################
        sf_2 = sf[phase_exis[1]]
        sf_3 = sf[phase_exis[2]]
        grads_2 = gradient_point(sf_2, 1, 1, dx, dy)
        normal_2 = -grads_2
        grads_3 = gradient_point(sf_3, 1, 1, dx, dy)
        normal_3 = -grads_3
        dir = normal_2 - normal_3
        z_avg = np.sqrt(dx * dy)
        # error_L = []
        error_min = float('inf')
        tp_p = np.array([None, None])
        theta_p = 0
        if abs(normal_1[1]) >= abs(normal_1[0]):
            ang_cos = abs(normal_1[1])
            z_L = np.linspace(-9 * z_avg * ang_cos, 9 * z_avg * ang_cos, 180)
            for iz in range(len(z_L)):
                z = z_L[iz]
                tp = np.array([0., 0.])
                x = z
                y = (d_1 - normal_1[0] * x) / normal_1[1]
                tp[0] = x
                tp[1] = y
                normal, vol, theta = get_normal_angleSearch_hybrid(cell_remain, tp, sf_2, dir, dx, dy, sep)
                # print(tp, normal, vol / (dx * dy), sf_2[1, 1], theta)
                if normal[0] is not None and normal[1] is not None:
                    error = get_er_choi(tp, normal_1, d_1, normal, sf_2, sf_3, dx, dy)
                else:
                    error = float('inf')
                # if error < error_min and vol / (dx * dy) * (1 - vol / (dx * dy)) != 0:
                if error < error_min:
                    error_min = error
                    tp_p = tp
                    theta_p = theta
                # error_L.append(error)
        else:
            ang_cos = abs(normal_1[0])
            z_L = np.linspace(-9 * z_avg * ang_cos, 9 * z_avg * ang_cos, 180)
            for iz in range(len(z_L)):
                z = z_L[iz]
                tp = np.array([0., 0.])
                y = z
                x = (d_1 - normal_1[1] * y) / normal_1[0]
                tp[0] = x
                tp[1] = y
                normal, vol, theta = get_normal_angleSearch_hybrid(cell_remain, tp, sf_2, dir, dx, dy, sep)
                # print(tp, normal, vol/(dx *dy), sf_2[1, 1], theta)
                if normal[0] is not None and normal[1] is not None:
                    error = get_er_choi(tp, normal_1, d_1, normal, sf_2, sf_3, dx, dy)
                    # print(error)
                else:
                    error = float('inf')
                #### NOTICE: MAKE SURE THE get_normal_angleSearch_hybrid INTERSECTS WITH THE CENTER CELL
                # if error < error_min and vol / (dx * dy) * (1 - vol / (dx * dy)) != 0:
                if error < error_min:
                    error_min = error
                    tp_p = tp
                    theta_p = theta
                # error_L.append(error)
        ################################### USE GOLDEN SEARCH TO FIND EXACT NORMAL #####################################
        # print(theta_p, tp_p)
        normal_exact, vol_exact = get_normal_angleSearch_exact(cell_remain, tp_p, sf_2, dir, dx, dy, tolerance, theta_p, sep)
        # print(vol_exact)
        # print(normal_exact)
        # normal_exact = np.array([math.cos(theta_p), math.sin(theta_p)])
        normals.append(normal_exact)
        d_23 = normal_exact.dot(tp_p)
        d.append(d_23)
        intersects = plic_get_intersects(cell_remain, normal_exact, d_23)
        cell_2 = plic_cell_remain_with_intersects(normal_exact, d_23, cell_remain, intersects)
        if len(cell_2) > 2:
            cell_2 = [phase_exis[2], cell_2, 0]
            cells.append(cell_2)
            vol_2 = get_cell_volume_shapely(cell_2[1])
            # print(vol_2)
            error_2 = sf[phase_exis[2], 1, 1] - vol_2 / (dx * dy)
            # print(error_2)
            errors[phase_exis[2]] = error_2
        else:
            # cell_2 = [phase_exis[2], np.array([None, None]), 0]
            # cells.append(cell_2)
            # print('here, cell2')
            vol_2 = 0
            error_2 = sf[phase_exis[2], 1, 1] - vol_2 / (dx * dy)
            errors[phase_exis[2]] = error_2
        cell_3 = plic_cell_remain_with_intersects(-normal_exact, -d_23, cell_remain, intersects)
        if len(cell_3) > 2:
            cell_3 = [phase_exis[1], cell_3, 0]
            cells.append(cell_3)
            vol_3 = dx * dy - (vol_1 + vol_2)
            # print(vol_3)
            error_3 = sf[phase_exis[1], 1, 1] - vol_3 / (dx * dy)
            # print(error_3)
            errors[phase_exis[1]] = error_3
        else:
            # cell_3 = [phase_exis[1], np.array([None, None]), 0]
            # cells.append(cell_3)
            # print('here, cell3')
            vol_3 = 0
            error_3 = sf[phase_exis[1], 1, 1] - vol_3 / (dx * dy)
            errors[phase_exis[1]] = error_3
        error = abs(errors[0]) + abs(errors[1]) + abs(errors[2])
    else:
        error = float('inf')
        print('more than 3 phase!')
    # print(error)
    return normals, d, cells, errors, error

### This function returns the separation based on specified phase
def PLIC_2d_specified(sf, dx, dy, i, j, phase_ind, resolution):
    ###first, reconstruct interface I1
    ###
    sf_1 = sf[phase_ind]
    ###gradients calculation
    grads = gradient_point(sf_1, i, j, dx, dy)
    ###assign normal vector as -gradient
    normal = -grads
    ###call the search function to search for the approximate d in equation n * x -d <= 0
    d = get_d_lineSearch_speci(normal, dx, dy, sf_1[i, j], resolution)
    return normal, d

### This function uses dichotomy search to improve the accuracy
def PLIC_DP5(sf, dx, dy, i, j, phase_ind, err_tar):
    ###first, reconstruct interface I1
    ###
    sf_1 = sf[phase_ind]
    ###gradients calculation
    grads = gradient_point(sf_1, i, j, dx, dy)
    ###assign normal vector as -gradient
    normal = -grads
    ###call the search function to search for the approximate d in equation n * x -d <= 0
    d = get_d_lineSearch_DP5(normal, dx, dy, sf_1[i, j], err_tar)
    return normal, d

### This is the multiprocessing version of PLIC reconstruction
def PLIC_mp(f, dx, dy, tolerance, num_p=12):
    result = np.zeros([len(f[0]), len(f[0, 0]), 1], dtype='int').tolist()
    manager = mp.Manager()
    return_dict = manager.dict()
    return_dict['recons'] = result
    que = Queue()
    recons_ghost = 1
    x_parts, y_parts = divide_domain(len(f[0]) - 2 * recons_ghost, len(f[0, 0]) - 2 * recons_ghost, num_p)
    info = {'f': f,
            'recons_ghost': recons_ghost,
            'dx': dx,
            'dy': dy,
            'tolerance': tolerance,
            'x_parts': x_parts,
            'y_parts': y_parts}
    processes = create_processes_PLIC_2(PLIC_mp_exc, combine_results_PLIC, info, que, return_dict)
    result = start_and_join_processes_PLIC(processes, return_dict)
    return result

def PLIC_mp_exc(info, que, start_x, end_x, start_y, end_y):
    ### initialize the sub_result
    sub_result = np.zeros([end_x - start_x, end_y - start_y, 1], dtype='int').tolist()
    # print(sub_result)
    f = info['f']
    ghost = info['recons_ghost']
    dx = info['dx']
    dy = info['dy']
    tolerance = info['tolerance']
    for i in range(end_x - start_x):
        for j in range(end_y - start_y):
            # print(i + start_x, j + start_y)
            sub_result[i][j].append({})
            pos = [i + ghost + start_x, j + ghost + start_y]
            sf_stencil = get_sf(pos, f)
            phase_exist = judge_phase_num(sf_stencil)
            if len(phase_exist) > 1:
                # normals, ds, cells, errors, error = PLIC_2d_tripleP_GSadv(sf_stencil, dx, dy, 1, 1, phase_exist, tolerance)
                normals, ds, cells, errors, error = PLIC_2d_hybrid(sf_stencil, dx, dy, phase_exist, tolerance)
                ### JUDGE IF NEED TO SWITCH TO YOUNGS' NESTED METHOD
                if error < tolerance * 10:
                    pass
                else:
                    normals, ds, cells, errors, error = Youngs_2d(sf_stencil, dx, dy, tolerance, phase_exist)
                sub_result[i][j][0] = 1
                sub_result[i][j][1]['method'] = 'PLIC'
                sub_result[i][j][1]['cells'] = cells
                sub_result[i][j][1]['normals'] = normals
                sub_result[i][j][1]['ds'] = ds
                sub_result[i][j][1]['errors'] = errors
                sub_result[i][j][1]['error'] = error
                if error > tolerance * 10:
                    print(i + start_x - (4 - ghost), j + start_y - (4 - ghost), errors)
                    print(sf_stencil)
                    print(normals)
                    print(ds)
                    print(cells)
                if len(phase_exist) > 2:
                    print(i + start_x - (4 - ghost), j + start_y - (4 - ghost), errors)
    que.put({'sub_result': sub_result, 'start_x': start_x, 'end_x': end_x, 'start_y': start_y, 'end_y': end_y})

def PLIC_mp2_exc(f, ghost, dx, dy, start_x, end_x, start_y, end_y, tolerance):
    ### in order to calculate the flux, reconstruct one more layer
    PLIC_recons = np.zeros([end_x - start_x + 2, end_y - start_y + 2, 1], dtype='int').tolist()
    for i in range(start_x - 1,  end_x + 1):
        for j in range(start_y - 1, end_y + 1):
            PLIC_recons[i - start_x + 1][j - start_y + 1].append({})
            pos = [i + ghost, j + ghost]
            sf_stencil = get_sf(pos, f)
            phase_exist = judge_phase_num(sf_stencil)
            if len(phase_exist) > 1:
                # normals, ds, cells, errors, error = PLIC_2d_tripleP_GSadv(sf_stencil, dx, dy, 1, 1, phase_exist, tolerance)
                normals, ds, cells, errors, error = PLIC_2d_tripleP_GS(sf_stencil, dx, dy, phase_exist, tolerance)
                ### JUDGE IF NEED TO SWITCH TO YOUNGS' NESTED METHOD
                if error < tolerance * 10:
                    pass
                else:
                    normals, ds, cells, errors, error = Youngs_2d(sf_stencil, dx, dy, tolerance, phase_exist)
                PLIC_recons[i - start_x + 1][j - start_y + 1][0] = 1
                PLIC_recons[i - start_x + 1][j - start_y + 1][1]['method'] = 'PLIC'
                PLIC_recons[i - start_x + 1][j - start_y + 1][1]['cells'] = cells
                PLIC_recons[i - start_x + 1][j - start_y + 1][1]['normals'] = normals
                PLIC_recons[i - start_x + 1][j - start_y + 1][1]['ds'] = ds
                PLIC_recons[i - start_x + 1][j - start_y + 1][1]['errors'] = errors
                PLIC_recons[i - start_x + 1][j - start_y + 1][1]['error'] = error
            else:
                cell_ = np.array([[0., 0.],
                                  [dx, 0.],
                                  [dx, dy],
                                  [0., dy]])
                cell = [phase_exist[0], cell_, 0]
                cells = [cell]
                PLIC_recons[i - start_x + 1][j - start_y + 1][1]['cells'] = cells
    return PLIC_recons

def Grad_PLIC_mp2_exc(f, ghost, dx, dy, start_x, end_x, start_y, end_y, tolerance):
    ### in order to calculate the flux, reconstruct one more layer
    PLIC_recons = np.zeros([end_x - start_x + 2, end_y - start_y + 2, 1], dtype='int').tolist()
    for i in range(start_x - 1,  end_x + 1):
        for j in range(start_y - 1, end_y + 1):
            PLIC_recons[i - start_x + 1][j - start_y + 1].append({})
            pos = [i + ghost, j + ghost]
            sf_stencil = get_sf(pos, f)
            phase_exist = judge_phase_num(sf_stencil)
            if len(phase_exist) > 1:
                normals, ds, cells, errors, error = Youngs_2d(sf_stencil, dx, dy, tolerance, phase_exist)
                PLIC_recons[i - start_x + 1][j - start_y + 1][0] = 1
                PLIC_recons[i - start_x + 1][j - start_y + 1][1]['method'] = 'PLIC'
                PLIC_recons[i - start_x + 1][j - start_y + 1][1]['cells'] = cells
                PLIC_recons[i - start_x + 1][j - start_y + 1][1]['normals'] = normals
                PLIC_recons[i - start_x + 1][j - start_y + 1][1]['ds'] = ds
                PLIC_recons[i - start_x + 1][j - start_y + 1][1]['errors'] = errors
                PLIC_recons[i - start_x + 1][j - start_y + 1][1]['error'] = error
            else:
                cell_ = np.array([[0., 0.],
                                  [dx, 0.],
                                  [dx, dy],
                                  [0., dy]])
                cell = [phase_exist[0], cell_, 0]
                cells = [cell]
                PLIC_recons[i - start_x + 1][j - start_y + 1][1]['cells'] = cells
    return PLIC_recons

### This is the PLIC reconstruction for unsplit schemes, where uniform cell are reconstruct with entire cell
def PLIC_unsplit_mp(f, dx, dy, tolerance, num_p=12):
    result = np.zeros([len(f[0]), len(f[0, 0]), 1], dtype='int').tolist()
    manager = mp.Manager()
    return_dict = manager.dict()
    return_dict['recons'] = result
    que = Queue()
    recons_ghost = 1
    x_parts, y_parts = divide_domain(len(f[0]) - 2 * recons_ghost, len(f[0, 0]) - 2 * recons_ghost, num_p)
    info = {'f': f,
            'recons_ghost': recons_ghost,
            'dx': dx,
            'dy': dy,
            'tolerance': tolerance,
            'x_parts': x_parts,
            'y_parts': y_parts}
    processes = create_processes_PLIC_2(PLIC_unsplit_mp_exc, combine_results_PLIC, info, que, return_dict)
    result = start_and_join_processes_PLIC(processes, return_dict)
    return result

def PLIC_unsplit_mp_exc(info, que, start_x, end_x, start_y, end_y):
    ### initialize the sub_result
    sub_result = np.zeros([end_x - start_x, end_y - start_y, 1], dtype='int').tolist()
    # print(sub_result)
    f = info['f']
    ghost = info['recons_ghost']
    dx = info['dx']
    dy = info['dy']
    tolerance = info['tolerance']
    for i in range(end_x - start_x):
        for j in range(end_y - start_y):
            # print(i + start_x, j + start_y)
            sub_result[i][j].append({})
            pos = [i + ghost + start_x, j + ghost + start_y]
            sf_stencil = get_sf(pos, f)
            phase_exist = judge_phase_num(sf_stencil)
            if len(phase_exist) > 1:
                # normals, ds, cells, errors, error = PLIC_2d_tripleP_GSadv(sf_stencil, dx, dy, 1, 1, phase_exist, tolerance)
                normals, ds, cells, errors, error = PLIC_2d_hybrid(sf_stencil, dx, dy, phase_exist, tolerance)
                sub_result[i][j][0] = 1
                sub_result[i][j][1]['method'] = 'PLIC'
                sub_result[i][j][1]['cells'] = cells
                sub_result[i][j][1]['normals'] = normals
                sub_result[i][j][1]['ds'] = ds
                sub_result[i][j][1]['errors'] = errors
                sub_result[i][j][1]['error'] = error
                # if error > 1e-7:
                #     print(i + start_x - (4 - ghost), j + start_y - (4 - ghost), errors)
                #     print(sf_stencil)
                #     print(normals)
                #     print(ds)
                #     print(cells)
                # if len(phase_exist) > 2:
                #     print(i + start_x - (4 - ghost), j + start_y - (4 - ghost), errors)
            else:
                cell_ = np.array([[0., 0.],
                                 [dx, 0.],
                                 [dx, dy],
                                 [0., dy]])
                cell = [phase_exist[0], cell_, 0]
                cells = [cell]
                sub_result[i][j][1]['cells'] = cells

    que.put({'sub_result': sub_result, 'start_x': start_x, 'end_x': end_x, 'start_y': start_y, 'end_y': end_y})

### THIS EXACT PLIC INTERFACE RECONSTRUCTION USES BUSSMANN AS A FIRST TRY, IF THE ERROR IS LARGER THAN TOLERANCE, THEN
### USES YOUNGS'S NESTED METHOD

def PLIC_unsplit_exact_mp(f, dx, dy, tolerance, num_p=12):
    result = np.zeros([len(f[0]), len(f[0, 0]), 1], dtype='int').tolist()
    manager = mp.Manager()
    return_dict = manager.dict()
    return_dict['recons'] = result
    que = Queue()
    recons_ghost = 1
    x_parts, y_parts = divide_domain(len(f[0]) - 2 * recons_ghost, len(f[0, 0]) - 2 * recons_ghost, num_p)
    info = {'f': f,
            'recons_ghost': recons_ghost,
            'dx': dx,
            'dy': dy,
            'tolerance': tolerance,
            'x_parts': x_parts,
            'y_parts': y_parts}
    processes = create_processes_PLIC_2(PLIC_unsplit_exact_mp_exc, combine_results_PLIC, info, que, return_dict)
    result = start_and_join_processes_PLIC(processes, return_dict)
    return result

def PLIC_unsplit_exact_mp_exc(info, que, start_x, end_x, start_y, end_y):
    ### initialize the sub_result
    sub_result = np.zeros([end_x - start_x, end_y - start_y, 1], dtype='int').tolist()
    f = info['f']
    ghost = info['recons_ghost']
    dx = info['dx']
    dy = info['dy']
    tolerance = info['tolerance']
    for i in range(end_x - start_x):
        for j in range(end_y - start_y):
            sub_result[i][j].append({})
            pos = [i + ghost + start_x, j + ghost + start_y]
            sf_stencil = get_sf(pos, f)
            phase_exist = judge_phase_num(sf_stencil)
            if len(phase_exist) > 1:
                # normals, ds, cells, errors, error = PLIC_2d_tripleP_GSadv(sf_stencil, dx, dy, phase_exist, tolerance)
                normals, ds, cells, errors, error = PLIC_2d_tripleP_GS(sf_stencil, dx, dy, phase_exist, tolerance)
                ### JUDGE IF NEED TO SWITCH TO YOUNGS' NESTED METHOD
                if error < tolerance * 10:
                    pass
                else:
                    # print('YOUNGS')
                    normals, ds, cells, errors, error = Youngs_2d(sf_stencil, dx, dy, tolerance, phase_exist)
                    # print(i + start_x, j + start_y, errors)
                sub_result[i][j][0] = 1
                sub_result[i][j][1]['method'] = 'PLIC'
                sub_result[i][j][1]['cells'] = cells
                sub_result[i][j][1]['normals'] = normals
                sub_result[i][j][1]['ds'] = ds
                sub_result[i][j][1]['errors'] = errors
                sub_result[i][j][1]['error'] = error
            else:
                cell_ = np.array([[0., 0.],
                                 [dx, 0.],
                                 [dx, dy],
                                 [0., dy]])
                cell = [phase_exist[0], cell_, 0]
                cells = [cell]
                sub_result[i][j][1]['cells'] = cells
    que.put({'sub_result': sub_result, 'start_x': start_x, 'end_x': end_x, 'start_y': start_y, 'end_y': end_y})

def Grad_PLIC_unsplit_exact_mp(f, dx, dy, tolerance, num_p=12):
    result = np.zeros([len(f[0]), len(f[0, 0]), 1], dtype='int').tolist()
    manager = mp.Manager()
    return_dict = manager.dict()
    return_dict['recons'] = result
    que = Queue()
    recons_ghost = 1
    x_parts, y_parts = divide_domain(len(f[0]) - 2 * recons_ghost, len(f[0, 0]) - 2 * recons_ghost, num_p)
    info = {'f': f,
            'recons_ghost': recons_ghost,
            'dx': dx,
            'dy': dy,
            'tolerance': tolerance,
            'x_parts': x_parts,
            'y_parts': y_parts}
    processes = create_processes_PLIC_2(Grad_PLIC_unsplit_exact_mp_exc, combine_results_PLIC, info, que, return_dict)
    result = start_and_join_processes_PLIC(processes, return_dict)
    return result

def Grad_PLIC_unsplit_exact_mp_exc(info, que, start_x, end_x, start_y, end_y):
    ### initialize the sub_result
    sub_result = np.zeros([end_x - start_x, end_y - start_y, 1], dtype='int').tolist()
    f = info['f']
    ghost = info['recons_ghost']
    dx = info['dx']
    dy = info['dy']
    tolerance = info['tolerance']
    for i in range(end_x - start_x):
        for j in range(end_y - start_y):
            sub_result[i][j].append({})
            pos = [i + ghost + start_x, j + ghost + start_y]
            sf_stencil = get_sf(pos, f)
            phase_exist = judge_phase_num(sf_stencil)
            if len(phase_exist) > 1:
                normals, ds, cells, errors, error = Youngs_2d(sf_stencil, dx, dy, tolerance, phase_exist)
                sub_result[i][j][0] = 1
                sub_result[i][j][1]['method'] = 'PLIC'
                sub_result[i][j][1]['cells'] = cells
                sub_result[i][j][1]['normals'] = normals
                sub_result[i][j][1]['ds'] = ds
                sub_result[i][j][1]['errors'] = errors
                sub_result[i][j][1]['error'] = error
            else:
                cell_ = np.array([[0., 0.],
                                 [dx, 0.],
                                 [dx, dy],
                                 [0., dy]])
                cell = [phase_exist[0], cell_, 0]
                cells = [cell]
                sub_result[i][j][1]['cells'] = cells
    que.put({'sub_result': sub_result, 'start_x': start_x, 'end_x': end_x, 'start_y': start_y, 'end_y': end_y})

### THIS FUNCTION RECIEVE THE SCO INFORMATION AND SKIP THE CELL WITH 0 VALUE

def PLIC_unsplit_exact_mp_sco(f, dx, dy, tolerance, num_p=12):
    result = np.zeros([len(f[0]), len(f[0, 0]), 1], dtype='int').tolist()
    manager = mp.Manager()
    return_dict = manager.dict()
    return_dict['recons'] = result
    que = Queue()
    recons_ghost = 1
    x_parts, y_parts = divide_domain(len(f[0]) - 2 * recons_ghost, len(f[0, 0]) - 2 * recons_ghost, num_p)
    info = {'f': f,
            'recons_ghost': recons_ghost,
            'dx': dx,
            'dy': dy,
            'tolerance': tolerance,
            'x_parts': x_parts,
            'y_parts': y_parts}
    processes = create_processes_PLIC_2(PLIC_unsplit_exact_mp_sco_exc, combine_results_PLIC, info, que, return_dict)
    result = start_and_join_processes_PLIC(processes, return_dict)
    return result

def PLIC_unsplit_exact_mp_sco_exc(info, que, start_x, end_x, start_y, end_y):
    ### initialize the sub_result
    sub_result = np.zeros([end_x - start_x, end_y - start_y, 1], dtype='int').tolist()
    # print(sub_result)
    f = info['f']
    ghost = info['recons_ghost']
    dx = info['dx']
    dy = info['dy']
    tolerance = info['tolerance']
    for i in range(end_x - start_x):
        for j in range(end_y - start_y):
            # print(i + start_x, j + start_y)
            sub_result[i][j].append({})
            pos = [i + ghost + start_x, j + ghost + start_y]
            sf_stencil = get_sf(pos, f)
            phase_exist = judge_phase_num(sf_stencil)
            if len(phase_exist) > 1:
                normals, ds, cells, errors, error = PLIC_2d_tripleP_GSadv(sf_stencil, dx, dy, phase_exist, tolerance)
                # print(errors)
                ### JUDGE IF NEED TO SWITCH TO YOUNGS' NESTED METHOD
                if error < tolerance * 10:
                    pass
                else:
                    normals, ds, cells, errors, error = Youngs_2d(sf_stencil, dx, dy, tolerance, phase_exist)
                sub_result[i][j][0] = 1
                sub_result[i][j][1]['method'] = 'PLIC'
                sub_result[i][j][1]['cells'] = cells
                sub_result[i][j][1]['normals'] = normals
                sub_result[i][j][1]['ds'] = ds
                sub_result[i][j][1]['errors'] = errors
                sub_result[i][j][1]['error'] = error
                sub_result[i][j][1]['sco'] = 1
            else:
                cell_ = np.array([[0., 0.],
                                 [dx, 0.],
                                 [dx, dy],
                                 [0., dy]])
                sco = get_sco_tag(sf_stencil, tolerance)
                if sco == 1:
                    sub_result[i][j][1]['sco'] = 1
                else:
                    sub_result[i][j][1]['sco'] = 0
                cell = [phase_exist[0], cell_, 0]
                cells = [cell]
                sub_result[i][j][1]['cells'] = cells
    que.put({'sub_result': sub_result, 'start_x': start_x, 'end_x': end_x, 'start_y': start_y, 'end_y': end_y})

def Grad_PLIC_unsplit_exact_mp_sco(f, dx, dy, tolerance, num_p=12):
    result = np.zeros([len(f[0]), len(f[0, 0]), 1], dtype='int').tolist()
    manager = mp.Manager()
    return_dict = manager.dict()
    return_dict['recons'] = result
    que = Queue()
    recons_ghost = 1
    x_parts, y_parts = divide_domain(len(f[0]) - 2 * recons_ghost, len(f[0, 0]) - 2 * recons_ghost, num_p)
    info = {'f': f,
            'recons_ghost': recons_ghost,
            'dx': dx,
            'dy': dy,
            'tolerance': tolerance,
            'x_parts': x_parts,
            'y_parts': y_parts}
    processes = create_processes_PLIC_2(Grad_PLIC_unsplit_exact_mp_sco_exc, combine_results_PLIC, info, que, return_dict)
    result = start_and_join_processes_PLIC(processes, return_dict)
    return result

def Grad_PLIC_unsplit_exact_mp_sco_exc(info, que, start_x, end_x, start_y, end_y):
    ### initialize the sub_result
    sub_result = np.zeros([end_x - start_x, end_y - start_y, 1], dtype='int').tolist()
    # print(sub_result)
    f = info['f']
    ghost = info['recons_ghost']
    dx = info['dx']
    dy = info['dy']
    tolerance = info['tolerance']
    for i in range(end_x - start_x):
        for j in range(end_y - start_y):
            # print(i + start_x, j + start_y)
            sub_result[i][j].append({})
            pos = [i + ghost + start_x, j + ghost + start_y]
            sf_stencil = get_sf(pos, f)
            phase_exist = judge_phase_num(sf_stencil)
            if len(phase_exist) > 1:
                normals, ds, cells, errors, error = Youngs_2d(sf_stencil, dx, dy, tolerance, phase_exist)
                sub_result[i][j][0] = 1
                sub_result[i][j][1]['method'] = 'PLIC'
                sub_result[i][j][1]['cells'] = cells
                sub_result[i][j][1]['normals'] = normals
                sub_result[i][j][1]['ds'] = ds
                sub_result[i][j][1]['errors'] = errors
                sub_result[i][j][1]['error'] = error
                sub_result[i][j][1]['sco'] = 1
            else:
                cell_ = np.array([[0., 0.],
                                 [dx, 0.],
                                 [dx, dy],
                                 [0., dy]])
                sco = get_sco_tag(sf_stencil, tolerance)
                if sco == 1:
                    sub_result[i][j][1]['sco'] = 1
                else:
                    sub_result[i][j][1]['sco'] = 0
                cell = [phase_exist[0], cell_, 0]
                cells = [cell]
                sub_result[i][j][1]['cells'] = cells
    que.put({'sub_result': sub_result, 'start_x': start_x, 'end_x': end_x, 'start_y': start_y, 'end_y': end_y})

# sf = np.array([[[0.19124227, 0.0068458,  0.04677452],
#                 [1.,         0.98626921, 0.9803205 ],
#                 [1.,         1.,         1.        ]],
#
#                 [[0.80875773, 0.54979913, 0.        ],
#                 [0.,         0.00742273, 0.        ],
#                 [0.,         0.,         0.        ]],
#
#                 [[0.,         0.44335507, 0.95322548],
#                 [0.,         0.00630806, 0.0196795 ],
#                 [0.,         0.,         0.        ]]])

# sf = np.array([[[0.,         0.,         0.07448664],
#               [0.01063087, 0.47671983, 0.88208358],
#               [0.65993837, 1.,         1.,        ]],
#
#              [[1.,         1.,         0.83145758],
#               [0.98936913, 0.45429053, 0.11791642],
#               [0.34006163, 0.,         0.        ]],
#
#              [[0.,         0.,         0.09405578],
#               [0.,         0.06898964, 0.        ],
#               [0.,         0.,         0.        ]]])


# phase_exist = judge_phase_num(sf)
# normals, ds, cells, errors, error = PLIC_2d_hybrid(sf, 0.03125, 0.03125, phase_exist, 1e-8)
# print(errors, error)



