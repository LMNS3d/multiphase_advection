###This is a multiphase fluid interface reconstruction script
###based on Volume of fluid method
###creator: Zhang, HKUST
from cmath import phase

from src.functions.new_function import *
from src.reconstruction.PLIC import *
from src.reconstruction.YOUNGS import *
from src.reconstruction.Old_sep_pretrain import get_sep_points_DP5
from src.functions.functions import get_cell_volume_shapely
import shapely

# from plot_function import *
### Single phase split for discontinuous condition, modified the min_move judge method
def Dynamic_Point_9(sf, dx, dy, tolerance, max_step, neigh_sep_point, sep_tags, neigh_sep_point_unlimited,
                    sep_tags_un, sep_recons_left):
    pos = [np.array([dx / 2, dy / 2])]
    posL = [[np.array([dx / 2, dy / 2])]]
    step = 0
    step_size = []
    # move_length = max(dx, dy)
    # smoothed = False
    ### cell is modified to have 8 points
    cell = np.array([[0., 0.], [0., dy / 2], [0., dy], [dx / 2, dy], [dx, dy], [dx, dy / 2], [dx, 0.], [dx / 2, 0.]])
    cells = []
    phase_num = len(sf)
    volumes = np.zeros([phase_num])
    errors = np.zeros([phase_num])
    error = dx * dy
    ### We interpolate the cell vertices and cell boundary mid-point volume fraction value from the scalar field by linear interpolation
    sub_sf = get_local_field_sym_4(sf)
    sub_sf_avg = get_local_field_sym(sf)
    ### first we construct the tag array in which record the dominate phase in each vertex or cell boundary
    tags = get_tag_2_new(sub_sf, sf)
    ### reshape the vertice tag into 1D list, starts from lower-left, clockwise
    tags_clk = get_tag_clk(tags)
    # print(tags_clk)
    ### judge if a specific phase only dominate an opposite pair
    judge = judge_still_phase(tags_clk, phase_num)
    # print(judge)
    ### no volume-still pair, only continuously connected phase
    if not judge.any():
        ### Then we construct the cell boundary cut in which each cell boundary is separate by two phase
        ### If the cell boundary is in between two same phase dominated vertice, no cut point is needed
        ### The cut point is to reach a balance between two different phases' influence
        sep_points = get_sep_points_DP5(sub_sf_avg, sub_sf, tags, dx, dy, neigh_sep_point, sep_tags, neigh_sep_point_unlimited, sep_tags_un, sep_recons_left)
        ### now we calculate the baseline and base vector
        base_line = get_baseline(sep_points, tags_clk)
        ### construct the base vector, which is perpendicular to the sep-point connection of a subcell
        base_vector = get_basevector_new(base_line, cell, dx, dy)
        ### get the list of subcells and the volumes of phases
        pos_single = pos[0]
        cells, volumes = get_subcells(phase_num, sep_points, tags_clk, pos_single, cell)
        ### after we calculate the volume fraction for the current triple point, the error can be computed
        error, errors = get_errors_linear(sf, dx, dy, volumes)
        while step <= max_step and error > tolerance:
            ### get the correction vector based on the error
            cor_vector = get_correction_vector_2(base_vector, base_line, errors, dx, dy)
            # print(cor_vector)
            ### update the DP positions
            pos, posL = update_position(pos, posL, cor_vector, 0, dx, dy)
            # print(pos, posL)
            ### update step
            step, step_size = update_step(step, step_size, cor_vector)
            ### get the list of subcells and the volumes of phases
            pos_single = pos[0]
            cells, volumes = get_subcells(phase_num, sep_points, tags_clk, pos_single, cell)
            ### after we calculate the volume fraction for the current triple point, the error can be computed
            error, errors = get_errors_linear(sf, dx, dy, volumes)
            # if len(posL) > 5:
            #     move = posL[-1][0] - posL[-2][0]
            #     move_length = np.sqrt(move[0] ** 2 + move[1] ** 2)
            # else:
            #     move_length = max(dx, dy)
    ### if there exist two opposite vertices dominated by the same phase k, a dynamic point split is necessary to
    ### make sure the phase k's volume fraction is adjustable
    else:
        ### first we get all the volume-still pairs, vertex/boundary mid-point based
        odd_pairs, normal_pairs = get_odd_pairs(tags_clk, judge)
        # print(odd_pairs, normal_pairs)
        ### if there is no normal pairs, all phases are not continuous around the cell
        if not normal_pairs:
            print('no normal pairs')
            print(odd_pairs, normal_pairs)
            while not normal_pairs:
                tags_clk, tags = fix_tag_2(tags_clk, tags, phase_num, odd_pairs)
                judge = judge_still_phase(tags_clk, phase_num)
                print('judge: ', judge)
                odd_pairs, normal_pairs = get_odd_pairs(tags_clk, judge)
                print('after fix: ', odd_pairs, normal_pairs)
            # ### fix according to the largest existing odd_phase
            # tags_clk, tags = fix_tag_2(tags_clk, tags, phase_num, odd_pairs)
            # judge = judge_still_phase(tags_clk, phase_num)
            ### if after fix, there is no odd_phase
            if not judge.any():
                # print('after fix, there is no odd_phase')
                ### Then we construct the cell boundary cut in which each cell boundary is separate by two phase
                ### If the cell boundary is in between two same phase dominated vertice, no cut point is needed
                ### The cut point is to reach a balance between two different phases' influence
                sep_points = get_sep_points_DP5(sub_sf_avg, sub_sf, tags, dx, dy, neigh_sep_point, sep_tags, neigh_sep_point_unlimited, sep_tags_un, sep_recons_left)
                ### now we calculate the baseline and base vector
                base_line = get_baseline(sep_points, tags_clk)
                ### construct the base vector, which is perpendicular to the sep-point connection of a subcell
                base_vector = get_basevector_new(base_line, cell, dx, dy)
                ### get the list of subcells and the volumes of phases
                pos_single = pos[0]
                cells, volumes = get_subcells(phase_num, sep_points, tags_clk, pos_single, cell)
                ### after we calculate the volume fraction for the current triple point, the error can be computed
                error, errors = get_errors_linear(sf, dx, dy, volumes)
                while step <= max_step and error > tolerance:
                    ### get the correction vector based on the error
                    cor_vector = get_correction_vector_2(base_vector, base_line, errors, dx, dy)
                    ### update the DP positions
                    pos, posL = update_position(pos, posL, cor_vector, 0, dx, dy)
                    ### update step
                    step, step_size = update_step(step, step_size, cor_vector)
                    ### get the list of subcells and the volumes of phases
                    pos_single = pos[0]
                    cells, volumes = get_subcells(phase_num, sep_points, tags_clk, pos_single, cell)
                    ### after we calculate the volume fraction for the current triple point, the error can be computed
                    error, errors = get_errors_linear(sf, dx, dy, volumes)
                    # if len(posL) > 5:
                    #     move = posL[-1][0] - posL[-2][0]
                    #     move_length = np.sqrt(move[0] ** 2 + move[1] ** 2)
                    # else:
                    #     move_length = max(dx, dy)
            ### if there still exist odd_phase, use the dp split
            else:
                # print('there still exist odd_phase, use the dp split')
                # odd_pairs, normal_pairs = get_odd_pairs(tags_clk, judge)
                # print(odd_pairs, normal_pairs)
                ### Then we construct the cell boundary cut in which each cell boundary is separate by two phase
                ### If the cell boundary is in between two same phase dominated vertice, no cut point is needed
                ### The cut point is to reach a balance between two different phases' influence
                sep_points = get_sep_points_DP5(sub_sf_avg, sub_sf, tags, dx, dy, neigh_sep_point, sep_tags, neigh_sep_point_unlimited, sep_tags_un, sep_recons_left)
                ### now we calculate the baseline and base vector
                base_line = get_baseline(sep_points, tags_clk)
                ### construct the base vector, which is perpendicular to the sep-point connection of a subcell
                base_vector = get_basevector_new(base_line, cell, dx, dy)
                error_tag = []
                for cp in range(len(normal_pairs)):
                    construct_v = normal_pairs[cp]
                    construct_tag = tags_clk[construct_v[0]]
                    ### add the current phase tag to the error tag list
                    error_tag.append(construct_tag)
                    pos_cur = pos[cp]
                    # print('the new position: ', pos)
                    ### iteratively calculate the existing volume fraction
                    ### and optimize(move) the triple point by an error-based vector
                    ### in this part the error and the position correction vector
                    ### is only calculated based on the first reconstruct vertice
                    ### second error measuring method error = f_predic - f_target
                    if cp == 0:
                        cells, volumes = get_subcells(phase_num, sep_points, tags_clk, pos_cur, cell)
                    else:
                        ### get the volumes and cells for the 2 dynamic point condition
                        cells, volumes = get_subcells_2dp(phase_num, sep_points, tags_clk, pos, cell, base_line,
                                                          error_tag[0],
                                                          error_tag[1], construct_v)
                    ### now, according to the phase volume fraction error, we construct the direction vector weights
                    ### then, add them up to construct the overall triple point position correction vector
                    error, errors = get_errors_linear_specifics(sf, dx, dy, volumes, error_tag)
                    move_length = 1.
                    while step <= max_step and error > tolerance:

                        cor_vector = get_correction_vector_specific_2(base_vector, base_line, errors, dx, dy,
                                                                      construct_tag)
                        pos, posL = update_position_DP9(pos, posL, cor_vector, cp, dx, dy)
                        # print(pos, posL)
                        step, step_size = update_step(step, step_size, cor_vector)
                        pos_cur = pos[cp]
                        if cp == 0:
                            cells, volumes = get_subcells(phase_num, sep_points, tags_clk, pos_cur, cell)
                            # if len(posL) > 5:
                            #     move = posL[-1][0] - posL[-2][0]
                            #     move_length = np.sqrt(move[0] ** 2 + move[1] ** 2)
                            # else:
                            #     move_length = max(dx, dy)
                        else:
                            cells, volumes = get_subcells_2dp(phase_num, sep_points, tags_clk, pos, cell, base_line,
                                                              error_tag[0],
                                                              error_tag[1], construct_v)
                            # if len(posL) > 5 and len(posL[-1]) == 2 and len(posL[-2]) == 2:
                            #     move = posL[-1][1] - posL[-2][1]
                            #     move_length = np.sqrt(move[0] ** 2 + move[1] ** 2)
                            # else:
                            #     move_length = max(dx, dy)
                        error, errors = get_errors_linear_specifics(sf, dx, dy, volumes, error_tag)
                    ### if there is more continuous phase to be reconstructed, split the dynamic point
                    if cp + 1 < len(normal_pairs):
                        # print('before new position: ', pos)
                        pos = generate_new_dp(pos)
                        # print('new position: ', pos)
                    ### reinitialize the correction vector and error for the next reconstrution
                    error = get_error_all(errors)
        ### there exist at least one continuous phase, we first reconstruct the continuous phase (cp)
        else:
            ### if there is more than or equal to 2 normal phase, use dp split directly
            if len(normal_pairs) >= 2:
                # print('split directly')
                ### Then we construct the cell boundary cut in which each cell boundary is separate by two phase
                ### If the cell boundary is in between two same phase dominated vertice, no cut point is needed
                ### The cut point is to reach a balance between two different phases' influence
                sep_points = get_sep_points_DP5(sub_sf_avg, sub_sf, tags, dx, dy, neigh_sep_point, sep_tags, neigh_sep_point_unlimited, sep_tags_un, sep_recons_left)
                ### now we calculate the baseline and base vector
                base_line = get_baseline(sep_points, tags_clk)
                ### construct the base vector, which is perpendicular to the sep-point connection of a subcell
                base_vector = get_basevector_new(base_line, cell, dx, dy)
                error_tag = []
                for cp in range(len(normal_pairs)):
                    construct_v = normal_pairs[cp]
                    construct_tag = tags_clk[construct_v[0]]
                    ### add the current phase tag to the error tag list
                    error_tag.append(construct_tag)
                    pos_cur = pos[cp]
                    # print('the new position: ', pos)
                    ### iteratively calculate the existing volume fraction
                    ### and optimize(move) the triple point by an error-based vector
                    ### in this part the error and the position correction vector
                    ### is only calculated based on the first reconstruct vertice
                    ### second error measuring method error = f_predic - f_target
                    if cp == 0:
                        cells, volumes = get_subcells(phase_num, sep_points, tags_clk, pos_cur, cell)
                    else:
                        ### get the volumes and cells for the 2 dynamic point condition
                        cells, volumes = get_subcells_2dp(phase_num, sep_points, tags_clk, pos, cell, base_line,
                                                          error_tag[0],
                                                          error_tag[1], construct_v)
                    ### now, according to the phase volume fraction error, we construct the direction vector weights
                    ### then, add them up to construct the overall triple point position correction vector
                    error, errors = get_errors_linear_specifics(sf, dx, dy, volumes, error_tag)
                    move_length = max(dx, dy)
                    while step <= max_step and error > tolerance:

                        cor_vector = get_correction_vector_specific_2(base_vector, base_line, errors, dx, dy,
                                                                      construct_tag)
                        pos, posL = update_position_DP9(pos, posL, cor_vector, cp, dx, dy)
                        step, step_size = update_step(step, step_size, cor_vector)
                        pos_cur = pos[cp]
                        if cp == 0:
                            cells, volumes = get_subcells(phase_num, sep_points, tags_clk, pos_cur, cell)
                            # if len(posL) > 5:
                            #     move = posL[-1][0] - posL[-2][0]
                            #     move_length = np.sqrt(move[0] ** 2 + move[1] ** 2)
                            # else:
                            #     move_length = max(dx, dy)
                        else:
                            cells, volumes = get_subcells_2dp(phase_num, sep_points, tags_clk, pos, cell, base_line,
                                                              error_tag[0],
                                                              error_tag[1], construct_v)
                            # if len(posL) > 5 and len(posL[-1]) == 2 and len(posL[-2]) == 2:
                            #     move = posL[-1][1] - posL[-2][1]
                            #     move_length = np.sqrt(move[0] ** 2 + move[1] ** 2)
                            # else:
                            #     move_length = max(dx, dy)
                        error, errors = get_errors_linear_specifics(sf, dx, dy, volumes, error_tag)
                    ### if there is more continuous phase to be reconstructed, split the dynamic point
                    if cp + 1 < len(normal_pairs):
                        # print('before new position: ', pos)
                        pos = generate_new_dp(pos)
                        # print('new position: ', pos)
                    ### reinitialize the correction vector and error for the next reconstrution
                    error = get_error_all(errors)
            ### fix according to the normal phase
            else:
                # print('fix')
                tags_clk, tags = fix_tag(tags_clk, tags, phase_num, normal_pairs)
                # print(tags_clk)
                judge = judge_still_phase(tags_clk, phase_num)
                ### if after fix, there is no odd_phase
                if not judge.any():
                    # print('After fix, there is no odd phase')
                    ### Then we construct the cell boundary cut in which each cell boundary is separate by two phase
                    ### If the cell boundary is in between two same phase dominated vertice, no cut point is needed
                    ### The cut point is to reach a balance between two different phases' influence
                    sep_points = get_sep_points_DP5(sub_sf_avg, sub_sf, tags, dx, dy, neigh_sep_point, sep_tags, neigh_sep_point_unlimited, sep_tags_un, sep_recons_left)
                    ### now we calculate the baseline and base vector
                    base_line = get_baseline(sep_points, tags_clk)
                    ### construct the base vector, which is perpendicular to the sep-point connection of a subcell
                    base_vector = get_basevector_new(base_line, cell, dx, dy)
                    ### get the list of subcells and the volumes of phases
                    pos_single = pos[0]
                    cells, volumes = get_subcells(phase_num, sep_points, tags_clk, pos_single, cell)
                    ### after we calculate the volume fraction for the current triple point, the error can be computed
                    error, errors = get_errors_linear(sf, dx, dy, volumes)
                    while step <= max_step and error > tolerance:
                        ### get the correction vector based on the error
                        cor_vector = get_correction_vector_2(base_vector, base_line, errors, dx, dy)
                        ### update the DP positions
                        pos, posL = update_position(pos, posL, cor_vector, 0, dx, dy)
                        ### update step
                        step, step_size = update_step(step, step_size, cor_vector)
                        ### get the list of subcells and the volumes of phases
                        pos_single = pos[0]
                        cells, volumes = get_subcells(phase_num, sep_points, tags_clk, pos_single, cell)
                        ### after we calculate the volume fraction for the current triple point, the error can be computed
                        error, errors = get_errors_linear(sf, dx, dy, volumes)
                        # if len(posL) > 5:
                        #     move = posL[-1][0] - posL[-2][0]
                        #     move_length = np.sqrt(move[0] ** 2 + move[1] ** 2)
                        # else:
                        #     move_length = max(dx, dy)
                ### if there is still odd_phase, then use dp split
                else:
                    # print('split after fix')
                    odd_pairs, normal_pairs = get_odd_pairs(tags_clk, judge)
                    ### Then we construct the cell boundary cut in which each cell boundary is separate by two phase
                    ### If the cell boundary is in between two same phase dominated vertice, no cut point is needed
                    ### The cut point is to reach a balance between two different phases' influence
                    sep_points = get_sep_points_DP5(sub_sf_avg, sub_sf, tags, dx, dy, neigh_sep_point, sep_tags, neigh_sep_point_unlimited, sep_tags_un, sep_recons_left)
                    ### now we calculate the baseline and base vector
                    base_line = get_baseline(sep_points, tags_clk)
                    # print(base_line)
                    ### construct the base vector, which is perpendicular to the sep-point connection of a subcell
                    base_vector = get_basevector_new(base_line, cell, dx, dy)
                    error_tag = []
                    for cp in range(len(normal_pairs)):
                        construct_v = normal_pairs[cp]
                        construct_tag = tags_clk[construct_v[0]]
                        ### add the current phase tag to the error tag list
                        error_tag.append(construct_tag)
                        pos_cur = pos[cp]
                        ### iteratively calculate the existing volume fraction
                        ### and optimize(move) the triple point by an error-based vector
                        ### in this part the error and the position correction vector
                        ### is only calculated based on the first reconstruct vertice
                        ### second error measuring method error = f_predic - f_target
                        if cp == 0:
                            cells, volumes = get_subcells(phase_num, sep_points, tags_clk, pos_cur, cell)
                        else:
                            ### get the volumes and cells for the 2 dynamic point condition
                            cells, volumes = get_subcells_2dp(phase_num, sep_points, tags_clk, pos, cell, base_line,
                                                              error_tag[0],
                                                              error_tag[1], construct_v)
                        ### now, according to the phase volume fraction error, we construct the direction vector weights
                        ### then, add them up to construct the overall triple point position correction vector
                        error, errors = get_errors_linear_specifics(sf, dx, dy, volumes, error_tag)
                        # move_length = max(dx, dy)
                        while step <= max_step and error > tolerance:

                            cor_vector = get_correction_vector_specific_2(base_vector, base_line, errors, dx, dy,
                                                                            construct_tag)
                            pos, posL = update_position_DP9(pos, posL, cor_vector, cp, dx, dy)
                            step, step_size = update_step(step, step_size, cor_vector)
                            pos_cur = pos[cp]
                            if cp == 0:
                                cells, volumes = get_subcells(phase_num, sep_points, tags_clk, pos_cur, cell)
                                # if len(posL) > 5:
                                #     move = posL[-1][0] - posL[-2][0]
                                #     move_length = np.sqrt(move[0] ** 2 + move[1] ** 2)
                                # else:
                                #     move_length = max(dx, dy)
                            else:
                                cells, volumes = get_subcells_2dp(phase_num, sep_points, tags_clk, pos, cell, base_line,
                                                                  error_tag[0],
                                                                  error_tag[1], construct_v)
                                # if len(posL) > 5 and len(posL[-1]) == 2 and len(posL[-2]) == 2:
                                #     move = posL[-1][1] - posL[-2][1]
                                #     move_length = np.sqrt(move[0] ** 2 + move[1] ** 2)
                                # else:
                                #     move_length = max(dx, dy)
                            error, errors = get_errors_linear_specifics(sf, dx, dy, volumes, error_tag)
                        ### if there is more continuous phase to be reconstructed, split the dynamic point
                        if cp + 1 < len(normal_pairs):
                            # print('before new position: ', pos)
                            pos = generate_new_dp(pos)
                            # print('new position: ', pos)
                        ### reinitialize the correction vector and error for the next reconstrution
                        error = get_error_all(errors)
    ### here we implement an interface flatten strategy
    # print(pos, posL)
    # pos, posL, cells, volumes, changed = flatten_interface(pos, posL, cells, volumes)
    # # print(pos, posL)
    # if changed:
    #     error, errors = get_errors_linear(sf, dx, dy, volumes)
    #     smoothed = True
    #     # print('activate the interface smoothing!')

    return pos, posL, base_line, base_vector, cells, volumes, errors, error, step, step_size, tags_clk, sep_points

def DP_PLIC_exact(Sf, dx, dy, tolerance, max_step):
    reconstruction_result = np.zeros([len(Sf[0]), len(Sf[0, 0]), 1], dtype='int').tolist()
    recons_ghost = 1
    cell_plic = np.array([[0., 0.],
                          [0., dy],
                          [dx, dy],
                          [dx, 0.]])
    for m in range(len(Sf[0]) - 2 * recons_ghost):
        for n in range(len(Sf[0, 0]) - 2 * recons_ghost):
            i = m + recons_ghost
            j = n + recons_ghost
            sf_c = Sf[:, i, j]
            phase_exist = judge_phase_num_center(sf_c)
            reconstruction_result[i][j].append({})
            reconstruction_result[i][j][1]['phase_exist'] = phase_exist
            phase_num = len(phase_exist)
            reconstruction_result[i][j][1]['phase_num'] = phase_num
            # reconstruction_result[i][j][1]['position'] = [i, j]
            if phase_num == 1:
                reconstruction_result[i][j][1]['method'] = None
                reconstruction_result[i][j][0] = 1
                cell = [phase_exist[0], cell_plic, 0]
                cells = [cell]
                reconstruction_result[i][j][1]['cells'] = cells
            elif phase_num == 2:
                reconstruction_result[i][j][1]['method'] = 'PLIC'
                phase_exist = reconstruction_result[i][j][1]['phase_exist']
                sf = get_sf([i, j], Sf)
                normal, d, cells, errors, error = Youngs2P_2d(sf, dx, dy, tolerance, phase_exist)
                intersects = plic_get_intersects(cell_plic, normal, d)
                intersects_DP5 = plic_get_intersects_DP5(cell_plic, normal, d)
                reconstruction_result[i][j][1]['intersects'] = intersects
                reconstruction_result[i][j][1]['intersects_unlimited'] = intersects_DP5
                reconstruction_result[i][j][1]['intersects_tag'] = [phase_exist[0], phase_exist[1]]
                reconstruction_result[i][j][1]['cells'] = cells
                reconstruction_result[i][j][1]['errors'] = errors
                reconstruction_result[i][j][1]['error'] = error
                reconstruction_result[i][j][0] = 1
                # print(i + ghost + start_x, j + ghost + start_y, 'PLIC', sf[:, 1, 1], errors)
            else:
                reconstruction_result[i][j][1]['method'] = 'DP'
    ### after reconstruction the PLIC, set the neighbor num for the following reconstruction using DP method
    reconstruction_result, max_neigh_num, min_neigh_num, unrecons_num = (
        update_neigh_matrix(reconstruction_result, Sf, recons_ghost))
    while unrecons_num > 0:
        x, y = get_max_neighbor_entities(reconstruction_result, Sf, recons_ghost, max_neigh_num)
        if x:
            for i in range(len(x)):
                neighbor_sep, sep_tags, recons_left = get_neighbor_sep(reconstruction_result, dx, dy, x[i], y[i])
                neighbor_sep_unlimited, sep_tags_un = get_neighbor_sep_unlimited(reconstruction_result, dx, dy,
                                                                                 x[i], y[i])
                # print(neighbor_sep)
                # print(sep_tags)
                # print(neighbor_sep_unlimited)
                # print(sep_tags_un)
                sf_center_pos = [x[i], y[i]]
                sf = get_sf(sf_center_pos, Sf)
                (pos, posL,
                 base_line, base_vector,
                 cells, volumes,
                 errors, error,
                 step, step_size,
                 ver_tag, sep_points) = Dynamic_Point_9(sf, dx, dy, tolerance, max_step, neighbor_sep, sep_tags,
                                                        neighbor_sep_unlimited, sep_tags_un, recons_left)
                reconstruction_result[x[i]][y[i]][1]['intersects'] = sep_points
                reconstruction_result[x[i]][y[i]][1]['cells'] = cells
                # reconstruction_result[x[i]][y[i]][1]['baselines'] = base_line
                # reconstruction_result[x[i]][y[i]][1]['base_vectors'] = base_vector
                # reconstruction_result[x[i]][y[i]][1]['pos'] = pos
                # reconstruction_result[x[i]][y[i]][1]['posL'] = posL
                reconstruction_result[x[i]][y[i]][1]['errors'] = errors
                reconstruction_result[x[i]][y[i]][1]['error'] = error
                reconstruction_result[x[i]][y[i]][1]['step'] = step
                reconstruction_result[x[i]][y[i]][1]['tags'] = ver_tag
                reconstruction_result[x[i]][y[i]][0] = 1
                reconstruction_result[x[i]][y[i]][1]['method'] = 'DP'
                # print(x[i], y[i], 'DP', sf[:, 1, 1], step, errors, len(posL[-1]))
                if abs(np.sum(errors)) > 1e-8:
                    # print(x[i], y[i], 'DP', sf[:, 1, 1], step, errors, len(posL[-1]))
                    sf_test = np.zeros([3])
                    for m in range(len(cells)):
                        cell_i = cells[m][1]
                        cell_ind = cells[m][0]
                        sf_test[cell_ind] += get_cell_volume_shapely(cell_i) / (dx * dy)
                    # print(sf_test, np.sum(sf_test))
                # reconstruction_result[x[i]][y[i]][1]['smoothed'] = smoothed
                # ### JUDGE IF NEED TO SWITCH TO YOUNGS' NESTED METHOD
                # if error < tolerance * 10:
                #     pass
                # else:
                #     phase_exist = judge_phase_num(sf)
                #     normals, ds, cells, errors, error = Youngs_2d(sf, dx, dy, tolerance, phase_exist)
                #     reconstruction_result[x[i]][y[i]][0] = 1
                #     reconstruction_result[x[i]][y[i]][1]['method'] = 'PLIC'
                #     reconstruction_result[x[i]][y[i]][1]['cells'] = cells
                #     reconstruction_result[x[i]][y[i]][1]['normals'] = normals
                #     reconstruction_result[x[i]][y[i]][1]['ds'] = ds
                #     reconstruction_result[x[i]][y[i]][1]['errors'] = errors
                #     reconstruction_result[x[i]][y[i]][1]['error'] = error
        reconstruction_result, max_neigh_num, min_neigh_num, unrecons_num = (
            update_neigh_matrix(reconstruction_result, Sf, recons_ghost))
    # after reconstruct for the first iteration, we look for the trouble cell where the left and right reconstruction
    # are not the same (around the tri-phase grid reconstructed by the DP method)
    tri_x, tri_y, x, y, reason = get_trouble_grid_3(reconstruction_result, Sf, recons_ghost)
    if x:
        ### set the trouble three-phase cell to be unconstructed
        for i in range(len(tri_x)):
            reconstruction_result[tri_x[i]][tri_y[i]][0] = 0
        ### set the trouble girds to be unconstructed
        for i in range(len(x)):
            reconstruction_result[x[i]][y[i]][0] = 0
        ### Then reconstruct all the trouble cell using the DP method
        for i in range(len(x)):
            if reconstruction_result[x[i]][y[i]][0] == 0:
                ### In this trouble fix procedure, don't reference to DP method intersects!!!
                neighbor_sep, sep_tags, recons_left = get_neighbor_sep_withoutDP(reconstruction_result, dx, dy,
                                                                                 x[i], y[i])
                neighbor_sep_unlimited, sep_tags_un = get_neighbor_sep_unlimited_withoutDP(reconstruction_result,
                                                                                           dx, dy, x[i], y[i])
                sf_center_pos = [x[i], y[i]]
                sf = get_sf(sf_center_pos, Sf)
                (pos, posL,
                 base_line, base_vector,
                 cells, volumes,
                 errors, error,
                 step, step_size,
                 ver_tag, sep_points) = Dynamic_Point_9(sf, dx, dy, tolerance, max_step, neighbor_sep, sep_tags,
                                                        neighbor_sep_unlimited, sep_tags_un, recons_left)
                reconstruction_result[x[i]][y[i]][1]['intersects'] = sep_points
                reconstruction_result[x[i]][y[i]][1]['cells'] = cells
                # reconstruction_result[x[i]][y[i]][1]['baselines'] = base_line
                # reconstruction_result[x[i]][y[i]][1]['base_vectors'] = base_vector
                # reconstruction_result[x[i]][y[i]][1]['pos'] = pos
                # reconstruction_result[x[i]][y[i]][1]['posL'] = posL
                reconstruction_result[x[i]][y[i]][1]['errors'] = errors
                reconstruction_result[x[i]][y[i]][1]['error'] = error
                reconstruction_result[x[i]][y[i]][1]['step'] = step
                reconstruction_result[x[i]][y[i]][1]['tags'] = ver_tag
                reconstruction_result[x[i]][y[i]][0] = 1
                reconstruction_result[x[i]][y[i]][1]['method'] = 'DP'
                # reconstruction_result[x[i]][y[i]][1]['smoothed'] = smoothed
        ### reconstruct the left three-phase grids
        reconstruction_result, max_neigh_num, min_neigh_num, unrecons_num = (
            update_neigh_matrix(reconstruction_result, Sf, recons_ghost))
        while unrecons_num > 0:
            x, y = get_max_neighbor_entities(reconstruction_result, Sf, recons_ghost, max_neigh_num)
            if x:
                for i in range(len(x)):
                    neighbor_sep, sep_tags, recons_left = get_neighbor_sep(reconstruction_result, dx, dy, x[i],
                                                                           y[i])
                    neighbor_sep_unlimited, sep_tags_un = get_neighbor_sep_unlimited(reconstruction_result, dx, dy,
                                                                                     x[i], y[i])
                    sf_center_pos = [x[i], y[i]]
                    sf = get_sf(sf_center_pos, Sf)
                    (pos, posL,
                     base_line, base_vector,
                     cells, volumes,
                     errors, error,
                     step, step_size,
                     ver_tag, sep_points) = Dynamic_Point_9(sf, dx, dy, tolerance, max_step, neighbor_sep, sep_tags,
                                                            neighbor_sep_unlimited, sep_tags_un, recons_left)
                    # reconstruction_result[x[i]][y[i]][1]['intersects'] = sep_points
                    reconstruction_result[x[i]][y[i]][1]['cells'] = cells
                    # reconstruction_result[x[i]][y[i]][1]['baselines'] = base_line
                    # reconstruction_result[x[i]][y[i]][1]['base_vectors'] = base_vector
                    # reconstruction_result[x[i]][y[i]][1]['pos'] = pos
                    # reconstruction_result[x[i]][y[i]][1]['posL'] = posL
                    reconstruction_result[x[i]][y[i]][1]['errors'] = errors
                    reconstruction_result[x[i]][y[i]][1]['error'] = error
                    reconstruction_result[x[i]][y[i]][1]['step'] = step
                    reconstruction_result[x[i]][y[i]][1]['tags'] = ver_tag
                    reconstruction_result[x[i]][y[i]][0] = 1
                    reconstruction_result[x[i]][y[i]][1]['method'] = 'DP'
                    # reconstruction_result[x[i]][y[i]][1]['smoothed'] = smoothed
            reconstruction_result, max_neigh_num, min_neigh_num, unrecons_num = (
                update_neigh_matrix(reconstruction_result, Sf, recons_ghost))
    for i in range(len(Sf[0]) - 2 * recons_ghost):
        for j in range(len(Sf[0, 0]) - 2 * recons_ghost):
            grid_info = reconstruction_result[i + recons_ghost][j + recons_ghost]
            if grid_info[1]['method']:
                if grid_info[1]['error'] > tolerance * 10:
                    sf = get_sf([i + recons_ghost, j + recons_ghost], Sf)
                    phase_exist = judge_phase_num(sf)
                    normals, ds, cells, errors, error = Youngs_2d(sf, dx, dy, tolerance, phase_exist)
                    reconstruction_result[i + recons_ghost][j + recons_ghost][0] = 1
                    reconstruction_result[i + recons_ghost][j + recons_ghost][1]['method'] = 'YOUNGS'
                    reconstruction_result[i + recons_ghost][j + recons_ghost][1]['cells'] = cells
                    reconstruction_result[i + recons_ghost][j + recons_ghost][1]['normals'] = normals
                    reconstruction_result[i + recons_ghost][j + recons_ghost][1]['ds'] = ds
                    reconstruction_result[i + recons_ghost][j + recons_ghost][1]['errors'] = errors
                    reconstruction_result[i + recons_ghost][j + recons_ghost][1]['error'] = error
                    # print(i + recons_ghost, j + recons_ghost, 'YOUNGS', sf[:, 1, 1], errors)
                else:
                    pass
            else:
                pass
    return reconstruction_result

### multiprocessing version of DP-PLIC

def DP_PLIC_unsplit_exact_mp(f, dx, dy, tolerance, max_step, num_p=12):
    result = np.zeros([len(f[0]), len(f[0, 0]), 1], dtype='int').tolist()
    manager = mp.Manager()
    return_dict = manager.dict()
    return_dict['recons'] = result
    que = Queue()
    recons_ghost = 1
    x_parts, y_parts = divide_domain(len(f[0]) - 2 * recons_ghost, len(f[0, 0]) - 2 * recons_ghost, num_p)
    info = {'f': f,
            'recons_ghost': recons_ghost,
            'dx': dx,
            'dy': dy,
            'tolerance': tolerance,
            'x_parts': x_parts,
            'y_parts': y_parts}
    processes = create_processes_PLIC_2(DP_PLIC_unsplit_exact_mp_exc_1, combine_results_PLIC, info, que, return_dict)
    reconstruction_result = start_and_join_processes_PLIC(processes, return_dict)
    ### after reconstruction the PLIC, set the neighbor num for the following reconstruction using DP method
    reconstruction_result, max_neigh_num, min_neigh_num, unrecons_num = (
        update_neigh_matrix(reconstruction_result, f, recons_ghost))
    while unrecons_num > 0:
        x, y = get_max_neighbor_entities(reconstruction_result, f, recons_ghost, max_neigh_num)
        if x:
            for i in range(len(x)):
                neighbor_sep, sep_tags, recons_left = get_neighbor_sep(reconstruction_result, dx, dy, x[i], y[i])
                neighbor_sep_unlimited, sep_tags_un = get_neighbor_sep_unlimited(reconstruction_result, dx, dy, x[i], y[i])
                sf_center_pos = [x[i], y[i]]
                sf = get_sf(sf_center_pos, f)
                (pos, posL,
                 base_line, base_vector,
                 cells, volumes,
                 errors, error,
                 step, step_size,
                 ver_tag, sep_points) = Dynamic_Point_9(sf, dx, dy, tolerance, max_step, neighbor_sep, sep_tags, neighbor_sep_unlimited, sep_tags_un, recons_left)
                reconstruction_result[x[i]][y[i]][1]['intersects'] = sep_points
                reconstruction_result[x[i]][y[i]][1]['cells'] = cells
                # reconstruction_result[x[i]][y[i]][1]['baselines'] = base_line
                # reconstruction_result[x[i]][y[i]][1]['base_vectors'] = base_vector
                # reconstruction_result[x[i]][y[i]][1]['pos'] = pos
                # reconstruction_result[x[i]][y[i]][1]['posL'] = posL
                reconstruction_result[x[i]][y[i]][1]['errors'] = errors
                reconstruction_result[x[i]][y[i]][1]['error'] = error
                reconstruction_result[x[i]][y[i]][1]['step'] = step
                reconstruction_result[x[i]][y[i]][1]['tags'] = ver_tag
                reconstruction_result[x[i]][y[i]][0] = 1
                reconstruction_result[x[i]][y[i]][1]['method'] = 'DP'
                print(x[i], y[i], 'DP', step, errors)
        reconstruction_result, max_neigh_num, min_neigh_num, unrecons_num = (
            update_neigh_matrix(reconstruction_result, f, recons_ghost))
    # after reconstruct for the first iteration, we look for the trouble cell where the left and right reconstruction
    # are not the same (around the tri-phase grid reconstructed by the DP method)
    tri_x, tri_y, x, y, reason = get_trouble_grid_3(reconstruction_result, f, recons_ghost)
    if x:
        ### set the trouble three-phase cell to be unconstructed
        for i in range(len(tri_x)):
            reconstruction_result[tri_x[i]][tri_y[i]][0] = 0
        ### set the trouble girds to be unconstructed
        for i in range(len(x)):
            reconstruction_result[x[i]][y[i]][0] = 0
        ### Then reconstruct all the trouble cell using the DP method
        for i in range(len(x)):
            if reconstruction_result[x[i]][y[i]][0] == 0:
                ### In this trouble fix procedure, don't reference to DP method intersects!!!
                neighbor_sep, sep_tags, recons_left = get_neighbor_sep_withoutDP(reconstruction_result, dx, dy, x[i], y[i])
                neighbor_sep_unlimited, sep_tags_un = get_neighbor_sep_unlimited_withoutDP(reconstruction_result, dx, dy, x[i], y[i])
                sf_center_pos = [x[i], y[i]]
                sf = get_sf(sf_center_pos, f)
                (pos, posL,
                 base_line, base_vector,
                 cells, volumes,
                 errors, error,
                 step, step_size,
                 ver_tag, sep_points) = Dynamic_Point_9(sf, dx, dy, tolerance, max_step, neighbor_sep, sep_tags, neighbor_sep_unlimited, sep_tags_un, recons_left)
                reconstruction_result[x[i]][y[i]][1]['intersects'] = sep_points
                reconstruction_result[x[i]][y[i]][1]['cells'] = cells
                # reconstruction_result[x[i]][y[i]][1]['baselines'] = base_line
                # reconstruction_result[x[i]][y[i]][1]['base_vectors'] = base_vector
                # reconstruction_result[x[i]][y[i]][1]['pos'] = pos
                # reconstruction_result[x[i]][y[i]][1]['posL'] = posL
                reconstruction_result[x[i]][y[i]][1]['errors'] = errors
                reconstruction_result[x[i]][y[i]][1]['error'] = error
                reconstruction_result[x[i]][y[i]][1]['step'] = step
                reconstruction_result[x[i]][y[i]][1]['tags'] = ver_tag
                reconstruction_result[x[i]][y[i]][0] = 1
                reconstruction_result[x[i]][y[i]][1]['method'] = 'DP'
                print(x[i], y[i], 'DP', step, errors)
        ### reconstruct the left three-phase grids
        reconstruction_result, max_neigh_num, min_neigh_num, unrecons_num = (
            update_neigh_matrix(reconstruction_result, f, recons_ghost))
        while unrecons_num > 0:
            x, y = get_max_neighbor_entities(reconstruction_result, f, recons_ghost, max_neigh_num)
            if x:
                for i in range(len(x)):
                    neighbor_sep, sep_tags, recons_left = get_neighbor_sep(reconstruction_result, dx, dy, x[i], y[i])
                    neighbor_sep_unlimited, sep_tags_un = get_neighbor_sep_unlimited(reconstruction_result, dx, dy,
                                                                                     x[i], y[i])
                    sf_center_pos = [x[i], y[i]]
                    sf = get_sf(sf_center_pos, f)
                    (pos, posL,
                     base_line, base_vector,
                     cells, volumes,
                     errors, error,
                     step, step_size,
                     ver_tag, sep_points) = Dynamic_Point_9(sf, dx, dy, tolerance, max_step, neighbor_sep, sep_tags, neighbor_sep_unlimited, sep_tags_un,recons_left)
                    reconstruction_result[x[i]][y[i]][1]['intersects'] = sep_points
                    reconstruction_result[x[i]][y[i]][1]['cells'] = cells
                    # reconstruction_result[x[i]][y[i]][1]['baselines'] = base_line
                    # reconstruction_result[x[i]][y[i]][1]['base_vectors'] = base_vector
                    # reconstruction_result[x[i]][y[i]][1]['pos'] = pos
                    # reconstruction_result[x[i]][y[i]][1]['posL'] = posL
                    reconstruction_result[x[i]][y[i]][1]['errors'] = errors
                    reconstruction_result[x[i]][y[i]][1]['error'] = error
                    reconstruction_result[x[i]][y[i]][1]['step'] = step
                    reconstruction_result[x[i]][y[i]][1]['tags'] = ver_tag
                    reconstruction_result[x[i]][y[i]][0] = 1
                    reconstruction_result[x[i]][y[i]][1]['method'] = 'DP'
                    print(x[i], y[i], 'DP', step, errors)
            reconstruction_result, max_neigh_num, min_neigh_num, unrecons_num = (
                update_neigh_matrix(reconstruction_result, f, recons_ghost))
    for i in range(len(f[0]) - 2 * recons_ghost):
        for j in range(len(f[0, 0]) - 2 * recons_ghost):
            grid_info = reconstruction_result[i + recons_ghost][j + recons_ghost]
            if grid_info[1]['method']:
                if grid_info[1]['error'] > tolerance * 10:
                    reconstruction_result[i + recons_ghost][j + recons_ghost][1] = {}
                    sf = get_sf([i + recons_ghost, j + recons_ghost], f)
                    phase_exist = judge_phase_num(sf)
                    normals, ds, cells, errors, error = Youngs_2d(sf, dx, dy, tolerance, phase_exist)
                    reconstruction_result[i + recons_ghost][j + recons_ghost][0] = 1
                    reconstruction_result[i + recons_ghost][j + recons_ghost][1]['method'] = 'YOUNGS'
                    reconstruction_result[i + recons_ghost][j + recons_ghost][1]['cells'] = cells
                    reconstruction_result[i + recons_ghost][j + recons_ghost][1]['normals'] = normals
                    reconstruction_result[i + recons_ghost][j + recons_ghost][1]['ds'] = ds
                    reconstruction_result[i + recons_ghost][j + recons_ghost][1]['errors'] = errors
                    reconstruction_result[i + recons_ghost][j + recons_ghost][1]['error'] = error
                    print(i + recons_ghost, j + recons_ghost, 'YOUNGS', errors)
                else:
                    pass
            else:
                pass
    return reconstruction_result

def DP_PLIC_unsplit_exact_mp_exc_1(info, que, start_x, end_x, start_y, end_y):
    Sf = info['f']
    ghost = info['recons_ghost']
    dx = info['dx']
    dy = info['dy']
    tolerance = info['tolerance']
    ### initialize the sub_result, one more layer for the neighbor related calculations
    reconstruction_result = np.zeros([end_x - start_x, end_y - start_y, 1], dtype='int').tolist()
    cell_plic = np.array([[0., 0.],
                          [0., dx],
                          [dx, dy],
                          [dx, 0.]])
    for i in range(end_x - start_x):
        for j in range(end_y - start_y):
            sf_c = Sf[:, i + ghost + start_x, j + ghost + start_y]
            phase_exist = judge_phase_num_center(sf_c)
            reconstruction_result[i][j].append({})
            reconstruction_result[i][j][1]['phase_exist'] = phase_exist
            phase_num = len(phase_exist)
            reconstruction_result[i][j][1]['phase_num'] = phase_num
            # reconstruction_result[i][j][1]['position'] = [i + start_x, j + start_y]
            if phase_num == 1:
                reconstruction_result[i][j][1]['method'] = None
                reconstruction_result[i][j][0] = 1
                cell = [phase_exist[0], cell_plic, 0]
                cells = [cell]
                reconstruction_result[i][j][1]['cells'] = cells
            elif phase_num == 2:
                reconstruction_result[i][j][1]['method'] = 'PLIC'
                phase_exist = reconstruction_result[i][j][1]['phase_exist']
                sf = get_sf([i + ghost + start_x, j + ghost + start_y], Sf)
                normal, d, cells, errors, error = Youngs2P_2d(sf, dx, dy, tolerance, phase_exist)
                intersects = plic_get_intersects(cell_plic, normal, d)
                intersects_DP5 = plic_get_intersects_DP5(cell_plic, normal, d)
                reconstruction_result[i][j][1]['intersects'] = intersects
                reconstruction_result[i][j][1]['intersects_unlimited'] = intersects_DP5
                reconstruction_result[i][j][1]['intersects_tag'] = [phase_exist[0], phase_exist[1]]
                reconstruction_result[i][j][1]['cells'] = cells
                reconstruction_result[i][j][1]['errors'] = errors
                reconstruction_result[i][j][1]['error'] = error
                reconstruction_result[i][j][0] = 1
                # print(i + ghost + start_x, j + ghost + start_y, 'PLIC', sf[:, 1, 1], errors)
            else:
                reconstruction_result[i][j][1]['method'] = 'DP'

    que.put({'sub_result': reconstruction_result, 'start_x': start_x, 'end_x': end_x, 'start_y': start_y, 'end_y': end_y})

