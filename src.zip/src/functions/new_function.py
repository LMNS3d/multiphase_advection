###This is the function toolbox for the newly designed algorithm
###creator: Zhang, HKUST
from cmath import phase

import numpy as np
import math
import copy
from src.functions.functions import get_cell_volume_shapely, get_cell_volume_new

### This code is to generate 3 * 3 stencil from n * m field
### The center subgrid index is the position
### position: [i, j]
### Sf: n * m VF field
def get_sf(position, Sf):
    ### first make sure the the position is within the n * m field
    if not ((0 < position[0] < len(Sf[0])) and (0 < position[1] < len(Sf[0][0]))):
        return False
    else:
        field_position = position
        sf_cc = Sf[:, field_position[0] - 1:field_position[0] + 2, field_position[1] - 1:field_position[1] + 2]
    return sf_cc

###This function get the vertice tag based on volume fraction interpolated at the vertice points
###input
###sf: the scalar field contains volume fraction for all three phases
###i, j: location index
###output
###vertice_list: in which contains the tagging information
###                      tag(0, 1)-----------tag(1, 1)
###                      |                   |
###                      |                   |
###                      |                   |
###                      |                   |
###                      tag(0, 0)-----------tag(1, 0)
### This function retains the sysmetricity
### new input sf is the 3 * 3 stencil
def get_tag_2_new(sub_sf_in, sf):
    ###initialize
    tags = np.zeros([3, 3], dtype=int)
    phase_exist_indicator = np.zeros([len(sub_sf_in)], dtype=int)
    phase_exist = [sub_sf_in[i, 1, 1] != 0. for i in range(len(sub_sf_in))]
    phase_exist = np.array(phase_exist)
    ###first we interpolate the cell vertices volume fraction value from the scalar field by linear interpolation
    sub_sf = sub_sf_in
    sub_sf_pp = copy.deepcopy(sub_sf_in)
    sub_sf_pp[:, 1, 1] = -1.
    vf_avg_all = get_local_field_sym(sf)
    ###now we look through four vertices to find all the tags
    ###in this algorithm, the tag is the index of phase which has a largest volume fraction at the vertice
    for m in [0, 1, 2]:
        for n in [0, 1, 2]:
            # print(m, n)
            vf = sub_sf[:, m, n]
            # print(vf)
            tag_i = np.argmax(vf)
            # print(tag_i)
            max_list = np.flatnonzero(vf == vf[tag_i])
            ### if there exist two maximum VOF, then use the symmetric averaged field
            if len(max_list) > 1 and not (m == 1 and n == 1):
                # print('here')
                vf = vf_avg_all[:, m, n]
                # print(vf)
                # print(max_list)
                vf_ = np.zeros([len(vf), 1])
                for i in max_list:
                    vf_[i] = vf[i]
                # print(vf)
                tag_i = np.argmax(vf)
                # print(tag_i)
            else:
                pass
            ### If center subgrid contains the phase, then tag is kept
            if sub_sf_in[tag_i, 1, 1] != 0.:
                tags[m, n] = tag_i
            ### If the center subgrid (about to reconstruct) does not have the tagging phase,
            ### then eliminate this phase from the candidates phases
            else:
                # vf[tag_i] = 0.
                # tag_i = np.argmax(vf)
                tags[m, n] = tag_i
            phase_exist_indicator[tag_i] += 1
    ### This is a phase preserving algorithm
    for i in range(len(phase_exist_indicator)):
        if phase_exist_indicator[i] == 0 and phase_exist[i] != 0:
            max_ind = np.argmax(sub_sf_pp[i])
            tags[max_ind // len(sub_sf_pp[0])][max_ind % len(sub_sf_pp[0])] = i
        else:
            pass
    return tags

### This function applies when the normal phase is less than 2
def fix_tag(tags_clk, tags, phase_num, nor_p):
    tags_clk_test = copy.deepcopy(tags_clk)
    tags_new = copy.deepcopy(tags)
    normal_phase = tags_clk[nor_p[0][0]]
    indi = False
    cur = 0
    while indi == False and cur < len(tags_clk):
        if tags_clk[cur] == normal_phase:
            cur += 1
            continue
        else:
            tags_clk_test = copy.deepcopy(tags_clk)
            tags_clk_test[cur] = normal_phase
            judge_new = judge_still_phase(tags_clk_test, phase_num)
            odd_new, nor_new = get_odd_pairs(tags_clk_test, judge_new)
            if len(nor_new) >= 2:
                tags_new = assign_tags(tags, cur, normal_phase)
                indi = True
                break
            else:
                cur += 1
                continue
    return tags_clk_test, tags_new

### no normal phase
def fix_tag_2(tags_clk, tags, phase_num, odd_p):
    tags_clk_test = copy.deepcopy(tags_clk)
    tags_new = copy.deepcopy(tags)
    phase_odd_largest_len = len(odd_p[0])
    phase_odd_largest = tags_clk[odd_p[0][0]]
    for i in range(len(odd_p)):
        if len(odd_p[i]) > phase_odd_largest_len:
            phase_odd_largest_len = len(odd_p[i])
            phase_odd_largest = tags_clk[odd_p[i][0]]
    indi = False
    cur = 0
    while indi == False and cur < len(tags_clk):
        if tags_clk[cur] == phase_odd_largest:
            cur += 1
            continue
        else:
            tags_clk_test = copy.deepcopy(tags_clk)
            tags_clk_test[cur] = phase_odd_largest
            judge_new = judge_still_phase(tags_clk_test, phase_num)
            odd_new, nor_new = get_odd_pairs(tags_clk_test, judge_new)
            if len(nor_new) >= 2:
                tags_new = assign_tags(tags, cur, phase_odd_largest)
                break
            else:
                cur += 1
                continue
    return tags_clk_test, tags_new

def assign_tags(tags, clk_n, val):
    if clk_n == 0:
        tags[0, 0] = val
    elif clk_n == 1:
        tags[0, 1] = val
    elif clk_n == 2:
        tags[0, 2] = val
    elif clk_n == 3:
        tags[1, 2] = val
    elif clk_n == 4:
        tags[2, 2] = val
    elif clk_n == 5:
        tags[2, 1] = val
    elif clk_n == 6:
        tags[2, 0] = val
    elif clk_n == 7:
        tags[1, 0] = val
    else:
        pass
    return tags

### This function get the clockwise ordered 1D tags list, start from lower-left vertex
### input
### tags
### output
### tags_l
###                      tag(2)-----tag(3)------tag(4)
###                      |                      |
###                      |                      |
###                      tag(1)                 tag(5)
###                      |                      |
###                      |                      |
###                      tag(0)-----tag(7)------tag(6)
def get_tag_clk(tags):
    result = np.array([tags[0, 0], tags[0, 1], tags[0, 2], tags[1, 2], tags[2, 2], tags[2, 1], tags[2, 0], tags[1, 0]])
    return result

###This function interpolates the cell vertices value, cell boundary mid-point value from the volume fraction field
###and organize them as a 3 * 3 matrix within the cell
###                                     subgrid
###                 (m-1, n+1)---------(m, n+1)----------(m+1, n+1)
###                      |                 |                 |
###                      |                 |                 |
###                      |                 |                 |
###                      |                 |                 |
###                      |                 |                 |
###                  (m-1, n)-----------(m, n)-----------(m+1, n)
###                      |                 |                 |
###                      |                 |                 |
###                      |                 |                 |
###                      |                 |                 |
###                      |                 |                 |
###                 (m-1, n-1)----------(m, n-1)----------(m+1, n-1)
###                   ~(0, 0)
###input
###sf: the scalar field contains volume fraction for all three phases
###i, j: location index
###output
###sf_cell: the 3 * 3 interpolated scalar field contains the local colume fraction of the cell

### This method maintains the symmetricity
def get_local_field_sym(sf):
    ###initialize a 3 * 3 matrix
    result = np.zeros([len(sf), 3, 3])
    ###linear interpolation
    for k in range(len(sf)):
        sf_i = sf[k]
        for m in [-1, 0, 1]:
            for n in [-1, 0, 1]:
                ### side values are reconstructed with two neighboring grid
                if m * n == 0:
                    result[k, 1 + m, 1 + n] = 0.5 * (sf_i[1 + m, 1 + n] + sf_i[1, 1])
                ### corner values are reconstructed with four neighboring grid
                else:
                    result[k, 1 + m, 1 + n] = 0.25 * (sf_i[1 + m, 1 + n] + sf_i[1, 1] + sf_i[1, 1 + n] + sf_i[1 + m, 1])
        ###recover the middle value
        result[k][1][1] = sf_i[1, 1]
    return result

### This method generate local field by multiplication, symmetry fixed
def get_local_field_sym_4(sf):
    ###initialize a 3 * 3 matrix
    result = np.zeros([len(sf), 3, 3])
    ###linear interpolation
    for k in range(len(sf)):
        sf_i = sf[k]
        for m in [-1, 0, 1]:
            for n in [-1, 0, 1]:
                ### side values are reconstructed with two neighboring grid
                if m * n == 0:
                    result[k, 1 + m, 1 + n] = (sf_i[1 + m, 1 + n] * sf_i[1, 1])
                ### corner values are reconstructed with four neighboring grid
                else:
                    result[k, 1 + m, 1 + n] = (sf_i[1 + m, 1 + n] * sf_i[1, 1] * sf_i[1, 1 + n] * sf_i[1 + m, 1]) ** 0.5
        ###recover the middle value
        result[k, 1, 1] = sf_i[1, 1]
    return result

###This function calculate the normal vector which perpendicular to the given two-points constructed line
###input
###points1, points2
###vertice: one vertice inside the line, the result normal points outwards
### dx, dy
###output
###normal
### This function takes odd_case5 and 6 into consideration
### If the two separation points are on the same edge of the sub-grid
### n.dot(v) - d = 0 for all phases
def get_normal_perpendicular_2p_new(base_line, cell, icell, dx, dy):
    p1 = base_line[icell][1]
    p2 = base_line[icell][2]
    v = cell[base_line[icell][3]]
    ###the vector along the line from p1 to p2
    l = p2 - p1
    ###the vector perpendicular to l
    n = np.array([l[1], -l[0]])
    ###normalize to unit vector
    n = n / (np.sqrt(n[0] ** 2 + n[1] ** 2) + 1e-8)
    ###redirect the normal vector such that the vertice is included in region n * x - d <= 0
    ###which means the normal vector points outwards
    d = n.dot(p1)
    if n.dot(v) - d < 0:
        return n
    ### Test if recorded vertex is on the same line of separation points
    elif n.dot(v) - d == 0:
        # print('same line!')
        cur = base_line[icell - 1][3]
        middle = np.array([dx / 2, dy / 2])
        while cur % len(cell) != base_line[icell][3]:
            cur = cur + 1
            vv = cell[cur % len(cell)]
            if n.dot(vv) - d > 0:
                n = -n
                return n
            else:
                pass
        ### then the middle point should be outside
        if n.dot(middle) - d < 0:
            n = -n
            return n
        else:
            pass
    else:
        n = -n
    return n

### This function is used to construct the baseline, the baseline is the connection of two neighboring sep point
### input
### sep_points: the separation points on each cell boundary
### ver_tag_line: the vertice tag, indicates the dominate phases, starting from lower-left, clockwise
### output
### base_line: [[phase index, sep_point_k, sep_point_(k-l), vertex/mid-point index],[],...]
def get_baseline(sep_points, ver_tag_line):
    base_line = []
    for k in range(len(sep_points)):
        if not np.isnan(sep_points[k][0]):
            phase_ind = ver_tag_line[k]
            ### we look backwards until find another separation point
            neighbor_ind = k - 1
            while np.isnan(sep_points[neighbor_ind][0]):
                neighbor_ind -= 1
            ### The base-line is just the connection of two neighboring sep-point
            ### the first element indicates the phase, the second and third elements are two adjcent point
            ### The last term indicates the included vertices index(only one)
            base_line.append([phase_ind, sep_points[k], sep_points[neighbor_ind], k])
    return base_line

### This function is used to get the base vector based on the base line
### input
### base_line: contains the base line information
### cell: the original cell
### dx, dy
### output
### base_vector: [[vector, vertex/mid-point index],[],...
###
### This is the modified algorithm take odd_case5 and 6 into consideration
def get_basevector_new(base_line, cell, dx, dy):
    base_vector = []
    for icell in range(len(base_line)):
        vector = get_normal_perpendicular_2p_new(base_line, cell, icell, dx, dy)
        base_vector.append([vector, base_line[icell][3]])
    return base_vector

### This function judge is there exist volume-still phase (discontinuous)
### The phase is defined as volume-still is there exist non-neighboring tag clusters
### if not, return False, else, return True
### input
### tags_clk: the vertex/boundary center tags
### output
### [phase1 is volume-still(None/1), phase2 is volume-still(None/1), ...]
def judge_still_phase(tags_clk, phase_num):
    ### initialize, assume no still volume phase
    judge = [None for i in range(phase_num)]
    ### copy one iteration of the list, and start from the second unrepeated element
    tags_clk_itera = list(tags_clk) + list(tags_clk)
    # print(tags_clk_itera)
    ### first find all types of phases
    phase_appeared = []
    start_tag = tags_clk[0]
    start_ind = 0
    ### find the second unrepeated element index
    for i in range(len(tags_clk)):
        if tags_clk[i] != start_tag:
            start_ind = i
            break
    # print(start_ind)
    for j in range(start_ind, start_ind + len(tags_clk)):
        # print(j)
        # print(tags_clk_itera[j])
        if tags_clk_itera[j] not in phase_appeared:
            phase_appeared.append(tags_clk_itera[j])
            # print('put ' + str(tags_clk_itera[j]) + ' in phase_appeared')
        else:
            ### if continuous
            if tags_clk_itera[j] == tags_clk_itera[j - 1]:
                # print(str(tags_clk_itera[j]) + ' = ' + str(tags_clk_itera[j - 1]))
                pass
            ### if not continuous
            else:
                # print('not continuous' + str(tags_clk_itera[j]))
                judge[tags_clk_itera[j]] = 1
    return np.array(judge)

### This function construct the subcell and calculate the volume of the subcells for single dynamic point condition
### input
### sep_points: the separation points on each cell boundary
### ver_tag_line: the vertice tag, indicates the dominate phases, starting from lower-left, clockwise
### pos: dynamic point positions, only one dynamic point, not a list!
### sf: all phases scalar field
### cell: the original cell
### output
### cells: [subcell1, subcell2, ...]
### volumes: [volume of phase1, volume of phase2, ...]
def get_subcells(phase_num, sep_points, ver_tag_line, pos, cell):
    ### initialize the volume list for each fluid
    volumes = np.zeros([phase_num])
    ### initilize the cells list
    cells = []
    ### iteratively calculate the existing volume fraction
    ### and optimize(move) the triple point by an error-based vector
    for k in range(len(sep_points)):
        if not np.isnan(sep_points[k]).all():
            ### local initialize
            phase_ind = ver_tag_line[k]
            ### we look backwards until find another separation point
            neighbor_ind = k - 1
            while np.isnan(sep_points[neighbor_ind][0]):
                neighbor_ind -= 1
            ### after find the two neighboring cut point on the boundary, we could constitue a cell
            ### the cell start from the triple point, clockwise
            cell_k = [pos, sep_points[k]]
            for l in range(k - neighbor_ind):
                cell_k.append(cell[k - l])
            cell_k.append(sep_points[neighbor_ind])
            cell_k = np.array(cell_k)
            sub_cell_indicator = 0
            cells.append([phase_ind, cell_k, sub_cell_indicator])
            ### after the construction of the cell, we can calculate the volume of the cell
            volume_k = get_cell_volume_shapely(cell_k)
            volumes[phase_ind] += volume_k
        else:
            pass
    return cells, volumes

### This function construct the subcell and calculate the volume of the subcells for two dynamic point condition
### input
### sep_points: the separation points on each cell boundary
### ver_tag_line: the vertice tag, indicates the dominate phases, starting from lower-left, clockwise
### pos: dynamic point positions, including two dynamic points, is a list!
### sf: all phases scalar field
### cell: the original cell
### base_line
### first_recons_tag, second_recons_tag, second_recons_v
### output
### cells: [phase_ind, [subcell1, subcell2, ...], sub_cell_indicator]
### volumes: [volume of phase1, volume of phase2, ...]
def get_subcells_2dp(phase_num, sep_points, ver_tag_line, pos, cell, base_line, first_recons_tag, second_recons_tag, second_recons_v):
    ### identify the second reconstruct base line
    # print(base_line)
    # print(second_recons_v)
    for i in range(len(base_line)):
        if base_line[i][3] in second_recons_v:
            # print('here')
            second_recons_baseline = base_line[i]
    ### local initialize the error list for each fluid
    volumes = np.zeros([phase_num])
    cells = []
    ### iteratively calculate the existing volume fraction
    ### and optimize(move) the triple point by an error-based vector
    ### in this part the error and the position correction vector
    ### is calculated based on all phases
    for k in range(len(sep_points)):
        if not np.isnan(sep_points[k][0]):
            ### local initialize
            phase_ind = ver_tag_line[k]
            ### we look backwards until find another separation point
            neighbor_ind = k - 1
            while np.isnan(sep_points[neighbor_ind][0]):
                neighbor_ind -= 1
            ### after find the two neighboring cut point on the boundary, we could constitue a cell anti-ck
            ### This time, the construction of the cell is dependent on the phase index
            ### If the phase is firstly reconstructed phase, then the starting point is from
            ### the first dynamic point, if the phase is secondly reconstructed phase, the starting point
            ### is from the second dynamic point, for the else phase (the third), the cell includes both dynamic points
            if phase_ind == first_recons_tag:
                cell_k = [pos[0], sep_points[k]]
                for l in range(k - neighbor_ind):
                    cell_k.append(cell[k - l])
                cell_k.append(sep_points[neighbor_ind])
                cell_k = np.array(cell_k)
                sub_cell_indicator = 0
                cells.append([phase_ind, cell_k, sub_cell_indicator])
                ### after the construction of the cell, we can calculate the volume of the cell
                volume_k = get_cell_volume_shapely(cell_k)
                volumes[phase_ind] += volume_k
            elif phase_ind == second_recons_tag:
                cell_k = [pos[1], sep_points[k]]
                for l in range(k - neighbor_ind):
                    cell_k.append(cell[k - l])
                cell_k.append(sep_points[neighbor_ind])
                cell_k = np.array(cell_k)
                sub_cell_indicator = 0
                cells.append([phase_ind, cell_k, sub_cell_indicator])
                ### after the construction of the cell, we can calculate the volume of the cell
                volume_k = get_cell_volume_shapely(cell_k)
                volumes[phase_ind] += volume_k
            else:
                ### subcell component 1
                cell_k1 = [pos[0], sep_points[k]]
                for l in range(k - neighbor_ind):
                    cell_k1.append(cell[k - l])
                cell_k1.append(sep_points[neighbor_ind])
                cell_k1 = np.array(cell_k1)
                sub_cell_indicator = 1
                cells.append([phase_ind, cell_k1, sub_cell_indicator])
                ### after the construction of the cell, we can calculate the volume of the cell
                volume_k1 = get_cell_volume_shapely(cell_k1)
                volumes[phase_ind] += volume_k1
                ###subcell component 2
                cell_k2 = [pos[0], pos[1], sep_points[k]]
                for kk in second_recons_baseline:
                    if (sep_points[neighbor_ind] == kk).all():
                        cell_k2 = [pos[0], pos[1], sep_points[neighbor_ind]]
                        break
                cell_k2 = np.array(cell_k2)
                cells.append([phase_ind, cell_k2, sub_cell_indicator])
                ### after the construction of the cell, we can calculate the volume of the cell
                volume_k2 = get_cell_volume_shapely(cell_k2)
                volumes[phase_ind] += volume_k2
        else:
            pass
    return cells, volumes

### This function calculate the linear errors for the given subcells' volume
### error measuring method, error = f_predic - f_target
### input
### volumes: [volume of phase1, volume of phase2, ...]
### sf: all phases scalar field
### dx, dy: grid intervals
### i, j
### output
### error: the total error
### errors: the inidividual errors, phase-wise
def get_errors_linear(sf, dx, dy, volumes):
    ### local initialize the error list for each phase
    errors = np.zeros([len(sf)])
    error = 0.
    for phase in range(len(sf)):
        errors[phase] = sf[phase, 1, 1] - volumes[phase] / (dx * dy)
        error += abs(errors[phase])
    return error, errors

### This function calculate the linear errors of the given subcells' volume
### but the total error only for the for the specific tag
### error measuring method, error = f_predic - f_target
### input
### volumes: [volume of phase1, volume of phase2, ...]
### sf: all phases scalar field
### dx, dy: grid intervals
### i, j
### tag: phase tag
### output
### error: the total error for the specific phase tag
### errors: the inidividual errors, phase-wise

### The input tag is a list of tags
def get_errors_linear_specifics(sf, dx, dy, volumes, tags):
    ### local initialize the error list for each phase
    errors = np.zeros([len(sf)])
    error = 0.
    for phase in range(len(sf)):
        errors[phase] = sf[phase, 1, 1] - volumes[phase] / (dx * dy)
        ###the error is only calculated for the first reconstruct phase
        if phase in tags:
            error += abs(errors[phase])
    return error, errors

### This function is used to calculate the correction vector based on the errors
### w_i = error / (dx * dy)
### input
### base_vector, base_line
### dx, dy
### errors
### output
### correction vector: [x, y]
### This function gives the correction vector based on the length of the baseline
def get_correction_vector_2(base_vector, base_line, errors, dx, dy):
    cor_vector = np.array([0., 0.])
    for icell in range(len(base_vector)):
        ###base line length
        base_length = np.sqrt((base_line[icell][1][0] - base_line[icell][2][0]) ** 2
                              + (base_line[icell][1][1] - base_line[icell][2][1]) ** 2)
        ### according to the phase volume fraction error, we construct the direction vector weights
        omegai = 1.2 * dx * dy * errors[base_line[icell][0]] / base_length
        ### add them up to construct the overall triple point position correction vector
        cor_vector += omegai * base_vector[icell][0]
    return cor_vector

### This function gives the correction vector based on the length of the baseline
def get_correction_vector_specific_2(base_vector, base_line, errors, dx, dy, tag):
    # print('errors: ', errors)
    cor_vector = np.array([0., 0.])
    # print('specified tag: ', tag)
    for icell in range(len(base_vector)):
        ### reconstruct the specific material
        if base_line[icell][0] == tag:
            ###base line length
            base_length = np.sqrt((base_line[icell][1][0] - base_line[icell][2][0]) ** 2
                                  + (base_line[icell][1][1] - base_line[icell][2][1]) ** 2)
            # print('base_length: ', base_length)
            omegai = 2 * dx * dy * errors[tag] / base_length
            cor_vector += omegai * base_vector[icell][0]
            # print('cor_vector: ', cor_vector)
        else:
            pass
    return cor_vector

### This function is used to update the position of the dynamic point
### input
### pos: the current dynamic position list
### posL: the history DP list
### cor_vector: the correction vector of the DP position
### q: dynamic point index
### dx, dy
### output
### pos, posL
def update_position(pos, posL, cor_vector, q, dx, dy):
    cur_pos = copy.deepcopy(pos)
    cur_pos[q] += cor_vector
    ### keeping the dynamic point inside the sub-grid
    cur_pos[q][0] = min(dx - 1e-8, max(cur_pos[q][0], 1e-8))
    cur_pos[q][1] = min(dy - 1e-8, max(cur_pos[q][1], 1e-8))
    posL.append(cur_pos)
    return cur_pos, posL

### This function adds an enhancement to the over-shoot of the position point 2
def update_position_DP9(pos, posL, cor_vector, q, dx, dy):
    # print('The current position is: ', pos)
    # print('The correction vector is: ', cor_vector)
    new_pos = copy.deepcopy(pos)
    new_pos[q] += cor_vector
    ### keeping the dynamic point inside the sub-grid
    new_pos[q][0] = min(dx - 1e-8, max(new_pos[q][0], 1e-8))
    new_pos[q][1] = min(dy - 1e-8, max(new_pos[q][1], 1e-8))
    pos[q] += cor_vector
    if not (np.array(pos[q]) == np.array(new_pos[q])).all():
        # print('touch the boundary, activate the position fix')
        if pos[q][0] == new_pos[q][0] and pos[q][1] != new_pos[q][1]:
            if new_pos[q][1] == 0:
                ### touched lower boundary
                v_n_sin = abs(np.cross(cor_vector, np.array([0., -1.])))
                v_n_cos = abs(np.dot(cor_vector, np.array([0., -1.])))
            else:
                ### touched upper boundary
                v_n_sin = abs(np.cross(cor_vector, np.array([0., 1.])))
                v_n_cos = abs(np.dot(cor_vector, np.array([0., 1.])))
            v_n_tan = v_n_sin / v_n_cos
            compen_x = abs(pos[q][1] - new_pos[q][1]) / (v_n_tan + 1e-2)
            compen_x = min(0.015 * dx, max(compen_x, 0.))
            compen = np.array([compen_x, 0.])
            new_pos[q] += (cor_vector[0] > 0) * compen + (cor_vector[0] < 0) * (-compen)
        elif pos[q][1] == new_pos[q][1] and pos[q][0] != new_pos[q][0]:
            if new_pos[q][0] == 0:
                ### touched left boundary
                v_n_sin = abs(np.cross(cor_vector, np.array([-1., 0.])))
                v_n_cos = abs(np.dot(cor_vector, np.array([-1., 0.])))
            else:
                ### touched right boundary
                v_n_sin = abs(np.cross(cor_vector, np.array([1., 0.])))
                # print('sin is: ', v_n_sin)
                v_n_cos = abs(np.dot(cor_vector, np.array([1., 0.])))
                # print('cos is: ', v_n_cos)
            v_n_tan = v_n_sin / v_n_cos
            # print('tangent is: ', v_n_tan)
            compen_y = abs(pos[q][0] - new_pos[q][0]) / (v_n_tan + 1e-2)
            compen_y = min(0.015 * dx, max(compen_y, 0.))
            compen = np.array([0., compen_y])
            new_pos[q] += (cor_vector[1] > 0) * compen + (cor_vector[1] < 0) * (-compen)
        else:
            pos[q][0] = min(dx - 1e-8, max(new_pos[q][0], 1e-8))
            pos[q][1] = min(dy - 1e-8, max(new_pos[q][1], 1e-8))
            cur_pos = copy.deepcopy(pos)
            posL.append(cur_pos)
            return pos, posL
    pos[q][0] = min(dx - 1e-8, max(new_pos[q][0], 1e-8))
    pos[q][1] = min(dy - 1e-8, max(new_pos[q][1], 1e-8))
    cur_pos = copy.deepcopy(pos)
    posL.append(cur_pos)
    return pos, posL
### This fucntion is used to update the move step of DP
### input
### step: the count of steps
### step_size: the list of the size of each step for DP
### cor_vector: the correction vector
### output
### step, step_size
def update_step(step, step_size, cor_vector):
    step_s = np.sqrt(cor_vector[0] ** 2 + cor_vector[1] ** 2)
    step_size.append(step_s)
    step += 1
    return step, step_size

### This function is used to generate new DP position
### input
### pos
### output
### pos
def generate_new_dp(pos):
    new_point = copy.deepcopy(pos[0])
    pos.append(new_point)
    return pos

### This function calculate the total error based on the errors list for all the phases
### input
### errors
### output
### error
def get_error_all(errors):
    error = 0.
    for phase in range(len(errors)):
        error += abs(errors[phase])
    return error

# sub_ = get_local_field(sf_cc, 1, 1)
# print(sub_)
# ver_tag = get_vertice_tag(sub_, 1, 1)
# print(ver_tag)
# side_sep = get_sep_points(sub_, ver_tag)
# print(side_sep)

### This function is used to get all the volume-still pairs:
### input
### tags_clk, judge
### output
### odd_v: [[v1, v2, ...], [v3, v4, ...], ...]
### normal_v: [[v5, v6, ...], [...], ...]
def get_odd_pairs(tags_clk, judge):
    odd_v = []
    normal_v = []
    for i in range(len(judge)):
        if judge[i] != None:
            odd_vi = []
            for j in range(len(tags_clk)):
                if tags_clk[j] == i:
                    odd_vi.append(j)
                else:
                    pass
            if odd_vi:
                odd_v.append(odd_vi)
        else:
            normal_vi = []
            for j in range(len(tags_clk)):
                if tags_clk[j] == i:
                    normal_vi.append(j)
                else:
                    pass
            if normal_vi:
                normal_v.append(normal_vi)
    return odd_v, normal_v

def judge_phase_num(sf):
    center_sf = sf[:, 1, 1]
    num = []
    for ii in range(len(center_sf)):
        if center_sf[ii] > 1e-8:
            num.append(ii)
    # print(num)
    return num

def judge_phase_num_center(sf_c):
    num = []
    for ii in range(len(sf_c)):
        if abs(sf_c[ii] - 0.) > 1e-8:
            num.append(ii)
    return num

### THIS FUNCTION ELIMINATE THE EFFECT FROM THE THIRD PHASE IN THE STENCIL
def stencil_eliminate(sf, phase_exist):
    phase_eli = None
    for i in range(len(sf)):
        if i not in phase_exist:
            phase_eli = i
            break
    sf_eli = copy.deepcopy(sf)
    sf_eli[phase_eli] = np.zeros([3, 3])
    for i in range(len(sf[0])):
        for j in range(len(sf[0, 0])):
            sum_ = sum(sf_eli[:, i, j])
            for p in range(len(sf)):
                sf_eli[p, i, j] = sf_eli[p, i, j] / sum_
    return sf_eli

### This function is used to update the number of neighboring reconstructed grid for un-recons grids
def update_neigh_matrix(reconstruction, Sf, ghost):
    max_neigh_num = 0
    min_neigh_num = 4
    unreconstructed_num = 0
    for i in range(len(Sf[0]) - 2 * ghost):
        for j in range(len(Sf[0, 0]) - 2 * ghost):
            grid_info = reconstruction[i + ghost][j + ghost]
            ### for the un-reconstructed grid
            if grid_info[0] == 0:
                neigh_num = 0
                for ii in [-1, 0, 1]:
                    for jj in [-1, 0, 1]:
                        if ii * jj == 0 and ii + jj != 0:
                            neighbor = reconstruction[i + ii + ghost][j + jj + ghost]
                            if neighbor[0] == 1:
                                neigh_num += 1
                grid_info[1]['neighbor_num'] = neigh_num
                if neigh_num > max_neigh_num:
                    max_neigh_num = neigh_num
                elif neigh_num < min_neigh_num:
                    min_neigh_num = neigh_num
                else:
                    pass
                unreconstructed_num += 1
            else:
                pass
    return reconstruction, max_neigh_num, min_neigh_num, unreconstructed_num

### This function gives all the grid which has the largest neighbor number
def get_max_neighbor_entities(reconstruction, Sf, ghost, max_neigh_num):
    en_x = []
    en_y = []
    for i in range(len(Sf[0]) - 2 * ghost):
        for j in range(len(Sf[0, 0]) - 2 * ghost):
            grid_info = reconstruction[i + ghost][j + ghost]
            if grid_info[0] == 0 and grid_info[1]['neighbor_num'] == max_neigh_num:
                en_x.append(i + ghost)
                en_y.append(j + ghost)
            else:
                pass
    return en_x, en_y

### This function is used to get the neighbor separation point from reconstructed grids
def get_neighbor_sep(reconstruction, dx, dy, m, n):
    ###initialize
    result = np.zeros([8, 2])
    result_tag = np.zeros([8, 2])
    result.fill(np.nan)
    result_tag.fill(np.nan)
    recons_left = np.zeros([8, 1])
    ### left neighbor
    neighbor_l = reconstruction[m - 1][n]
    if neighbor_l[0] == 1 and neighbor_l[1]['method']:
        intersects = neighbor_l[1]['intersects']
        ### get the right intersect
        if neighbor_l[1]['method'] == 'PLIC':
            intersects_tag = neighbor_l[1]['intersects_tag']
            intersect = intersects[2]
            if not np.isnan(intersect).all():
                y = intersect[1]
                if y < 0.5 * dy:
                    result[0, 0] = 0.
                    result[0, 1] = y
                    result_tag[0, 0] = intersects_tag[0]
                    result_tag[0, 1] = intersects_tag[1]
                else:
                    result[1, 0] = 0.
                    result[1, 1] = y
                    result_tag[1, 0] = intersects_tag[0]
                    result_tag[1, 1] = intersects_tag[1]
            else:
                pass
        elif neighbor_l[1]['method'] == 'DP':
            vertag = neighbor_l[1]['tags']
            if not np.isnan(intersects[5]).all():
                result[0, 1] = intersects[5, 1]
                result[0, 0] = 0.
                result_tag[0, 0] = vertag[5]
                result_tag[0, 1] = vertag[6]
            else:
                pass
            if not np.isnan(intersects[4]).all():
                result[1, 1] = intersects[4, 1]
                result[1, 0] = 0.
                result_tag[1, 0] = vertag[4]
                result_tag[1, 1] = vertag[5]
            else:
                pass
            if np.isnan(intersects[5]).all() and np.isnan(intersects[4]).all():
                recons_left[0] = 1
                recons_left[1] = 1
            else:
                pass
        else:
            pass
    else:
        recons_left[0] = 1
        recons_left[1] = 1
    ### right neighbor
    neighbor_r = reconstruction[m + 1][n]
    if neighbor_r[0] == 1 and neighbor_r[1]['method']:
        intersects = neighbor_r[1]['intersects']
        ### get the left intersect
        if neighbor_r[1]['method'] == 'PLIC':
            intersects_tag = neighbor_r[1]['intersects_tag']
            intersect = intersects[0]
            if not np.isnan(intersect).all():
                y = intersect[1]
                if y < 0.5 * dy:
                    result[5, 0] = dx
                    result[5, 1] = y
                    result_tag[5, 0] = intersects_tag[0]
                    result_tag[5, 1] = intersects_tag[1]
                else:
                    result[4, 0] = dx
                    result[4, 1] = y
                    result_tag[4, 0] = intersects_tag[0]
                    result_tag[4, 1] = intersects_tag[1]
            else:
                pass
        elif neighbor_r[1]['method'] == 'DP':
            vertag = neighbor_r[1]['tags']
            if not np.isnan(intersects[0]).all():
                result[5, 1] = intersects[0, 1]
                result[5, 0] = dx
                result_tag[5, 0] = vertag[0]
                result_tag[5, 1] = vertag[1]
            else:
                pass
            if not np.isnan(intersects[1]).all():
                result[4, 1] = intersects[1, 1]
                result[4, 0] = dx
                result_tag[4, 0] = vertag[1]
                result_tag[4, 1] = vertag[2]
            else:
                pass
            if np.isnan(intersects[0]).all() and np.isnan(intersects[1]).all():
                recons_left[5] = 1
                recons_left[4] = 1
            else:
                pass
        else:
            pass
    else:
        recons_left[5] = 1
        recons_left[4] = 1
    ### lower neighbor
    neighbor_low = reconstruction[m][n - 1]
    if neighbor_low[0] == 1 and neighbor_low[1]['method']:
        intersects = neighbor_low[1]['intersects']
        ### get the upper intersect
        if neighbor_low[1]['method'] == 'PLIC':
            intersects_tag = neighbor_low[1]['intersects_tag']
            intersect = intersects[1]
            if not np.isnan(intersect).all():
                x = intersect[0]
                if x < 0.5 * dx:
                    result[7, 0] = x
                    result[7, 1] = 0.
                    result_tag[7, 0] = intersects_tag[0]
                    result_tag[7, 1] = intersects_tag[1]
                else:
                    result[6, 0] = x
                    result[6, 1] = 0.
                    result_tag[6, 0] = intersects_tag[0]
                    result_tag[6, 1] = intersects_tag[1]
            else:
                pass
        elif neighbor_low[1]['method'] == 'DP':
            vertag = neighbor_low[1]['tags']
            if not np.isnan(intersects[2]).all():
                result[7, 0] = intersects[2, 0]
                result[7, 1] = 0.
                result_tag[7, 0] = vertag[2]
                result_tag[7, 1] = vertag[3]
            else:
                pass
            if not np.isnan(intersects[3]).all():
                result[6, 0] = intersects[3, 0]
                result[6, 1] = 0.
                result_tag[6, 0] = vertag[3]
                result_tag[6, 1] = vertag[4]
            else:
                pass
            if np.isnan(intersects[2]).all() and np.isnan(intersects[3]).all():
                recons_left[6] = 1
                recons_left[7] = 1
            else:
                pass
        else:
            pass
    else:
        recons_left[6] = 1
        recons_left[7] = 1
    ### upper neighbor
    neighbor_up = reconstruction[m][n + 1]
    if neighbor_up[0] == 1 and neighbor_up[1]['method']:
        intersects = neighbor_up[1]['intersects']
        ### get the lower intersect
        if neighbor_up[1]['method'] == 'PLIC':
            intersects_tag = neighbor_up[1]['intersects_tag']
            intersect = intersects[3]
            if not np.isnan(intersect).all():
                x = intersect[0]
                if x < 0.5 * dx:
                    result[2, 0] = x
                    result[2, 1] = dy
                    result_tag[2, 0] = intersects_tag[0]
                    result_tag[2, 1] = intersects_tag[1]
                else:
                    result[3, 0] = x
                    result[3, 1] = dy
                    result_tag[3, 0] = intersects_tag[0]
                    result_tag[3, 1] = intersects_tag[1]
            else:
                pass
        elif neighbor_up[1]['method'] == 'DP':
            vertag = neighbor_up[1]['tags']
            if not np.isnan(intersects[7]).all():
                result[2, 0] = intersects[7, 0]
                result[2, 1] = dy
                result_tag[2, 0] = vertag[0]
                result_tag[2, 1] = vertag[7]
            else:
                pass
            if not np.isnan(intersects[6]).all():
                result[3, 0] = intersects[6, 0]
                result[3, 1] = dy
                result_tag[3, 0] = vertag[6]
                result_tag[3, 1] = vertag[7]
            else:
                pass
            if np.isnan(intersects[6]).all() and np.isnan(intersects[7]).all():
                recons_left[2] = 1
                recons_left[3] = 1
            else:
                pass
        else:
            pass
    else:
        recons_left[2] = 1
        recons_left[3] = 1
    return result, result_tag, recons_left

### This function get the neighbor sep without limit for PLIC
def get_neighbor_sep_unlimited(reconstruction, dx, dy, m, n):
    ###initialize
    result = np.zeros([8, 2])
    result_tag = np.zeros([8, 2])
    result.fill(np.nan)
    result_tag.fill(np.nan)
    ### left neighbor
    neighbor_l = reconstruction[m - 1][n]
    if neighbor_l[0] == 1 and neighbor_l[1]['method']:
        intersects = neighbor_l[1]['intersects']
        ### get the right intersect
        if neighbor_l[1]['method'] == 'PLIC':
            intersects_tag = neighbor_l[1]['intersects_tag']
            intersects_unlimited = neighbor_l[1]['intersects_unlimited']
            intersect = intersects_unlimited[2]
            y = intersect[1]
            if not np.isnan(intersect).all() and 0. < y < dy:
                result[0, 0] = 0.
                result[0, 1] = y
                result[1, 0] = 0.
                result[1, 1] = y
                result_tag[0, 0] = intersects_tag[0]
                result_tag[0, 1] = intersects_tag[1]
                result_tag[1, 0] = intersects_tag[0]
                result_tag[1, 1] = intersects_tag[1]
            else:
                pass
        elif neighbor_l[1]['method'] == 'DP':
            vertag = neighbor_l[1]['tags']
            if not np.isnan(intersects[5]).all():
                result[0, 1] = intersects[5, 1]
                result[0, 0] = 0.
                result_tag[0, 0] = vertag[5]
                result_tag[0, 1] = vertag[6]
            else:
                pass
            if not np.isnan(intersects[4]).all():
                result[1, 1] = intersects[4, 1]
                result[1, 0] = 0.
                result_tag[1, 0] = vertag[4]
                result_tag[1, 1] = vertag[5]
            else:
                pass
        else:
            pass
    else:
        pass
    ### right neighbor
    neighbor_r = reconstruction[m + 1][n]
    if neighbor_r[0] == 1 and neighbor_r[1]['method']:
        intersects = neighbor_r[1]['intersects']
        # print('The intersects are: ', intersects)
        ### get the left intersect
        if neighbor_r[1]['method'] == 'PLIC':
            intersects_tag = neighbor_r[1]['intersects_tag']
            intersects_unlimited = neighbor_r[1]['intersects_unlimited']
            intersect = intersects_unlimited[0]
            y = intersect[1]
            if not np.isnan(intersect).all() and 0. < y < dy:
                result[5, 0] = dx
                result[5, 1] = y
                result[4, 0] = dx
                result[4, 1] = y
                result_tag[5, 0] = intersects_tag[0]
                result_tag[5, 1] = intersects_tag[1]
                result_tag[4, 0] = intersects_tag[0]
                result_tag[4, 1] = intersects_tag[1]
            else:
                pass
        elif neighbor_r[1]['method'] == 'DP':
            vertag = neighbor_r[1]['tags']
            if not np.isnan(intersects[0]).all():
                result[5, 1] = intersects[0, 1]
                result[5, 0] = dx
                result_tag[5, 0] = vertag[0]
                result_tag[5, 1] = vertag[1]
            else:
                pass
            if not np.isnan(intersects[1]).all():
                result[4, 1] = intersects[1, 1]
                result[4, 0] = dx
                result_tag[4, 0] = vertag[1]
                result_tag[4, 1] = vertag[2]
            else:
                pass
        else:
            pass
    else:
        pass
    ### lower neighbor
    neighbor_low = reconstruction[m][n - 1]
    if neighbor_low[0] == 1 and neighbor_low[1]['method']:
        intersects = neighbor_low[1]['intersects']
        ### get the upper intersect
        if neighbor_low[1]['method'] == 'PLIC':
            intersects_tag = neighbor_low[1]['intersects_tag']
            intersects_unlimited = neighbor_low[1]['intersects_unlimited']
            intersect = intersects_unlimited[1]
            x = intersect[0]
            if not np.isnan(intersect).all() and 0 < x < dx:
                result[7, 0] = x
                result[7, 1] = 0.
                result[6, 0] = x
                result[6, 1] = 0.
                result_tag[7, 0] = intersects_tag[0]
                result_tag[7, 1] = intersects_tag[1]
                result_tag[6, 0] = intersects_tag[0]
                result_tag[6, 1] = intersects_tag[1]
            else:
                pass
        elif neighbor_low[1]['method'] == 'DP':
            vertag = neighbor_low[1]['tags']
            if not np.isnan(intersects[2]).all():
                result[7, 0] = intersects[2, 0]
                result[7, 1] = 0.
                result_tag[7, 0] = vertag[2]
                result_tag[7, 1] = vertag[3]
            else:
                pass
            if not np.isnan(intersects[3]).all():
                result[6, 0] = intersects[3, 0]
                result[6, 1] = 0.
                result_tag[6, 0] = vertag[3]
                result_tag[6, 1] = vertag[4]
            else:
                pass
        else:
            pass
    else:
        pass
    ### upper neighbor
    neighbor_up = reconstruction[m][n + 1]
    if neighbor_up[0] == 1 and neighbor_up[1]['method']:
        intersects = neighbor_up[1]['intersects']
        ### get the lower intersect
        if neighbor_up[1]['method'] == 'PLIC':
            intersects_tag = neighbor_up[1]['intersects_tag']
            intersects_unlimited = neighbor_up[1]['intersects_unlimited']
            intersect = intersects_unlimited[3]
            x = intersect[0]
            if not np.isnan(intersect).all() and 0 < x < dx:
                result[2, 0] = x
                result[2, 1] = dy
                result[3, 0] = x
                result[3, 1] = dy
                result_tag[2, 0] = intersects_tag[0]
                result_tag[2, 1] = intersects_tag[1]
                result_tag[3, 0] = intersects_tag[0]
                result_tag[3, 1] = intersects_tag[1]
            else:
                pass
        elif neighbor_up[1]['method'] == 'DP':
            vertag = neighbor_up[1]['tags']
            if not np.isnan(intersects[7]).all():
                result[2, 0] = intersects[7, 0]
                result[2, 1] = dy
                result_tag[2, 0] = vertag[0]
                result_tag[2, 1] = vertag[7]
            else:
                pass
            if not np.isnan(intersects[6]).all():
                result[3, 0] = intersects[6, 0]
                result[3, 1] = dy
                result_tag[3, 0] = vertag[6]
                result_tag[3, 1] = vertag[7]
            else:
                pass
        else:
            pass
    else:
        pass
    return result, result_tag

### This function is used to get the neighbor separation point from reconstructed grids
def get_neighbor_sep_withoutDP(reconstruction, dx, dy, m, n):
    ###initialize
    result = np.zeros([8, 2])
    result_tag = np.zeros([8, 2])
    result.fill(np.nan)
    result_tag.fill(np.nan)
    recons_left = np.zeros([8, 1])
    ### left neighbor
    neighbor_l = reconstruction[m - 1][n]
    if neighbor_l[0] == 1 and neighbor_l[1]['method']:
        intersects = neighbor_l[1]['intersects']
        ### get the right intersect
        if neighbor_l[1]['method'] == 'PLIC':
            intersects_tag = neighbor_l[1]['intersects_tag']
            intersect = intersects[2]
            if not np.isnan(intersect).all():
                y = intersect[1]
                if y < 0.5 * dy:
                    result[0, 0] = 0.
                    result[0, 1] = y
                    result_tag[0, 0] = intersects_tag[0]
                    result_tag[0, 1] = intersects_tag[1]
                else:
                    result[1, 0] = 0.
                    result[1, 1] = y
                    result_tag[1, 0] = intersects_tag[0]
                    result_tag[1, 1] = intersects_tag[1]
            else:
                pass
        elif neighbor_l[1]['method'] == 'DP':
            recons_left[0] = 1
            recons_left[1] = 1
    else:
        recons_left[0] = 1
        recons_left[1] = 1
    ### right neighbor
    neighbor_r = reconstruction[m + 1][n]
    if neighbor_r[0] == 1 and neighbor_r[1]['method']:
        intersects = neighbor_r[1]['intersects']
        ### get the left intersect
        if neighbor_r[1]['method'] == 'PLIC':
            intersects_tag = neighbor_r[1]['intersects_tag']
            intersect = intersects[0]
            if not np.isnan(intersect).all():
                y = intersect[1]
                if y < 0.5 * dy:
                    result[5, 0] = dx
                    result[5, 1] = y
                    result_tag[5, 0] = intersects_tag[0]
                    result_tag[5, 1] = intersects_tag[1]
                else:
                    result[4, 0] = dx
                    result[4, 1] = y
                    result_tag[4, 0] = intersects_tag[0]
                    result_tag[4, 1] = intersects_tag[1]
            else:
                pass
        elif neighbor_r[1]['method'] == 'DP':
            recons_left[5] = 1
            recons_left[4] = 1
        else:
            pass
    else:
        recons_left[5] = 1
        recons_left[4] = 1
    ### lower neighbor
    neighbor_low = reconstruction[m][n - 1]
    if neighbor_low[0] == 1 and neighbor_low[1]['method']:
        intersects = neighbor_low[1]['intersects']
        ### get the upper intersect
        if neighbor_low[1]['method'] == 'PLIC':
            intersects_tag = neighbor_low[1]['intersects_tag']
            intersect = intersects[1]
            if not np.isnan(intersect).all():
                x = intersect[0]
                if x < 0.5 * dx:
                    result[7, 0] = x
                    result[7, 1] = 0.
                    result_tag[7, 0] = intersects_tag[0]
                    result_tag[7, 1] = intersects_tag[1]
                else:
                    result[6, 0] = x
                    result[6, 1] = 0.
                    result_tag[6, 0] = intersects_tag[0]
                    result_tag[6, 1] = intersects_tag[1]
            else:
                pass
        elif neighbor_low[1]['method'] == 'DP':
            recons_left[6] = 1
            recons_left[7] = 1
        else:
            pass
    else:
        recons_left[6] = 1
        recons_left[7] = 1
    ### upper neighbor
    neighbor_up = reconstruction[m][n + 1]
    if neighbor_up[0] == 1 and neighbor_up[1]['method']:
        intersects = neighbor_up[1]['intersects']
        ### get the lower intersect
        if neighbor_up[1]['method'] == 'PLIC':
            intersects_tag = neighbor_up[1]['intersects_tag']
            intersect = intersects[3]
            if not np.isnan(intersect).all():
                x = intersect[0]
                if x < 0.5 * dx:
                    result[2, 0] = x
                    result[2, 1] = dy
                    result_tag[2, 0] = intersects_tag[0]
                    result_tag[2, 1] = intersects_tag[1]
                else:
                    result[3, 0] = x
                    result[3, 1] = dy
                    result_tag[3, 0] = intersects_tag[0]
                    result_tag[3, 1] = intersects_tag[1]
            else:
                pass
        elif neighbor_up[1]['method'] == 'DP':
            recons_left[2] = 1
            recons_left[3] = 1
        else:
            pass
    else:
        recons_left[2] = 1
        recons_left[3] = 1
    return result, result_tag, recons_left


### This function get the neighbor sep without limit for PLIC
def get_neighbor_sep_unlimited_withoutDP(reconstruction, dx, dy, m, n):
    ###initialize
    result = np.zeros([8, 2])
    result_tag = np.zeros([8, 2])
    result.fill(np.nan)
    result_tag.fill(np.nan)
    # ### left neighbor
    # neighbor_l = reconstruction[m - 1][n]
    # if neighbor_l[0] == 1 and neighbor_l[1]['method']:
    #     intersects = neighbor_l[1]['intersects']
    #     ### get the right intersect
    #     if neighbor_l[1]['method'] == 'PLIC':
    #         intersects_unlimited = neighbor_l[1]['intersects_unlimited']
    #         intersect = intersects_unlimited[2]
    #         if not np.isnan(intersect).all():
    #             y = intersect[1]
    #             result[0, 0] = 0.
    #             result[0, 1] = y
    #             result[1, 0] = 0.
    #             result[1, 1] = y
    #         else:
    #             pass
        # elif neighbor_l[1]['method'] == 'DP':
        #     if not np.isnan(intersects[5]).all():
        #         result[0, 1] = intersects[5, 1]
        #         result[0, 0] = 0.
        #     else:
        #         pass
        #     if not np.isnan(intersects[4]).all():
        #         result[1, 1] = intersects[4, 1]
        #         result[1, 0] = 0.
        #     else:
        #         pass
    #     else:
    #         pass
    # else:
    #     pass
    # ### right neighbor
    # neighbor_r = reconstruction[m + 1][n]
    # if neighbor_r[0] == 1 and neighbor_r[1]['method']:
    #     intersects = neighbor_r[1]['intersects']
    #     # print('The intersects are: ', intersects)
    #     ### get the left intersect
    #     if neighbor_r[1]['method'] == 'PLIC':
    #         intersects_unlimited = neighbor_r[1]['intersects_unlimited']
    #         intersect = intersects_unlimited[0]
    #         # print('The intersection at the right side is: ', intersect)
    #         if not np.isnan(intersect).all():
    #             y = intersect[1]
    #             result[5, 0] = dx
    #             result[5, 1] = y
    #             result[4, 0] = dx
    #             result[4, 1] = y
    #         else:
    #             pass
        # elif neighbor_r[1]['method'] == 'DP':
        #     if not np.isnan(intersects[0]).all():
        #         result[5, 1] = intersects[0, 1]
        #         result[5, 0] = dx
        #     else:
        #         pass
        #     if not np.isnan(intersects[1]).all():
        #         result[4, 1] = intersects[1, 1]
        #         result[4, 0] = dx
        #     else:
        #         pass
    #     else:
    #         pass
    # else:
    #     pass
    # ### lower neighbor
    # neighbor_low = reconstruction[m][n - 1]
    # if neighbor_low[0] == 1 and neighbor_low[1]['method']:
    #     intersects = neighbor_low[1]['intersects']
    #     ### get the upper intersect
    #     if neighbor_low[1]['method'] == 'PLIC':
    #         intersects_unlimited = neighbor_low[1]['intersects_unlimited']
    #         intersect = intersects_unlimited[1]
    #         if not np.isnan(intersect).all():
    #             x = intersect[0]
    #             result[7, 0] = x
    #             result[7, 1] = 0.
    #             result[6, 0] = x
    #             result[6, 1] = 0.
    #         else:
    #             pass
    #     # elif neighbor_low[1]['method'] == 'DP':
    #     #     if not np.isnan(intersects[2]).all():
    #     #         result[7, 0] = intersects[2, 0]
    #     #         result[7, 1] = 0.
    #     #     else:
    #     #         pass
    #     #     if not np.isnan(intersects[3]).all():
    #     #         result[6, 0] = intersects[3, 0]
    #     #         result[6, 1] = 0.
    #     #     else:
    #     #         pass
    #     else:
    #         pass
    # else:
    #     pass
    # ### upper neighbor
    # neighbor_up = reconstruction[m][n + 1]
    # if neighbor_up[0] == 1 and neighbor_up[1]['method']:
    #     intersects = neighbor_up[1]['intersects']
    #     ### get the lower intersect
    #     if neighbor_up[1]['method'] == 'PLIC':
    #         intersects_unlimited = neighbor_up[1]['intersects_unlimited']
    #         intersect = intersects_unlimited[3]
    #         if not np.isnan(intersect).all():
    #             x = intersect[0]
    #             result[2, 0] = x
    #             result[2, 1] = dy
    #             result[3, 0] = x
    #             result[3, 1] = dy
    #         else:
    #             pass
    #     # elif neighbor_up[1]['method'] == 'DP':
    #     #     if not np.isnan(intersects[7]).all():
    #     #         result[2, 0] = intersects[7, 0]
    #     #         result[2, 1] = dy
    #     #     else:
    #     #         pass
    #     #     if not np.isnan(intersects[6]).all():
    #     #         result[3, 0] = intersects[6, 0]
    #     #         result[3, 1] = dy
    #     #     else:
    #     #         pass
    #     else:
    #         pass
    # else:
    #     pass
    return result, result_tag

### This function returns all the grid location around the three-phase grid
### where the intersection conditions are not the same
def get_trouble_grid_3(reconstruction, Sf, ghost):
    en_x = []
    en_y = []
    tri_x = []
    tri_y = []
    reason = []
    for i in range(len(Sf[0]) - 2 * ghost):
        for j in range(len(Sf[0, 0]) - 2 * ghost):
            trouble = False
            grid_info = reconstruction[i + ghost][j + ghost]
            if grid_info[1]['method'] == 'DP':
                sep = grid_info[1]['intersects']
                ### left neighbor
                neighbor = reconstruction[i + ghost - 1][j + ghost]
                if neighbor[0] == 1 and neighbor[1]['method']:
                    neigh_sep = neighbor[1]['intersects']
                    judge_intersect = (not np.isnan(sep[0]).all()) or (not np.isnan(sep[1]).all())
                    if neighbor[1]['method'] == 'PLIC':
                        intersect = neigh_sep[2]
                        judge_intersect_nei = np.isnan(intersect).all()
                        if judge_intersect and judge_intersect_nei:
                            trouble = True
                            en_x.append(i + ghost - 1)
                            en_y.append(j + ghost)
                            reason.append('left neighbor')
                        else:
                            sub_trouble = judge_subtrouble_single(reconstruction, ghost, i - 1, j)
                            if sub_trouble:
                                trouble = True
                                en_x.append(i + ghost - 1)
                                en_y.append(j + ghost)
                    else:
                        pass
                else:
                    pass
                ### right neighbor
                neighbor = reconstruction[i + ghost + 1][j + ghost]
                if neighbor[0] == 1 and neighbor[1]['method']:
                    neigh_sep = neighbor[1]['intersects']
                    judge_intersect = (not np.isnan(sep[4]).all()) or (not np.isnan(sep[5]).all())
                    if neighbor[1]['method'] == 'PLIC':
                        intersect = neigh_sep[0]
                        judge_intersect_nei = np.isnan(intersect).all()
                        if judge_intersect and judge_intersect_nei:
                            trouble = True
                            en_x.append(i + ghost + 1)
                            en_y.append(j + ghost)
                            reason.append('right neighbor')
                        else:
                            sub_trouble = judge_subtrouble_single(reconstruction, ghost, i + 1, j)
                            if sub_trouble:
                                trouble = True
                                en_x.append(i + ghost + 1)
                                en_y.append(j + ghost)
                    else:
                        pass
                else:
                    pass
                ### lower neighbor
                neighbor = reconstruction[i + ghost][j + ghost - 1]
                if neighbor[0] == 1 and neighbor[1]['method']:
                    neigh_sep = neighbor[1]['intersects']
                    judge_intersect = (not np.isnan(sep[6]).all()) or (not np.isnan(sep[7]).all())
                    if neighbor[1]['method'] == 'PLIC':
                        intersect = neigh_sep[1]
                        judge_intersect_nei = np.isnan(intersect).all()
                        if judge_intersect and judge_intersect_nei:
                            trouble = True
                            en_x.append(i + ghost)
                            en_y.append(j + ghost - 1)
                            reason.append('lower neighbor')
                        else:
                            sub_trouble = judge_subtrouble_single(reconstruction, ghost, i, j - 1)
                            if sub_trouble:
                                trouble = True
                                en_x.append(i + ghost)
                                en_y.append(j + ghost - 1)
                    else:
                        pass
                else:
                    pass
                ### upper neighbor
                neighbor = reconstruction[i + ghost][j + ghost + 1]
                if neighbor[0] == 1 and neighbor[1]['method']:
                    neigh_sep = neighbor[1]['intersects']
                    judge_intersect = (not np.isnan(sep[2]).all()) or (not np.isnan(sep[3]).all())
                    if neighbor[1]['method'] == 'PLIC':
                        intersect = neigh_sep[3]
                        judge_intersect_nei = np.isnan(intersect).all()
                        if judge_intersect and judge_intersect_nei:
                            trouble = True
                            en_x.append(i + ghost)
                            en_y.append(j + ghost + 1)
                            reason.append('upper neighbor')
                        else:
                            sub_trouble = judge_subtrouble_single(reconstruction, ghost, i, j + 1)
                            if sub_trouble:
                                trouble = True
                                en_x.append(i + ghost)
                                en_y.append(j + ghost + 1)
                    else:
                        pass
                else:
                    pass
            else:
                pass

            if trouble and grid_info[1]['method'] == 'DP':
                tri_x.append(i + ghost)
                tri_y.append(j + ghost)
            else:
                pass
    return tri_x, tri_y, en_x, en_y, reason

def judge_subtrouble_single(reconstruction, ghost, i, j):
    trouble = False
    grid_info = reconstruction[i + ghost][j + ghost]
    sep = grid_info[1]['intersects']
    ### left neighbor
    neighbor = reconstruction[i - 1 + ghost][j + ghost]
    if neighbor[0] == 1 and neighbor[1]['method']:
        neigh_sep = neighbor[1]['intersects']
        judge_intersect = not np.isnan(sep[0]).all()
        if neighbor[1]['method'] == 'PLIC':
            intersect = neigh_sep[2]
            judge_intersect_nei = np.isnan(intersect).all()
            A = judge_intersect and judge_intersect_nei
            B = not judge_intersect and not judge_intersect_nei
            if A or B:
                trouble = True
            else:
                pass
        else:
            pass
    else:
        pass
    ### right neighbor
    neighbor = reconstruction[i + ghost + 1][j + ghost]
    if neighbor[0] == 1 and neighbor[1]['method']:
        neigh_sep = neighbor[1]['intersects']
        judge_intersect = not np.isnan(sep[2]).all()
        if neighbor[1]['method'] == 'PLIC':
            intersect = neigh_sep[0]
            judge_intersect_nei = np.isnan(intersect).all()
            A = judge_intersect and judge_intersect_nei
            B = not judge_intersect and not judge_intersect_nei
            if A or B:
                trouble = True
            else:
                pass
        else:
            pass
    else:
        pass
    ### lower neighbor
    neighbor = reconstruction[i + ghost][j + ghost - 1]
    if neighbor[0] == 1 and neighbor[1]['method']:
        neigh_sep = neighbor[1]['intersects']
        judge_intersect = not np.isnan(sep[3]).all()
        if neighbor[1]['method'] == 'PLIC':
            intersect = neigh_sep[1]
            judge_intersect_nei = np.isnan(intersect).all()
            A = judge_intersect and judge_intersect_nei
            B = not judge_intersect and not judge_intersect_nei
            if A or B:
                trouble = True
            else:
                pass
        else:
            pass
    else:
        pass
    ### upper neighbor
    neighbor = reconstruction[i + ghost][j + ghost + 1]
    if neighbor[0] == 1 and neighbor[1]['method']:
        neigh_sep = neighbor[1]['intersects']
        judge_intersect = not np.isnan(sep[1]).all()
        if neighbor[1]['method'] == 'PLIC':
            intersect = neigh_sep[3]
            judge_intersect_nei = np.isnan(intersect).all()
            A = judge_intersect and judge_intersect_nei
            B = not judge_intersect and not judge_intersect_nei
            if A or B:
                trouble = True
            else:
                pass
        else:
            pass
    else:
        pass
    return trouble

### This function is used to move the position point to avoid sharp interface formation
def flatten_interface(pos, posL, cells, volumes):
    # print('activate!')
    threshold_cos = 0.996
    yita = 0.005
    pos_new = copy.deepcopy(pos)
    changed = False
    volumes_new = np.zeros([len(volumes)])
    cells_new = copy.deepcopy(cells)
    # print(pos)
    # print(cells)
    if len(pos) == 1:
        if len(cells) > 2:
            pass
            # # print('len(pos)=1')
            # for i in range(len(cells)):
            #     line_a = np.array(-cells[i][1][0] + cells[i][1][1])
            #     line_b = np.array(-cells[i][1][0] + cells[i][1][-1])
            #     # print(line_a, line_b)
            #     dot = np.dot(line_a, line_b)
            #     # print(dot)
            #     ang_cos = dot / (np.sqrt(line_a[0] ** 2 + line_a[1] ** 2) * np.sqrt(line_b[0] ** 2 + line_b[1] ** 2))
            #     # print(ang_cos)
            #     volume = get_cell_volume(cells[i][1])
            #     # print(volume)
            #     if ang_cos > threshold_cos and (volume < yita or volume > 1 - yita):
            #         pos_new[0] = 0.5 * (cells[i][1][1] + cells[i][1][-1])
            #         changed = True
            #         posL.append(pos_new)
            #         break
            #     else:
            #         pass
            # if changed:
            #     ### update the cells and volumes
            #     for i in range(len(cells)):
            #         cells_new[i][1][0] = pos_new[0]
            #     for i in range(len(cells)):
            #         volumes_new[cells_new[i][0]] += get_cell_volume(cells_new[i][1])
            #     return pos_new, posL, cells_new, volumes_new, changed
        else:
            for i in range(len(cells)):
                line_a = np.array(-cells[i][1][0] + cells[i][1][1])
                line_b = np.array(-cells[i][1][0] + cells[i][1][-1])
                # print(line_a, line_b)
                dot = np.dot(line_a, line_b)
                # print(dot)
                ang_cos = dot / (np.sqrt(line_a[0] ** 2 + line_a[1] ** 2) * np.sqrt(line_b[0] ** 2 + line_b[1] ** 2))
                # print(ang_cos)
                volume = get_cell_volume_shapely(cells[i][1])
                # print(volume)
                if ang_cos > threshold_cos and (volume < yita or volume > 1 - yita):
                    pos_new[0] = 0.5 * (cells[i][1][1] + cells[i][1][-1])
                    changed = True
                    posL.append(pos_new)
                    break
                else:
                    pass
            if changed:
                ### update the cells and volumes
                for i in range(len(cells)):
                    cells_new[i][1][0] = pos_new[0]
                for i in range(len(cells)):
                    volumes_new[cells_new[i][0]] += get_cell_volume_shapely(cells_new[i][1])
                return pos_new, posL, cells_new, volumes_new, changed
    elif len(pos) == 2:
        # print('len(pos)=2')
        for i in range(len(cells)):
            ### is not a subcell
            if not cells[i][-1] == 1:
                line_a = np.array(-cells[i][1][0] + cells[i][1][1])
                line_b = np.array(-cells[i][1][0] + cells[i][1][-1])
                dot = np.dot(line_a, line_b)
                # print(line_a, line_b)
                # print(dot)
                ang_cos = dot / (np.sqrt(line_a[0] ** 2 + line_a[1] ** 2) * np.sqrt(line_b[0] ** 2 + line_b[1] ** 2))
                # print(ang_cos)
                volume = get_cell_volume_shapely(cells[i][1])
                # print(volume)
                if ang_cos > threshold_cos and (volume < yita or volume > 1 - yita):
                    # print(cells[i][1][0], pos[0], pos[1])
                    if (cells[i][1][0] == pos[0]).all():
                        # print('first dp')
                        pos_new[0] = 0.5 * (cells[i][1][1] + cells[i][1][-1])
                        changed = True
                        posL.append(pos_new)
                    elif (cells[i][1][0] == pos[1]).all():
                        # print('second dp')
                        pos_new[1] = 0.5 * (cells[i][1][1] + cells[i][1][-1])
                        changed = True
                        posL.append(pos_new)
                    else:
                        pass
                else:
                    pass
            else:
                pass
        if changed:
            ### update the cells and volumes
            for i in range(len(cells)):
                if not cells[i][-1] == 1:
                    if (cells[i][1][0] == pos[0]).all():
                        cells_new[i][1][0] = pos_new[0]
                    elif (cells[i][1][0] == pos[1]).all():
                        cells_new[i][1][0] = pos_new[1]
                    else:
                        pass
                else:
                    ### subcell
                    cells_new[i][1][0] = pos_new[0]
                    cells_new[i][1][1] = pos_new[1]
            for i in range(len(cells)):
                volumes_new[cells_new[i][0]] += get_cell_volume_shapely(cells_new[i][1])
            return pos_new, posL, cells_new, volumes_new, changed
    else:
        # print('len(pos) > 2')
        pass

    return pos_new, posL, cells, volumes, changed

