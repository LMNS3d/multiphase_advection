###This is the function toolbox
###creator: Zhang, HKUST
from shutil import Error

import numpy as np
import math

from numpy.distutils.misc_util import terminal_has_colors
from shapely import Polygon, Point

###This is the gradient calculator which calculates the gradient of a scalar field at point (i, j)
###The method used is based on Parker and Youngs’ method
###input
###sf: the scalar field for a single phase that must contains 3 * 3 stencil around (i, j)
###i, j: the location point where the gradient applied
###dx, dy: the grid intervals
###output
###gradient: arrary([[grad_x],[grad_y]])
def gradient_point(sf, i, j, dx, dy):
    ###make sure a 3 * 3 stencil exist
    # test = True
    # for m in range(3):
    #     for n in range(3):
    #         if np.isnan(sf[i + m - 1][j + n - 1]):
    #             test = False
    #             return test
    # if test:
    f_E = 0.25 * (sf[i + 1][j - 1] + 2 * sf[i + 1][j] + sf[i + 1][j + 1])
    f_W = 0.25 * (sf[i - 1][j - 1] + 2 * sf[i - 1][j] + sf[i - 1][j + 1])
    f_N = 0.25 * (sf[i - 1][j + 1] + 2 * sf[i][j + 1] + sf[i + 1][j + 1])
    f_S = 0.25 * (sf[i - 1][j - 1] + 2 * sf[i][j - 1] + sf[i + 1][j - 1])
    grad_x = (1 / (2 * dx)) * (f_E - f_W)
    grad_y = (1 / (2 * dy)) * (f_N - f_S)
    ###we obtain the gradient after a normalization
    if (grad_x ** 2 + grad_y ** 2) != 0:
        scale = 1 / np.sqrt(grad_x ** 2 + grad_y ** 2)
        grad_x = scale * grad_x
        grad_y = scale * grad_y
        # print(grad_x, grad_y)
        normal = np.array([grad_x, grad_y])
    else:
        ### no gradient condition: assume normal [0., 0.]
        normal = np.array([0., 0.])
    return normal
    # else:
    #     return False

###This is a function that mix the two given scalar fields by just adding up entities
###input
###sf1, sf2: the scalar fields for a single phase that need to be added
def sf_mix(sf1, sf2):
    mix_sf = sf1 + sf2
    return mix_sf

###This function acquire the normal vector which modified based on the alignment to the cell boundary
def slic_align_normal(normal):
    normal_abs = normal.copy()
    for i in range(len(normal)):
        normal_abs[i] = abs(normal[i])
    grad_ind = np.argmax(normal_abs)
    if normal[grad_ind] > 0:
        normal = np.array([1. - grad_ind, grad_ind])
    else:
        normal = np.array([-1. + grad_ind, -grad_ind])
    return normal

###This function calculates the remaining rectangular cell
###cell is represented by [lower-left-x, lower-left-y, upper-right-x, upper-right-y]
###d is local distance relative to cell[0, 0], always positive
def slic_rectangular_cell_remain(cell, normal, d):
    if normal[0] == 1:
        cell[0] += d
    elif normal[0] == -1:
        cell[2] -= (cell[2] - cell[0]) - d
    elif normal[1] == 1:
        cell[1] += d
    elif normal[1] == -1:
        cell[3] -= (cell[3] - cell[1]) - d
    else:
        pass
    return cell

###This function calculates the distance of the offset which cut the cell according to the volume fraction
###The alpha is the volume fraction relative to the remaining volume, subtracting the already occupied phases
###The distance has sign which indicates the inner volume, we strictly follow the equation
###n * x - d <= 0 is the volume the phase occupied
###here, d is local distance relative to cell[0, 0], local d is always larger than 0
def slic_rectangular_offset(cell, normal, alpha):
    d = 0
    if normal[0] == 1:
        d = alpha * (cell[2] - cell[0])
    elif normal[0] == -1:
        d = (1 - alpha) * (cell[2] - cell[0])
    elif normal[1] == 1:
        d = alpha * (cell[3] - cell[1])
    elif normal[1] == -1:
        d = (1 - alpha) * (cell[3] - cell[1])
    else:
        pass
    return d

###This function used to get a global d from cell, normal and local d
def get_global_d(cell, normal, d):
    gd = 0
    if normal[0] == 1:
        gd = cell[0] + d
    elif normal[0] == -1:
        gd = -(cell[0] + d)
    elif normal[1] == 1:
        gd = cell[1] + d
    elif normal[1] == -1:
        gd = -(cell[1] + d)
    else:
        pass
    return gd

###This function calculate the cell boundary value from the given field by linear interpolation
###input
###sf is the single phase scalar field
###The calculation is central scheme averaged by f_i-+1/2 = (f_i + f_i-+1) / 2
###direction indicates the x or y direction the averaging procedure applied on 0 for x, 1 for y
###sign indicates which side the boundary is calculated, 0 for - and 1 for +
###The output is just the value of the cell boundary f
def cell_boundary(sf, direction, i, j, sign):
    f_tar = 0
    if direction == 0:
        f_tar = 0.5 * (sf[i][j] + (1 - sign) * sf[i - 1][j] + sign * sf[i + 1][j])
    elif direction == 1:
        f_tar = 0.5 * (sf[i][j] + (1 - sign) * sf[i][j - 1] + sign * sf[i][j + 1])
    else:
        pass
    return f_tar

###This function based on the cell_boundary, just iteratively get four sides
###The output
###sides = [fx-, fx+, fy-, fy+]
def cell_boundarys(sf, i, j):
    sides = []
    directions = [0, 1]
    signs = [0, 1]
    for direc in directions:
        for sign in signs:
            f_cb = cell_boundary(sf, direc, i, j, sign)
            sides.append(f_cb)
    sides = np.array(sides)
    return sides

###This function calculate the slope of the cell interface based on the four side fractions
###according to Youngs-1982-Fig1.(c)
###input
###cbs = [fx-, fx+, fy-, fy+]
def cell_slope(cbs):
    if cbs[2] != cbs[3]:
        k = (cbs[1] - cbs[0]) / (cbs[2] - cbs[3])
    else:
        k = float('inf')
    return k

### This function calculate the normal vector from the slope, according to the gradient,
### we define the normal points outward
###input
### k refers to the slope
### the gradient of the phase at the cell center
def slope2normal(k, grad):
    normal = np.array([0., 0.])
    ###first check is the k is infinite
    if k == math.inf:
        normal[1] = 1.
    else:
        theta = math.atan(k)
        normal[0] = -math.sin(theta)
        normal[1] = math.cos(theta)
    ### check the normal direction
    if grad.dot(normal) > 0:
        normal = -normal
    return normal

###This function get the four intersection point between a given line and the grid sides
###input
###normal: normal vector of the line
###distance: normal distance followed by n * x - d <= 0
###dx, dy: the grid intervals
###output
###[x-, x+, y-, y+], in which x_.. are position vectors
def get_intersects(normal, dis, dx, dy):
    # print(normal, dis)
    ###initialize
    x_E = np.array([0., 0.])
    x_W = np.array([0., 0.])
    x_N = np.array([0., 0.])
    x_S = np.array([0., 0.])
    ###calculate the abnormal condition where the line is horizontal or vertical
    if normal[1] == 0. and normal[0] != 0.:
        x_E[0] = None
        x_E[1] = None
        x_W[0] = None
        x_W[1] = None
        x_S[0] = dis / normal[0]
        if x_S[0] < 0. or x_S[0] > dx:
            x_S[0] = None
            x_S[1] = None
            x_N[0] = None
            x_N[1] = None
        else:
            x_N[0] = x_S[0]
            x_N[1] = dy
        result = np.array([x_W, x_E, x_S, x_N])
        return result
    elif normal[0] == 0. and normal[1] != 0.:
        x_N[0] = None
        x_N[1] = None
        x_S[0] = None
        x_S[1] = None
        x_W[1] = dis / normal[1]
        if x_W[1] < 0. or x_W[1] > dy:
            x_W[1] = None
            x_W[0] = None
            x_E[1] = None
            x_E[0] = None
        else:
            x_E[1] = x_W[1]
            x_E[0] = dx
        result = np.array([x_W, x_E, x_S, x_N])
        return result
    elif normal[0] == 0. and normal[1] == 0.:
        x_E[0] = None
        x_E[1] = None
        x_W[0] = None
        x_W[1] = None
        x_S[0] = None
        x_S[1] = None
        x_N[0] = None
        x_N[1] = None
        result = np.array([x_W, x_E, x_S, x_N])
        return result
    else:
        ###calculate the intersection with the West side
        x_W[1] = dis / (normal[1] + 1e-12)
        if x_W[1] < 0. or x_W[1] > dy:
            x_W[1] = None
            x_W[0] = None
        ###East
        x_E[1] = (dis - normal[0] * dx) / (normal[1] + 1e-12)
        x_E[0] = dx
        if x_E[1] < 0. or x_E[1] > dy:
            x_E[1] = None
            x_E[0] = None
        ###North
        x_N[0] = (dis - normal[1] * dy) / (normal[0] + 1e-12)
        x_N[1] = dy
        if x_N[0] < 0. or x_N[0] > dx:
            x_N[0] = None
            x_N[1] = None
        ###South
        x_S[0] = dis / (normal[0] + 1e-12)
        if x_S[0] < 0. or x_S[0] > dx:
            x_S[0] = None
            x_S[1] = None
        result = np.array([x_W, x_E, x_S, x_N])
        return result

###This function calculate the grid volume enclosed by the line, the normal vector points outwards
###input
###normal: normal vector of the line
###distance: normal distance followed by n * x - d <= 0
###dx, dy: the grid intervals
###output
###value of the volume
def cut_volume(normal, distance, dx, dy):
    volume = 0.
    ###first get the intersects of the cell
    intersects = get_intersects(normal, distance, dx, dy)
    ###if they have intersections
    if not np.isnan(intersects).all():
        ###line intersects the opposite sides
        # print(intersects)
        ###x- and x+
        if not np.isnan(intersects[0]).all() and not np.isnan(intersects[1]).all():
            rect_h = min(intersects[0][1], intersects[1][1])
            tran_h = max(intersects[0][1], intersects[1][1]) - rect_h
            volume = dx * (rect_h + 0.5 * tran_h)
            # print(volume)
            volume = (normal[1] > 0) * volume + (normal[1] < 0) * (dx * dy - volume)
            return volume
        ###y- and y+
        elif not np.isnan(intersects[2]).all() and not np.isnan(intersects[3]).all():
            rect_h = min(intersects[2][0], intersects[3][0])
            tran_h = max(intersects[2][0], intersects[3][0]) - rect_h
            volume = dy * (rect_h + 0.5 * tran_h)
            # print(volume)
            volume = (normal[0] > 0) * volume + (normal[0] < 0) * (dx * dy - volume)
            # print(volume)
            return volume
        ###neighboring sides
        ###x- and y-
        elif not np.isnan(intersects[0]).all() and not np.isnan(intersects[2]).all():
            volume = 0.5 * intersects[0][1] * intersects[2][0]
            # print(volume)
            volume = (normal[0] > 0) * volume + (normal[0] < 0) * (dx * dy - volume)
            return volume
        ###x- and y+
        elif not np.isnan(intersects[0]).all() and not np.isnan(intersects[3]).all():
            volume = 0.5 * (dy - intersects[0][1]) * intersects[3][0]
            # print(volume)
            volume = (normal[0] > 0) * volume + (normal[0] < 0) * (dx * dy - volume)
            return volume
        ###x+ and y-
        elif not np.isnan(intersects[1]).all() and not np.isnan(intersects[2]).all():
            volume = 0.5 * (dx - intersects[2][0]) * intersects[1][1]
            # print(volume)
            volume = (normal[0] < 0) * volume + (normal[0] > 0) * (dx * dy - volume)
            return volume
        ###x+ and y+
        elif not np.isnan(intersects[1]).all() and not np.isnan(intersects[3]).all():
            volume = 0.5 * (dx - intersects[3][0]) * (dy - intersects[1][1])
            # print(volume)
            volume = (normal[0] < 0) * volume + (normal[0] > 0) * (dx * dy - volume)
            return volume
        else:
            return volume
    ###condition where no intersection point at all
    else:
        if distance >= 0 and dx * normal[0] + dy * normal[1] - distance <= 0 :
            volume = dx * dy
        else:
            pass
        return volume

###This function is used to compute the distance d in the equation n * x - d <= 0
###with the constraint of the volume fraction in the subgrid
###input
###normal: normal direction of the line, n
###dx, dy: grid intervals
###f_tar: targeted volume fraction
###output
###d: the distance in the equation n * x - d <= 0
def get_d_lineSearch(normal, dx, dy, f_tar):
    d = 0.
    # print('The target volume is: ', f_tar)
    distances = np.linspace(0, math.sqrt(dx ** 2 + dy ** 2), 100)
    for l in range(len(distances) - 1):
        cut_V1 = cut_volume(normal, distances[l], dx, dy)
        temp_frac1 = cut_V1 / (dx * dy)
        error1 = temp_frac1 - f_tar
        cut_V2 = cut_volume(normal, distances[l + 1], dx, dy)
        temp_frac2 = cut_V2 / (dx * dy)
        error2 = temp_frac2 - f_tar
        cut_V3 = cut_volume(normal, -distances[l], dx, dy)
        temp_frac3 = cut_V3 / (dx * dy)
        error3 = temp_frac3 - f_tar
        cut_V4 = cut_volume(normal, -distances[l + 1], dx, dy)
        temp_frac4 = cut_V4 / (dx * dy)
        error4 = temp_frac4 - f_tar
        # print('The cut volume is: ', [cut_V1, cut_V2, cut_V3, cut_V4])
        if error1 * error2 <= 0:
            ###choose the cloest one
            ind = np.argmin(np.array([abs(error1), abs(error2)]))
            d = distances[l + ind]
            break
        elif error3 * error4 <= 0:
            ###choose the cloest one
            ind = np.argmin(np.array([abs(error1), abs(error2)]))
            d = -distances[l + ind]
            break
        else:
            pass
    return d

def get_d_lineSearch_speci(normal, dx, dy, f_tar, resolution):
    d = 0.
    # print('The target volume is: ', f_tar)
    distances = np.linspace(0, math.sqrt(dx ** 2 + dy ** 2), resolution)
    time = 0
    error = float('inf')
    for l in range(len(distances) - 1):
        cut_V1 = cut_volume(normal, distances[l], dx, dy)
        temp_frac1 = cut_V1 / (dx * dy)
        error1 = temp_frac1 - f_tar
        cut_V2 = cut_volume(normal, distances[l + 1], dx, dy)
        temp_frac2 = cut_V2 / (dx * dy)
        error2 = temp_frac2 - f_tar
        cut_V3 = cut_volume(normal, -distances[l], dx, dy)
        temp_frac3 = cut_V3 / (dx * dy)
        error3 = temp_frac3 - f_tar
        cut_V4 = cut_volume(normal, -distances[l + 1], dx, dy)
        temp_frac4 = cut_V4 / (dx * dy)
        error4 = temp_frac4 - f_tar
        time += 4
        # print('The cut volume is: ', [cut_V1, cut_V2, cut_V3, cut_V4])
        if error1 * error2 <= 0:
            ###choose the cloest one
            ind = np.argmin(np.array([abs(error1), abs(error2)]))
            d = distances[l + ind]
            error = min([abs(error1), abs(error2)])
            break
        elif error3 * error4 <= 0:
            ###choose the cloest one
            ind = np.argmin(np.array([abs(error1), abs(error2)]))
            d = -distances[l + ind]
            error = min([abs(error1), abs(error2)])
            break
        else:
            pass
    # print(time)
    # print(error)
    return d

### This function uses a dichotomy search
def get_d_lineSearch_DP5(normal, dx, dy, f_tar, error_tar):
    d = 0.
    small = -math.sqrt(dx ** 2 + dy ** 2)
    large = math.sqrt(dx ** 2 + dy ** 2)
    error = float('inf')
    time = 0
    while (error > error_tar and time < 30) :
        cut_V1 = cut_volume(normal, small, dx, dy)
        temp_frac1 = cut_V1 / (dx * dy)
        error1 = temp_frac1 - f_tar
        cut_V2 = cut_volume(normal, large, dx, dy)
        temp_frac2 = cut_V2 / (dx * dy)
        error2 = temp_frac2 - f_tar
        cut_V3 = cut_volume(normal, (large + small) * 0.5, dx, dy)
        temp_frac3 = cut_V3 / (dx * dy)
        error3 = temp_frac3 - f_tar
        time += 1
        if error1 * error3 <= 0:
            ### choose (large + small) * 0.5 and small
            large = (large + small) * 0.5
            error = max(abs(error1), abs(error3))
            d = (large + small) * 0.5
        elif error2 * error3 <= 0:
            ### choose (large + small) * 0.5 and large
            small = (large + small) * 0.5
            error = max(abs(error2), abs(error3))
            d = (large + small) * 0.5
        else:
            break
    return d

### THIS FUNCTION IS USED IN YOUNGS METHOD, SEARCH WITHIN THE POLYGON WITH ASSIGNED D RANGE
def get_d_lineSearch_general(polygon, normal, dx, dy, f_tar, tolerance):
    d_s, d_l = get_d_range(normal, polygon)
    error = float('inf')
    time = 0
    time_max = 30
    while error > tolerance and time < time_max:
        cut_V1 = get_cut_volume_polygon(polygon, normal, d_s)
        temp_frac1 = cut_V1 / (dx * dy)
        error1 = temp_frac1 - f_tar
        cut_V2 = get_cut_volume_polygon(polygon, normal, d_l)
        temp_frac2 = cut_V2 / (dx * dy)
        error2 = temp_frac2 - f_tar
        cut_V3 = get_cut_volume_polygon(polygon, normal, 0.5 * (d_s + d_l))
        temp_frac3 = cut_V3 / (dx * dy)
        error3 = temp_frac3 - f_tar
        time += 1
        if error1 * error3 <= 0:
            ### choose (large + small) * 0.5 and small
            d_l = (d_l + d_s) * 0.5
            error = max(abs(error1), abs(error3))
        elif error2 * error3 <= 0:
            ### choose (large + small) * 0.5 and large
            d_s = (d_l + d_s) * 0.5
            error = max(abs(error2), abs(error3))
        else:
            if error1 > error2:
                return d_l
            else:
                return d_s
    d = (d_l + d_s) * 0.5
    return d

### THIS FUNCTION RETURN THE MAXIMUM AND MINIMUM D WHEN INTERSECTING WTIH AN ARBITRARY POLYGON WITH FIX NORMAL
def get_d_range(normal, polygon):
    d_L = []
    for p in range(len(polygon)):
        vertex = polygon[p]
        d_p = normal.dot(vertex)
        d_L.append(d_p)
    d_min = min(d_L)
    d_max = max(d_L)
    return d_min, d_max

###This function gives the remaining cell cut by a line from original cell [0, 0, dx, dy]
###input
###normal, d, dx, dy
###ouput
###cell = [vertice1, vertice2, ...] from the lower-left, clockwise
def plic_cell_remain(normal, d, dx, dy):
    intersects = get_intersects(normal, d, dx, dy)
    # print(intersects)
    if not np.isnan(intersects).all():
        ###line intersects the opposite sides
        # print(intersects)
        ###x- and x+
        if not np.isnan(intersects[0]).all() and not np.isnan(intersects[1]).all():
            indicator = np.array([0., 0.]).dot(normal) - d
            if indicator <= 0:
                cell = np.array([
                    [0., intersects[0][1]],
                    [0., dy],
                    [dx, dy],
                    [dx, intersects[1][1]]
                ])
            else:
                cell = np.array([
                    [0., 0.],
                    [0., intersects[0][1]],
                    [dx, intersects[1][1]],
                    [dx, 0.]
                ])
            return cell
        ###y- and y+
        elif not np.isnan(intersects[2]).all() and not np.isnan(intersects[3]).all():
            indicator = np.array([0., 0.]).dot(normal) - d
            if indicator <= 0:
                cell = np.array([
                    [intersects[2][0], 0.],
                    [intersects[3][0], dy],
                    [dx, dy],
                    [dx, 0.]
                ])
            else:
                cell = np.array([
                    [0., 0.],
                    [0., dy],
                    [intersects[3][0], dy],
                    [intersects[2][0], 0.]
                ])
            return cell
        ###line intersects the neighboring side
        ###x- and y-
        elif not np.isnan(intersects[0]).all() and not np.isnan(intersects[2]).all():
            indicator = np.array([0., 0.]).dot(normal) - d
            if indicator <= 0:
                cell = np.array([
                    [intersects[2][0], 0.],
                    [0., intersects[0][1]],
                    [0., dy],
                    [dx, dy],
                    [dx, 0.]
                ])
            else:
                cell = np.array([
                    [0., 0.],
                    [0., intersects[0][1]],
                    [intersects[2][0], 0.]
                ])
            return cell
        ###x- and y+
        elif not np.isnan(intersects[0]).all() and not np.isnan(intersects[3]).all():
            indicator = np.array([0., 0.]).dot(normal) - d
            if indicator <= 0:
                cell = np.array([
                    [0., intersects[0][1]],
                    [0., dx],
                    [intersects[3][0], dy]
                ])
            else:
                cell = np.array([
                    [0., 0.],
                    [0., intersects[0][1]],
                    [intersects[3][0], dy],
                    [dx, dy],
                    [dx, 0.]
                ])
            return cell
        ###x+ and y-
        elif not np.isnan(intersects[1]).all() and not np.isnan(intersects[2]).all():
            indicator = np.array([0., 0.]).dot(normal) - d
            if indicator <= 0:
                cell = np.array([
                    [intersects[2][0], 0.],
                    [dx, intersects[1][1]],
                    [dx, 0.]
                ])
            else:
                cell = np.array([
                    [0., 0.],
                    [0., dy],
                    [dx, dy],
                    [dx, intersects[1][1]],
                    [intersects[2][0], 0.]
                ])
            return cell
        ###x+ and y+
        elif not np.isnan(intersects[1]).all() and not np.isnan(intersects[3]).all():
            indicator = np.array([0., 0.]).dot(normal) - d
            if indicator <= 0:
                cell = np.array([
                    [dx, intersects[1][1]],
                    [intersects[3][0], dy],
                    [dx, dy]
                ])
            else:
                cell = np.array([
                    [0., 0.],
                    [0., dy],
                    [intersects[3][0], dy],
                    [dx, intersects[1][1]],
                    [dx, 0.]
                ])
            return cell
        else:
            pass
    else:
        cell = np.array([[0., 0.],
                         [0., dy],
                         [dx, dy],
                         [dx, 0.]])
        ###The entire cell is in the domain of line
        if not judge_outside_line(cell, normal, d):
            cell = np.array([])
        ###The entire cell lies outside
        else:
            pass
        return cell

### This function bases on the general position, with original point(x, y)
### This function applies only when the cell is partially or entirely inside the line
def plic_cell_remain_general(normal, d, dx, dy, origin):
    polygon = np.array([origin,
                        [origin[0], origin[1] + dy],
                        [origin[0] + dx, origin[1] + dy],
                        [origin[0] + dx, origin[1]]])
    intersects = plic_get_intersects(polygon, normal, d)
    # print('The intersections are: ', intersects)
    if not np.isnan(intersects).all():
        cur = 0
        cell = []
        while cur < len(polygon) and cur < len(intersects):
            if polygon[cur % len(polygon)].dot(normal) - d >= 0:
                cell.append(polygon[cur % len(polygon)])
            else:
                pass
            if (not np.isnan(intersects[cur % len(intersects)]).all() and not
            (intersects[cur % len(intersects)][0] - polygon[cur % len(polygon)][0] == 0 and
             intersects[cur % len(intersects)][1] - polygon[cur % len(polygon)][1] == 0) and not
            (intersects[cur % len(intersects)][0] - polygon[(cur + 1) % len(polygon)][0] == 0 and
             intersects[cur % len(intersects)][1] - polygon[(cur + 1) % len(polygon)][1] == 0)):
                cell.append(intersects[cur % len(intersects)])
            else:
                pass
            cur += 1
        return cell
    else:
        ###The entire cell is in the domain of line
        if not judge_outside_line(polygon, normal, d):
            cell = np.array([])
        ###The entire cell lies outside
        else:
            cell = polygon
        return cell

def plic_cell_remain_with_intersects(normal, d, polygon, intersects):
    cell = []
    if not np.isnan(intersects).all():
        cur = 0
        cell = []
        while cur < len(polygon) and cur < len(intersects):
            if polygon[cur % len(polygon)].dot(normal) - d >= -1e-12:
                cell.append(polygon[cur % len(polygon)])
            else:
                pass
            if (not np.isnan(intersects[cur % len(intersects)]).all() and not
            (intersects[cur % len(intersects)][0] - polygon[cur % len(polygon)][0] == 0 and
             intersects[cur % len(intersects)][1] - polygon[cur % len(polygon)][1] == 0) and not
            (intersects[cur % len(intersects)][0] - polygon[(cur + 1) % len(polygon)][0] == 0 and
             intersects[cur % len(intersects)][1] - polygon[(cur + 1) % len(polygon)][1] == 0)):
                cell.append(intersects[cur % len(intersects)])
            else:
                pass
            cur += 1
    else:
        ###The entire cell is in the domain of line
        if not judge_outside_line(polygon, normal, d):
            pass
        ###The entire cell lies outside
        else:
            cell = polygon
    return cell

### This function test if the cell is completely outside the line
def judge_outside_line(cell, n, d):
    test = np.zeros([len(cell), 1])
    for i in range(len(cell)):
        v = cell[i]
        if n.dot(v) - d >= 0:
            test[i] = None
        else:
            test[i] = 1.
    # print('The test of the outside is: ', test)
    ###### ALL NODES ARE OUTSIDE OF THE LINE
    if np.isnan(test).all():
        # print(np.isnan(test).all())
        return True
    else:

        return False
###This function get the intersection points between a given polygon and the line
###input
###polygon: represents by vertices,[verti1, verti2, ...], from lower-left, clockwise
###normal: normal vector of the line
###distance: normal distance followed by n * x - d <= 0
###output
###[p1, p2, ...], in which p are position vectors, the order is the same as polygon list
### p1 is the point between verti1 and verti2, p2 is the point between verti2 and verti3, ...,
### the last p is between verti_n and verti1
def plic_get_intersects(polygon, normal, dis):
    ###initialize
    result = []
    for i in range(len(polygon)):
        result.append([0., 0.])
    result = np.array(result)
    ###calculate the abnormal condition where the line is horizontal or vertical
    for i in range(len(polygon)):
        if i == len(polygon) - 1:
            points = np.array([polygon[-1], polygon[0]])
        else:
            points = np.array([polygon[i], polygon[i + 1]])
        ###exclude the condition if two vertice is overlapped
        if not (points[0][0] == points[1][0] and points[0][1] == points[1][1]):
            intersect = line_intersection(normal, dis, points)
            if (intersect[0] is not None and (intersect[0] - points[0][0]) * (intersect[0] - points[1][0]) <= 0 and
                    (intersect[1] - points[0][1]) * (intersect[1] - points[1][1]) <= 0):
                result[i][0] = intersect[0]
                result[i][1] = intersect[1]
            else:
                result[i][0] = None
                result[i][1] = None
        else:
            result[i][0] = None
            result[i][1] = None
    return result.round(15)

### This version has no limitation to the intersection point
def plic_get_intersects_DP5(polygon, normal, dis):
    ###initialize
    result = []
    for i in range(len(polygon)):
        result.append([0., 0.])
    result = np.array(result)
    ###calculate the abnormal condition where the line is horizontal or vertical
    for i in range(len(polygon)):
        if i == len(polygon) - 1:
            points = np.array([polygon[-1], polygon[0]])
        else:
            points = np.array([polygon[i], polygon[i + 1]])
        # print(points)
        ###exclude the condition if two vertice is overlapped
        if not (points[0][0] == points[1][0] and points[0][1] == points[1][1]):
            intersect = line_intersection(normal, dis, points)
            if intersect[0] is not None:
                result[i][0] = intersect[0]
                result[i][1] = intersect[1]
            else:
                result[i][0] = None
                result[i][1] = None
        else:
            result[i][0] = None
            result[i][1] = None
    return result

###This function return an intersection point of two infinite long line
###input
###The first line is defined by a normal vector and offset, follows nx-d=0
###normal, d
###The second line is defined by two arbitary non-overlap point
###points = [point1, point2], where point = [x, y]
###output
###The output is the intersection point [x, y], [None, None] if not
def line_intersection(normal, d, points):
    ###first exclude two parallel conditions
    ###horizontal parallel
    if points[0][1] == points[1][1] and normal[0] == 0:
        return np.array([None, None])
    ###vertical parallel
    elif points[0][0] == points[1][0] and normal[1] == 0:
        return np.array([None, None])
    ###non-parallel condition
    ###condition3: second line is horizontal, first line is not horizontal
    elif points[0][1] == points[1][1] and normal[0] != 0:
        y = points[0][1]
        ###The calculation of x is determined by the first line equation
        x = (d - normal[1] * y) / normal[0]
        return np.array([x, y])
    ###condition4: second line is vertical, first line is not vertical
    elif points[0][0] == points[1][0] and normal[1] != 0:
        x = points[0][0]
        y = (d - normal[0] * x) / normal[1]
        return np.array([x, y])
    ###general parallel
    elif ((points[0][0] - points[1][0]) / (points[0][1] - points[1][1])) * normal[0] + normal[1] == 0:
        return np.array([None, None])
    ###condition5: second line is neither horizontal nor vertical, two line has intersection
    else:
        y = ((d + ((normal[0] * points[0][1] * (points[0][0] - points[1][0])) / (points[0][1] - points[1][1])) - normal[0] * points[0][0]) /
             (normal[1] + normal[0] * ((points[0][0] - points[1][0]) / (points[0][1] - points[1][1]))))
        x = (points[0][0] - points[1][0]) * ((y - points[0][1]) / (points[0][1] - points[1][1])) + points[0][0]
        return np.array([x, y])

### THE INPUT IS TWO NORMALS AND DS
def line_intersection_2(normal, d, normal2, d2):
    ###first exclude two parallel conditions
    ###horizontal parallel
    if normal2[0] == 0 and normal[0] == 0:
        return np.array([None, None])
    ###vertical parallel
    elif normal2[1] == 0 and normal[1] == 0:
        return np.array([None, None])
    ###non-parallel condition
    ###condition3: second line is horizontal, first line is not horizontal
    elif normal2[0] == 0 and normal[0] != 0:
        y = -d2 / normal2[1]
        ###The calculation of x is determined by the first line equation
        x = (d - normal[1] * y) / normal[0]
        return np.array([x, y])
    ###condition4: second line is vertical, first line is not vertical
    elif normal2[1] == 0 and normal[1] != 0:
        x = -d2 / normal2[0]
        y = (d - normal[0] * x) / normal[1]
        return np.array([x, y])
    ### condition5: first line is horizontal, second line is not horizontal
    elif normal[0] == 0 and normal2[0] != 0:
        y = -d / normal[1]
        x = (d2 - normal2[1] * y) / normal2[0]
        return np.array([x, y])
    ### condition6: first line is vertical, second line is not vertical
    elif normal[1] == 0 and normal2[1] != 0:
        x = -d / normal[0]
        y = (d2 - normal2[0] * x) / normal2[1]
        return np.array([x, y])
    ###general parallel
    elif normal[1] / normal[0] == normal2[1] / normal2[0]:
        return np.array([None, None])
    ###condition5: second line is neither horizontal nor vertical, two line has intersection
    else:
        y = (d2 - (normal2[0] / normal[0]) * d) * (normal[0] / (normal2[0] * normal[1] - normal2[1] * normal[0]))
        x = (-d - normal[1] * y) / normal[0]
        return np.array([x, y])
###This function compute the volume that cut by a line
###input
###cell: This cell is represented by its cell vertices, from lower-left, clockwise
###normal, d
###output
###volume: the cut volume inside the line, the normal pointed outwards
def get_cut_volume_polygon(cell, normal, d):
    # print(cell, normal, d)
    ###initialize
    volume_result = 0.
    vol_polygon = []
    ###get all the intersection with the cell
    if not np.isnan(cell).all():
        intersects = plic_get_intersects(cell, normal, d)
        # print(intersects)
    else:
        return 0.
    # print(cell)
    # print(intersects)
    ###now we iterate through the cell vertices to build another polygon which volume will be calculated later
    ###if the line intersects with the cell
    if not np.isnan(intersects).all():
        for i in range(len(cell)):
            point = cell[i]
            ###which indicates that the vertice is in the volume
            if not np.isnan(point[0]) and point.dot(normal) - d <= 0:
                vol_polygon.append(point)
                ###which indicates that between point i and i+1, there exist a non-overlapped intersection
                if np.isnan(intersects[i][0]):
                    pass
                else:
                    if not (point[0] == intersects[i][0] and point[1] == intersects[i][1]):
                        vol_polygon.append(intersects[i])
                    else:
                        pass
            else:
                if np.isnan(intersects[i][0]):
                    pass
                else:
                    if not (point[0] == intersects[i][0] and point[1] == intersects[i][1]):
                        vol_polygon.append(intersects[i])
                    else:
                        pass
        vol_polygon = np.array(vol_polygon)
        # print(vol_polygon)
    else:
        ###The entire cell is in the domain of line
        if not judge_outside_line(cell, normal, d):
            vol_polygon = cell
        ###The entire cell lies outside
        else:
            return 0.

    ###to make sure there exist an area to compute, otherwise should return 0
    if len(vol_polygon) >= 3:
        volume_result = get_cell_volume_new(vol_polygon)
        # print(volume_result)
    else:
        pass
    ###according to the reconstructed vol_polygon, we can calculate its inner volume

    return volume_result

### Modified version
def get_cut_volume_polygon_with_intersects(intersects, cell, normal, d):
    ###initialize
    volume_result = 0
    vol_polygon = []
    ###now we iterate through the cell vertices to build another polygon which volume will be calculated later
    ###if the line intersects with the cell
    if not np.isnan(intersects).all():
        for i in range(len(cell)):
            point = cell[i]
            ###which indicates that the vertice is in the volume
            if not np.isnan(point[0]) and point.dot(normal) - d <= 0:
                vol_polygon.append(point)
                ###which indicates that between point i and i+1, there exist a non-overlapped intersection
                if np.isnan(intersects[i][0]):
                    pass
                else:
                    if not (point[0] == intersects[i][0] and point[1] == intersects[i][1]):
                        vol_polygon.append(intersects[i])
                    else:
                        pass
            else:
                if np.isnan(intersects[i][0]):
                    pass
                else:
                    if not (point[0] == intersects[i][0] and point[1] == intersects[i][1]):
                        vol_polygon.append(intersects[i])
                    else:
                        pass
        vol_polygon = np.array(vol_polygon)
        # print(vol_polygon)
    else:
        ###The entire cell is in the domain of line
        if not judge_outside_line(cell, normal, d):
            vol_polygon = cell
        ###The entire cell lies outside
        else:
            vol_polygon.append(cell[0])
            vol_polygon = np.array(vol_polygon)
    ###to make sure there exist an area to compute, otherwise should return 0
    if len(vol_polygon) >= 3:
        volume_result = get_cell_volume_new(vol_polygon)
        # print(volume_result)
    else:
        pass
    ###according to the reconstructed vol_polygon, we can calculate its inner volume

    return volume_result

### This function get the cut polygon for arbitary cell
def get_cut_polygon_2(intersects, cell, normal, d):
    ###
    polygon = []
    # print('The in-function cut cell 1 is: ', cell)
    ###now we iterate through the cell vertices to build another polygon which volume will be calculated later
    ###if the line intersects with the cell
    if not np.isnan(intersects).all():
        for i in range(len(cell)):
            point = cell[i]
            ###which indicates that the vertice is in the volume
            if not np.isnan(point[0]) and point.dot(normal) - d <= 0:
                polygon.append(point)
                ###which indicates that between point i and i+1, there exist a non-overlapped intersection
                if np.isnan(intersects[i][0]):
                    pass
                else:
                    if not (point[0] == intersects[i][0] and point[1] == intersects[i][1]):
                        polygon.append(intersects[i])
                    else:
                        pass
            else:
                if np.isnan(intersects[i][0]):
                    pass
                else:
                    if not (point[0] == intersects[i][0] and point[1] == intersects[i][1]):
                        polygon.append(intersects[i])
                    else:
                        pass
        polygon = np.array(polygon)
        # print(vol_polygon)
    else:
        ###The entire cell is in the domain of line
        if not judge_outside_line(cell, normal, d):
            polygon = cell
        ###The entire cell lies outside
        else:
            polygon = [np.array([0., 0.])]
    return polygon

### This function is used to find the number of intersections
def get_inters_num(intersects):
    num = 0
    for i in range(len(intersects)):
        if not np.isnan(intersects[i]).all():
            num += 1
    return num

###This function calculate the inner volume of a particular cell
###we decompose the polygon into several triangles and iteratively sum them up, the base point cell[0]
###input
###cell, represent by clockwise vertices
###output
###volume
def get_cell_volume(cell):
    ###the base point cell[0]
    x0 = cell[0]
    ###initialize
    vol = 0
    for i in range(len(cell) - 2):
        x1 = cell[i + 1]
        x2 = cell[i + 2]
        r1 = x1 - x0
        r2 = x2 - x0
        vol_i = abs(np.cross(r1, r2)) / 2
        # print(vol_i)
        vol += vol_i
    return vol

def get_cell_volume_new(cell):
    if len(cell) >= 3:
        ###the base point cell[0]
        x0 = cell[0]
        ###initialize
        vol = 0
        for i in range(len(cell) - 2):
            x1 = cell[i + 1]
            x2 = cell[i + 2]
            r1 = x1 - x0
            r2 = x2 - x0
            vol_i = abs(np.cross(r1, r2)) / 2
            vol += vol_i
        return vol
    else:
        return 0.

def get_cell_volume_shapely(cell):
    polygon1 = np.array(cell)
    polygon_1_inp = []
    for i in range(len(polygon1)):
        polygon_1_inp.append((polygon1[i, 0], polygon1[i, 1]))
    polygon1 = Polygon(polygon_1_inp)
    return polygon1.area
###This function is used to offset a cell with deltax and deltay distance
###input
###cell: clockwise, vertice-based
###deltax, deltay: biased distances
###output
###cell_offset
def cell_offset(cell, deltax, deltay):
    for i in range(len(cell)):
        cell[i][0] += deltax
        cell[i][1] += deltay
    return cell

###This function compute the nine cell error following the equation in Choi and Bussmann 2006
###input
###tp: virtual triple point
###normal_1: the normal of the interface I1
###normal_23: the normal of the interface I23
###sf_2, sf_3: the VOF field of phase 2 and 3
###i, j: index of the center cell
###dx, dy: grid intervals
###output:
###error: the total error
def get_er_choi(tp, normal_1, d_1, normal_23, sf_2, sf_3, dx, dy):
    i, j = 1, 1
    ###initialize
    error = 0.
    d_2 = normal_23.dot(tp)
    ###The search is within 3 * 3 stencil
    for m in range(3):
        for n in range(3):
            ###first locate the focus cell
            vol_tar2i = sf_2[i - 1 + m][j - 1 + n] * dx * dy
            vol_tar3i = sf_3[i - 1 + m][j - 1 + n] * dx * dy
            ### in order to calculate the relationship between the line and a transported cell, we instead transport the line
            ### n * (x + dx, y + dy) - d = 0
            ### n * x - d = 0 ---> n * x - d' = 0, in which d' = d - (nxdx + nydy)
            ### This is the x and y offset
            ### IMPORTANT NOTE: DIFFERENT FROM CHOI AND BUSSMANN
            if sf_2[i - 1 + m][j - 1 + n] + sf_3[i - 1 + m][j - 1 + n] > 1e-8:
                delta_x = dx * (i - 1 + m - i)
                delta_y = dy * (j - 1 + n - j)
                ###This is the d1 and d2 offset
                d1_p = d_1 - (normal_1[0] * delta_x + normal_1[1] * delta_y)
                d2_p = d_2 - (normal_23[0] * delta_x + normal_23[1] * delta_y)
                ###first calculate the remaining cell that I1 cut
                remain_cell = plic_cell_remain(normal_1, d1_p, dx, dy)
                if len(remain_cell) > 2:
                    vol_2i = get_cut_volume_polygon(remain_cell, normal_23, d2_p)
                    vol_3i = get_cell_volume_new(remain_cell) - vol_2i
                else:
                    vol_2i = 0.
                    vol_3i = 0.
                errori = ((vol_2i - vol_tar2i) / (dx * dy)) ** 2 + ((vol_3i - vol_tar3i) / (dx * dy)) ** 2
                error += errori
            else:
                pass
    ### return the normalized error
    return error

###This function iteratively find the suitable normal vector(theta) that divide the grid ij by volume fraction 2 and 3
###input
###tp: virtual triple point
###sf: VOF field
###dir_ref: reference vector that indicates the result normal direction
###dx, dy: grid intervals
###i, j: the targeted cell index
###left_cell: the remained cell that have been cut by I1 [vetice1, vertice2, vertice3, vertice4]
###output:
###normal: the searched result
def get_normal_angleSearch(left_cell, tp, sf, dir, i, j, dx, dy):
    ###initialize the theta search space
    theta_L = np.linspace(0, 2 * math.pi, 721)
    volume_tar = dx * dy * sf[i][j]
    normal = np.array([None, None])
    volume = None
    error = float('inf')
    ###now we iteratively search for the normal_2 vector by a variation of theta
    for itheta in range(len(theta_L) - 1):
        theta = theta_L[itheta]
        ###construct normal vector from inclination angle theta
        normal_2_1 = np.array([math.cos(theta), math.sin(theta)])
        ###This judgement is important because this helped to correct position relationship between 2 and 3
        if normal_2_1.dot(dir) >= 0:
            dis1 = normal_2_1.dot(tp)
            volume1 = get_cut_volume_polygon(left_cell, normal_2_1, dis1)
            error1 = abs(volume1 - volume_tar)
            if error1 < error:
                normal = normal_2_1
                volume = volume1
                error = error1
            else:
                pass
        else:
            pass
    return normal, volume

def get_normal_angleSearch_hybrid(left_cell, tp, sf, dir, dx, dy, sep):
    ###initialize the theta search space
    theta_L = np.linspace(0, 2 * math.pi, sep)
    volume_tar = dx * dy * sf[1][1]
    normal = np.array([None, None])
    volume = None
    theta_out = 0.
    error = float('inf')
    ###now we iteratively search for the normal_2 vector by a variation of theta
    for itheta in range(len(theta_L) - 1):
        theta = theta_L[itheta]
        ###construct normal vector from inclination angle theta
        normal_2_1 = np.array([math.cos(theta), math.sin(theta)])
        ###This judgement is important because this helped to correct position relationship between 2 and 3
        if normal_2_1.dot(dir) >= 0:
            dis1 = normal_2_1.dot(tp)
            volume1 = get_cut_volume_polygon(left_cell, normal_2_1, dis1)
            error1 = abs(volume1 - volume_tar) / (dx * dy)
            # print(error1)
            if error1 < error:
                normal = normal_2_1
                volume = volume1
                error = error1
                theta_out = theta
            else:
                pass
        else:
            continue
    return normal, volume, theta_out

def get_normal_angleSearch_GS(left_cell, tp, sf, dx, dy, tolerance, normal_1):
    normal_incr = np.array([None, None])
    volume_incr = None
    normal_decr = np.array([None, None])
    volume_decr = None
    max_step = 30
    if point_on_the_edge_shapely(tp, left_cell):
        # print(tp, 'on the edge')
        theta_cri = math.acos(normal_1[0])
        ### FIRST HALF
        theta_s = theta_cri
        theta_l = theta_cri + np.pi
        ###initialize the theta search space
        gr = (math.sqrt(5) + 1) / 2
        tolerance = tolerance
        volume_tar = dx * dy * sf[1][1]
        error = float('inf')
        ###now we use the Golden search to find normal_2 vector by a variation of theta
        step = 0
        while error > tolerance and step <= max_step:
            theta_mid1 = theta_l - (theta_l - theta_s) / gr
            theta_mid2 = theta_s + (theta_l - theta_s) / gr
            normal_2_1 = np.array([math.cos(theta_mid1), math.sin(theta_mid1)])
            normal_2_2 = np.array([math.cos(theta_mid2), math.sin(theta_mid2)])
            dis2_1 = normal_2_1.dot(tp)
            volume2_1 = get_cut_volume_polygon(left_cell, normal_2_1, dis2_1)
            error_1 = abs(volume2_1 - volume_tar) / (dx * dy)
            dis2_2 = normal_2_2.dot(tp)
            volume2_2 = get_cut_volume_polygon(left_cell, normal_2_2, dis2_2)
            error_2 = abs(volume2_2 - volume_tar) / (dx * dy)
            ### compare the error to the minimum error, converge the interval
            if error_1 < error_2:
                theta_l = theta_mid2
                normal_incr = normal_2_1
                volume_incr = volume2_1
            else:
                theta_s = theta_mid1
                normal_incr = normal_2_2
                volume_incr = volume2_2
            error = max(error_1, error_2)
            step += 1
        ### SECOND HALF
        theta_s = theta_cri - np.pi
        theta_l = theta_cri
        ###initialize the theta search space
        gr = (math.sqrt(5) + 1) / 2
        tolerance = tolerance
        volume_tar = dx * dy * sf[1][1]
        error = float('inf')
        ###now we use the Golden search to find normal_2 vector by a variation of theta
        step = 0
        while error > tolerance and step <= max_step:
            theta_mid1 = theta_l - (theta_l - theta_s) / gr
            theta_mid2 = theta_s + (theta_l - theta_s) / gr
            normal_2_1 = np.array([math.cos(theta_mid1), math.sin(theta_mid1)])
            normal_2_2 = np.array([math.cos(theta_mid2), math.sin(theta_mid2)])
            dis2_1 = normal_2_1.dot(tp)
            volume2_1 = get_cut_volume_polygon(left_cell, normal_2_1, dis2_1)
            error_1 = abs(volume2_1 - volume_tar) / (dx * dy)
            dis2_2 = normal_2_2.dot(tp)
            volume2_2 = get_cut_volume_polygon(left_cell, normal_2_2, dis2_2)
            error_2 = abs(volume2_2 - volume_tar) / (dx * dy)
            ### compare the error to the minimum error, converge the interval
            if error_1 < error_2:
                theta_l = theta_mid2
                normal_decr = normal_2_1
                volume_decr = volume2_1
            else:
                theta_s = theta_mid1
                normal_decr = normal_2_2
                volume_decr = volume2_2
            error = max(error_1, error_2)
            step += 1
    else:
        ### BECAUSE THE EXISTENCE OF THE ERROR STAGE (CONSTANT WHEN NOT INTERSECT WITH THE REMAIN CELL)
        ### first narrow down the Golden search range by a linear search with interval smaller than tan^-1(1/9)
        ### HERE GIVEN INTERVAL = 1 DEGREE
        theta_L = np.linspace(0., 2 * np.pi, 361)
        theta_decrease_to_zero = 2 * np.pi
        theta_increase_from_zero = 0.
        theta_decrease_from_full = 0.
        theta_increase_to_full = 2 * np.pi
        left_cell_volume = get_cell_volume_shapely(left_cell)
        ###now we iteratively search for the normal_2 vector by a variation of theta
        for itheta in range(len(theta_L)):
            theta = theta_L[itheta]
            theta_2 = theta_L[itheta - 1]
            ###construct normal vector from inclination angle theta
            normal_2_1 = np.array([math.cos(theta), math.sin(theta)])
            dis1 = normal_2_1.dot(tp)
            volume1 = get_cut_volume_polygon(left_cell, normal_2_1, dis1)
            normal_2_2 = np.array([math.cos(theta_2), math.sin(theta_2)])
            dis2 = normal_2_2.dot(tp)
            volume2 = get_cut_volume_polygon(left_cell, normal_2_2, dis2)
            if volume1 * volume2 == 0 and volume1 + volume2 > 0 and volume1 > volume2:
                theta_increase_from_zero = theta_2
            elif (volume1 - left_cell_volume) * (volume2 - left_cell_volume) == 0 and volume1 + volume2 < 2 * left_cell_volume and volume1 > volume2:
                theta_increase_to_full = theta
            elif (volume1 - left_cell_volume) * (volume2 - left_cell_volume) == 0 and volume1 + volume2 < 2 * left_cell_volume and volume2 > volume1:
                theta_decrease_from_full = theta_2
            elif volume1 * volume2 == 0 and volume1 + volume2 > 0 and volume2 > volume1:
                theta_decrease_to_zero = theta
        # print('theta_decrease_to_zero ', theta_decrease_to_zero)
        # print('theta_increase_from_zero ', theta_increase_from_zero)
        # print('theta_decrease_from_full ', theta_decrease_from_full)
        # print('theta_increase_to_full ', theta_increase_to_full)
        ### THE FIRST PAIR IS INCREASING PAIR, A NORMAL CAN BE CALCULATED
        theta_l = max(theta_increase_from_zero, theta_increase_to_full)
        theta_s = min(theta_increase_from_zero, theta_increase_to_full)
        # print('increasing pair: ')
        if theta_l - theta_s < np.pi:
            pass
        else:
            theta_l = theta_s
            theta_s = max(theta_increase_from_zero, theta_increase_to_full) - 2 * np.pi
        ###initialize the theta search space
        gr = (math.sqrt(5) + 1) / 2
        tolerance = tolerance
        volume_tar = dx * dy * sf[1][1]
        error = float('inf')
        ###now we use the Golden search to find normal_2 vector by a variation of theta
        step = 0
        while error > tolerance and step <= max_step:
            # print(theta_l, theta_s, error)
            theta_mid1 = theta_l - (theta_l - theta_s) / gr
            theta_mid2 = theta_s + (theta_l - theta_s) / gr
            normal_2_1 = np.array([math.cos(theta_mid1), math.sin(theta_mid1)])
            normal_2_2 = np.array([math.cos(theta_mid2), math.sin(theta_mid2)])
            dis2_1 = normal_2_1.dot(tp)
            volume2_1 = get_cut_volume_polygon(left_cell, normal_2_1, dis2_1)
            error_1 = abs(volume2_1 - volume_tar) / (dx * dy)
            dis2_2 = normal_2_2.dot(tp)
            volume2_2 = get_cut_volume_polygon(left_cell, normal_2_2, dis2_2)
            error_2 = abs(volume2_2 - volume_tar) / (dx * dy)
            ### compare the error to the minimum error, converge the interval
            if error_1 < error_2:
                theta_l = theta_mid2
                normal_incr = normal_2_1
                volume_incr = volume2_1
            else:
                theta_s = theta_mid1
                normal_incr = normal_2_2
                volume_incr = volume2_2
            error = max(error_1, error_2)
            step += 1
        ### THE SECOND PAIR IS DECREASING PAIR, ANOTHER NORMAL CAN BE CALCULATED
        # print('decreasing pair: ')
        theta_l = max(theta_decrease_from_full, theta_decrease_to_zero)
        theta_s = min(theta_decrease_from_full, theta_decrease_to_zero)
        if theta_l - theta_s < np.pi:
            pass
        else:
            theta_l = theta_s
            theta_s = max(theta_decrease_from_full, theta_decrease_to_zero) - 2 * np.pi
        ###initialize the theta search space
        gr = (math.sqrt(5) + 1) / 2
        tolerance = tolerance
        volume_tar = dx * dy * sf[1][1]
        error = float('inf')
        ###now we use the Golden search to find normal_2 vector by a variation of theta
        step = 0
        while error > tolerance and step <= max_step:
            # print(theta_l, theta_s, error)
            theta_mid1 = theta_l - (theta_l - theta_s) / gr
            theta_mid2 = theta_s + (theta_l - theta_s) / gr
            normal_2_1 = np.array([math.cos(theta_mid1), math.sin(theta_mid1)])
            normal_2_2 = np.array([math.cos(theta_mid2), math.sin(theta_mid2)])
            dis2_1 = normal_2_1.dot(tp)
            volume2_1 = get_cut_volume_polygon(left_cell, normal_2_1, dis2_1)
            error_1 = abs(volume2_1 - volume_tar) / (dx * dy)
            dis2_2 = normal_2_2.dot(tp)
            volume2_2 = get_cut_volume_polygon(left_cell, normal_2_2, dis2_2)
            error_2 = abs(volume2_2 - volume_tar) / (dx * dy)
            ### compare the error to the minimum error, converge the interval
            if error_1 < error_2:
                theta_l = theta_mid2
                normal_decr = normal_2_1
                volume_decr = volume2_1
            else:
                theta_s = theta_mid1
                normal_decr = normal_2_2
                volume_decr = volume2_2
            error = max(error_1, error_2)
            step += 1

    return normal_incr, volume_incr, normal_decr, volume_decr

def get_normal_angleSearch_GS_direct(left_cell, tp, sf, dx, dy, tolerance, normal_1):
    normal_incr = np.array([None, None])
    volume_incr = None
    normal_decr = np.array([None, None])
    volume_decr = None
    max_step = 30
    if point_on_the_edge_shapely(tp, left_cell):
        # print(tp, 'on the edge')
        theta_cri = math.acos(normal_1[0])
        ### FIRST HALF
        theta_s = theta_cri
        theta_l = theta_cri + np.pi
        ###initialize the theta search space
        gr = (math.sqrt(5) + 1) / 2
        tolerance = tolerance
        volume_tar = dx * dy * sf[1][1]
        error = float('inf')
        ###now we use the Golden search to find normal_2 vector by a variation of theta
        step = 0
        while error > tolerance and step <= max_step:
            theta_mid1 = theta_l - (theta_l - theta_s) / gr
            theta_mid2 = theta_s + (theta_l - theta_s) / gr
            normal_2_1 = np.array([math.cos(theta_mid1), math.sin(theta_mid1)])
            normal_2_2 = np.array([math.cos(theta_mid2), math.sin(theta_mid2)])
            dis2_1 = normal_2_1.dot(tp)
            volume2_1 = get_cut_volume_polygon(left_cell, normal_2_1, dis2_1)
            error_1 = abs(volume2_1 - volume_tar) / (dx * dy)
            dis2_2 = normal_2_2.dot(tp)
            volume2_2 = get_cut_volume_polygon(left_cell, normal_2_2, dis2_2)
            error_2 = abs(volume2_2 - volume_tar) / (dx * dy)
            ### compare the error to the minimum error, converge the interval
            if error_1 < error_2:
                theta_l = theta_mid2
                normal_incr = normal_2_1
                volume_incr = volume2_1
            else:
                theta_s = theta_mid1
                normal_incr = normal_2_2
                volume_incr = volume2_2
            error = max(error_1, error_2)
            step += 1
        ### SECOND HALF
        theta_s = theta_cri - np.pi
        theta_l = theta_cri
        ###initialize the theta search space
        gr = (math.sqrt(5) + 1) / 2
        tolerance = tolerance
        volume_tar = dx * dy * sf[1][1]
        error = float('inf')
        ###now we use the Golden search to find normal_2 vector by a variation of theta
        step = 0
        while error > tolerance and step <= max_step:
            theta_mid1 = theta_l - (theta_l - theta_s) / gr
            theta_mid2 = theta_s + (theta_l - theta_s) / gr
            normal_2_1 = np.array([math.cos(theta_mid1), math.sin(theta_mid1)])
            normal_2_2 = np.array([math.cos(theta_mid2), math.sin(theta_mid2)])
            dis2_1 = normal_2_1.dot(tp)
            volume2_1 = get_cut_volume_polygon(left_cell, normal_2_1, dis2_1)
            error_1 = abs(volume2_1 - volume_tar) / (dx * dy)
            dis2_2 = normal_2_2.dot(tp)
            volume2_2 = get_cut_volume_polygon(left_cell, normal_2_2, dis2_2)
            error_2 = abs(volume2_2 - volume_tar) / (dx * dy)
            ### compare the error to the minimum error, converge the interval
            if error_1 < error_2:
                theta_l = theta_mid2
                normal_decr = normal_2_1
                volume_decr = volume2_1
            else:
                theta_s = theta_mid1
                normal_decr = normal_2_2
                volume_decr = volume2_2
            error = max(error_1, error_2)
            step += 1
    else:
        ### angle_rot counterclk
        theta_cri = math.atan2(normal_1[1], normal_1[0])
        if 0 <= theta_cri < np.pi / 2:
            angle_rot = np.pi / 2 - theta_cri
        elif np.pi / 2 <= theta_cri <= np.pi:
            angle_rot = -(theta_cri - np.pi / 2)
        elif -np.pi / 2 <= theta_cri < 0:
            angle_rot = np.pi / 2 - theta_cri
        else:              ## (-np.pi <= theta_cri < -np.pi / 2)
            angle_rot = -(np.pi / 2 + (np.pi + theta_cri))
        ### TRANSFORMATION
        R_matrix = np.array([[math.cos(angle_rot), math.sin(angle_rot)],
                             [-math.sin(angle_rot), math.cos(angle_rot)]])
        tp_transf = R_matrix.dot(tp)
        polygon_transf = R_matrix.dot(left_cell.transpose()).transpose()
        ### FIND THE RANGE OF THE ANGLE
        angle_L = []
        for kk in range(len(polygon_transf)):
            vertex = polygon_transf[kk]
            tp2vertex = vertex - tp_transf
            angle = math.atan2(tp2vertex[1], tp2vertex[0])
            angle_L.append(angle)
        angle_range = max(angle_L) - min(angle_L)
        ### THE FIRST PAIR IS INCREASING PAIR, A NORMAL CAN BE CALCULATED
        theta_l = theta_cri + angle_range
        theta_s = theta_cri
        gr = (math.sqrt(5) + 1) / 2
        tolerance = tolerance
        volume_tar = dx * dy * sf[1][1]
        error = float('inf')
        ###now we use the Golden search to find normal_2 vector by a variation of theta
        step = 0
        while error > tolerance and step <= max_step:
            # print(theta_l, theta_s, error)
            theta_mid1 = theta_l - (theta_l - theta_s) / gr
            theta_mid2 = theta_s + (theta_l - theta_s) / gr
            normal_2_1 = np.array([math.cos(theta_mid1), math.sin(theta_mid1)])
            normal_2_2 = np.array([math.cos(theta_mid2), math.sin(theta_mid2)])
            dis2_1 = normal_2_1.dot(tp)
            volume2_1 = get_cut_volume_polygon(left_cell, normal_2_1, dis2_1)
            error_1 = abs(volume2_1 - volume_tar) / (dx * dy)
            dis2_2 = normal_2_2.dot(tp)
            volume2_2 = get_cut_volume_polygon(left_cell, normal_2_2, dis2_2)
            error_2 = abs(volume2_2 - volume_tar) / (dx * dy)
            ### compare the error to the minimum error, converge the interval
            if error_1 < error_2:
                theta_l = theta_mid2
                normal_incr = normal_2_1
                volume_incr = volume2_1
            else:
                theta_s = theta_mid1
                normal_incr = normal_2_2
                volume_incr = volume2_2
            error = max(error_1, error_2)
            step += 1
        ### THE SECOND PAIR IS DECREASING PAIR, ANOTHER NORMAL CAN BE CALCULATED
        # print('decreasing pair: ')
        theta_l = theta_cri
        theta_s = theta_cri - angle_range
        ###initialize the theta search space
        gr = (math.sqrt(5) + 1) / 2
        tolerance = tolerance
        volume_tar = dx * dy * sf[1][1]
        error = float('inf')
        ###now we use the Golden search to find normal_2 vector by a variation of theta
        step = 0
        while error > tolerance and step <= max_step:
            # print(theta_l, theta_s, error)
            theta_mid1 = theta_l - (theta_l - theta_s) / gr
            theta_mid2 = theta_s + (theta_l - theta_s) / gr
            normal_2_1 = np.array([math.cos(theta_mid1), math.sin(theta_mid1)])
            normal_2_2 = np.array([math.cos(theta_mid2), math.sin(theta_mid2)])
            dis2_1 = normal_2_1.dot(tp)
            volume2_1 = get_cut_volume_polygon(left_cell, normal_2_1, dis2_1)
            error_1 = abs(volume2_1 - volume_tar) / (dx * dy)
            dis2_2 = normal_2_2.dot(tp)
            volume2_2 = get_cut_volume_polygon(left_cell, normal_2_2, dis2_2)
            error_2 = abs(volume2_2 - volume_tar) / (dx * dy)
            ### compare the error to the minimum error, converge the interval
            if error_1 < error_2:
                theta_l = theta_mid2
                normal_decr = normal_2_1
                volume_decr = volume2_1
            else:
                theta_s = theta_mid1
                normal_decr = normal_2_2
                volume_decr = volume2_2
            error = max(error_1, error_2)
            step += 1

    return normal_incr, volume_incr, normal_decr, volume_decr

def get_normal_angleSearch_exact(left_cell, tp, sf_2, dir, dx, dy, tolerance, theta_ini, sep):
    gr = (math.sqrt(5) + 1) / 2
    volume_tar = dx * dy * sf_2[1][1]
    # volume_left = get_cell_volume_new(left_cell)
    # print('volume left ', volume_left)
    normal = np.array([math.cos(theta_ini), math.sin(theta_ini)])
    normal_ini = normal.copy()
    dis_ini = normal.dot(tp)
    volume2_ini = get_cut_volume_polygon(left_cell, normal, dis_ini)
    # print('volume_2_ini ', volume2_ini)
    error_ini = abs(volume2_ini - volume_tar) / (dx * dy)
    # print(theta_ini, normal, error_ini)
    volume = None
    error = float('inf')
    rang = 2 * math.pi / (sep - 1)
    theta_l = theta_ini + rang / 2
    theta_s = theta_ini - rang / 2
    iteration = 0
    while error > tolerance and iteration < 30:
        theta_mid1 = theta_l - (theta_l - theta_s) / gr
        theta_mid2 = theta_s + (theta_l - theta_s) / gr
        # print(theta_mid1, theta_mid2)
        normal_2_1 = np.array([math.cos(theta_mid1), math.sin(theta_mid1)])
        normal_2_2 = np.array([math.cos(theta_mid2), math.sin(theta_mid2)])
        if normal_2_1.dot(dir) >= 0 and normal_2_2.dot(dir) >= 0:
            dis2_1 = normal_2_1.dot(tp)
            volume2_1 = get_cut_volume_polygon(left_cell, normal_2_1, dis2_1)
            # print('volume_2_1 ', volume2_1)
            error_1 = abs(volume2_1 - volume_tar) / (dx * dy)
            dis2_2 = normal_2_2.dot(tp)
            volume2_2 = get_cut_volume_polygon(left_cell, normal_2_2, dis2_2)
            # print('volume_2_2 ', volume2_2)
            error_2 = abs(volume2_2 - volume_tar) / (dx * dy)
            # print(error_1, error_2)
        elif normal_2_1.dot(dir) < 0 and normal_2_2.dot(dir) >= 0:
            error_1 = float('inf')
            volume2_1 = float('inf')
            dis2_2 = normal_2_2.dot(tp)
            volume2_2 = get_cut_volume_polygon(left_cell, normal_2_2, dis2_2)
            error_2 = abs(volume2_2 - volume_tar) / (dx * dy)
        elif normal_2_1.dot(dir) >= 0 and normal_2_2.dot(dir) < 0:
            dis2_1 = normal_2_1.dot(tp)
            volume2_1 = get_cut_volume_polygon(left_cell, normal_2_1, dis2_1)
            error_1 = abs(volume2_1 - volume_tar) / (dx * dy)
            error_2 = float('inf')
            volume2_2 = float('inf')
        else:
            # print('Here')
            theta_l = theta_ini + (theta_l - theta_s) / 4
            theta_s = theta_ini - (theta_l - theta_s) / 4
            iteration += 1
            continue
        # print(theta_mid1, theta_mid2)
        if error_1 < error_2:
            theta_l = theta_mid2
            normal = normal_2_1
            volume = volume2_1
            error = error_1
        elif error_1 > error_2:
            theta_s = theta_mid1
            normal = normal_2_2
            volume = volume2_2
            error = error_2
        ### IMPOROVED THE GOLDEN SECTION SEARCH, WE COMPARE THE STENCIL ERROR WHEN COUNTERING STAGE IN THE MIDDLE
        # else:
        #     stencil_error_1 = get_er_choi(tp, normal_1, d_1, normal_2_1, sf_2, sf_3, 1, 1, dx, dy)
        #     stencil_error_2 = get_er_choi(tp, normal_1, d_1, normal_2_2, sf_2, sf_3, 1, 1, dx, dy)
        #     if stencil_error_1 < stencil_error_2:
        #         theta_l = theta_mid2
        #         normal = normal_2_1
        #         volume = volume2_1
        #         error = error_1
        #     else:
        #         theta_s = theta_mid1
        #         normal = normal_2_2
        #         volume = volume2_2
        #         error = error_2
        else:
            theta_s = theta_mid1
            normal = normal_2_2
            volume = volume2_2
            error = error_2
            # print(stencil_error_1, stencil_error_2)
            # print(theta_s, theta_l, error, theta_mid1, theta_mid2)
        # print(theta_s, theta_l, error)
        iteration += 1
    ### COMPARE WITH THE INITIAL ERROR
    if error_ini > error:
        pass
    else:
        normal = normal_ini
        volume = volume2_ini

    return normal, volume

def point_on_the_line(point, p1, p2):
    def distance(p1, p2):
        return ((p1[0]-p2[0])**2 + (p1[1]-p2[1])**2)**0.5
    # Determine whether the point is on the line segment
    d1 = distance(point, p1)
    d2 = distance(point, p2)
    d3 = distance(p1, p2)
    return abs(d1 + d2 - d3) < 1e-15

def point_on_the_edge_shapely(point, polygon):
    point = np.array(point)
    polygon = np.array(polygon)
    point = Point(point[0], point[1])
    polygon_inp = []
    for i in range(len(polygon)):
        polygon_inp.append((polygon[i, 0], polygon[i, 1]))
    polygon = Polygon(polygon_inp)
    result = polygon.boundary.distance(point) < 1e-15
    return result

def point_in_polygon_shapely(point, polygon):
    point = np.array(point)
    polygon = np.array(polygon)
    point = Point(point[0], point[1])
    polygon_inp = []
    for i in range(len(polygon)):
        polygon_inp.append((polygon[i, 0], polygon[i, 1]))
    polygon = Polygon(polygon_inp)
    result = polygon.contains(point)
    return result

def clip_polygon_shapely(polygon1, polygon2):
    # print(polygon1, polygon2)
    polygon1 = np.array(polygon1)
    polygon_1_inp = []
    for i in range(len(polygon1)):
        polygon_1_inp.append((polygon1[i, 0], polygon1[i, 1]))
    polygon1 = Polygon(polygon_1_inp)
    polygon2 = np.array(polygon2)
    polygon_2_inp = []
    for i in range(len(polygon2)):
        polygon_2_inp.append((polygon2[i, 0], polygon2[i, 1]))
    polygon2 = Polygon(polygon_2_inp)
    # print(polygon1, polygon2)
    intersection = polygon1.intersection(polygon2)
    return intersection

# def get_normal_angleSearch_choi(tp, normal_1, d_1, sf_2, sf_3, dir, i, j, dx, dy):
#     ###initialize the theta search space
#     theta_L = np.linspace(0, 2 * math.pi, 721)
#     normal = np.array([None, None])
#     error_min = float('inf')
#     ###now we iteratively search for the normal_2 vector by a variation of theta
#     for itheta in range(len(theta_L) - 1):
#         theta = theta_L[itheta]
#         ###construct normal vector from inclination angle theta
#         normal_2_1 = np.array([math.cos(theta), math.sin(theta)])
#         ###This judgement is important because this helped to correct position relationship between 2 and 3
#         if normal_2_1.dot(dir) >= 0:
#             error = get_er_choi(tp, normal_1, d_1, normal_2_1, sf_2, sf_3, i, j, dx, dy)
#             if error < error_min:
#                 normal = normal_2_1
#                 error_min = error
#             else:
#                 pass
#         else:
#             pass
#     return normal, error_min

# cell = np.array([[0.,         0.49997449],
#  [0.,         1.        ],
#  [1.,         1.        ],
#  [1.,         0.49997449]])
# normal = np.array([1., 0.])
# d = 0.5
# volume = get_cut_volume_polygon(cell, normal, d)

# cell = np.array([[0., 0.39333287],
#                  [0., 1.],
#                  [1., 1.],
#                  [1., 0.19333287]])
# normal = np.array([0.75968708, 0.65028881])
# d = 0.5779648651850745
# volume = get_cut_volume_polygon(cell, normal, d)
# print(volume)


# normal_1 = np.array([-0.99879957,  0.04898393])
# d_1 = 0.00038529101329065564
# cell_remain = plic_cell_remain(normal_1, d_1, 0.03125, 0.03125)
# print(cell_remain)
# normal_exact = np.array([0.99996213, 0.00870236])
# d_23 = -0.016626044674854755
# intersects = plic_get_intersects(cell_remain, normal_exact, d_23)
# print(intersects)
# cell_2 = plic_cell_and_intersect_general(normal_exact, d_23, cell_remain, intersects)
# print(cell_2)
# cell_3 = plic_cell_and_intersect_general(-normal_exact, -d_23, cell_remain, intersects)
# print(cell_3)