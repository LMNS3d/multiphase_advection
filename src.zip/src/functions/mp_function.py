### created by Zhang
### HKUST FU's Lab
### 2024.09.25
import numpy as np
from multiprocessing import Process, Manager
from multiprocessing.managers import BaseManager
import multiprocessing as mp

# ### custom manager
# class CustomManager(BaseManager):
#     pass

def divide_domain(nx, ny, num_processes=12, type='x-favored'):
    ratio = ny / nx
    zx = int(np.sqrt(num_processes/ratio))
    while num_processes % zx != 0:
        if type == 'x-favored':
            zx += 1
        else:
            zx -= 1
    zy = num_processes // zx
    x_parts = np.linspace(0, nx, zx, endpoint=False, dtype=int).tolist()
    y_parts = np.linspace(0, ny, zy, endpoint=False, dtype=int).tolist()
    x_parts.append(nx)
    y_parts.append(ny)
    x_parts, y_parts = np.array(x_parts), np.array(y_parts)
    return x_parts, y_parts

def create_processes(func, info, q):
    processes = []
    x_parts = info['x_parts']
    y_parts = info['y_parts']
    for i in range(len(x_parts) - 1):
        for j in range(len(y_parts) - 1):
            start_x = x_parts[i]
            start_y = y_parts[j]
            end_x = x_parts[i + 1]
            end_y = y_parts[j + 1]
            processes.append(Process(target=func, args=(info, q, start_x, end_x, start_y, end_y)))
    return processes

### create DP_PLIC_8_mp
def create_processes_DP(x_parts, y_parts, func, f, reconstruction_result, dx, dy, tolerance, max_step, recons_ghost):
    processes = []
    for i in range(len(x_parts) - 1):
        for j in range(len(y_parts) - 1):
            start_x = x_parts[i]
            start_y = y_parts[j]
            end_x = x_parts[i + 1]
            end_y = y_parts[j + 1]
            processes.append(Process(target=func, args=(f, reconstruction_result, dx, dy,
                                                        tolerance, max_step, tolerance, recons_ghost, tolerance,
                                                        start_x, end_x, start_y, end_y)))
    return processes

### create process PLIC
def create_processes_PLIC(func, info, q):
    processes = []
    x_parts = info['x_parts']
    y_parts = info['y_parts']
    for i in range(len(x_parts) - 1):
        for j in range(len(y_parts) - 1):
            start_x = x_parts[i]
            start_y = y_parts[j]
            end_x = x_parts[i + 1]
            end_y = y_parts[j + 1]
            processes.append(Process(target=func, args=(info, q, start_x, end_x, start_y, end_y)))
    return processes

# def create_processes_circle(func, info, q):
#     processes = []
#     x_parts = info['x_parts']
#     y_parts = info['y_parts']
#     for i in range(len(x_parts) - 1):
#         for j in range(len(y_parts) - 1):
#             start_x = x_parts[i]
#             start_y = y_parts[j]
#             end_x = x_parts[i + 1]
#             end_y = y_parts[j + 1]
#             processes.append(Process(target=func, args=(info, q, start_x, end_x, start_y, end_y)))
#     return processes

def start_and_join_processes(processes):
    for p in processes:
        p.start()
    for p in processes:
        p.join()

def start_and_join_processes_flux(processes, ret_dict):
    for p in processes:
        p.start()
    for p in processes:
        p.join()
    flux = ret_dict['flux']
    return flux

def start_and_join_processes_f_A(processes, ret_dict):
    for p in processes:
        p.start()
    for p in processes:
        p.join()
    PLIC_f_avg_X = ret_dict['PLIC_f_avg_X']
    PLIC_f_avg_Y = ret_dict['PLIC_f_avg_Y']
    return PLIC_f_avg_X, PLIC_f_avg_Y

def start_and_join_processes_f_C(processes, ret_dict):
    for p in processes:
        p.start()
    for p in processes:
        p.join()
    PLIC_f = ret_dict['PLIC_f']
    return PLIC_f

def start_and_join_processes_PLIC(processes, ret_dict):
    for p in processes:
        p.start()
    for p in processes:
        p.join()
    recons = ret_dict['recons']
    return recons
### This process creation function also create result combining function at the end
def create_processes_flux(func, combine_func, info, q, ret_dict):
    processes = []
    x_parts = info['x_parts']
    y_parts = info['y_parts']
    flux_ghost = info['flux_ghost']
    for i in range(len(x_parts) - 1):
        for j in range(len(y_parts) - 1):
            start_x = x_parts[i]
            start_y = y_parts[j]
            end_x = x_parts[i + 1]
            end_y = y_parts[j + 1]
            processes.append(Process(target=func, args=(info, q, start_x, end_x, start_y, end_y)))
    processes.append(Process(target=combine_func, args=(q, ret_dict, flux_ghost)))
    return processes

def create_processes_f_A(func, combine_func, info, q, ret_dict):
    processes = []
    x_parts = info['x_parts']
    y_parts = info['y_parts']
    ghost = info['ghost']
    ### define the expected number of result stored in the queue
    k_expect = int(2 * (len(x_parts) - 1) * (len(y_parts) - 1))
    # print('k_expect is: ', k_expect)
    for i in range(len(x_parts) - 1):
        for j in range(len(y_parts) - 1):
            start_x = x_parts[i]
            start_y = y_parts[j]
            end_x = x_parts[i + 1]
            end_y = y_parts[j + 1]
            processes.append(Process(target=func, args=(info, q, start_x, end_x, start_y, end_y)))
    processes.append(Process(target=combine_func, args=(q, ret_dict, ghost, k_expect)))
    return processes

### same with f_A
def create_processes_f_C(func, combine_func, info, q, ret_dict):
    processes = []
    x_parts = info['x_parts']
    y_parts = info['y_parts']
    ghost = info['ghost']
    ### define the expected number of result stored in the queue
    k_expect = int((len(x_parts) - 1) * (len(y_parts) - 1))
    # print('k_expect is: ', k_expect)
    for i in range(len(x_parts) - 1):
        for j in range(len(y_parts) - 1):
            start_x = x_parts[i]
            start_y = y_parts[j]
            end_x = x_parts[i + 1]
            end_y = y_parts[j + 1]
            processes.append(Process(target=func, args=(info, q, start_x, end_x, start_y, end_y)))
    processes.append(Process(target=combine_func, args=(q, ret_dict, ghost, k_expect)))
    return processes

def create_processes_PLIC_2(func, combine_func, info, q, ret_dict):
    processes = []
    x_parts = info['x_parts']
    y_parts = info['y_parts']
    recons_ghost = info['recons_ghost']
    ### define the expected number of result stored in the queue
    k_expect = int((len(x_parts) - 1) * (len(y_parts) - 1))
    # print('k_expect is: ', k_expect)
    for i in range(len(x_parts) - 1):
        for j in range(len(y_parts) - 1):
            start_x = x_parts[i]
            start_y = y_parts[j]
            end_x = x_parts[i + 1]
            end_y = y_parts[j + 1]
            processes.append(Process(target=func, args=(info, q, start_x, end_x, start_y, end_y)))
    processes.append(Process(target=combine_func, args=(q, ret_dict, recons_ghost, k_expect)))
    return processes

def combine_results_vof(processes, result, q):
    sub_results = [q.get() for p in processes]
    for re in sub_results:
        result[:, re['start_x']:re['end_x'], re['start_y']:re['end_y']] = re['sub_result']
    return result

# def combine_results_u(processes, result, q, u_stencil):
#     sub_results = [q.get() for p in processes]
#     for re in sub_results:
#         result[:,
#                re['start_x'] + u_stencil:re['end_x'] + u_stencil,
#                re['start_y'] + u_stencil:re['end_y'] + u_stencil] = re['sub_result']
#     return result

# def combine_results_phi(processes, result, q):
#     sub_results = [q.get() for p in processes]
#     for re in sub_results:
#         result[re['start_x']:re['end_x'], re['start_y']:re['end_y']] = re['sub_result']
#     return result

def combine_results_flux(q, ret_dict, flux_ghost):
    while not q.empty():
        re = q.get()
        flux = ret_dict['flux']
        flux[:,
             re['phase'],
             re['start_x'] + flux_ghost:re['end_x'] + flux_ghost,
             re['start_y'] + flux_ghost:re['end_y'] + flux_ghost] = re['sub_result']
        ret_dict['flux'] = flux

def combine_results_f(q, ret_dict, ghost, k_expect):
    k = 0
    while k < k_expect:
        try:
            re = q.get(timeout=1)
            if re['type'] == 0:
                PLIC_f_avg_X = ret_dict['PLIC_f_avg_X']
                PLIC_f_avg_X[:,
                re['start_x'] + ghost:re['end_x'] + ghost,
                re['start_y'] + ghost:re['end_y'] + ghost] = re['result']
                ret_dict['PLIC_f_avg_X'] = PLIC_f_avg_X
                k += 1
            else:
                PLIC_f_avg_Y = ret_dict['PLIC_f_avg_Y']
                PLIC_f_avg_Y[:,
                re['start_x'] + ghost:re['end_x'] + ghost,
                re['start_y'] + ghost:re['end_y'] + ghost] = re['result']
                ret_dict['PLIC_f_avg_Y'] = PLIC_f_avg_Y
                k += 1
            # print('current k is: ', k)
        except mp.queues.Empty:
            pass

def combine_results_f_C(q, ret_dict, ghost, k_expect):
    k = 0
    while k < k_expect:
        try:
            re = q.get(timeout=1)
            PLIC_f = ret_dict['PLIC_f']
            PLIC_f[:,
            re['start_x'] + ghost:re['end_x'] + ghost,
            re['start_y'] + ghost:re['end_y'] + ghost] = re['result']
            ret_dict['PLIC_f'] = PLIC_f
            k += 1
            # print('current k is: ', k)
        except mp.queues.Empty:
            pass

def combine_results_PLIC(q, ret_dict, ghost, k_expect):
    k = 0
    while k < k_expect:
        try:
            re = q.get(timeout=1)
            result = ret_dict['recons']
            for i in range(0, re['end_x'] - re['start_x']):
                for j in range(0, re['end_y'] - re['start_y']):
                    result[ghost + i + re['start_x']][ghost + j + re['start_y']] = re['sub_result'][i][j]
            ret_dict['recons'] = result
            k += 1
        except mp.queues.Empty:
            pass
    result = ret_dict['recons']
    for i in range(len(result)):
        for j in range(len(result[0])):
            if len(result[i][j]) == 1:
                result[i][j].append({})

def combine_results_recons(processes, result, q, recons_ghost):
    sub_results = [q.get() for p in processes]
    for re in sub_results:
        for i in range(0, re['end_x'] - re['start_x']):
            for j in range(0, re['end_y'] - re['start_y']):
                result[recons_ghost + i + re['start_x']][recons_ghost + j + re['start_y']] = re['sub_result'][i][j]
    for i in range(len(result)):
        for j in range(len(result[0])):
            if len(result[i][j]) == 1:
                result[i][j].append({})
    return result

def combine_results_vof_mp2_A(processes, q, PLIC_f_avg_X, PLIC_f_avg_Y, ghost):
    sub_results = [q.get() for p in processes]
    for re in sub_results:
        if re['type'] == 0:
            PLIC_f_avg_X[:,
                         re['start_x'] + ghost:re['end_x'] + ghost,
                         re['start_y'] + ghost:re['end_y'] + ghost] = re['result']
        else:
            PLIC_f_avg_Y[:,
                         re['start_x'] + ghost:re['end_x'] + ghost,
                         re['start_y'] + ghost:re['end_y'] + ghost] = re['result']
    return PLIC_f_avg_X, PLIC_f_avg_Y

def combine_results_vof_mp2_C(processes, q, PLIC_f, ghost):
    sub_results = [q.get() for p in processes]
    for re in sub_results:
        PLIC_f[:,
               re['start_x'] + ghost:re['end_x'] + ghost,
               re['start_y'] + ghost:re['end_y'] + ghost] = re['result']
    return PLIC_f

#################################################   DDR    #############################################################

def combine_results_ddr_flux(q, ret_dict, k_expect):
    k = 0
    while k < k_expect:
        try:
            re = q.get(timeout=1)
            flux = ret_dict['flux']
            # print(np.shape(flux))
            flux[:,
                 :,
                 re['start_x']:re['end_x'],
                 re['start_y']:re['end_y']] += np.array(re['result'])
            ret_dict['flux'] = flux
            k += 1
            # print('current k is: ', k)
        except mp.queues.Empty:
            pass

def create_processes_ddr_flux(func, combine_func, info, q, ret_dict):
    processes = []
    x_parts = info['x_parts']
    y_parts = info['y_parts']
    k_expect = int((len(x_parts) - 1) * (len(y_parts) - 1))
    for i in range(len(x_parts) - 1):
        for j in range(len(y_parts) - 1):
            start_x = x_parts[i]
            start_y = y_parts[j]
            end_x = x_parts[i + 1]
            end_y = y_parts[j + 1]
            processes.append(Process(target=func, args=(info, q, start_x, end_x, start_y, end_y)))
    processes.append(Process(target=combine_func, args=(q, ret_dict, k_expect)))
    return processes

def start_and_join_processes_ddr_flux(processes, ret_dict):
    for p in processes:
        p.start()
    for p in processes:
        p.join()
    flux = ret_dict['flux']
    return flux

############################################   Particle    #############################################################
def create_processes_particle_flux(func, combine_func, info, q, ret_dict):
    processes = []
    x_parts = info['x_parts']
    y_parts = info['y_parts']
    k_expect = int((len(x_parts) - 1) * (len(y_parts) - 1))
    for i in range(len(x_parts) - 1):
        for j in range(len(y_parts) - 1):
            start_x = x_parts[i]
            start_y = y_parts[j]
            end_x = x_parts[i + 1]
            end_y = y_parts[j + 1]
            processes.append(Process(target=func, args=(info, q, start_x, end_x, start_y, end_y)))
    processes.append(Process(target=combine_func, args=(q, ret_dict, k_expect)))
    return processes

def combine_results_particle_flux(q, ret_dict, k_expect):
    k = 0
    while k < k_expect:
        try:
            re = q.get(timeout=1)
            flux = ret_dict['flux']
            # print(np.shape(flux))
            flux[:,
                 :,
                 re['start_x']:re['end_x'],
                 re['start_y']:re['end_y']] += re['result']
            ret_dict['flux'] = flux
            k += 1
            # print('current k is: ', k)
        except mp.queues.Empty:
            pass

def start_and_join_processes_particle_flux(processes, ret_dict):
    for p in processes:
        p.start()
    for p in processes:
        p.join()
    flux = ret_dict['flux']
    return flux

########################################### FIELD INITIALIZATION #######################################################
def create_processes_circle(func, combine_func, info, q, ret_dict):
    processes = []
    x_parts = info['x_parts']
    y_parts = info['y_parts']
    k_expect = int((len(x_parts) - 1) * (len(y_parts) - 1))
    for i in range(len(x_parts) - 1):
        for j in range(len(y_parts) - 1):
            start_x = x_parts[i]
            start_y = y_parts[j]
            end_x = x_parts[i + 1]
            end_y = y_parts[j + 1]
            processes.append(Process(target=func, args=(info, q, start_x, end_x, start_y, end_y)))
    processes.append(Process(target=combine_func, args=(q, ret_dict, k_expect)))
    return processes

def combine_results_circle(q, ret_dict, k_expect):
    k = 0
    while k < k_expect:
        try:
            re = q.get(timeout=1)
            f = ret_dict['f']
            # print(np.shape(flux))
            f[:                        ,
              re['start_x']:re['end_x'],
              re['start_y']:re['end_y']] = re['result']
            ret_dict['f'] = f
            k += 1
            # print('current k is: ', k)
        except mp.queues.Empty:
            pass

def start_and_join_processes_circle(processes, ret_dict):
    for p in processes:
        p.start()
    for p in processes:
        p.join()
    f = ret_dict['f']
    return f

##################################################### PHI ##############################################################
def combine_results_phi(q, ret_dict, k_expect):
    k = 0
    while k < k_expect:
        try:
            re = q.get(timeout=1)
            phi = ret_dict['phi']
            # print(np.shape(flux))
            phi[re['start_x']:re['end_x'], re['start_y']:re['end_y']] = re['sub_result']
            ret_dict['phi'] = phi
            k += 1
            # print('current k is: ', k)
        except mp.queues.Empty:
            pass

def start_and_join_processes_phi(processes, ret_dict):
    for p in processes:
        p.start()
    for p in processes:
        p.join()
    phi = ret_dict['phi']
    return phi

##################################################### U ################################################################
def create_processes_u(func, combine_func, info, q, ret_dict):
    processes = []
    x_parts = info['x_parts']
    y_parts = info['y_parts']
    u_stencil = info['u_stencil']
    k_expect = int((len(x_parts) - 1) * (len(y_parts) - 1))
    for i in range(len(x_parts) - 1):
        for j in range(len(y_parts) - 1):
            start_x = x_parts[i]
            start_y = y_parts[j]
            end_x = x_parts[i + 1]
            end_y = y_parts[j + 1]
            processes.append(Process(target=func, args=(info, q, start_x, end_x, start_y, end_y)))
    processes.append(Process(target=combine_func, args=(q, ret_dict, k_expect, u_stencil)))
    return processes

def combine_results_u(q, ret_dict, k_expect, u_stencil):
    k = 0
    while k < k_expect:
        try:
            re = q.get(timeout=1)
            u = ret_dict['u']
            # print(np.shape(flux))
            u[:,
              re['start_x'] + u_stencil:re['end_x'] + u_stencil,
              re['start_y'] + u_stencil:re['end_y'] + u_stencil] = re['sub_result']
            ret_dict['u'] = u
            k += 1
            # print('current k is: ', k)
        except mp.queues.Empty:
            pass

def start_and_join_processes_u(processes, ret_dict):
    for p in processes:
        p.start()
    for p in processes:
        p.join()
    u = ret_dict['u']
    return u

################################################### VCLP ##############################################################
def create_processes_vclp_flux(func, combine_func, info, q, ret_dict):
    processes = []
    x_parts = info['x_parts']
    y_parts = info['y_parts']
    k_expect = int((len(x_parts) - 1) * (len(y_parts) - 1))
    for i in range(len(x_parts) - 1):
        for j in range(len(y_parts) - 1):
            start_x = x_parts[i]
            start_y = y_parts[j]
            end_x = x_parts[i + 1]
            end_y = y_parts[j + 1]
            processes.append(Process(target=func, args=(info, q, start_x, end_x, start_y, end_y)))
    processes.append(Process(target=combine_func, args=(q, ret_dict, k_expect)))
    return processes

def combine_results_vclp_flux(q, ret_dict, k_expect):
    k = 0
    while k < k_expect:
        try:
            re = q.get(timeout=1)
            flux = ret_dict['flux']
            # print(np.shape(flux))
            flux[:,
                 :,
                 re['start_x']:re['end_x'],
                 re['start_y']:re['end_y']] += re['result']
            ret_dict['flux'] = flux
            k += 1
            # print('current k is: ', k)
        except mp.queues.Empty:
            pass

def start_and_join_processes_vclp_flux(processes, ret_dict):
    for p in processes:
        p.start()
    for p in processes:
        p.join()
    flux = ret_dict['flux']
    return flux

################################################## JCP REBUTTAL########################################################
def create_processes_acsde(func, combine_func, info, q, ret_dict):
    processes = []
    x_parts = info['x_parts']
    y_parts = info['y_parts']
    k_expect = int((len(x_parts) - 1) * (len(y_parts) - 1))
    for i in range(len(x_parts) - 1):
        for j in range(len(y_parts) - 1):
            start_x = x_parts[i]
            start_y = y_parts[j]
            end_x = x_parts[i + 1]
            end_y = y_parts[j + 1]
            processes.append(Process(target=func, args=(info, q, start_x, end_x, start_y, end_y)))
    processes.append(Process(target=combine_func, args=(q, ret_dict, k_expect)))
    return processes

def start_and_join_p_acsde(processes, ret_dict):
    for p in processes:
        p.start()
    for p in processes:
        p.join()
    DP = ret_dict['DP']
    Choi = ret_dict['Choi']
    Grad = ret_dict['Grad']
    count = ret_dict['count']
    return DP, Choi, Grad, count

def start_and_join_p_acsde_convergence(processes, ret_dict):
    for p in processes:
        p.start()
    for p in processes:
        p.join()
    DP = ret_dict['DP']
    count = ret_dict['count']
    junction = ret_dict['DP_junction']
    return DP, junction, count

def combine_results_acsde(q, ret_dict, k_expect):
    k = 0
    while k < k_expect:
        try:
            re = q.get(timeout=1)
            DP = ret_dict['DP']
            DP += re['DP']
            ret_dict['DP'] = DP
            Choi = ret_dict['Choi']
            Choi += re['Choi']
            ret_dict['Choi'] = Choi
            Grad = ret_dict['Grad']
            Grad += re['Grad']
            ret_dict['Grad'] = Grad
            count = ret_dict['count']
            count += re['count']
            ret_dict['count'] = count
            k += 1
            # print('current k is: ', k)
        except mp.queues.Empty:
            pass

def combine_results_acsde_convergence(q, ret_dict, k_expect):
    k = 0
    while k < k_expect:
        try:
            re = q.get(timeout=1)
            DP = ret_dict['DP']
            DP += re['DP']
            ret_dict['DP'] = DP
            count = ret_dict['count']
            count += re['count']
            ret_dict['count'] = count
            junction = ret_dict['DP_junction']
            junction = re['junction']
            ret_dict['DP_junction'] = junction
            k += 1
            # print('current k is: ', k)
        except mp.queues.Empty:
            pass
